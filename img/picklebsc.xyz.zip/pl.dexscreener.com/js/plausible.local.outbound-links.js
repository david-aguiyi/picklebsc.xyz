! function() {
    "use strict";
    var o = window.location,
        r = window.document,
        l = r.currentScript,
        p = l.getAttribute("data-api") || new URL(l.src).origin + "/api/event";

    function t(t, e) {
        try {
            if ("true" === window.localStorage.plausible_ignore) return a = e, (n = "localStorage flag") && console.warn("Ignoring Event: " + n), void(a && a.callback && a.callback())
        } catch (t) {}
        var a, n = {},
            i = (n.n = t, n.u = o.href, n.d = l.getAttribute("data-domain"), n.r = r.referrer || null, e && e.meta && (n.m = JSON.stringify(e.meta)), e && e.props && (n.p = e.props), new XMLHttpRequest);
        i.open("POST", p, !0), i.setRequestHeader("Content-Type", "text/plain"), i.send(JSON.stringify(n)), i.onreadystatechange = function() {
            4 === i.readyState && e && e.callback && e.callback()
        }
    }
    var e = window.plausible && window.plausible.q || [];
    window.plausible = t;
    for (var a, n = 0; n < e.length; n++) t.apply(this, e[n]);

    function i() {
        a !== o.pathname && (a = o.pathname, t("pageview"))
    }
    var s, c = window.history;
    c.pushState && (s = c.pushState, c.pushState = function() {
        s.apply(this, arguments), i()
    }, window.addEventListener("popstate", i)), "prerender" === r.visibilityState ? r.addEventListener("visibilitychange", function() {
        a || "visible" !== r.visibilityState || i()
    }) : i();
    var u = 1;

    function d(t) {
        var e, a, n, i;

        function r() {
            n || (n = !0, window.location = a.href)
        }
        "auxclick" === t.type && t.button !== u || ((e = function(t) {
            for (; t && (void 0 === t.tagName || !(e = t) || !e.tagName || "a" !== e.tagName.toLowerCase() || !t.href);) t = t.parentNode;
            var e;
            return t
        }(t.target)) && e.href && e.href.split("?")[0], (i = e) && i.href && i.host && i.host !== o.host && (i = t, t = {
            name: "Outbound Link: Click",
            props: {
                url: (a = e).href
            }
        }, n = !1, ! function(t, e) {
            if (!t.defaultPrevented) return e = !e.target || e.target.match(/^_(self|parent|top)$/i), t = !(t.ctrlKey || t.metaKey || t.shiftKey) && "click" === t.type, e && t
        }(i, a) ? plausible(t.name, {
            props: t.props
        }) : (plausible(t.name, {
            props: t.props,
            callback: r
        }), setTimeout(r, 5e3), i.preventDefault())))
    }
    r.addEventListener("click", d), r.addEventListener("auxclick", d)
}();