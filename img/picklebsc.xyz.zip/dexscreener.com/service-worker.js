self.addEventListener("appinstalled", () => {});

self.addEventListener('fetch', () => {});