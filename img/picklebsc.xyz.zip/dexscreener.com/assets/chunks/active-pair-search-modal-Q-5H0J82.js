import {
    b8 as s,
    b9 as i,
    ba as n,
    x as h,
    y as r,
    bb as l
} from "../entries/pages_catch-all.K13KjGu-.js";
import {
    C as u
} from "./controlled-pair-search-modal-UBUjDTdW.js";
import "./preload-helper-Jimfoxkq.js";
import "./dex-search.service-VOfr-JK0.js";
import "./display-a-ads-ad-1eoQH_VD.js";
import "./span-2n6MBXt2.js";
import "./catchError-zPFqauN4.js";
import "./ads-provider-KuUDbfp5.js";
import "./embed-feature-disabled-modal-4NIwn0pw.js";
import "./logo-RhqyaPCw.js";
import "./chunk-ZPFGWTBB-n950qSiC.js";
const m = () => {
        const o = s(),
            e = i(),
            a = n(),
            c = h.useCallback(t => {
                e(t)
            }, [e]);
        return {
            close: o,
            activeSearch: a,
            onChange: c
        }
    },
    f = () => {
        var t;
        const {
            close: o,
            activeSearch: e,
            onChange: a
        } = m();
        if (!e) return null;
        const c = ((t = e.filters) == null ? void 0 : t.moonshot) === !0 ? `Moonshot - Search${e.query===""?"":` "${e.query}"`}` : `DEX Screener - Search${e.query===""?"":` "${e.query}"`}`;
        return r.jsxs(r.Fragment, {
            children: [r.jsx(l, {
                children: r.jsx("title", {
                    children: c
                })
            }), r.jsx(u, {
                onClose: o,
                searchValue: e,
                onSearchValueChange: a
            })]
        })
    };
export {
    f as ActivePairSearchModal
};