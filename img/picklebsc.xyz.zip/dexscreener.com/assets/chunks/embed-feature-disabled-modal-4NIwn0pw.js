import {
    a1 as x,
    x as c,
    y as a,
    a3 as t,
    bD as m,
    b7 as d,
    ar as _,
    as as M,
    at as S,
    au as v,
    ax as C,
    O as E,
    a9 as p,
    bF as I,
    aw as N,
    Z as B,
    aR as D,
    bG as F
} from "../entries/pages_catch-all.K13KjGu-.js";
import {
    S as z
} from "./span-2n6MBXt2.js";
var G = x(function(s, n) {
    const {
        spacing: r = "0.5rem",
        spacingX: l,
        spacingY: u,
        children: o,
        justify: f,
        direction: g,
        align: b,
        className: j,
        shouldWrapChildren: i,
        ...y
    } = s, w = c.useMemo(() => i ? c.Children.map(o, (W, k) => a.jsx(h, {
        children: W
    }, k)) : o, [o, i]);
    return a.jsx(t.div, {
        ref: n,
        className: m("chakra-wrap", j),
        ...y,
        children: a.jsx(t.ul, {
            className: "chakra-wrap__list",
            __css: {
                display: "flex",
                flexWrap: "wrap",
                justifyContent: f,
                alignItems: b,
                flexDirection: g,
                listStyleType: "none",
                gap: r,
                columnGap: l,
                rowGap: u,
                padding: "0"
            },
            children: w
        })
    })
});
G.displayName = "Wrap";
var h = x(function(s, n) {
    const {
        className: r,
        ...l
    } = s;
    return a.jsx(t.li, {
        ref: n,
        __css: {
            display: "flex",
            alignItems: "flex-start"
        },
        className: m("chakra-wrap__listitem", r),
        ...l
    })
});
h.displayName = "WrapItem";
const A = ({
        label: e
    }) => a.jsx(z, {
        display: "inline-block",
        position: "relative",
        top: "-1px",
        minW: "20px",
        px: "4px",
        py: "2px",
        ml: "6px",
        textAlign: "center",
        fontSize: "xs",
        fontWeight: "bold",
        fontFamily: "mono",
        borderRadius: "lg",
        bg: d("rgba(0, 0, 0, 0.2)", "rgba(255, 255, 255, 0.5)"),
        color: d("rgba(255, 255, 255, 0.9)", "rgba(0, 0, 0, 0.8)"),
        children: e
    }),
    T = ({
        onClose: e
    }) => a.jsxs(_, {
        size: "lg",
        onClose: e,
        motionPreset: "none",
        blockScrollOnMount: !1,
        isOpen: !0,
        children: [a.jsx(M, {}), a.jsxs(S, {
            children: [a.jsx(v, {}), a.jsx(C, {
                p: 5,
                children: a.jsxs(E, {
                    flexDir: "column",
                    textAlign: "center",
                    sx: {
                        "a:hover": {
                            textDecor: "none"
                        }
                    },
                    children: [a.jsx(p, {
                        as: I,
                        color: "yellow.500",
                        boxSize: "60px"
                    }), a.jsx(N, {
                        mt: 4,
                        size: "md",
                        children: "This feature is only available on dexscreener.com"
                    }), a.jsx(B, {
                        as: D,
                        onClick: () => e(),
                        target: "_blank",
                        href: typeof window > "u" ? "#" : window.location.href,
                        mt: 4,
                        colorScheme: "accent",
                        rightIcon: a.jsx(p, {
                            as: F
                        }),
                        children: "Go to DEX Screener"
                    })]
                })
            })]
        })]
    });
export {
    A as B, T as E, G as W, h as a
};