import {
    h$ as eu,
    c6 as tu,
    hc as nu,
    al as ou,
    am as ru,
    i0 as su,
    a$ as dt,
    i1 as ys,
    i2 as iu,
    an as au,
    bx as lr,
    h9 as lu,
    gA as cu,
    cu as be,
    $ as Ve,
    c4 as Qe,
    i3 as du,
    bt as Os,
    i4 as uu,
    da as ts,
    db as Wt,
    d9 as on,
    i5 as hu,
    dO as fu,
    gy as gu,
    d1 as Ye,
    i6 as mu,
    a5 as mt,
    fg as cr,
    i7 as pu,
    bo as Z,
    dG as pt,
    fL as Bn,
    x as f,
    gL as js,
    i8 as xu,
    i9 as bu,
    hi as ta,
    ia as vu,
    bg as dn,
    ib as Ol,
    a1 as at,
    y as n,
    a3 as qe,
    bD as lt,
    bI as Ul,
    cL as pn,
    cK as ot,
    ic as Co,
    a9 as L,
    fm as yu,
    fn as Us,
    fo as na,
    fq as _o,
    bh as Vs,
    bi as Xs,
    id as ju,
    ie as Su,
    ig as wu,
    ih as Cu,
    ii as ku,
    ij as Tu,
    ik as Vl,
    il as ns,
    ft as Iu,
    im as Au,
    cN as Eu,
    cM as ko,
    io as Pu,
    bj as Ru,
    b4 as To,
    ip as zu,
    b2 as Mu,
    b7 as ee,
    ab as Io,
    J as I,
    T as q,
    iq as Bu,
    bm as Fu,
    ir as Wu,
    dx as Du,
    br as Lu,
    ao as pe,
    z as ho,
    Z as ue,
    aR as we,
    U as K,
    az as T,
    bU as Ze,
    P as Qt,
    A as xe,
    fx as qs,
    ak as dr,
    bE as Xl,
    O as Ae,
    bQ as ql,
    cR as Gs,
    cY as ur,
    bn as kn,
    bT as Gl,
    ah as Nu,
    a6 as Tr,
    a7 as Xn,
    a8 as qn,
    fW as Hu,
    ac as Gn,
    dg as Hn,
    af as Je,
    ag as oa,
    f6 as er,
    ad as _u,
    ae as tt,
    bX as Ir,
    cQ as Ou,
    b6 as Ks,
    gf as Dt,
    cZ as hr,
    d6 as Uu,
    bP as Kl,
    bR as Vu,
    bS as Ql,
    dc as fr,
    is as $l,
    ar as Qs,
    as as $s,
    at as Ys,
    au as Zs,
    av as Yl,
    it as Js,
    aw as Lt,
    ey as Zl,
    ax as ei,
    V as he,
    bL as Jl,
    dl as ti,
    aS as Ao,
    iu as ec,
    iv as tc,
    eg as Yt,
    aV as gr,
    iw as Xu,
    eI as nc,
    eD as _n,
    aG as De,
    c3 as mr,
    ct as fo,
    dP as Ss,
    c7 as an,
    g6 as tr,
    fC as ra,
    eo as sa,
    dT as ws,
    cx as Nt,
    ix as ni,
    gi as oi,
    d2 as oc,
    G as Cs,
    c8 as ri,
    fK as vn,
    iy as Mn,
    iz as gn,
    gs as ia,
    iA as qu,
    ca as aa,
    iB as Sn,
    ai as Kn,
    iC as $t,
    iD as Tn,
    iE as rc,
    iF as Gu,
    iG as ks,
    bG as yt,
    cy as St,
    g0 as Ct,
    dw as la,
    dt as Gt,
    c$ as xn,
    iH as ln,
    iI as sc,
    dW as ic,
    bK as Ar,
    Q as Qn,
    cl as ac,
    cm as lc,
    ch as Er,
    bM as si,
    cV as Dn,
    H as nr,
    aP as ca,
    cp as Ku,
    fb as Qu,
    bZ as $u,
    iJ as Yu,
    aY as ii,
    I as Zu,
    iK as cc,
    fe as dc,
    iL as uc,
    iM as hc,
    iN as Ju,
    cc as Cn,
    M as Pr,
    iO as In,
    dJ as Eo,
    iP as It,
    cf as pr,
    iQ as Po,
    bF as cn,
    iR as xr,
    iS as fc,
    iT as br,
    aX as Rr,
    d0 as eh,
    b9 as th,
    fZ as gc,
    de as nh,
    f3 as or,
    aD as oh,
    cv as ai,
    iU as rh,
    g4 as sh,
    f_ as ih,
    gn as ah,
    fH as go,
    go as lh,
    cW as mo,
    cT as rr,
    iV as ch,
    iW as dh,
    e6 as mc,
    fG as li,
    iX as uh,
    gb as pc,
    e5 as bn,
    iY as hh,
    iZ as fh,
    i_ as et,
    fI as Jn,
    fJ as eo,
    dS as gh,
    fR as mh,
    fN as ph,
    fO as xh,
    fP as bh,
    fQ as vh,
    fS as yh,
    b5 as jh,
    dZ as Fn,
    i$ as Ts,
    cX as da,
    j0 as mn,
    j1 as po,
    j2 as Sh,
    j3 as wh,
    ck as Oo,
    j4 as Ch,
    d4 as xc,
    e9 as kh,
    hY as ci,
    j5 as Th,
    j6 as qt,
    dm as Ih,
    ce as di,
    gt as yn,
    g9 as Ah,
    j7 as Eh,
    j8 as Ph,
    cP as so,
    ef as Rh,
    aN as bc,
    gj as zh,
    dH as Mh,
    df as Bh,
    j9 as Fh,
    ja as ua,
    hg as ha,
    bW as Wh,
    jb as Dh,
    jc as Lh,
    jd as Nh,
    gD as fa,
    dX as Hh,
    je as _h,
    aU as ui,
    bb as Oh,
    e4 as Uh,
    e1 as ga,
    e0 as Vh,
    jf as os,
    dC as ma,
    d$ as Xh,
    jg as qh,
    cb as vc,
    aT as M,
    jh as Gh,
    dD as Ht,
    ji as pa,
    d5 as yc,
    jj as Kh,
    jk as hi,
    jl as Qh,
    jm as $h,
    gT as Uo,
    jn as Yh,
    hh as Zh,
    eT as Jh,
    gJ as ef,
    jo as xa,
    ds as tf,
    jp as rs,
    jq as ba,
    gg as nf,
    jr as of ,
    js as rf,
    jt as sf,
    ju as af,
    jv as va
} from "../entries/pages_catch-all.K13KjGu-.js";
import {
    D as lf
} from "./delayed-P4PgrpHN.js";
import {
    S as k
} from "./span-2n6MBXt2.js";
import {
    c as cf,
    g as df,
    a as fi,
    n as uf,
    B as hf,
    b as jc,
    s as Sc,
    S as ff,
    f as gf,
    h as wc,
    i as mf,
    A as ya,
    W as pf,
    E as Cc
} from "./dex-search.service-VOfr-JK0.js";
import {
    u as xf,
    I as On,
    S as bf,
    i as vf,
    d as yf,
    c as vr,
    P as jf,
    b as ja
} from "./price-alerts-button-oX0St9rY.js";
import {
    c as Sf,
    S as wf,
    C as gi,
    u as kc,
    b as Cf,
    d as Is,
    e as kf,
    f as Tf,
    g as If,
    h as Af,
    A as Ef
} from "./conditional-wrap-CdExTxC-.js";
import {
    _ as zr
} from "./preload-helper-Jimfoxkq.js";
import {
    G as Pf,
    n as jt,
    A as Sa
} from "./ads-provider-KuUDbfp5.js";
import {
    c as wa
} from "./catchError-zPFqauN4.js";
import {
    b as mi,
    a as Ca,
    c as Rf
} from "./index.esm-DX-SEys8.js";
import {
    W as Ro,
    a as to
} from "./embed-feature-disabled-modal-4NIwn0pw.js";
import {
    i as Tc,
    n as ka,
    L as Ta,
    b as Ia,
    c as zf
} from "./util-nd4DUSPU.js";
import {
    D as Mr,
    T as Mf
} from "./time-ago-gWdbdBsa.js";
import {
    L as Ic
} from "./live-time-ago-bACH5JyH.js";

function Bf() {
    return eu(1)
}

function Ff() {
    for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
    return Bf()(tu(e, nu(e)))
}

function Wf() {
    return ou(function(e, t) {
        e.subscribe(ru(t, su))
    })
}

function Df(e) {
    return dt(function() {
        return e
    })
}

function Ac(e, t) {
    return t ? function(o) {
        return Ff(t.pipe(ys(1), Wf()), o.pipe(Ac(e)))
    } : iu(function(o, r) {
        return au(e(o, r)).pipe(ys(1), Df(o))
    })
}

function Lf(e, t) {
    t === void 0 && (t = lu);
    var o = lr(e, t);
    return Ac(function() {
        return o
    })
}

function Nf(e) {
    return e && e.length ? cu(e) : []
}
const Hf = Ve({
        webSocketClientFactory: du,
        logger: Os,
        reconnectionStrategy: uu
    }, ({
        webSocketClientFactory: e,
        logger: t,
        reconnectionStrategy: o
    }) => r => e.create.pipe(Qe(s => {
        const {
            serializer: i,
            url: a
        } = r, l = s({
            serializer: i,
            url: a,
            reconnectionStrategy: o,
            logger: t,
            binaryType: r.binaryType
        });
        return new fu(d => {
            const u = new gu({
                    status: l.status,
                    data: void 0
                }),
                h = l.message.subscribe({
                    next: p => u.next({
                        data: p,
                        status: l.status
                    })
                }),
                m = u.subscribe(d),
                g = l.connect();
            return () => {
                h.unsubscribe(), m.unsubscribe(), g()
            }
        })
    }))),
    _f = (e, t) => {
        const o = s => t.data ? Wt(t) : ts({
                data: s.data,
                status: t.status
            }),
            r = () => {
                switch (t.status) {
                    case "closed":
                    case "reconnecting":
                        return t.data ? ts(t) : hu(new Error("Can not reach the server!"));
                    case "connected":
                        return Wt(t);
                    default:
                        return t.data ? ts(t) : on
                }
            };
        return be({
            value: e,
            onFailure: r,
            onFailureWithData: o,
            onPending: r,
            onPendingWithData: o,
            onSuccess: o
        })
    },
    Of = Ve(() => ({
        pair: e
    }) => e.baseToken.name.toLowerCase().includes("dex screener") || e.baseToken.name.toLowerCase().includes("dexscreener") || e.baseToken.symbol.toLowerCase().includes("dex screener") || e.baseToken.symbol.toLowerCase().includes("dexscreener") ? [{
        type: "ds-token",
        status: "error"
    }] : []),
    Uf = Ve(() => ({
        pair: e,
        data: t
    }) => !(t != null && t.gp) || Ye(e) ? [] : t.gp.isHoneypot === !0 ? [{
        type: "goplus-honey-pot",
        status: "error"
    }] : []),
    pi = Ve(() => ({
        pair: e
    }) => {
        if (Ye(e)) return [];
        const t = e.pairCreatedAt ? mu(new Date, e.pairCreatedAt) : null;
        return t !== null && t < 23 ? [{
            type: "new-pair",
            status: "warning"
        }] : []
    }),
    Vf = Ve(pi, e => t => Ye(t.pair) ? [] : e(t) && t.pair.txns.h24.buys > 10 && t.pair.txns.h24.sells === 0 ? [{
        type: "honey-pot",
        status: "warning"
    }] : []),
    Xf = Ve("@dexscreener/feature-pair/low-liquidity-validator-liquidity", () => 1e3),
    qf = Ve(Xf, e => ({
        pair: t
    }) => {
        var r;
        return Ye(t) ? [] : ((r = t.liquidity) == null ? void 0 : r.usd) !== void 0 && t.liquidity.usd <= e ? [{
            type: "low-liquidity",
            status: "warning"
        }] : []
    }),
    Gf = Ve(() => ({
        pair: e,
        data: t
    }) => Ye(e) || !(t != null && t.ts) || t.ts.status !== "ready" ? [] : t.ts.isFlagged === !0 ? [{
        type: "tokensniffer-flagged",
        status: "error"
    }] : []),
    Kf = Ve(() => ({
        pair: e,
        data: t
    }) => {
        if (Ye(e) || !(t != null && t.ts) || t.ts.status !== "ready" || t.ts.score === void 0) return [];
        const o = t.ts.score;
        return o === 0 ? [{
            type: "tokensniffer-score",
            status: "error",
            data: {
                score: o
            }
        }] : []
    }),
    Qf = Ve(() => ({
        pair: e
    }) => {
        var o;
        return Ye(e) ? [] : e.dexId === "hyperliquid" ? [] : ((o = e.liquidity) == null ? void 0 : o.usd) === void 0 ? [{
            type: "unknown-liquidity",
            status: "warning"
        }] : []
    }),
    $f = e => {
        switch (e) {
            case "Discord":
                return "discord";
            case "Telegram":
                return "telegram";
            case "Twitter":
                return "twitter";
            case "Facebook":
                return "facebook"
        }
    },
    Yf = e => {
        const {
            tokenSupplies: t,
            priceUsd: o
        } = e;
        return t && t.totalSupply !== void 0 && o && t.circulatingSupply !== t.totalSupply ? new mt(t.circulatingSupply).multipliedBy(cr(o)).decimalPlaces(0).toNumber() : void 0
    },
    Ec = e => e.networkId ? new URL(`https://tokensniffer.com/token/${e.networkId}/${e.tokenAddress.toLowerCase()}`) : new URL(`https://tokensniffer.com/token/${e.tokenAddress.toLowerCase()}`),
    Aa = .25,
    Ea = .8,
    Zf = Ve(() => ({
        pair: e,
        data: t
    }) => {
        if (!(t != null && t.gp) || Ye(e)) return [];
        const o = t.gp.buyTax ? cr(t.gp.buyTax) : void 0,
            r = t.gp.sellTax ? cr(t.gp.sellTax) : void 0,
            s = o !== void 0 && o >= Aa || r !== void 0 && r >= Aa,
            i = o !== void 0 && o >= Ea || r !== void 0 && r >= Ea;
        return i ? [{
            type: "scam-tax",
            status: "error",
            data: {
                buyTax: o,
                sellTax: r
            }
        }] : !i && s ? [{
            type: "high-tax",
            status: "warning",
            data: {
                buyTax: o,
                sellTax: r
            }
        }] : []
    }),
    Pa = ["moonshot", "moon shot"],
    Jf = Ve(() => ({
        pair: e
    }) => Pa.includes(e.baseToken.name.toLowerCase()) || Pa.includes(e.baseToken.symbol.toLowerCase()) ? [{
        type: "moonshot-token",
        status: "error"
    }] : []),
    eg = Ve(() => ({
        pair: e,
        data: t
    }) => {
        var r;
        return Ye(e) || !(t != null && t.qi) ? [] : ((r = t.qi.tokenDynamicDetails) == null ? void 0 : r.isHoneypot) === !0 ? [{
            type: "quickintel-honey-pot",
            status: "error"
        }] : []
    }),
    tg = Ve(() => ({
        pair: e,
        data: t
    }) => {
        if (!(t != null && t.holders)) return [];
        const o = [],
            r = t.holders.holders.filter(a => a.id !== e.pairAddress).sort((a, l) => l.percentage - a.percentage),
            [s] = r;
        s && s.percentage > 30 && o.push({
            type: "significant-holder",
            status: "warning",
            data: {
                holderId: s.id,
                percentage: s.percentage
            }
        });
        const i = r.slice(0, 10).reduce((a, l) => a + l.percentage, 0);
        return i > 60 && o.push({
            type: "significant-top-10-holders",
            status: "warning",
            data: {
                percentage: i
            }
        }), o
    }),
    Ra = ["error", "warning", "info"],
    ng = Ve(pi, pu, Vf, qf, Qf, Of, Uf, Kf, Gf, Zf, eg, Jf, tg, (...e) => e),
    og = Ve(ng, e => t => {
        const o = e.flatMap(r => r(t)).filter(({
            status: r
        }) => r === "error" || r === "warning" || r === "info").sort((r, s) => Ra.indexOf(r.status) - Ra.indexOf(s.status));
        return cf(o, "type")
    }),
    rn = Z.enum(["poop", "fire", "rocket", "triangular_flag_on_post"]),
    rg = Ve(() => ({
        calculateCost: e => {
            try {
                const {
                    amount: t,
                    buyType: o,
                    direction: r,
                    curvePosition: s,
                    curve: i
                } = e;
                if (r === "buy" && o === "quote") return i.getTokensNumberFromCollateral({
                    curvePosition: pt(s),
                    direction: r,
                    collateralAmount: Bn(t, i.getConfig().collateralDecimalsNr)
                });
                if (r === "sell") {
                    const a = Bn(t, i.getConfig().tokenDecimalsNr),
                        l = pt(s).minus(a);
                    return i.getCollateralPriceForTokens({
                        curvePosition: l.lt(0) ? pt(0) : l,
                        tokenAmount: a
                    })
                }
                return i.getCollateralPriceForTokens({
                    curvePosition: pt(s),
                    tokenAmount: Bn(t, i.getConfig().tokenDecimalsNr)
                })
            } catch {
                return
            }
        },
        getTokensNumberFromCollateral: e => {
            try {
                const {
                    amount: t,
                    curve: o,
                    curvePosition: r,
                    direction: s
                } = e;
                return o.getTokensNumberFromCollateral({
                    curvePosition: pt(r),
                    direction: s,
                    collateralAmount: Bn(t, o.getConfig().collateralDecimalsNr)
                })
            } catch {
                return
            }
        }
    })),
    sg = f.memo,
    sr = e => {
        const t = f.useMemo(() => new js(e), []);
        return f.useEffect(() => {
            t.next(e)
        }, [e, t]), t
    },
    ig = () => {
        const e = f.useRef(!0);
        return e.current ? (e.current = !1, !0) : e.current
    },
    ag = (e, t) => {
        const o = ig();
        f.useEffect(() => {
            o || e()
        }, t)
    },
    lg = e => {
        const t = f.useRef(e);
        return f.useMemo(() => t === e ? e : (t.current = bu(t.current, e), t.current), [e])
    },
    hv = e => {
        const t = f.useRef(e);
        return f.useMemo(() => t === e ? e : (t.current = xu(t.current, e), t.current), [e])
    };

function cg() {
    const e = ta(() => ({
            current: null,
            animations: []
        })),
        t = ta(() => Sf(e));
    return vu(() => {
        e.animations.forEach(o => o.stop())
    }), [e, t]
}
var [dg, Br] = dn({
    name: "AccordionStylesContext",
    hookName: "useAccordionStyles",
    providerName: "<Accordion />"
}), [ug, xi] = dn({
    name: "AccordionItemContext",
    hookName: "useAccordionItemContext",
    providerName: "<AccordionItem />"
}), [hg, fv, fg, gg] = Ol(), As = at(function(t, o) {
    const {
        getButtonProps: r
    } = xi(), s = r(t, o), a = {
        display: "flex",
        alignItems: "center",
        width: "100%",
        outline: 0,
        ...Br().button
    };
    return n.jsx(qe.button, { ...s,
        className: lt("chakra-accordion__button", t.className),
        __css: a
    })
});
As.displayName = "AccordionButton";

function mg(e) {
    const {
        onChange: t,
        defaultIndex: o,
        index: r,
        allowMultiple: s,
        allowToggle: i,
        ...a
    } = e;
    bg(e), vg(e);
    const l = fg(),
        [c, d] = f.useState(-1);
    f.useEffect(() => () => {
        d(-1)
    }, []);
    const [u, h] = Ul({
        value: r,
        defaultValue() {
            return s ? o ? ? [] : o ? ? -1
        },
        onChange: t
    });
    return {
        index: u,
        setIndex: h,
        htmlProps: a,
        getAccordionItemProps: g => {
            let p = !1;
            return g !== null && (p = Array.isArray(u) ? u.includes(g) : u === g), {
                isOpen: p,
                onChange: j => {
                    if (g !== null)
                        if (s && Array.isArray(u)) {
                            const y = j ? u.concat(g) : u.filter(S => S !== g);
                            h(y)
                        } else j ? h(g) : i && h(-1)
                }
            }
        },
        focusedIndex: c,
        setFocusedIndex: d,
        descendants: l
    }
}
var [pg, bi] = dn({
    name: "AccordionContext",
    hookName: "useAccordionContext",
    providerName: "Accordion"
});

function xg(e) {
    const {
        isDisabled: t,
        isFocusable: o,
        id: r,
        ...s
    } = e, {
        getAccordionItemProps: i,
        setFocusedIndex: a
    } = bi(), l = f.useRef(null), c = f.useId(), d = r ? ? c, u = `accordion-button-${d}`, h = `accordion-panel-${d}`;
    yg(e);
    const {
        register: m,
        index: g,
        descendants: p
    } = gg({
        disabled: t && !o
    }), {
        isOpen: b,
        onChange: j
    } = i(g === -1 ? null : g);
    jg({
        isOpen: b,
        isDisabled: t
    });
    const y = () => {
            j == null || j(!0)
        },
        S = () => {
            j == null || j(!1)
        },
        w = f.useCallback(() => {
            j == null || j(!b), a(g)
        }, [g, a, b, j]),
        v = f.useCallback(R => {
            const A = {
                ArrowDown: () => {
                    const P = p.nextEnabled(g);
                    P == null || P.node.focus()
                },
                ArrowUp: () => {
                    const P = p.prevEnabled(g);
                    P == null || P.node.focus()
                },
                Home: () => {
                    const P = p.firstEnabled();
                    P == null || P.node.focus()
                },
                End: () => {
                    const P = p.lastEnabled();
                    P == null || P.node.focus()
                }
            }[R.key];
            A && (R.preventDefault(), A(R))
        }, [p, g]),
        x = f.useCallback(() => {
            a(g)
        }, [a, g]),
        C = f.useCallback(function(B = {}, A = null) {
            return { ...B,
                type: "button",
                ref: pn(m, l, A),
                id: u,
                disabled: !!t,
                "aria-expanded": !!b,
                "aria-controls": h,
                onClick: ot(B.onClick, w),
                onFocus: ot(B.onFocus, x),
                onKeyDown: ot(B.onKeyDown, v)
            }
        }, [u, t, b, w, x, v, h, m]),
        E = f.useCallback(function(B = {}, A = null) {
            return { ...B,
                ref: A,
                role: "region",
                id: h,
                "aria-labelledby": u,
                hidden: !b
            }
        }, [u, b, h]);
    return {
        isOpen: b,
        isDisabled: t,
        isFocusable: o,
        onOpen: y,
        onClose: S,
        getButtonProps: C,
        getPanelProps: E,
        htmlProps: s
    }
}

function bg(e) {
    const t = e.index || e.defaultIndex,
        o = t != null && !Array.isArray(t) && e.allowMultiple;
    Co({
        condition: !!o,
        message: `If 'allowMultiple' is passed, then 'index' or 'defaultIndex' must be an array. You passed: ${typeof t},`
    })
}

function vg(e) {
    Co({
        condition: !!(e.allowMultiple && e.allowToggle),
        message: "If 'allowMultiple' is passed, 'allowToggle' will be ignored. Either remove 'allowToggle' or 'allowMultiple' depending on whether you want multiple accordions visible or not"
    })
}

function yg(e) {
    Co({
        condition: !!(e.isFocusable && !e.isDisabled),
        message: `Using only 'isFocusable', this prop is reserved for situations where you pass 'isDisabled' but you still want the element to receive focus (A11y). Either remove it or pass 'isDisabled' as well.
    `
    })
}

function jg(e) {
    Co({
        condition: e.isOpen && !!e.isDisabled,
        message: "Cannot open a disabled accordion item"
    })
}

function Es(e) {
    const {
        isOpen: t,
        isDisabled: o
    } = xi(), {
        reduceMotion: r
    } = bi(), s = lt("chakra-accordion__icon", e.className), i = Br(), a = {
        opacity: o ? .4 : 1,
        transform: t ? "rotate(-180deg)" : void 0,
        transition: r ? void 0 : "transform 0.2s",
        transformOrigin: "center",
        ...i.icon
    };
    return n.jsx(L, {
        viewBox: "0 0 24 24",
        "aria-hidden": !0,
        className: s,
        __css: a,
        ...e,
        children: n.jsx("path", {
            fill: "currentColor",
            d: "M16.59 8.59L12 13.17 7.41 8.59 6 10l6 6 6-6z"
        })
    })
}
Es.displayName = "AccordionIcon";
var Ps = at(function(t, o) {
    const {
        children: r,
        className: s
    } = t, {
        htmlProps: i,
        ...a
    } = xg(t), c = { ...Br().container,
        overflowAnchor: "none"
    }, d = f.useMemo(() => a, [a]);
    return n.jsx(ug, {
        value: d,
        children: n.jsx(qe.div, {
            ref: o,
            ...i,
            className: lt("chakra-accordion__item", s),
            __css: c,
            children: typeof r == "function" ? r({
                isExpanded: !!a.isOpen,
                isDisabled: !!a.isDisabled
            }) : r
        })
    })
});
Ps.displayName = "AccordionItem";
var Sg = e => e != null && parseInt(e.toString(), 10) > 0,
    za = {
        exit: {
            height: {
                duration: .2,
                ease: _o.ease
            },
            opacity: {
                duration: .3,
                ease: _o.ease
            }
        },
        enter: {
            height: {
                duration: .3,
                ease: _o.ease
            },
            opacity: {
                duration: .4,
                ease: _o.ease
            }
        }
    },
    wg = {
        exit: ({
            animateOpacity: e,
            startingHeight: t,
            transition: o,
            transitionEnd: r,
            delay: s
        }) => {
            var i;
            return { ...e && {
                    opacity: Sg(t) ? 1 : 0
                },
                height: t,
                transitionEnd: r == null ? void 0 : r.exit,
                transition: (i = o == null ? void 0 : o.exit) != null ? i : na.exit(za.exit, s)
            }
        },
        enter: ({
            animateOpacity: e,
            endingHeight: t,
            transition: o,
            transitionEnd: r,
            delay: s
        }) => {
            var i;
            return { ...e && {
                    opacity: 1
                },
                height: t,
                transitionEnd: r == null ? void 0 : r.enter,
                transition: (i = o == null ? void 0 : o.enter) != null ? i : na.enter(za.enter, s)
            }
        }
    },
    Pc = f.forwardRef((e, t) => {
        const { in: o, unmountOnExit: r, animateOpacity: s = !0, startingHeight: i = 0, endingHeight: a = "auto", style: l, className: c, transition: d, transitionEnd: u, ...h
        } = e, [m, g] = f.useState(!1);
        f.useEffect(() => {
            const S = setTimeout(() => {
                g(!0)
            });
            return () => clearTimeout(S)
        }, []), Co({
            condition: Number(i) > 0 && !!r,
            message: "startingHeight and unmountOnExit are mutually exclusive. You can't use them together"
        });
        const p = parseFloat(i.toString()) > 0,
            b = {
                startingHeight: i,
                endingHeight: a,
                animateOpacity: s,
                transition: m ? d : {
                    enter: {
                        duration: 0
                    }
                },
                transitionEnd: {
                    enter: u == null ? void 0 : u.enter,
                    exit: r ? u == null ? void 0 : u.exit : { ...u == null ? void 0 : u.exit,
                        display: p ? "block" : "none"
                    }
                }
            },
            j = r ? o : !0,
            y = o || r ? "enter" : "exit";
        return n.jsx(yu, {
            initial: !1,
            custom: b,
            children: j && n.jsx(Us.div, {
                ref: t,
                ...h,
                className: lt("chakra-collapse", c),
                style: {
                    overflow: "hidden",
                    display: "block",
                    ...l
                },
                custom: b,
                variants: wg,
                initial: r ? "exit" : !1,
                animate: y,
                exit: "exit"
            })
        })
    });
Pc.displayName = "Collapse";
var Rs = at(function(t, o) {
    const {
        className: r,
        motionProps: s,
        ...i
    } = t, {
        reduceMotion: a
    } = bi(), {
        getPanelProps: l,
        isOpen: c
    } = xi(), d = l(i, o), u = lt("chakra-accordion__panel", r), h = Br();
    a || delete d.hidden;
    const m = n.jsx(qe.div, { ...d,
        __css: h.panel,
        className: u
    });
    return a ? m : n.jsx(Pc, { in: c,
        ...s,
        children: m
    })
});
Rs.displayName = "AccordionPanel";
var Rc = at(function({
    children: t,
    reduceMotion: o,
    ...r
}, s) {
    const i = Vs("Accordion", r),
        a = Xs(r),
        {
            htmlProps: l,
            descendants: c,
            ...d
        } = mg(a),
        u = f.useMemo(() => ({ ...d,
            reduceMotion: !!o
        }), [d, o]);
    return n.jsx(hg, {
        value: c,
        children: n.jsx(pg, {
            value: u,
            children: n.jsx(dg, {
                value: i,
                children: n.jsx(qe.div, {
                    ref: s,
                    ...l,
                    className: lt("chakra-accordion", r.className),
                    __css: i.root,
                    children: t
                })
            })
        })
    })
});
Rc.displayName = "Accordion";

function Cg(e) {
    return "current" in e
}
var zc = () => typeof window < "u";

function kg() {
    var e;
    const t = navigator.userAgentData;
    return (e = t == null ? void 0 : t.platform) != null ? e : navigator.platform
}
var Tg = e => zc() && e.test(navigator.vendor),
    Ig = e => zc() && e.test(kg()),
    Ag = () => Ig(/mac|iphone|ipad|ipod/i),
    Eg = () => Ag() && Tg(/apple/i);

function Pg(e) {
    const {
        ref: t,
        elements: o,
        enabled: r
    } = e, s = () => {
        var i, a;
        return (a = (i = t.current) == null ? void 0 : i.ownerDocument) != null ? a : document
    };
    ju(s, "pointerdown", i => {
        if (!Eg() || !r) return;
        const a = i.target,
            c = (o ? ? [t]).some(d => {
                const u = Cg(d) ? d.current : d;
                return (u == null ? void 0 : u.contains(a)) || u === a
            });
        s().activeElement !== a && c && (i.preventDefault(), a.focus())
    })
}
var Rg = qe("div", {
        baseStyle: {
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            position: "absolute",
            top: "0",
            zIndex: 2
        }
    }),
    Fr = at(function(t, o) {
        var r, s;
        const {
            placement: i = "left",
            ...a
        } = t, l = xf(), c = l.field, u = {
            [i === "left" ? "insetStart" : "insetEnd"]: "0",
            width: (r = c == null ? void 0 : c.height) != null ? r : c == null ? void 0 : c.h,
            height: (s = c == null ? void 0 : c.height) != null ? s : c == null ? void 0 : c.h,
            fontSize: c == null ? void 0 : c.fontSize,
            ...l.element
        };
        return n.jsx(Rg, {
            ref: o,
            __css: u,
            ...a
        })
    });
Fr.id = "InputElement";
Fr.displayName = "InputElement";
var vi = at(function(t, o) {
    const {
        className: r,
        ...s
    } = t, i = lt("chakra-input__left-element", r);
    return n.jsx(Fr, {
        ref: o,
        placement: "left",
        className: i,
        ...s
    })
});
vi.id = "InputLeftElement";
vi.displayName = "InputLeftElement";
var Wr = at(function(t, o) {
    const {
        className: r,
        ...s
    } = t, i = lt("chakra-input__right-element", r);
    return n.jsx(Fr, {
        ref: o,
        placement: "right",
        className: i,
        ...s
    })
});
Wr.id = "InputRightElement";
Wr.displayName = "InputRightElement";
var [zg, zo] = dn({
    name: "PopoverContext",
    errorMessage: "usePopoverContext: `context` is undefined. Seems you forgot to wrap all popover components within `<Popover />`"
}), [Mg, yi] = dn({
    name: "PopoverStylesContext",
    errorMessage: `usePopoverStyles returned is 'undefined'. Seems you forgot to wrap the components in "<Popover />" `
});

function ji(e) {
    const t = f.Children.only(e.children),
        {
            getTriggerProps: o
        } = zo();
    return f.cloneElement(t, o(t.props, t.ref))
}
ji.displayName = "PopoverTrigger";
var Pn = {
    click: "click",
    hover: "hover"
};

function Bg(e = {}) {
    const {
        closeOnBlur: t = !0,
        closeOnEsc: o = !0,
        initialFocusRef: r,
        id: s,
        returnFocusOnClose: i = !0,
        autoFocus: a = !0,
        arrowSize: l,
        arrowShadowColor: c,
        trigger: d = Pn.click,
        openDelay: u = 200,
        closeDelay: h = 200,
        isLazy: m,
        lazyBehavior: g = "unmount",
        computePositionOnMount: p,
        ...b
    } = e, {
        isOpen: j,
        onClose: y,
        onOpen: S,
        onToggle: w
    } = Su(e), v = f.useRef(null), x = f.useRef(null), C = f.useRef(null), E = f.useRef(!1), R = f.useRef(!1);
    j && (R.current = !0);
    const [B, A] = f.useState(!1), [P, D] = f.useState(!1), O = f.useId(), V = s ? ? O, [z, H, oe, re] = ["popover-trigger", "popover-content", "popover-header", "popover-body"].map(Q => `${Q}-${V}`), {
        referenceRef: ye,
        getArrowProps: fe,
        getPopperProps: je,
        getArrowInnerProps: ze,
        forceUpdate: Me
    } = wu({ ...b,
        enabled: j || !!p
    }), Fe = Cu({
        isOpen: j,
        ref: C
    });
    Pg({
        enabled: j,
        ref: x
    }), ku(C, {
        focusRef: x,
        visible: j,
        shouldFocus: i && d === Pn.click
    }), Tu(C, {
        focusRef: r,
        visible: j,
        shouldFocus: a && d === Pn.click
    });
    const Be = Vl({
            wasSelected: R.current,
            enabled: m,
            mode: g,
            isSelected: Fe.present
        }),
        W = f.useCallback((Q = {}, le = null) => {
            const te = { ...Q,
                style: { ...Q.style,
                    transformOrigin: ns.transformOrigin.varRef,
                    [ns.arrowSize.var]: l ? `${l}px` : void 0,
                    [ns.arrowShadowColor.var]: c
                },
                ref: pn(C, le),
                children: Be ? Q.children : null,
                id: H,
                tabIndex: -1,
                role: "dialog",
                onKeyDown: ot(Q.onKeyDown, N => {
                    o && N.key === "Escape" && y()
                }),
                onBlur: ot(Q.onBlur, N => {
                    const ne = Ma(N),
                        Pe = ss(C.current, ne),
                        Ke = ss(x.current, ne);
                    j && t && (!Pe && !Ke) && y()
                }),
                "aria-labelledby": B ? oe : void 0,
                "aria-describedby": P ? re : void 0
            };
            return d === Pn.hover && (te.role = "tooltip", te.onMouseEnter = ot(Q.onMouseEnter, () => {
                E.current = !0
            }), te.onMouseLeave = ot(Q.onMouseLeave, N => {
                N.nativeEvent.relatedTarget !== null && (E.current = !1, setTimeout(() => y(), h))
            })), te
        }, [Be, H, B, oe, P, re, d, o, y, j, t, h, c, l]),
        se = f.useCallback((Q = {}, le = null) => je({ ...Q,
            style: {
                visibility: j ? "visible" : "hidden",
                ...Q.style
            }
        }, le), [j, je]),
        J = f.useCallback((Q, le = null) => ({ ...Q,
            ref: pn(le, v, ye)
        }), [v, ye]),
        de = f.useRef(),
        ie = f.useRef(),
        U = f.useCallback(Q => {
            v.current == null && ye(Q)
        }, [ye]),
        F = f.useCallback((Q = {}, le = null) => {
            const te = { ...Q,
                ref: pn(x, le, U),
                id: z,
                "aria-haspopup": "dialog",
                "aria-expanded": j,
                "aria-controls": H
            };
            return d === Pn.click && (te.onClick = ot(Q.onClick, w)), d === Pn.hover && (te.onFocus = ot(Q.onFocus, () => {
                de.current === void 0 && S()
            }), te.onBlur = ot(Q.onBlur, N => {
                const ne = Ma(N),
                    Pe = !ss(C.current, ne);
                j && t && Pe && y()
            }), te.onKeyDown = ot(Q.onKeyDown, N => {
                N.key === "Escape" && y()
            }), te.onMouseEnter = ot(Q.onMouseEnter, () => {
                E.current = !0, de.current = window.setTimeout(() => S(), u)
            }), te.onMouseLeave = ot(Q.onMouseLeave, () => {
                E.current = !1, de.current && (clearTimeout(de.current), de.current = void 0), ie.current = window.setTimeout(() => {
                    E.current === !1 && y()
                }, h)
            })), te
        }, [z, j, H, d, U, w, S, t, y, u, h]);
    f.useEffect(() => () => {
        de.current && clearTimeout(de.current), ie.current && clearTimeout(ie.current)
    }, []);
    const G = f.useCallback((Q = {}, le = null) => ({ ...Q,
            id: oe,
            ref: pn(le, te => {
                A(!!te)
            })
        }), [oe]),
        ce = f.useCallback((Q = {}, le = null) => ({ ...Q,
            id: re,
            ref: pn(le, te => {
                D(!!te)
            })
        }), [re]);
    return {
        forceUpdate: Me,
        isOpen: j,
        onAnimationComplete: Fe.onComplete,
        onClose: y,
        getAnchorProps: J,
        getArrowProps: fe,
        getArrowInnerProps: ze,
        getPopoverPositionerProps: se,
        getPopoverProps: W,
        getTriggerProps: F,
        getHeaderProps: G,
        getBodyProps: ce
    }
}

function ss(e, t) {
    return e === t || (e == null ? void 0 : e.contains(t))
}

function Ma(e) {
    var t;
    const o = e.currentTarget.ownerDocument.activeElement;
    return (t = e.relatedTarget) != null ? t : o
}

function Si(e) {
    const t = Vs("Popover", e),
        {
            children: o,
            ...r
        } = Xs(e),
        s = Iu(),
        i = Bg({ ...r,
            direction: s.direction
        });
    return n.jsx(zg, {
        value: i,
        children: n.jsx(Mg, {
            value: t,
            children: Au(o, {
                isOpen: i.isOpen,
                onClose: i.onClose,
                forceUpdate: i.forceUpdate
            })
        })
    })
}
Si.displayName = "Popover";
var is = (e, t) => t ? `${e}.${t}, ${t}` : void 0;

function Mc(e) {
    var t;
    const {
        bg: o,
        bgColor: r,
        backgroundColor: s,
        shadow: i,
        boxShadow: a,
        shadowColor: l
    } = e, {
        getArrowProps: c,
        getArrowInnerProps: d
    } = zo(), u = yi(), h = (t = o ? ? r) != null ? t : s, m = i ? ? a;
    return n.jsx(qe.div, { ...c(),
        className: "chakra-popover__arrow-positioner",
        children: n.jsx(qe.div, {
            className: lt("chakra-popover__arrow", e.className),
            ...d(e),
            __css: {
                "--popper-arrow-shadow-color": is("colors", l),
                "--popper-arrow-bg": is("colors", h),
                "--popper-arrow-shadow": is("shadows", m),
                ...u.arrow
            }
        })
    })
}
Mc.displayName = "PopoverArrow";
var Bc = at(function(t, o) {
    const {
        getBodyProps: r
    } = zo(), s = yi();
    return n.jsx(qe.div, { ...r(t, o),
        className: lt("chakra-popover__body", t.className),
        __css: s.body
    })
});
Bc.displayName = "PopoverBody";

function Fg(e) {
    if (e) return {
        enter: { ...e.enter,
            visibility: "visible"
        },
        exit: { ...e.exit,
            transitionEnd: {
                visibility: "hidden"
            }
        }
    }
}
var Wg = {
        exit: {
            opacity: 0,
            scale: .95,
            transition: {
                duration: .1,
                ease: [.4, 0, 1, 1]
            }
        },
        enter: {
            scale: 1,
            opacity: 1,
            transition: {
                duration: .15,
                ease: [0, 0, .2, 1]
            }
        }
    },
    Dg = qe(Us.section),
    Fc = at(function(t, o) {
        const {
            variants: r = Wg,
            ...s
        } = t, {
            isOpen: i
        } = zo();
        return n.jsx(Dg, {
            ref: o,
            variants: Fg(r),
            initial: !1,
            animate: i ? "enter" : "exit",
            ...s
        })
    });
Fc.displayName = "PopoverTransition";
var wi = at(function(t, o) {
    const {
        rootProps: r,
        motionProps: s,
        ...i
    } = t, {
        getPopoverProps: a,
        getPopoverPositionerProps: l,
        onAnimationComplete: c
    } = zo(), d = yi(), u = {
        position: "relative",
        display: "flex",
        flexDirection: "column",
        ...d.content
    };
    return n.jsx(qe.div, { ...l(r),
        __css: d.popper,
        className: "chakra-popover__popper",
        children: n.jsx(Fc, { ...s,
            ...a(i, o),
            onAnimationComplete: Eu(c, i.onAnimationComplete),
            className: lt("chakra-popover__content", t.className),
            __css: u
        })
    })
});
wi.displayName = "PopoverContent";
var Wc = qe("div", {
    baseStyle: {
        fontSize: "0.24em",
        top: "50%",
        left: "50%",
        width: "100%",
        textAlign: "center",
        position: "absolute",
        transform: "translate(-50%, -50%)"
    }
});
Wc.displayName = "CircularProgressLabel";
var zs = e => n.jsx(qe.circle, {
    cx: 50,
    cy: 50,
    r: 42,
    fill: "transparent",
    ...e
});
zs.displayName = "Circle";

function Lg(e, t, o) {
    return (e - t) * 100 / (o - t)
}
var Ng = ko({
        "0%": {
            strokeDasharray: "1, 400",
            strokeDashoffset: "0"
        },
        "50%": {
            strokeDasharray: "400, 400",
            strokeDashoffset: "-100"
        },
        "100%": {
            strokeDasharray: "400, 400",
            strokeDashoffset: "-260"
        }
    }),
    Hg = ko({
        "0%": {
            transform: "rotate(0deg)"
        },
        "100%": {
            transform: "rotate(360deg)"
        }
    });
ko({
    "0%": {
        left: "-40%"
    },
    "100%": {
        left: "100%"
    }
});
ko({
    from: {
        backgroundPosition: "1rem 0"
    },
    to: {
        backgroundPosition: "0 0"
    }
});

function _g(e) {
    const {
        value: t = 0,
        min: o,
        max: r,
        valueText: s,
        getValueText: i,
        isIndeterminate: a,
        role: l = "progressbar"
    } = e, c = Lg(t, o, r);
    return {
        bind: {
            "data-indeterminate": a ? "" : void 0,
            "aria-valuemax": r,
            "aria-valuemin": o,
            "aria-valuenow": a ? void 0 : t,
            "aria-valuetext": (() => {
                if (t != null) return typeof i == "function" ? i(t, c) : s
            })(),
            role: l
        },
        percent: c,
        value: t
    }
}
var Dc = e => {
    const {
        size: t,
        isIndeterminate: o,
        ...r
    } = e;
    return n.jsx(qe.svg, {
        viewBox: "0 0 100 100",
        __css: {
            width: t,
            height: t,
            animation: o ? `${Hg} 2s linear infinite` : void 0
        },
        ...r
    })
};
Dc.displayName = "Shape";
var Lc = at((e, t) => {
    var o;
    const {
        size: r = "48px",
        max: s = 100,
        min: i = 0,
        valueText: a,
        getValueText: l,
        value: c,
        capIsRound: d,
        children: u,
        thickness: h = "10px",
        color: m = "#0078d4",
        trackColor: g = "#edebe9",
        isIndeterminate: p,
        ...b
    } = e, j = _g({
        min: i,
        max: s,
        value: c,
        valueText: a,
        getValueText: l,
        isIndeterminate: p
    }), y = p ? void 0 : ((o = j.percent) != null ? o : 0) * 2.64, S = y == null ? void 0 : `${y} ${264-y}`, w = p ? {
        css: {
            animation: `${Ng} 1.5s linear infinite`
        }
    } : {
        strokeDashoffset: 66,
        strokeDasharray: S,
        transitionProperty: "stroke-dasharray, stroke",
        transitionDuration: "0.6s",
        transitionTimingFunction: "ease"
    }, v = {
        display: "inline-block",
        position: "relative",
        verticalAlign: "middle",
        fontSize: r
    };
    return n.jsxs(qe.div, {
        ref: t,
        className: "chakra-progress",
        ...j.bind,
        ...b,
        __css: v,
        children: [n.jsxs(Dc, {
            size: r,
            isIndeterminate: p,
            children: [n.jsx(zs, {
                stroke: g,
                strokeWidth: h,
                className: "chakra-progress__track"
            }), n.jsx(zs, {
                stroke: m,
                strokeWidth: h,
                className: "chakra-progress__indicator",
                strokeLinecap: d ? "round" : void 0,
                opacity: j.value === 0 && !p ? 0 : void 0,
                ...w
            })]
        }), u]
    })
});
Lc.displayName = "CircularProgress";
var [Og, Ug, Vg, Xg] = Ol();

function qg(e) {
    var t;
    const {
        defaultIndex: o,
        onChange: r,
        index: s,
        isManual: i,
        isLazy: a,
        lazyBehavior: l = "unmount",
        orientation: c = "horizontal",
        direction: d = "ltr",
        ...u
    } = e, [h, m] = f.useState(o ? ? 0), [g, p] = Ul({
        defaultValue: o ? ? 0,
        value: s,
        onChange: r
    });
    f.useEffect(() => {
        s != null && m(s)
    }, [s]);
    const b = Vg(),
        j = f.useId();
    return {
        id: `tabs-${(t=e.id)!=null?t:j}`,
        selectedIndex: g,
        focusedIndex: h,
        setSelectedIndex: p,
        setFocusedIndex: m,
        isManual: i,
        isLazy: a,
        lazyBehavior: l,
        orientation: c,
        descendants: b,
        direction: d,
        htmlProps: u
    }
}
var [Gg, Dr] = dn({
    name: "TabsContext",
    errorMessage: "useTabsContext: `context` is undefined. Seems you forgot to wrap all tabs components within <Tabs />"
});

function Kg(e) {
    const {
        focusedIndex: t,
        orientation: o,
        direction: r
    } = Dr(), s = Ug(), i = f.useCallback(a => {
        const l = () => {
                var S;
                const w = s.nextEnabled(t);
                w && ((S = w.node) == null || S.focus())
            },
            c = () => {
                var S;
                const w = s.prevEnabled(t);
                w && ((S = w.node) == null || S.focus())
            },
            d = () => {
                var S;
                const w = s.firstEnabled();
                w && ((S = w.node) == null || S.focus())
            },
            u = () => {
                var S;
                const w = s.lastEnabled();
                w && ((S = w.node) == null || S.focus())
            },
            h = o === "horizontal",
            m = o === "vertical",
            g = a.key,
            p = r === "ltr" ? "ArrowLeft" : "ArrowRight",
            b = r === "ltr" ? "ArrowRight" : "ArrowLeft",
            y = {
                [p]: () => h && c(),
                [b]: () => h && l(),
                ArrowDown: () => m && l(),
                ArrowUp: () => m && c(),
                Home: d,
                End: u
            }[g];
        y && (a.preventDefault(), y(a))
    }, [s, t, o, r]);
    return { ...e,
        role: "tablist",
        "aria-orientation": o,
        onKeyDown: ot(e.onKeyDown, i)
    }
}

function Qg(e) {
    const {
        isDisabled: t = !1,
        isFocusable: o = !1,
        ...r
    } = e, {
        setSelectedIndex: s,
        isManual: i,
        id: a,
        setFocusedIndex: l,
        selectedIndex: c
    } = Dr(), {
        index: d,
        register: u
    } = Xg({
        disabled: t && !o
    }), h = d === c, m = () => {
        s(d)
    }, g = () => {
        l(d), !i && !(t && o) && s(d)
    };
    return { ...Pu({ ...r,
            ref: pn(u, e.ref),
            isDisabled: t,
            isFocusable: o,
            onClick: ot(e.onClick, m)
        }),
        id: Nc(a, d),
        role: "tab",
        tabIndex: h ? 0 : -1,
        type: "button",
        "aria-selected": h,
        "aria-controls": Hc(a, d),
        onFocus: t ? void 0 : ot(e.onFocus, g)
    }
}
var [$g, Yg] = dn({});

function Zg(e) {
    const t = Dr(),
        {
            id: o,
            selectedIndex: r
        } = t,
        i = Ru(e.children).map((a, l) => f.createElement($g, {
            key: l,
            value: {
                isSelected: l === r,
                id: Hc(o, l),
                tabId: Nc(o, l),
                selectedIndex: r
            }
        }, a));
    return { ...e,
        children: i
    }
}

function Jg(e) {
    const {
        children: t,
        ...o
    } = e, {
        isLazy: r,
        lazyBehavior: s
    } = Dr(), {
        isSelected: i,
        id: a,
        tabId: l
    } = Yg(), c = f.useRef(!1);
    i && (c.current = !0);
    const d = Vl({
        wasSelected: c.current,
        isSelected: i,
        enabled: r,
        mode: s
    });
    return {
        tabIndex: 0,
        ...o,
        children: d ? t : null,
        role: "tabpanel",
        "aria-labelledby": l,
        hidden: !i,
        id: a
    }
}

function Nc(e, t) {
    return `${e}--tab-${t}`
}

function Hc(e, t) {
    return `${e}--tabpanel-${t}`
}
var [e0, Lr] = dn({
    name: "TabsStylesContext",
    errorMessage: `useTabsStyles returned is 'undefined'. Seems you forgot to wrap the components in "<Tabs />" `
}), Ci = at(function(t, o) {
    const r = Vs("Tabs", t),
        {
            children: s,
            className: i,
            ...a
        } = Xs(t),
        {
            htmlProps: l,
            descendants: c,
            ...d
        } = qg(a),
        u = f.useMemo(() => d, [d]),
        {
            isFitted: h,
            ...m
        } = l,
        g = {
            position: "relative",
            ...r.root
        };
    return n.jsx(Og, {
        value: c,
        children: n.jsx(Gg, {
            value: u,
            children: n.jsx(e0, {
                value: r,
                children: n.jsx(qe.div, {
                    className: lt("chakra-tabs", i),
                    ref: o,
                    ...m,
                    __css: g,
                    children: s
                })
            })
        })
    })
});
Ci.displayName = "Tabs";
var ki = at(function(t, o) {
    const r = Kg({ ...t,
            ref: o
        }),
        i = {
            display: "flex",
            ...Lr().tablist
        };
    return n.jsx(qe.div, { ...r,
        className: lt("chakra-tabs__tablist", t.className),
        __css: i
    })
});
ki.displayName = "TabList";
var _c = at(function(t, o) {
    const r = Jg({ ...t,
            ref: o
        }),
        s = Lr();
    return n.jsx(qe.div, {
        outline: "0",
        ...r,
        className: lt("chakra-tabs__tab-panel", t.className),
        __css: s.tabpanel
    })
});
_c.displayName = "TabPanel";
var Oc = at(function(t, o) {
    const r = Zg(t),
        s = Lr();
    return n.jsx(qe.div, { ...r,
        width: "100%",
        ref: o,
        className: lt("chakra-tabs__tab-panels", t.className),
        __css: s.tabpanels
    })
});
Oc.displayName = "TabPanels";
var Ti = at(function(t, o) {
    const r = Lr(),
        s = Qg({ ...t,
            ref: o
        }),
        i = {
            outline: "0",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            ...r.tab
        };
    return n.jsx(qe.button, { ...s,
        className: lt("chakra-tabs__tab", t.className),
        __css: i
    })
});
Ti.displayName = "Tab";
var t0 = Tc ? f.useLayoutEffect : f.useEffect,
    n0 = function(e, t, o) {
        if (!Tc) return [t, ka, ka];
        if (!e) throw new Error("useLocalStorage key may not be falsy");
        var r = o ? o.raw ? function(u) {
                return u
            } : o.deserializer : JSON.parse,
            s = f.useRef(function(u) {
                try {
                    var h = o ? o.raw ? String : o.serializer : JSON.stringify,
                        m = localStorage.getItem(u);
                    return m !== null ? r(m) : (t && localStorage.setItem(u, h(t)), t)
                } catch {
                    return t
                }
            }),
            i = f.useState(function() {
                return s.current(e)
            }),
            a = i[0],
            l = i[1];
        f.useLayoutEffect(function() {
            return l(s.current(e))
        }, [e]);
        var c = f.useCallback(function(u) {
                try {
                    var h = typeof u == "function" ? u(a) : u;
                    if (typeof h > "u") return;
                    var m = void 0;
                    o ? o.raw ? typeof h == "string" ? m = h : m = JSON.stringify(h) : o.serializer ? m = o.serializer(h) : m = JSON.stringify(h) : m = JSON.stringify(h), localStorage.setItem(e, m), l(r(m))
                } catch {}
            }, [e, l]),
            d = f.useCallback(function() {
                try {
                    localStorage.removeItem(e), l(void 0)
                } catch {}
            }, [e, l]);
        return [a, c, d]
    };
const o0 = Ve(Mu, zu, (e, t) => ({
        setTokenValueAmount: (o, r, s) => e.ensuredCurrentUser.pipe(Qe(i => t.findByUserIdAndPairIdentity(i.id, o).pipe(ys(1), Qe(a => {
            const l = { ...(a == null ? void 0 : a.tokenValues) ? ? {}
            };
            return s === void 0 ? delete l[r] : l[r] = s, a ? t.update(a.id, {
                tokenValues: l
            }) : t.create(i.id, {
                tokenValues: l,
                pair: {
                    type: "dexPair",
                    chainId: o.chainId,
                    pairId: o.pairId
                }
            })
        })))),
        getTokenValueAmount: (o, r) => e.currentUser.pipe(Qe(s => s ? t.findByUserIdAndPairIdentity(s.id, o) : To(void 0)), dt(s => {
            var i;
            if (s) return (i = s.tokenValues) == null ? void 0 : i[r]
        }))
    })),
    r0 = e => f.createElement("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        xmlnsXlink: "http://www.w3.org/1999/xlink",
        x: "0px",
        y: "0px",
        viewBox: "0 0 128 128",
        style: {
            enableBackground: "new 0 0 128 128"
        },
        xmlSpace: "preserve",
        ...e
    }, f.createElement("g", null, f.createElement("radialGradient", {
        id: "emoji-u1f525-g1",
        cx: 68.8839,
        cy: 124.2963,
        r: 70.587,
        gradientTransform: "matrix(-1 -4.343011e-03 -7.125917e-03 1.6408 131.9857 -79.3452)",
        gradientUnits: "userSpaceOnUse"
    }, f.createElement("stop", {
        offset: .3144,
        style: {
            stopColor: "#FF9800"
        }
    }), f.createElement("stop", {
        offset: .6616,
        style: {
            stopColor: "#FF6D00"
        }
    }), f.createElement("stop", {
        offset: .9715,
        style: {
            stopColor: "#F44336"
        }
    })), f.createElement("path", {
        style: {
            fill: "url(#emoji-u1f525-g1)"
        },
        d: "M35.56,40.73c-0.57,6.08-0.97,16.84,2.62,21.42c0,0-1.69-11.82,13.46-26.65 c6.1-5.97,7.51-14.09,5.38-20.18c-1.21-3.45-3.42-6.3-5.34-8.29C50.56,5.86,51.42,3.93,53.05,4c9.86,0.44,25.84,3.18,32.63,20.22 c2.98,7.48,3.2,15.21,1.78,23.07c-0.9,5.02-4.1,16.18,3.2,17.55c5.21,0.98,7.73-3.16,8.86-6.14c0.47-1.24,2.1-1.55,2.98-0.56 c8.8,10.01,9.55,21.8,7.73,31.95c-3.52,19.62-23.39,33.9-43.13,33.9c-24.66,0-44.29-14.11-49.38-39.65 c-2.05-10.31-1.01-30.71,14.89-45.11C33.79,38.15,35.72,39.11,35.56,40.73z"
    }), f.createElement("g", null, f.createElement("radialGradient", {
        id: "emoji-u1f525-g2",
        cx: 64.9211,
        cy: 54.0621,
        r: 73.8599,
        gradientTransform: "matrix(-0.0101 0.9999 0.7525 7.603777e-03 26.1538 -11.2668)",
        gradientUnits: "userSpaceOnUse"
    }, f.createElement("stop", {
        offset: .2141,
        style: {
            stopColor: "#FFF176"
        }
    }), f.createElement("stop", {
        offset: .3275,
        style: {
            stopColor: "#FFF27D"
        }
    }), f.createElement("stop", {
        offset: .4868,
        style: {
            stopColor: "#FFF48F"
        }
    }), f.createElement("stop", {
        offset: .6722,
        style: {
            stopColor: "#FFF7AD"
        }
    }), f.createElement("stop", {
        offset: .7931,
        style: {
            stopColor: "#FFF9C4"
        }
    }), f.createElement("stop", {
        offset: .8221,
        style: {
            stopColor: "#FFF8BD",
            stopOpacity: .804
        }
    }), f.createElement("stop", {
        offset: .8627,
        style: {
            stopColor: "#FFF6AB",
            stopOpacity: .529
        }
    }), f.createElement("stop", {
        offset: .9101,
        style: {
            stopColor: "#FFF38D",
            stopOpacity: .2088
        }
    }), f.createElement("stop", {
        offset: .9409,
        style: {
            stopColor: "#FFF176",
            stopOpacity: 0
        }
    })), f.createElement("path", {
        style: {
            fill: "url(#emoji-u1f525-g2)"
        },
        d: "M76.11,77.42c-9.09-11.7-5.02-25.05-2.79-30.37c0.3-0.7-0.5-1.36-1.13-0.93 c-3.91,2.66-11.92,8.92-15.65,17.73c-5.05,11.91-4.69,17.74-1.7,24.86c1.8,4.29-0.29,5.2-1.34,5.36 c-1.02,0.16-1.96-0.52-2.71-1.23c-2.15-2.05-3.7-4.72-4.44-7.6c-0.16-0.62-0.97-0.79-1.34-0.28c-2.8,3.87-4.25,10.08-4.32,14.47 C40.47,113,51.68,124,65.24,124c17.09,0,29.54-18.9,19.72-34.7C82.11,84.7,79.43,81.69,76.11,77.42z"
    })))),
    s0 = e => f.createElement("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        xmlnsXlink: "http://www.w3.org/1999/xlink",
        x: "0px",
        y: "0px",
        viewBox: "0 0 128 128",
        style: {
            enableBackground: "new 0 0 128 128"
        },
        xmlSpace: "preserve",
        ...e
    }, f.createElement("g", null, f.createElement("path", {
        style: {
            fill: "#885742"
        },
        d: "M118.89,75.13c-1.46-3.15-3.92-5.73-7-7.33c-1.86-1.16-3.88-2.05-6-2.63 c1.53-5.6-0.64-10.06-3.69-13.39c-4.51-4.88-9.2-5.59-9.2-5.59l0,0c1.62-3.07,2.11-6.61,1.36-10c-0.77-3.69-3.08-6.86-6.36-8.72 c-3.1-1.83-6.92-2.73-10.84-3.47c-1.88-0.34-9.81-1.45-13.1-6c-2.65-3.69-2.73-10.33-3.45-12.32s-3.38-1.15-6.23,0.76 C51.05,8.7,44.15,15.83,41.49,23c-1.76,4.41-2.2,9.23-1.28,13.89c-2.14,0.35-4.23,0.97-6.21,1.85c-0.16,0-0.32,0.1-0.49,0.17 c-3,1.24-9.43,7-10,15.85c-0.21,3.13,0.19,6.26,1.17,9.24c-2.19,0.57-4.3,1.43-6.26,2.57c-2.29,0.98-4.38,2.38-6.15,4.13 c-1.95,2.41-3.37,5.2-4.15,8.2c-1.81,6.61-1.1,13.66,2,19.77c1.8,3.47,4.06,6.67,6.74,9.52c8.55,8.79,23.31,12.11,35,14 c14.19,2.34,29.05,1.52,42.33-4c19.92-8.22,25.22-21.44,26-25.17C121.92,84.77,119.8,77,118.89,75.13z"
    })), f.createElement("g", null, f.createElement("g", null, f.createElement("g", null, f.createElement("path", {
        style: {
            fill: "#35220B"
        },
        d: "M87.45,92.89c-1.57,0.8-3.17,1.52-4.78,2.16c-1.08,0.43-2.17,0.82-3.27,1.17 c-1.1,0.36-2.21,0.67-3.33,1c-2.24,0.56-4.52,0.97-6.82,1.21c-1.74,0.19-3.5,0.28-5.25,0.28c-4.62,0-9.22-0.65-13.67-1.91 l-1.46-0.44c-2.45-0.78-4.84-1.73-7.15-2.84l-1.39-0.69c1.66,6.79,6.35,12.43,12.72,15.31c3.43,1.59,7.17,2.4,10.95,2.38 c3.82,0.03,7.6-0.75,11.09-2.31c6.43-2.83,11.11-8.57,12.58-15.44L87.45,92.89z"
    }), f.createElement("path", {
        style: {
            fill: "#FFFFFF"
        },
        d: "M85.19,90c-7,1.23-14.09,1.82-21.19,1.77c-7.1,0.04-14.19-0.55-21.19-1.77 c-1.17-0.23-2.3,0.54-2.53,1.71c-0.05,0.27-0.05,0.56,0,0.83c0,0.08,0,0.16,0,0.25c7.32,3.83,15.46,5.84,23.72,5.87 c1.75,0,3.51-0.09,5.25-0.28c2.3-0.24,4.58-0.65,6.82-1.21c1.12-0.28,2.23-0.59,3.33-1s2.19-0.74,3.27-1.17 c1.62-0.67,3.21-1.39,4.78-2.16l0.22-0.12l0.06-0.27c0.17-1.19-0.66-2.29-1.86-2.46C85.65,89.96,85.42,89.96,85.19,90z"
    })), f.createElement("g", null, f.createElement("circle", {
        style: {
            fill: "#FFFFFF"
        },
        cx: 80.13,
        cy: 69.49,
        r: 12.4
    }), f.createElement("ellipse", {
        style: {
            fill: "#35220B"
        },
        cx: 80.13,
        cy: 69.49,
        rx: 5.73,
        ry: 5.82
    }), f.createElement("circle", {
        style: {
            fill: "#FFFFFF"
        },
        cx: 47.87,
        cy: 69.49,
        r: 12.4
    }), f.createElement("ellipse", {
        style: {
            fill: "#35220B"
        },
        cx: 47.87,
        cy: 69.49,
        rx: 5.73,
        ry: 5.82
    }))))),
    i0 = e => f.createElement("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        xmlnsXlink: "http://www.w3.org/1999/xlink",
        x: "0px",
        y: "0px",
        viewBox: "0 0 128 128",
        style: {
            enableBackground: "new 0 0 128 128"
        },
        xmlSpace: "preserve",
        ...e
    }, f.createElement("polygon", {
        style: {
            fill: "#CA2C31"
        },
        points: "3.77,71.73 20.11,55.63 47.93,50.7 45.18,65.26 7.57,76.82 5.14,75.77 "
    }), f.createElement("polygon", {
        style: {
            fill: "#A02422"
        },
        points: "22.94,59.76 5.2,75.88 18.25,82.24 38.06,72.13 38.06,67.36 42.11,56.44 "
    }), f.createElement("path", {
        style: {
            fill: "#A02422"
        },
        d: "M64.92,88.15l-8.57,3.72l-8.09,17.15c0,0,7.12,15.77,7.44,15.77c0.32,0,4.37,0.32,4.37,0.32 l14.4-16.1l3.64-27.5L64.92,88.15z"
    }), f.createElement("path", {
        style: {
            fill: "#CA2C31"
        },
        d: "M56.5,100.84c0,0,4.77-0.97,8.17-2.59c3.4-1.62,7.6-4.04,7.6-4.04l-1.54,13.43l-15.05,17.13 c0,0-0.59-0.73-3.09-6.17c-1.99-4.34-2.68-5.89-2.68-5.89L56.5,100.84z"
    }), f.createElement("path", {
        style: {
            fill: "#F7D74D"
        },
        d: "M31.58,80.66c0,0-5.74-0.48-12.03,7.47c-5.74,7.26-8.43,19.08-9.47,22.12s-3.53,3.66-2.7,5.05 s4.42,1.31,8.85,0.76s8.23-1.94,8.23-1.94s-0.19,0.48-0.83,1.52c-0.23,0.37-1.03,0.9-0.97,1.45c0.14,1.31,11.36,1.34,20.32-7.88 c9.68-9.95,4.98-18.11,4.98-18.11L31.58,80.66z"
    }), f.createElement("path", {
        style: {
            fill: "#FBF0B4"
        },
        d: "M33.31,85.29c0,0-6.19,0.33-11.31,8.28s-7.5,17.16-7.01,17.78c0.48,0.62,10.02-2.83,12.31-2.14 c1.57,0.48,0.76,2.07,1.18,2.49c0.35,0.35,4.49,0.94,11.19-6.32c6.71-7.26,5.12-17.46,5.12-17.46L33.31,85.29z"
    }), f.createElement("path", {
        style: {
            fill: "#858585"
        },
        d: "M36.35,74.44c0,0-3.11,2.77-4.22,4.36c-1.11,1.59-1.11,1.73-1.04,2.21 c0.07,0.48,1.22,5.75,6.01,10.37c5.88,5.67,11.13,6.43,11.89,6.43c0.76,0,5.81-5.67,5.81-5.67L36.35,74.44z"
    }), f.createElement("path", {
        style: {
            fill: "#437687"
        },
        d: "M50.1,91.24c0,0,5.04,3.31,13.49,0.47c11.55-3.88,20.02-12.56,30.51-23.52 c10.12-10.58,18.61-23.71,18.61-23.71l-5.95-19.93L50.1,91.24z"
    }), f.createElement("path", {
        style: {
            fill: "#3F545F"
        },
        d: "M67.99,80.33l1.39-4.32l3.48,0.49c0,0,2.65,1.25,4.6,2.16c1.95,0.91,4.46,1.6,4.46,1.6l-4.95,4.18 c0,0-2.7-1.02-4.67-1.88C70.08,81.59,67.99,80.33,67.99,80.33z"
    }), f.createElement("path", {
        style: {
            fill: "#8DAFBF"
        },
        d: "M84.32,16.14c0,0-9.62,5.58-23.41,18.63c-12.43,11.76-21.64,22.4-23.87,31.45 c-1.86,7.58-0.87,12.18,3.36,17.15c4.47,5.26,9.71,7.87,9.71,7.87s3.94,0.06,20.38-12.59c20.51-15.79,36.94-42.23,36.94-42.23 L84.32,16.14z"
    }), f.createElement("path", {
        style: {
            fill: "#D83F22"
        },
        d: "M104.18,41.84c0,0-8.37-3.57-14.34-11.9c-5.93-8.27-5.46-13.86-5.46-13.86s4.96-3.89,16.11-8.34 c7.5-2.99,17.71-4.52,21.07-2.03s-2.3,14.98-2.3,14.98l-10.31,19.96L104.18,41.84z"
    }), f.createElement("path", {
        style: {
            fill: "#6896A5"
        },
        d: "M68.17,80.4c0,0-7.23-3.69-11.83-8.94c-8.7-9.91-10.5-20.79-10.5-20.79l4.37-5.13 c0,0,1.09,11.56,10.42,21.55c6.08,6.51,12.43,9.49,12.43,9.49s-1.27,1.07-2.63,2.11C69.56,79.36,68.17,80.4,68.17,80.4z"
    }), f.createElement("path", {
        style: {
            fill: "#A02422"
        },
        d: "M112.71,44.48c0,0,4.34-5.23,8.45-17.02c5.74-16.44,0.74-21.42,0.74-21.42s-1.69,7.82-7.56,18.69 c-4.71,8.71-10.41,17-10.41,17s3.14,1.41,4.84,1.9C110.91,44.25,112.71,44.48,112.71,44.48z"
    }), f.createElement("path", {
        style: {
            fill: "#B3E1EE"
        },
        d: "M39.81,69.66c1.3,1.24,3.27-0.06,4.56-3.1c1.3-3.04,1.28-4.74,0.28-5.46 c-1.24-0.9-3.32,1.07-4.23,2.82C39.42,65.86,38.83,68.72,39.81,69.66z"
    }), f.createElement("path", {
        style: {
            fill: "#B3E1EE"
        },
        d: "M84.95,20.13c0,0-7.61,5.47-15.73,12.91c-7.45,6.83-12.39,12.17-13.07,13.41 c-0.72,1.33-0.73,3.21-0.17,4.17s1.8,1.46,2.93,0.62c1.13-0.85,9.18-9.75,16.45-16.11c6.65-5.82,11.78-9.51,11.78-9.51 s2.08-3.68,1.74-4.52C88.54,20.25,84.95,20.13,84.95,20.13z"
    }), f.createElement("path", {
        style: {
            fill: "#ED6A65"
        },
        d: "M84.95,20.13c0,0,5.62-4.31,11.74-7.34c5.69-2.82,11.35-5.17,12.37-3.13 c0.97,1.94-5.37,4.58-10.95,8.14c-5.58,3.56-10.95,7.81-10.95,7.81s-0.82-1.5-1.35-2.89C85.22,21.21,84.95,20.13,84.95,20.13z"
    }), f.createElement("path", {
        style: {
            fill: "#E1E1E1"
        },
        d: "M89.59,39.25c-5.57-5.13-13.32-3.75-17.14,0.81c-3.92,4.7-3.63,11.88,1,16.2 c4.21,3.92,12.04,4.81,16.76-0.69C94.41,50.69,94.15,43.44,89.59,39.25z"
    }), f.createElement("path", {
        style: {
            fill: "#3F545F"
        },
        d: "M75.33,41.87c-3.31,3.25-3.13,9.69,0.81,12.63c3.44,2.57,8.32,2.44,11.38-0.69 c3.06-3.13,3.06-8.82,0.19-11.76C84.41,38.68,79.12,38.15,75.33,41.87z"
    }), f.createElement("path", {
        style: {
            fill: "#A02524"
        },
        d: "M50,76.89c0,0,6.19-6.28,6.87-5.6c0.68,0.68,0.59,4.49-2.37,8.73c-2.97,4.24-9.5,11.79-14.67,16.88 c-5.1,5.01-12.29,10.74-12.97,10.64c-0.53-0.08-2.68-1.15-3.54-2.19c-0.84-1.03,1.67-5.9,2.68-7.51C27.02,96.23,50,76.89,50,76.89z"
    }), f.createElement("path", {
        style: {
            fill: "#CA2C31"
        },
        d: "M21.23,101.85c-0.08,1.44,2.12,3.54,2.12,3.54L56.87,71.3c0,0-1.57-1.77-6.19,1.1 c-4.66,2.9-8.74,6.38-14.76,12.21C27.53,92.75,21.31,100.41,21.23,101.85z"
    }), f.createElement("path", {
        style: {
            fill: "#FFFFFF"
        },
        d: "M19.06,36.95c-1.11,1.11-1.16,2.89,0.08,3.91c1.1,0.91,2.89,0.32,3.56-0.5s0.59-2.6-0.3-3.48 C21.51,35.99,19.74,36.28,19.06,36.95z"
    }), f.createElement("path", {
        style: {
            opacity: .5,
            fill: "#FFFFFF"
        },
        d: "M41.02,35.65c-0.84,0.93-0.57,2.31,0.21,2.82s1.95,0.46,2.52-0.24 c0.51-0.63,0.57-1.89-0.21-2.67C42.86,34.89,41.56,35.05,41.02,35.65z"
    }), f.createElement("path", {
        style: {
            fill: "#FFFFFF"
        },
        d: "M55.55,11.89c0,0,1.22-3.48,1.94-3.52c0.73-0.04,1.78,3.48,1.78,3.48s3.61,0.04,3.85,0.57 c0.31,0.68-2.31,2.96-2.31,2.96s0.85,3.4,0.45,3.81c-0.45,0.45-3.56-1.34-3.56-1.34s-3.2,2.23-3.89,1.62 c-0.6-0.53,0.65-4.13,0.65-4.13s-3-2.19-2.84-2.8C51.85,11.68,55.55,11.89,55.55,11.89z"
    }), f.createElement("path", {
        style: {
            fill: "#FFFFFF"
        },
        d: "M97.01,95.33c1.21,0.67,2.73,0.29,3.29-1c0.51-1.15-0.43-2.52-1.28-2.89 c-0.85-0.37-2.34,0.12-2.88,1.09C95.61,93.49,96.28,94.93,97.01,95.33z"
    }), f.createElement("path", {
        style: {
            fill: "#FFFFFF"
        },
        d: "M114.19,65.84c-0.69-1.07-2.18-1.42-3.15-0.56c-0.94,0.84-0.71,2.16-0.18,2.83 c0.53,0.67,1.95,0.92,2.81,0.37S114.61,66.48,114.19,65.84z"
    })),
    Uc = e => f.createElement("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        xmlnsXlink: "http://www.w3.org/1999/xlink",
        x: "0px",
        y: "0px",
        viewBox: "0 0 128 128",
        style: {
            enableBackground: "new 0 0 128 128"
        },
        xmlSpace: "preserve",
        ...e
    }, f.createElement("g", null, f.createElement("g", null, f.createElement("path", {
        style: {
            fill: "#FDD835"
        },
        d: "M121.59,60.83l-13.93-4.49c-8.91-2.94-14.13-10.15-16.58-19.21L84.95,7.27 c-0.16-0.59-0.55-1.38-1.75-1.38c-1.01,0-1.59,0.79-1.75,1.38l-6.13,29.87c-2.46,9.06-7.67,16.27-16.58,19.21l-13.93,4.49 c-1.97,0.64-2,3.42-0.04,4.09l14.03,4.83c8.88,2.95,14.06,10.15,16.52,19.17l6.14,29.53c0.16,0.59,0.49,1.65,1.75,1.65 c1.33,0,1.59-1.06,1.75-1.65l6.14-29.53c2.46-9.03,7.64-16.23,16.52-19.17l14.03-4.83C123.59,64.25,123.56,61.47,121.59,60.83z"
    }), f.createElement("path", {
        style: {
            fill: "#FFEE58"
        },
        d: "M122.91,62.08c-0.22-0.55-0.65-1.03-1.32-1.25l-13.93-4.49c-8.91-2.94-14.13-10.15-16.58-19.21 L84.95,7.27c-0.09-0.34-0.41-0.96-0.78-1.14l1.98,29.97c1.47,13.68,2.73,20.12,13.65,22C109.18,59.72,120.03,61.58,122.91,62.08z"
    }), f.createElement("path", {
        style: {
            fill: "#F4B400"
        },
        d: "M122.94,63.64l-24.16,5.54c-8.51,2.16-13.2,7.09-13.2,19.99l-2.37,30.94 c0.81-0.08,1.47-0.52,1.75-1.65l6.14-29.53c2.46-9.03,7.64-16.23,16.52-19.17l14.03-4.83C122.31,64.69,122.73,64.2,122.94,63.64z"
    })), f.createElement("g", null, f.createElement("path", {
        style: {
            fill: "#FDD835"
        },
        d: "M41.81,86.81c-8.33-2.75-9.09-5.85-10.49-11.08l-3.49-12.24c-0.21-0.79-2.27-0.79-2.49,0 L22.97,74.8c-1.41,5.21-4.41,9.35-9.53,11.04l-8.16,3.54c-1.13,0.37-1.15,1.97-0.02,2.35l8.22,2.91c5.1,1.69,8.08,5.83,9.5,11.02 l2.37,10.82c0.22,0.79,2.27,0.79,2.48,0l2.78-10.77c1.41-5.22,3.57-9.37,10.5-11.07l7.72-2.91c1.13-0.39,1.12-1.99-0.02-2.36 L41.81,86.81z"
    }), f.createElement("path", {
        style: {
            fill: "#FFEE58"
        },
        d: "M28.49,75.55c0.85,7.86,1.28,10.04,7.65,11.67l13.27,2.59c-0.14-0.19-0.34-0.35-0.61-0.43l-7-2.57 c-7.31-2.5-9.33-5.68-10.7-12.04c-1.37-6.36-2.83-10.51-2.83-10.51c-0.51-1.37-1.24-1.3-1.24-1.3L28.49,75.55z"
    }), f.createElement("path", {
        style: {
            fill: "#F4B400"
        },
        d: "M28.73,102.99c0-7.41,4.05-11.08,10.49-11.08l10.02-0.41c0,0-0.58,0.77-1.59,1.01l-6.54,2.13 c-5.55,2.23-8.08,3.35-9.8,10.94c0,0-2.22,8.83-2.64,9.76c-0.58,1.3-1.27,1.57-1.27,1.57L28.73,102.99z"
    })), f.createElement("path", {
        style: {
            fill: "#F4B400",
            stroke: "#F4B400",
            strokeMiterlimit: 10
        },
        d: "M59.74,28.14c0.56-0.19,0.54-0.99-0.03-1.15l-7.72-2.08 c-1.62-0.44-2.88-1.69-3.34-3.3L45.61,9.06c-0.15-0.61-1.02-0.61-1.17,0.01l-2.86,12.5c-0.44,1.66-1.74,2.94-3.4,3.37l-7.67,1.99 c-0.57,0.15-0.61,0.95-0.05,1.15l8.09,2.8c1.45,0.5,2.57,1.68,3.01,3.15l2.89,11.59c0.15,0.6,1.01,0.61,1.16,0l2.99-11.63 c0.45-1.47,1.58-2.64,3.04-3.13L59.74,28.14z"
    }))),
    a0 = e => f.createElement("svg", {
        viewBox: "0 0 128 128",
        xmlns: "http://www.w3.org/2000/svg",
        ...e
    }, f.createElement("g", {
        fill: "currentColor"
    }, f.createElement("path", {
        d: "M104,21.4C93.4,12.1,79.1,7,63.6,7c-3.68,0-7.39,0.31-11.08,0.93C49.06,6.6,45.3,6.16,41.57,6.74 c-0.87,0.11-1.62,0.65-2,1.44c-0.35,0.79-0.29,1.71,0.16,2.45l-0.04,0.05c0.13,0.22,0.29,0.41,0.47,0.59 C21.1,18.55,5.6,35.34,5.6,62.9c0,3.66,0.28,7.13,0.8,10.41c-0.71,0.45-1.21,1.1-1.27,1.93C4,77.85,6.83,82.56,7.9,85.63 c1.73,5.66,0.36,10.05,0.07,15.94c-0.86,14.17,11.06,23.4,23.63,21.75c7.17,0.26,14.71-1.87,17.34-6.16 c4.84,1.09,9.78,1.64,14.66,1.64c15.4,0,29.8-5.2,40.4-14.5c11.5-10.2,17.6-24.5,17.6-41.4C121.6,46,115.5,31.6,104,21.4z M47.48,89.14c-4.78,2.1-9.3,4.87-13.05,8.75c0,0,1.04,0.38,2.6-0.39c1.57-0.77,7.43-3.67,7.43-3.67c1.75,0.74,2.59,3.65,1.64,5.2 c-1.54,2.51-7.53,5.98-10.52,5.83c0.54,2.64,7.25,0.43,10.58-2c4.78,4.81-4.69,10.02-9.19,10.38c0.09,3.39,8.11,0.09,9.68-1.53 c2.91,5.72-10.72,8.82-16.03,9.71c-3.27-0.05-9.22-0.94-13.69-3.86c-6.18-3.72-8.01-13.7-6.48-21.27 c0.88-3.53,0.02-9.71-1.33-14.26c-0.61-3.05-3.51-7.72,1.39-7.19c0.62,0.1,1.21,0.19,1.76,0.47c6.09,2.72,2.28,14.17,9.69,15.91 c4.28,0.65,11.36-3.68,15.66-6.21c7.49-4.47,17.81-8.69,23.77-5.7C65.38,85.26,51.09,86.93,47.48,89.14z M101.36,101.29 C91.43,110,78.02,114.8,63.6,114.8c-4.66,0-9.27-0.53-13.71-1.53c-0.08-1.17-0.44-2.42-1.15-3.77c-0.04,0.14,0.92-1.59,1.1-2.79 c0.06-0.24,0.1-0.49,0.13-0.72c-0.01-0.01-0.01-0.02,0-0.03c0.18-1.72-0.26-3.99-1.51-5.06c0.64-2.14,0.92-3.67,0.69-5.66 c0.59-1.12,2.9-5.11,6.67-6.5c4.58-0.88,10.46-4.33,8.18-9.43c-1.99-7.6-18.91-2.18-27.73,3.6c-8.59,6.38-15.84,2.42-17.63-0.78 c0,0,0,0.02-0.01,0.03c-1.09-4.72-2.75-9.62-8.3-9.69C9.85,69.4,9.6,66.21,9.6,62.9c0-16.38,5.91-29.96,17.1-39.28 c5.95-4.96,13.37-8.61,21.43-10.67c3.44,0.97,6.66,2.65,9.43,4.97L57.65,18c1.01,0.92,2.55,0.95,3.6,0.08 c0.98-0.79,1.21-2.19,0.53-3.25c-0.07-0.12-0.14-0.23-0.22-0.33c-0.96-1.22-2.05-2.31-3.25-3.27C60.06,11.08,61.83,11,63.6,11 c14.5,0,27.91,4.76,37.75,13.39c10.63,9.43,16.25,22.75,16.25,38.51C117.6,78.59,111.98,91.88,101.36,101.29z"
    }), f.createElement("path", {
        d: "M41.58,62.54c-0.54,0.45-0.77,1.17-0.58,1.85c0.19,0.69,0.76,1.21,1.46,1.33c0.32,0.05,0.64,0.01,0.94-0.11 c5.43-2.01,11.29-2.55,17-1.56c5.71,0.88,11.09,3.24,15.6,6.86c0.25,0.21,0.55,0.34,0.87,0.4c0.71,0.1,1.42-0.22,1.81-0.83 c0.38-0.59,0.38-1.35,0-1.94c-0.6-0.95-1.26-1.87-1.98-2.74C67.9,55.2,52.18,53.74,41.58,62.54z"
    }), f.createElement("path", {
        d: "M80.77,31.11c-4.19,0-8,3.55-8,9.42c0,5.87,3.81,9.41,8,9.41s8-3.53,8-9.41C88.77,34.65,84.96,31.11,80.77,31.11z"
    }), f.createElement("path", {
        d: "M54.14,31.41c0-5.88-3.8-9.41-8-9.41c-4.19,0-8,3.54-8,9.41s3.81,9.42,8,9.42C50.34,40.83,54.14,37.29,54.14,31.41z"
    }), f.createElement("path", {
        d: "M73.71,26.08l0.14-0.02c5.6-1.04,11.39-0.17,16.44,2.47c0.83,0.47,1.84,0.47,2.67,0L93,28.52c0.74-0.41,1.24-1.16,1.34-2 c0.06-0.87-0.31-1.71-1-2.24c-4.33-3.45-9.83-5.1-15.34-4.58c-2.04,0.17-4.04,0.65-5.94,1.42l-0.36,0.17 c-1.11,0.59-1.6,1.92-1.14,3.09C71.05,25.65,72.38,26.37,73.71,26.08z"
    }))),
    Vc = e => f.createElement("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        xmlnsXlink: "http://www.w3.org/1999/xlink",
        x: "0px",
        y: "0px",
        viewBox: "0 0 128 128",
        style: {
            enableBackground: "new 0 0 128 128"
        },
        xmlSpace: "preserve",
        ...e
    }, f.createElement("path", {
        style: {
            fill: "#B0B0B0"
        },
        d: "M8.04,3.32C5.31,4.05,4.35,6.66,4.71,9.46c0.35,2.81,13.69,110.04,14.04,112.15 c0.35,2.11,2.46,2.98,4.91,2.81c2.46-0.18,4.39-2.11,4.21-4.21C27.7,118.1,13.66,8.41,13.3,6.83S10.67,2.62,8.04,3.32z"
    }), f.createElement("g", null, f.createElement("path", {
        style: {
            fill: "#C8C8C8"
        },
        d: "M22.43,117.14c-0.74,0-1.39-0.55-1.49-1.31L7.12,8.39C7.02,7.57,7.6,6.82,8.42,6.71 c0.82-0.1,1.57,0.47,1.68,1.3l13.82,107.44c0.11,0.82-0.47,1.57-1.3,1.68C22.56,117.14,22.49,117.14,22.43,117.14z"
    })), f.createElement("path", {
        style: {
            fill: "#CC1935"
        },
        d: "M20.98,73.61c0,0,0.21,2.14,0.85,3.33c0.46,0.87,1.9,0.31,3.06-0.73c1.22-1.1,7.22-5.26,16.64-7.47 c11.57-2.7,26.2-7.27,35.25-13.22c12.85-8.44,16.09-15.01,21.91-22.27c5.87-7.34,9.55-10.77,15.18-13.83 c5.68-3.09,7.96-3.55,8.69-3.55c0.73,0,1.84-1.96,0.12-2.81c-1.71-0.86-14.32-1.71-14.32-1.71L24.28,59.08L20.98,73.61z"
    }), f.createElement("path", {
        style: {
            fill: "#FE2C23"
        },
        d: "M12.65,7.92l8.32,65.72c0,0,4.31-5.05,13.58-8.32c10.77-3.79,25.33-6,32.68-9.79 S84.49,43.9,91.1,36.19c6.61-7.71,11.16-14.41,18.11-19.34c5.87-4.16,13.46-3.79,13.46-3.79s-5.75-4.41-16.28-3.3 c-12.17,1.27-27.76,10.76-33.9,9.67C60.75,17.34,59.04,9.14,47.41,6.57C29.08,2.52,12.65,7.92,12.65,7.92z"
    }), f.createElement("path", {
        style: {
            fill: "#FF5F5F"
        },
        d: "M25.5,53.08c1.58-0.18,3.18-9.79,7.47-17.13s11.01-13.46,13.58-15.18c2.57-1.71,5.63-3.92,1.59-6.12 s-11.26-3.92-18.48-3.92c-7,0-8.81,0.73-9.18,1.59c-0.37,0.86,1.71,23.01,2.45,28.15C23.67,45.62,24.4,53.2,25.5,53.08z"
    }), f.createElement("path", {
        style: {
            fill: "#FF5F5F"
        },
        d: "M59.89,52.47c0.13,0.77,11.99-4.41,17.87-11.14c4.79-5.48,6.73-11.87,11.14-16.4 c4.41-4.53,8.93-9.06,8.93-9.06s-12.97,1.59-20.19,10.16c-7.22,8.57-9.67,14.07-11.26,16.64C64.79,45.25,59.77,51.73,59.89,52.47z"
    })),
    l0 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADgAAAA4CAYAAACohjseAAAACXBIWXMAAC4jAAAuIwF4pT92AAAAGXRFWHRTb2Z0d2FyZQB3d3cuaW5rc2NhcGUub3Jnm+48GgAABzBJREFUaIHtmX9wVFcVxz/nbZJdskkgQMChQJXSToQEA5M/FAmmtBOmVItSi7SAM9BxkAQodGQ6Y1FMf/yhnak6kNDpQKu2Qys12A6t0RJCWik6jlBIUqRTbLTapgWKQglk9773jn/sZvdls4HsD0bj5Dtz5+29595zzved+879saKq/D/D+m87cK0xQnC4Y4TgcMcIweGOEYLDHSMEhwKpr7cqW9aMzkTHrEO1xdnwJRGS7l5U6uutmVWnv4FQi/J5IAfoQWkR4UcdCxoOX01H+cHa21XlPmA+4AdCwGsoP+68peG3aTmW6Gc6BD/TtipQ4OY/p/DVQbqoQv1bCxrqkwmXvrDUd2JcyQ7gW4Nb0R1v/X7iOt261U3ZQQ/SmqJBd9STHnJGhBaEXSB/iraJwA/KW2u/nWz8iXEljxAn5wq8jrBL4HUgSkjWzqz6KOkLSgUpR7C8tW6uwhvR4e9h6eLO6oZjMfnBuiWq7CYy5f5t5em09nmN/+qTl7XVTcflBJALcs4Sd0n7zY2vxca3rK9Wy90LFIOEfbaUHq/Z1pUuwZQj6MLKeM1Z5SUH0HFzw16QR6LVMa6Rr/RXIMuAXACBjV5yAB23bmsD7o/UNM/OdZal6qMXOakOsJQKFQA+7lywozVZH0fZ4xMejvhIxbbzh99QY6balpxC3QpEABzLHrU3uRF+hctOwIdKRao+9leVIlToWw7+Nlif4BjTBVDsL2LJ9JrlJhQ6ZbtuK7bz99unVX8pP3cUwJnjNY/1JBvfWd1wETgLIJDR8pH+OqgM+vEWfjJJxwbGsHBKFUHfqAnGGKJFxuaNGX/b1PkU5AavZjsrdynXZCcz9/qbxn2xZDa4iodcrOSqj3kT5xTXd7+cfy3se3FNCPrs/O155CQl11eCEsh1e+yHroV9L9IhWASAyIVkwi2dTZW2Cd95JXKxEjZ1WzqfnzKInYsAohSm4WMMKWXRyiNrciFnIoCIdifrE7JDDyHIEFUGQB8EBmwIBD5QmK4W16XiYyJSimDveauKvpei/CVRvvHIM1ONbRYaYzj54iHavv9zPn73g35R6z7+V1q/+xTvtr4ZbbNXbG5/JpioS1VORu1MKWurm54WO1KdouL7pseDfYnicDi83BhjhUNh2n+2n4/ePMU7+/7Yj+DJpkOc6eii89kDfW3BSz2hOwaYgrh+lZWJ8qFiyATLD9TOQnVFtNrecUtje2Ifx5i77ci3hTqRLaUdDmMbEytO2ADgGsfbdk+irou+nhbgQwBUN5W11X0qZXYMkeCNzRuKVKznAF/EIA8k9lndvK3EmHCZMQbHtQmMi+SiwPiifhEMlETaR00YHWsL26a6vq2+Xz7oqn66V9C+zXYhLk03Nm/wp0rwqkmm/NW6KX4/LwEzABB+2blg4FnNlnCVmnhyqXjga/T84yzFM6dgjIn1m3bXXIpnTqbohkne9oJTdv4s4KhX53hr4s4zeno5yjxgbiDgvDzrUO1S7+b9ahg0gmVtdQXlrXXf0RyOA7Mj3Dga6LFXJ+sfMmaeN1JWMI/C0knYjtMvgg4uRTMmg9/qv2SE3KpEnQert9o+495JdFuoyq1uWDrKD65bPdRoxiJY2bJmdK/47lXkerG4CaVaIRDrqfq7HJ9/2Z+/3HApmSLbmIw2xUDS8cdrdpyuaF07z1brRYRK4DpV3eX3Oz8pO1DXimgXIu/0yKWnuqqf7h2UYMjKfRh0vUDCLlDOoe6jM86d/emeu/Y4g3lnjLkhbWoRO9MGkxxbsOP9uX+4f/6Fy6EHgU1APlCIsBgEFAoIBoHHEsd6v0HvunYZOKzoS748ffZqc35R8wa/OIUZLcgIV3xBh7/w+GVgS+n+9Y05PmclyGJgDpGDtaO4bydV6z3Rl+5fPynHvdzbuXDnuVR8+94rjUu6ez9pir5Mr9MxRM6QklTW58pnx46v3Fy16mii5Er43KtrJ0BkKieTp32r1ocnmp+frT73CIJo5CAbIRMt6n0CKpK0HUDRsNjOpzdWrUi6DUwHKZ/oE+GzNOwoLuBDNRqZKNHoL9XILZQKSPQgKUjkqXGygtg+/HamPnmRcQQB1rzww7W9OI1xrXGZJmmL1+MvAgG/P+e2nYs2Z+U+tA8ZRxDgn+EL54d8frgC3F65mLmW/sgGQSkNlMy44IZiUUoatSEkoOK8gpnAoSz4FDeT6RR9ct/uTSL6eCx5wMAkcqUE02+MoOjX76u6uykjpzzIPMm4oBbxTJJsqqo3wUROwwMSEFF5Fqa6F9lIMrK1qaG227m4vS8ScUnkMVii0YS+k4Pj76ivuXfAOTMTZOMb1GPmvV/bbs72DPWYqe29r1CTBY88yMqt2py38z8EwhmqeX9rhv8kJUNW1kGARbu3rLPQAXcrQ4UL3b+559FfZMUZD7JG8H8VI//RD3eMEBzuGCE43DFCcLhjhOBwx38Aa/VDLM/IvdwAAAAASUVORK5CYII=",
    c0 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADgAAAA4CAYAAACohjseAAAACXBIWXMAAC4jAAAuIwF4pT92AAAAGXRFWHRTb2Z0d2FyZQB3d3cuaW5rc2NhcGUub3Jnm+48GgAAB3hJREFUaIHtmn1sXWUdxz+/c+/tXtgGY07HxsbGSocJynQvKCISE4hsY90ILZJtahRiEIyRxIygsX8QE1SMmigTp0jY6AtFNliXKGaSBSdiBNm6l4qMyejWdjCxm6us53l+P/+4b+fe3q7tPXdrtuybND3n3Oecfj/n9/I85/SKmXEuKxhtA6db5wHPdp3zgMmRnvDjlzrHTR6b+G4yERwfE1iYlMSRVIp3UkHirQ/0Xvz6ggWEp8NouZJyuuj6V7vaqgKWpgIhlRBSgVCV/t0P7AO2mcjWKf+Z8uJoA5eVos7LD50azgyvhjfDqeHUqoCrgfvEbNvRC9/9aWXtjlxlRRDg0VcOv1QVyCeyEYxEkUByw95PJW3ODbOndv/61c7qRCATvjR/xmuVMj8cld1kvNmPXCZyRVEkcsvGhk7uBug8dum/vAVbntjZ9cTje9+ZFt/68FQ24NQDMzZ5tf0+k6pZOJ9J27zsnraurvENN+Cc2mOh2hrpd/s27uq5owL+h1TZgHV1eK+23hk4Ba/gM9tOwedSX6aM7av6MkAY+EedSujULvKqjU/u6n6qsf3g5IqQDKJY82C/Z6NX88VRTDcfyDKa2T0A935s5mGn1pa+KYZTqzOt+mvL7q4Px0cprViA3/zkpYec6gulUjQLmtGV2948ugjAmTWlPyM7ptqpvNy8t2d5XJhSir2ScbC5VIpGpxAANVYBvJ84+bxTCwsg1SZ6Z8+07D5yd1w/xYq/VDuZeM6rWS6Klo0iZOtTDTBbCbB2weW9zvRPuXTWHGQiVH2kec+Rh2J7iig24H3XT3/bme0rlZ7RKQSY9fz+964CCJ1sdQXjyNev17XN7ZWDrMhi23vbUZiepMGKmg/qPgugAb8vgCqGNF3b3N7zYCW8VQTQCTsGNpl8imbr00SuBQj7Z3Y4s5OnhrTvNO/qeSCut8oAqrUXr2ZyTSYaRW+LANKTvr5eVIPFNYnDvteyq/tbow5Ib1WHMzQ6yQ9Si7PburrGAziVPfn0pWBsFDI0vt+yq7vs7loRwIZll/Q5tcP5KEZrkWhHDfRYohogVN1TEmrgvoTGz5p3d60ZNUAAr9Zzqgk/d8zLdABVO3wKqMK0NQucl980tnfXjRpgaPTkG0qJWswfmwrQr3aiMB31D17cbOftYudtXYmmk/DKhpbdXTeNCqB668s3lGwtFqRn+kd0IoBDTkQbSyj+K9++ds5b9183673LDs38ulPrLtGExvR7eaZpZ9d1ZxzQqYXFKVqcbt4M85IEsNBORJZqltLE8ey16urwoXJikNS9wBFsaWw/cvmZBQQbkKIlH4hVAEI4GRkj/3X2YH0rCYCG7Qfv8mpzs2vagZB6kVf/jeH4GvFbtcHklYkBhhMQFUQg0PQdTB8DAYJAegH6zSakFEBADODeWZMP3Hr/H+V/SWGukH/vQQAoGAIYBCAq888ooDOdJCaIQpCBc4Bk4ALSx0O1YwDOM0mCzONUIJB+1TE9up9WBkrIvArJ7R89s4Aq09IQ6XSSDFxxFDHtAjDTaU4zZjNQFn3VUQwZGKZE9383HF8VqUEB8aozS3bQojWpSHgAwMRm+QFTQdGyrWA/Wo/WdmThjF8Nx1tFIljXuvdDrio5PpqKJaMYcOJri2b3AJjJXCHz7iYTGSNzAqUjaQgi9ue+McnbG3JnnQHAIFX1UTNNR0ws31CKa9GzM+s+wBZappF4I1uDmYZSBJmBNtijVYlbGhZc0jdcb5UBxM8HwZshKoNGUZC/A3xh0/4Pmsis6DW8ka/BYsh0F+10Xpc89JnL/j0SbxUBFOTj2fvt1QqnhYIo2ssAii4udR3N1BxQCGm8iwQ3PnzTnIMj9VYRQINPR7ZxaiWjqKHbDuCFxTLItQogBUCOCdz8kyWzO8rxFhvw85vfmBtk56+oSSuKopf9P8hEIECvMQZDjEAG9Inpsl8srflbuf5iTxMJ9OZSx3OPR7llmz4LUN+6d4KJXD/UddUIvVG/fmnNi3H8xY6gwcrBPnNq+SZj9jRAMpVYgjF2iMt6E9ZsWH7F1rj+YkXwi5s6pgCDRiObql459PPPVf8FQKB2iMt6Qe5sqq1pieMtq1iAThK3MEQWZJ7qnzawr/7ylZQRlEzpjPpNWPXkiisej+MrqlgpasbKU/SKnNTstwDHp066AWyw/yYdN1jZVFuzLY6nYpUdwfrWvRMQu3EYQ9+ufq1mR3rTVpceIv8MRD/VtKKycBADMJVK3A6MG2qcYOsbGtD61jcvFLHbBo6wLWNILd5Ye2V7uV5OpbJT1JC7hjHMhUl5DCBZ5VaZyfjIZ70IDzTVzltnBQvPyqqsCK5+tuMjwDVDDjTZ/NSymkPpbe7MHYa2QIOrGmtrHjmdcFBmBNWC4UQP0HUAdzz3j4WCXA1sDtQe3njrvB3l/N1yNGLA+tbOccmUrB7yxgsdTSvmvdAIiE9ckEjIvA3L575Rps+yNWLARKrvNqBUq+8VrNeQToN9otKSTb/GldXb4xotV2V/Eehs0Tn/bcPzgGe7zgOe7TrnAf8P08QgtSyq49QAAAAASUVORK5CYII=",
    d0 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADgAAAA4CAYAAACohjseAAAACXBIWXMAAC4jAAAuIwF4pT92AAAAGXRFWHRTb2Z0d2FyZQB3d3cuaW5rc2NhcGUub3Jnm+48GgAABKhJREFUaIHtmmtom1UYx//Pm6aXNTed04lVN+elkyZNsR+0boIwoVVnFeflowwRRRRHhYIzvnvT1iIKxSEOiyL6ZeBAYcOBl87bnLj1g0lLV0XBaTeply5Z0jXtkvP4YQw07XvtOZFIf9+S8zzP+f85yXvOeXiJmfF/RvuvBahmxWC1s2Kw2jE1mDFit80MRK+spBgVmBr0Ab/7SnQ8m4z1wqCqXWmy2gezydhPAK4h8GHStEeDz6e+r5w0OVivDPMhAGDQJiF49Exf68MVUSURS4NMNPGPjwFm3ps1Ym/AaKlVrEsadit4YtF3hMeypH2dMdrWKdIkFUuDBO1nk6F2otLR00Z8k3xJcrE06AOmLIbXaCQ+ySajD0nWJBXrn2itz+6qUQ/Q3kyydZc0RZKxNKhxocZBDSKwnjVib2G43S9JlzQsDRbY58TgeQjbM9Pn3oexvn7ZqiRiabCWEXBTjJjvzmrBD6aGOhqWJ0selgaLgq53XZHRGcrlP5oxrgt5ViURm20CzV6KMrDZRw0jucGNq73JkofdIfoGz5UJeVqo9XnOl4TdQ+QWL0WZaXeEL+6B/lnRLvYPoyVQB6wl0KUCWDgH/6lLbrx2Gg+8V/Iydzmmt4lsf3QDBP3otiAzXovo6aesYjJ98TYS4kEQdQLcCoDKQgoMjBBwgFjsC+njM251XMDUYKav9RliHnJVjLA/lBi7F1i6aMZoiWuaZjBjKxabMiMDwku5QODVph1H5tzoASz+gyTEGgBuCv7Cfjxiai4Z7SHSjjHjHjg3BwARMAaDuVwq19/q+plgeeGdGupoCJ7J3wrCFgBbANxkFstM3RE9tX/RwHC7P/vb/LsgknGXPA2mbWE9dchpgqXBcrL90Q0kqFMAXQTcDmDV+Sr4NJxI37FkjtG6B8SPO57EngVi3BfS0wedBLsy+C+M9fVZCmwmUBcR9gUT6W/KQzLJaA+BXvE2gSVnmXBnJJH+wi7Qu0Eb/hqIX1FTEj/gwirLZ1YQdV2USH1lFaSsW+Yvll6EOnMA0Kgx78/0xdusgpSs4KzRsrZI2klUprF8PMxjLdBZLDWoRECRtG5VtZdgYwbxq8wGlYhgYKuKuiYU8qGGabNBJQZpOYd0t3MR91qdcBQYJALQJL/uIgoMbA8lxnZbBTlvSTjFWFcHgtq2BeFzTeCJoJ6etA1V8RTNJmN5AI2Sy86DcACC9rg5qslfQQAA/QmwN4OEg8x0jMD1AAkiPiUEj8+h7ujlL4yedVtOkUExCtDVXjJJYDKsp3aVfx/xqETNXkX08TKypWpSs9Fr2ocAFrzkCkJOphYlBlfv/O4kgHc8JZP7NokVyo5T7CsOAJh3m1cjSqMydSgzGNk5cQKEp12m/RrQxyfsw5yj9EAcTqSHwfym03hmvC1bg/ITfxj8JAhO2gt5v59flz2/+iuNPr6QCwS2ARixjCMMND43Znor8EpF7mxNO47MFVZRN4EPm4R8GW5uflnF3BV7weeyZ1OzRS7cBeDbsqFJjWvvl9WqL0dZ08mMqaGOhkButpcgbgZrY4TS4HJa83ZU3GClqdp30JyyYrDaWTFY7fwNGKGFs57j3qwAAAAASUVORK5CYII=",
    u0 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADgAAAA4CAYAAACohjseAAAACXBIWXMAAC4jAAAuIwF4pT92AAAAGXRFWHRTb2Z0d2FyZQB3d3cuaW5rc2NhcGUub3Jnm+48GgAABP5JREFUaIHtml1sVEUYht/vnO2WAoINNAYQEBMtCdEAgg3Qlq1GhEIw/K1IEDEiYCAI3igEWtYgRGIwkchPFUqIIm0VhKBQsfxIywWBCAgmjRjK34U1KAmBlu6Zeb0p2KC7O+fsbrslfZO52fO938yTM+fMnG9WSOJBltXWA0i2OgDbuzoA27seeEBfWw/g/ySATN/z27NQeoIWGSbA04BkgPRDcAXAaUAqdk56YlfMXKm2Dk796kwQYBGAQQbh5V+/MvjlaAEpAzhhY3WmnW5tF3CCG5/W6vG9c/IvRrqeMlOUbAg6jewHCAGIoa3Buc36aAEpcwfvqnB9RZYO+8cRnAnIcwDsCKEKIjMrl0zcGS1fygG21Ji1O3srR88FsABAz5bXCMw7tGxGSawcKQ14V8NCJZ27hq05FCwHkAWi8uiqOWNNvG0GGKz4tavtT89UfjZ2yfDdLA081hjLM+y9ku7pqmGpRdl37KNF1Sb9JB0wFIJVO/T3ACl5AHMADAHQA0DafaFhANcAnCdwHuBJfadTVfm0R/+Kp/+kAc7Ye/ERpZ0FAswG0NdjGiXACRK7Ldu3fcfEAX+4TZBwwHklp9Ju9OyyCMAKAN0TmDoMYlvZlIFz3ZgSug4GKy5kITOjDFoXJDJvs9IETHdrShhgsOJsNilVAPogWY+1yPduLQkBnLLj5/5iWQcB9klEvghynEZWujXFDTiv5FQauthl1Nrri8RUZ3fPHnLDrSluwD878wPQyUnatGyWACe9+OICnLrt1EBaenE8OUylIWe8+OICDLMpJPo/C3ZSJMILXnyeAcdvOd7fJ5zcWjs9p7UBbTrzydb7ngynN7rexQBxAFJzMqK8WQjUWcDnFBkJstBrP826U/nqmFtejJ4Ax208nG2LfjJKSJOCXbBvfqBOABm/qaoawEgvfTXrb69GT2VDm+Fcao2IjerK/vmBOgAgQJKHosbHakp7/qLwBEjq4dQKEZvS/V7c8MO9hZ8qnBM1PnbzDOhpimoVdXoCQJpFtb9w/f5PSeQDfCHa82og5dXoCrAgdKRTp4dvFpOSazDgQYTe4HVg9ylS4SmmjAFfWrv3IX83HtQKOV478yy2AmCDOOvQFnAAIEkGHLt6Vy/69Oxkb6gji529Oo0AHdt5HpptWAWXHl6dRoPWSvU1raUnSZ4BzdZBOrfiXMdArUitLlGrA1qp3S69/vw1pVleAI3uIB11AuJpT1BL4jsLPGr5pebHpbOuA0BB6IiPcvk0zI7IAAC2kmcAHHA7AKOyoQhk9MrSMyCeMshZD8EWS1lfHnr/tfORgkaHtuQLrSqYv8k/ObLy9bcNY+/JuC4aKNo6guBhAJFKdxcBrLpud/viXPG0JpOc+UVbFwv4sdlQcdWyrw44XFzsGMYDcFn4zVuxKSC0tgIY0OLnOoisvl3PbSc3zw276RwA8pd/VgQwZBYtU39a9eY3bvK7rmwXhEK+cFNWngXpo4lLNen1NSwu1q6S3KfcZZvfEHA9gIwYoed6XegxuLx8mvHeNGWOz3Lf3ZgN6FIIRkQNFE6vXrOwzDRvyvyNpPrDt2pr1i4YpclJ1Dwd6dsQitlu8qbMGT0AkCCw8FsR7Bn1zroAxZpFYBL+PcRpsKj3uMmZMlM0koLBCvta78tDlWUNt4Bjx9ct+cWNP+UB41XKPIPJUgdge1cHYHtXB2B71z8SjtJjoLdWewAAAABJRU5ErkJggg==",
    h0 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADgAAAA4CAYAAACohjseAAAACXBIWXMAAC4jAAAuIwF4pT92AAAAGXRFWHRTb2Z0d2FyZQB3d3cuaW5rc2NhcGUub3Jnm+48GgAABQNJREFUaIHtmntsFFUUxr9zZ9uF0gdbKBSpLFghRENiTEgU38YGRWM0pKSb2ESIpob4QAUaoEAW0UqTQqSgQBR5RYoJPgLEBBsDKoKiIiqGhwhYQCBqCksQ2p37+QetoXZ3e2dnRmzTX3L/mnPO/b6d17l3VkiiO6OutgC/6THY1ekx2NXpMdjV6fYGA6aBxUt2T4ao0WLLkp+fvfkbP0WZMLzuy1xbqWmkshC3ao5MuakpUZyRwaF1Xz0oxFLABoD7R9bsGLF/+m0xLwU7Ja5lGcgIYANKFwKYlCjO6BIV2x4OarSOwotB63UBxFPFDrhu8a4JgI60aRLaQ5LFGp1BDdqi2/Wsj4UXfREYEGx+8szku8+7FWyKRKGG5O18Qsi6dvoEjclyjAyKzT8hHZrysqyLgVuH1e5YZis0BAPnfjj0zAOXnMtuT/GChjwdDISoVQgaIbEkh5R+BEeFc6QEGjd2SCL2JKtneAbtxo7+AABhAtWiUd3c3EeHaz89CchRAEdIfVRBjkHxF6ul5dvDlfedTVY/XLu9BJQKAe5kILPg8q0OQABqAmCrj8QiCO50ZdCy9Pe6BUTq+04BKGodt0ubIBuIqwwdrtn+uYhefGzaPe+xVfG1r267XlnyGsBx/8h3vHqTCwPysr9LetR0PTik5pMDAEY4nb7jjNhtU8oVWCJADYDeruoRW3+tvHdsssPG70HQ3gzKC67EXGa0BewDYHlQCyDqUx0272S0/oAkPBqWN3UQCza3bEwl2/gSFUCKXt66F+Ao4x/FZ0jUHq8aOzVVjPElSoCDoauFfMe9NE+4JGIv6izIUbN9ckTsXWr9NbXGVR/UrzTOeuiEpwZZWmor2hFQx65o3a7GOJDVVy0w0Wx8D17J4LkfTiSw0nGiN8QU9R3H5z261yQ4LYMAMGjO+1Nb32P/ZdMdp8jDv0Uf+cg0IW2DAFBYtTEigjcBZKVdxJwWEUw6OW/8OidJrgwCwIDZG4dbWq8BcIurQqn5g4plp16a0OA00bVBAJDotkDhxVMvUqQKQLbrgu1piCv1+O/zSzt9YibU5uW3iYLK+mss4XwA5XDSBiZmPwVVp6sjKTuVzvDUYBuDZtQPtTWfE7AcQD8HqTGAm0XU+tO9D27h3LnarRZfDLYxcMr6gciI/wRIfoqwHwmsE5E9mfHMzxoXlv7lpQa3l1FSpGJFRkFOcC0o+SkXeZRNZ2rLjV7a6eCLQYlGVUGf8BpolhisYM/5oaENzw1KNKr6NxUtJ3SZSTwBX7cfPTUoFSsy8nsPXk0yYrr3QOEpLzX8G88MFlSuzMnPlHrRepyTPEvJYa80JMITg6Gnl4aVWJsAjHL4ULYzLqiDXmhIhmuDoclv3KVENoB6YBrp+04sf+qCWw2pSNugRKOB/DP95ggwk0x7A2lXuvObkpbB/hVLRoZU6C1Sj3EzORW3uMk3wZHBYRNX9WoKnp0BoBIaQZdzN2X30h+7rNEpZt8molGV15gzXgKqGjaLPZmZWN248HlP27JEpDQoE6KZfXOzI32RPZ3gDaSdKtwJLbB0Xedh7klqMHfSgjF52VkbqHWR57MKVzUtn+7r+6+NpAaFMpvwwRxw1qaa40PdhCTfNqR90JctP82Z59+e5mt7diVJz+A5aa7MjQcOUdGzs0gtu2NrZ7laoTvF1wXv/4Fu/z+ZHoNdnR6DXZ0eg12dbm/wb6MKCU994H4IAAAAAElFTkSuQmCC",
    f0 = e => e.type !== null || e.amountUsd.min !== null || e.amountUsd.max !== null || e.amount0.min !== null || e.amount0.max !== null || e.amount1.min !== null || e.amount1.max !== null || e.maker !== null,
    g0 = ({
        children: e,
        status: t,
        ...o
    }) => {
        const r = {
            info: {
                bg: ee("gray.600", "gray.750")
            },
            error: {
                bg: "red.500",
                color: "white"
            }
        };
        return n.jsx(Io, {
            children: n.jsx(I, {
                pos: "fixed",
                w: {
                    base: "100vw",
                    md: "initial"
                },
                bottom: {
                    base: 0,
                    md: 5
                },
                right: {
                    md: 5
                },
                borderRadius: {
                    md: "md"
                },
                fontSize: "md",
                boxShadow: "md",
                py: 2,
                px: 4,
                zIndex: "tooltip",
                ...r[t],
                ...o,
                children: e
            })
        })
    },
    m0 = () => n.jsx(g0, {
        status: "error",
        children: n.jsxs(q, {
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            textAlign: "center",
            children: [n.jsx(L, {
                as: Bu,
                mr: "6px"
            }), "Disconnected from server, attempting to reconnect..."]
        })
    });
class Nr extends Error {
    constructor(t) {
        super(t), this.name = "PairsServiceUnsupportedSchemaError", Object.setPrototypeOf(this, Nr.prototype)
    }
}
class Ii extends Error {
    constructor(t) {
        super(t), this.name = "PairsServiceDisconnectedError", Object.setPrototypeOf(this, Ii.prototype)
    }
}
const p0 = Ve({
        host: Lu
    }, ({
        host: e
    }) => ({
        chainId: t,
        pairId: o
    }) => {
        const r = new URL(e);
        return r.pathname = `/dex/screener/pair/${t}/${o.toLowerCase()}`, r
    }),
    x0 = Ve({
        getWebSocketData: Hf,
        getWSPairServerUrl: p0,
        servers: Du
    }, ({
        getWebSocketData: e,
        getWSPairServerUrl: t,
        servers: o
    }) => ({
        getPair: r => {
            const s = t(r),
                {
                    uniswapScreenerServer: i
                } = o;
            return e({
                url: s,
                serializer: Fu(Wu),
                binaryType: "arraybuffer"
            }).pipe(Qe(({
                data: a,
                status: l
            }) => {
                if (!a) return To({
                    data: void 0,
                    status: l.getValue()
                });
                switch (a.type) {
                    case "pair":
                        {
                            if (i.schemaVersion !== a.schemaVersion) throw new Nr(`${a.schemaVersion} is not supported (${i.schemaVersion})`);
                            return l.pipe(dt(c => ({
                                status: c,
                                data: a.pair ? ? void 0
                            })))
                        }
                }
            }))
        }
    })),
    b0 = f.memo(e => {
        const {
            ad: t
        } = e, {
            colorMode: o
        } = pe(), r = xe(qs), s = ee(t.imageUrl.light, t.imageUrl.dark);
        return f.useEffect(() => {
            for (const i of t.impressionURLs) r.text(i, {
                mode: "no-cors"
            }).catch(() => ho)
        }, [t.impressionURLs, r]), n.jsx(ue, {
            as: we,
            href: t.url,
            target: "_blank",
            rel: "sponsored noreferrer noopener",
            variant: "unstyled",
            display: "block",
            height: "auto",
            marginX: "0.5",
            textDecoration: "none !important",
            onClick: () => {
                for (const i of t.clickCountURLs) r.text(i, {
                    mode: "no-cors"
                }).catch(() => ho)
            },
            children: n.jsx(K, {
                spacing: {
                    base: .5,
                    md: 1
                },
                paddingX: {
                    base: 1,
                    lg: 2
                },
                paddingY: "1.5",
                borderRadius: "md",
                transition: "background-color 0.2s",
                sx: {
                    "@media (hover: hover)": {
                        _hover: {
                            background: T("gray.50", "blue.875", o)
                        }
                    }
                },
                children: n.jsx(Ze, {
                    src: s,
                    w: "125px",
                    maxW: "125px",
                    h: "21px",
                    overflow: "hidden",
                    loading: "lazy"
                })
            })
        })
    }),
    v0 = f.memo(e => {
        const {
            ad: t,
            chainId: o,
            activeTokenAddress: r
        } = e, {
            colorMode: s
        } = pe(), i = xe(qs), a = ee(t.imageUrl.light, t.imageUrl.dark), l = o === t.chainId && r.toLowerCase() === t.tokenAddress.toLowerCase(), c = `/${t.chainId}/${t.pairAddress??t.tokenAddress}`;
        return f.useEffect(() => {
            for (const d of t.impressionURLs) i.text(d, {
                mode: "no-cors"
            })
        }, [t.impressionURLs, i]), n.jsx(Qt, {
            to: c,
            rel: "sponsored noreferrer noopener",
            variant: "unstyled",
            display: "block",
            height: "auto",
            marginX: "0.5",
            textDecoration: "none !important",
            onClick: () => {
                for (const d of t.clickCountURLs) i.text(d, {
                    mode: "no-cors"
                })
            },
            children: n.jsxs(K, {
                spacing: {
                    base: .5,
                    md: 1
                },
                paddingX: {
                    base: 1,
                    lg: 2
                },
                paddingY: "1.5",
                background: l ? T("gray.50", "blue.875", s) : void 0,
                borderRadius: "md",
                transition: "background-color 0.2s",
                sx: {
                    "@media (hover: hover)": {
                        _hover: {
                            background: T("gray.50", "blue.875", s)
                        }
                    }
                },
                children: [n.jsx(k, {
                    fontSize: "xs",
                    fontWeight: "normal",
                    color: T("gray.400", "blue.500", s),
                    children: "Ad"
                }), n.jsx(Ze, {
                    src: a,
                    w: "15px",
                    maxW: "15px",
                    h: "16px",
                    loading: "lazy"
                }), n.jsx(k, {
                    maxWidth: "125px",
                    overflow: "hidden",
                    isTruncated: !0,
                    children: t.title
                })]
            })
        })
    }),
    y0 = f.memo(e => {
        const {
            chainId: t,
            activeTokenAddress: o,
            ad: r
        } = e;
        switch (r.source) {
            case "token":
                return n.jsx(v0, {
                    ad: r,
                    chainId: t,
                    activeTokenAddress: o
                });
            case "image":
                return n.jsx(b0, {
                    ad: r
                })
        }
    }),
    Ai = ({
        pairCreatedAt: e,
        containerProps: t
    }) => {
        var a, l;
        const {
            colorMode: o
        } = pe(), r = ((a = dr().current) == null ? void 0 : a.time) ? ? Date.now();
        if (!e || !((r - e) / 1e3 / 60 / 60 <= 24)) return null;
        const i = ((l = Xl(e, {
            now: r
        })) == null ? void 0 : l.split(" ")[0]) ? ? void 0;
        return n.jsxs(Ae, {
            color: T("green.700", "green.300", o),
            fontSize: "xs",
            fontWeight: "semibold",
            ...t,
            children: [n.jsx(L, {
                as: ql,
                mr: "2px"
            }), i]
        })
    },
    j0 = ({
        rank: e,
        pair: t,
        isActive: o
    }) => {
        var l, c, d;
        const r = xe(fi),
            s = xe(kn),
            {
                colorMode: i
            } = pe(),
            a = () => {
                s.track({
                    event: "trendingBarClick",
                    data: {
                        chainId: t.chainId,
                        rank: e
                    }
                })
            };
        return n.jsx(Qt, {
            to: Gs({
                platformId: t.chainId,
                pairAddress: t.pairAddress
            }),
            onClick: a,
            variant: "unstyled",
            display: "block",
            height: "auto",
            marginX: "0.5",
            children: n.jsxs(K, {
                spacing: {
                    base: .5,
                    md: 1
                },
                paddingX: {
                    base: 1,
                    lg: 2
                },
                paddingY: "1.5",
                background: o ? T("gray.50", "blue.875", i) : void 0,
                borderRadius: "md",
                transition: "background-color 0.2s",
                sx: {
                    "@media (hover: hover)": {
                        _hover: {
                            background: ee("gray.50", "blue.875")
                        }
                    }
                },
                children: [n.jsxs(k, {
                    fontSize: "xs",
                    fontWeight: "normal",
                    color: ee("gray.400", "blue.500"),
                    children: ["#", e]
                }), (((l = t.profile) == null ? void 0 : l.eti) || ((c = t.cmsProfile) == null ? void 0 : c.iconId)) && n.jsx(Ze, {
                    src: r({
                        dsDataParams: df({
                            pair: t
                        }),
                        cmsParams: t.cmsProfile ? {
                            assetId: (d = t.cmsProfile) == null ? void 0 : d.iconId,
                            fit: "crop",
                            size: "sm"
                        } : void 0
                    }),
                    alt: t.baseToken.name,
                    w: "16px",
                    h: "16px",
                    maxWidth: "initial",
                    loading: "lazy"
                }), n.jsx(k, {
                    maxWidth: "125px",
                    overflow: "hidden",
                    isTruncated: !0,
                    children: t.baseToken.symbol
                }), t.priceChange.h24 !== void 0 && t.priceChange.h24 !== 0 && n.jsx(k, {
                    fontSize: "xs",
                    children: n.jsx(ur, {
                        value: t.priceChange.h24,
                        colorScheme: "accent"
                    })
                }), n.jsx(Ai, {
                    pairCreatedAt: t.pairCreatedAt
                })]
            })
        })
    },
    S0 = () => n.jsx(k, {
        width: "80px",
        height: "18px",
        borderRadius: "md",
        background: ee("gray.25", "blue.950")
    }),
    w0 = e => {
        const {
            selectedChainIds: t
        } = e, {
            chains: o
        } = Gl(), [r, s] = f.useState(""), i = f.useMemo(() => o.filter(l => t.includes(l.slug)), [t, o]), a = f.useCallback(() => s(""), []);
        return {
            chains: o,
            selectedChains: i,
            query: r,
            setQuery: s,
            resetQuery: a
        }
    },
    C0 = ({
        onChange: e,
        variant: t,
        size: o,
        colorScheme: r,
        multiselect: s,
        ...i
    }) => {
        const a = xe(Ir),
            {
                chains: l,
                selectedChains: c,
                query: d,
                setQuery: u,
                resetQuery: h
            } = w0(i),
            [m, g] = f.useState(!0),
            p = f.useRef(null),
            {
                colorMode: b
            } = pe(),
            j = f.useCallback(x => u(x.target.value.trim()), [u]),
            y = f.useCallback(x => {
                e == null || e(Nu(x) ? x : [x])
            }, [e]),
            S = f.useCallback(() => e == null ? void 0 : e([]), [e]),
            w = f.useCallback(() => {
                var x;
                h(), (x = p.current) == null || x.blur(), document.activeElement instanceof HTMLElement && document.activeElement.blur()
            }, [h, p]),
            v = f.useMemo(() => {
                const x = c.map(C => C.slug);
                return s ? x : x[0]
            }, [s, c]);
        return f.useEffect(() => {
            const x = E => g(!E.metaKey && !E.ctrlKey && !E.shiftKey),
                C = () => g(!0);
            return document.addEventListener("keydown", x), document.addEventListener("keyup", C), () => {
                document.removeEventListener("keydown", x), document.removeEventListener("keyup", C)
            }
        }, []), n.jsxs(Tr, {
            isAttached: !0,
            size: o,
            variant: t ? ? "solid",
            colorScheme: r,
            children: [n.jsxs(Xn, {
                onClose: w,
                autoSelect: !1,
                children: [n.jsxs(qn, {
                    as: ue,
                    lineHeight: "1",
                    leftIcon: n.jsx(L, {
                        as: Hu
                    }),
                    children: [c.length === 0 && "All Chains", c.length > 0 && n.jsx(K, {
                        children: c.map(x => n.jsx(I, {
                            width: "max-content",
                            children: c.length > 2 ? n.jsx(Ze, {
                                src: a(x.slug),
                                w: "16px",
                                h: "16px",
                                loading: "lazy"
                            }) : n.jsxs(K, {
                                children: [n.jsx(Ze, {
                                    src: a(x.slug),
                                    w: "16px",
                                    h: "16px",
                                    loading: "lazy"
                                }), n.jsx(k, {
                                    children: x.name
                                })]
                            })
                        }, x.slug))
                    })]
                }), n.jsx(Io, {
                    children: n.jsxs(Gn, {
                        zIndex: "modal",
                        maxHeight: "50vh",
                        overflowY: "scroll",
                        children: [n.jsx(I, {
                            paddingX: "2",
                            children: n.jsxs(On, {
                                variant: "unstyled",
                                children: [n.jsx(Hn, {
                                    type: "text",
                                    placeholder: "Filter...",
                                    onChange: j,
                                    value: d,
                                    ref: p
                                }), d && n.jsx(Wr, {
                                    h: "100%",
                                    children: n.jsx(Je, {
                                        minW: "25px",
                                        h: "25px",
                                        onClick: h,
                                        icon: n.jsx(L, {
                                            as: oa
                                        }),
                                        variant: "unstyled",
                                        display: "flex",
                                        alignItems: "center",
                                        "aria-label": "Clear",
                                        color: T("gray.200", "gray.600", b),
                                        _hover: {
                                            color: T("red.400", "red.300", b)
                                        },
                                        _focus: {
                                            boxShadow: "none"
                                        }
                                    })
                                })]
                            })
                        }), n.jsx(er, {}), n.jsx(_u, {
                            value: v,
                            onChange: y,
                            type: s ? "checkbox" : "radio",
                            children: l.map(x => {
                                var R;
                                const C = c.find(B => B.slug === x.slug) !== void 0,
                                    E = d === "" || x.name.toLowerCase().includes(d.toLowerCase()) || ((R = x.shortName) == null ? void 0 : R.toLowerCase().includes(d.toLowerCase())) || x.slug.toLowerCase().includes(d.toLowerCase()) || C;
                                return n.jsx(tt, {
                                    value: x.slug,
                                    flexDirection: "row-reverse",
                                    closeOnSelect: m,
                                    display: E ? void 0 : "none",
                                    isFocusable: !1,
                                    children: n.jsxs(K, {
                                        children: [n.jsx(Ze, {
                                            src: a(x.slug),
                                            w: "16px",
                                            h: "16px"
                                        }), n.jsx(k, {
                                            fontWeight: C ? "semibold" : void 0,
                                            children: x.name
                                        })]
                                    })
                                }, x.slug)
                            })
                        }, v === void 0 ? 0 : 1)]
                    })
                })]
            }), c.length > 0 && n.jsx(Je, {
                icon: n.jsx(L, {
                    as: oa
                }),
                "aria-label": "Remove all chains",
                onClick: S,
                borderLeft: "0"
            })]
        })
    },
    Xc = {
        base: "105px",
        lg: "48px"
    },
    Vo = () => n.jsx(k, {
        color: ee("gray.200", "gray.700"),
        fontWeight: "normal",
        fontSize: "sm",
        children: "N/A"
    }),
    k0 = ({
        pair: e,
        index: t,
        showChainIcon: o
    }) => {
        var c, d;
        const r = xe(Ir),
            s = xe(Uu),
            i = xe(kn),
            {
                colorMode: a
            } = pe(),
            l = () => {
                i.track({
                    event: "trendingModalClick",
                    data: {
                        chainId: e.chainId,
                        rank: t + 1
                    }
                })
            };
        return n.jsx(Ou, {
            to: Gs({
                platformId: e.chainId,
                pairAddress: e.pairAddress
            }),
            onClick: l,
            display: "flex",
            alignItems: "center",
            background: T("gray.25", "blue.900", a),
            _hover: {
                bg: T("gray.75", "blue.825", a)
            },
            paddingY: "0",
            paddingX: "3",
            height: Xc,
            borderRadius: "md",
            isHoverable: !0,
            children: n.jsxs(Ks, {
                width: "100%",
                direction: {
                    base: "column",
                    md: "row"
                },
                spacing: {
                    base: "2",
                    md: "4"
                },
                children: [n.jsxs(I, {
                    width: {
                        md: "45%",
                        lg: "50%"
                    },
                    overflow: "hidden",
                    fontSize: "lg",
                    noOfLines: 1,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: {
                        base: "center",
                        md: "initial"
                    },
                    gap: "2",
                    children: [n.jsxs(k, {
                        color: T("gray.500", "blue.500", a),
                        fontFamily: "mono",
                        fontSize: "md",
                        children: ["#", t + 1]
                    }), o && n.jsx(Ze, {
                        src: r(e.chainId),
                        alt: e.chainId,
                        w: "22px",
                        h: "22px",
                        maxWidth: "initial",
                        loading: "lazy"
                    }), n.jsxs(k, {
                        isTruncated: !0,
                        children: [n.jsx(k, {
                            fontWeight: "semibold",
                            children: e.baseToken.symbol
                        }), n.jsx(k, {
                            ml: "2",
                            color: T("gray.400", "gray.200", a),
                            children: e.baseToken.name
                        })]
                    }), e.eti && n.jsx(Ze, {
                        src: s({
                            chainId: e.chainId,
                            tokenAddress: e.baseToken.address,
                            cacheKey: (c = e.profile) == null ? void 0 : c.imgKey
                        }),
                        alt: e.baseToken.name,
                        w: "22px",
                        h: "22px",
                        maxWidth: "initial",
                        loading: "lazy"
                    }), n.jsx(Ai, {
                        pairCreatedAt: e.pairCreatedAt
                    })]
                }), n.jsxs(I, {
                    flex: {
                        md: "1"
                    },
                    display: "grid",
                    rowGap: "1",
                    gridTemplateColumns: {
                        base: "1fr 1fr",
                        md: "1fr 1fr 1fr 80px"
                    },
                    fontWeight: "semibold",
                    children: [n.jsxs(K, {
                        justifyContent: {
                            base: "center",
                            md: "initial"
                        },
                        children: [n.jsx(k, {
                            color: T("gray.400", "gray.500", a),
                            fontWeight: "normal",
                            children: "1H"
                        }), n.jsx(ur, {
                            value: e.priceChange.h1,
                            colorScheme: "accent",
                            empty: n.jsx(Vo, {})
                        })]
                    }), n.jsxs(K, {
                        justifyContent: {
                            base: "center",
                            md: "initial"
                        },
                        children: [n.jsx(k, {
                            color: T("gray.400", "gray.500", a),
                            fontWeight: "normal",
                            children: "24H"
                        }), n.jsx(ur, {
                            value: e.priceChange.h24,
                            colorScheme: "accent",
                            empty: n.jsx(Vo, {})
                        })]
                    }), n.jsxs(K, {
                        justifyContent: {
                            base: "center",
                            md: "initial"
                        },
                        children: [n.jsx(k, {
                            color: T("gray.400", "gray.500", a),
                            fontWeight: "normal",
                            children: "VOL"
                        }), e.volume.h24 !== void 0 ? n.jsx(k, {
                            fontWeight: "semibold",
                            children: Dt(e.volume.h24)
                        }) : n.jsx(Vo, {})]
                    }), n.jsxs(K, {
                        justifyContent: {
                            base: "center",
                            md: "initial"
                        },
                        children: [n.jsx(k, {
                            color: T("gray.400", "gray.500", a),
                            fontWeight: "normal",
                            children: "LIQ"
                        }), ((d = e.liquidity) == null ? void 0 : d.usd) !== void 0 ? n.jsx(k, {
                            fontWeight: "semibold",
                            children: hr(e.liquidity.usd)
                        }) : n.jsx(Vo, {})]
                    })]
                })]
            })
        }, e.pairAddress)
    },
    T0 = () => n.jsx(k, {
        width: "100%",
        height: Xc,
        borderRadius: "md",
        background: ee("gray.50", "blue.925")
    }),
    gv = [{
        id: "trending",
        icon: n.jsx(L, {
            as: Kl
        }),
        label: "Trending",
        labelInfoLink: "https://docs.dexscreener.com/trending",
        presets: [{
            id: "trending:m5",
            name: "5M",
            query: {
                rankBy: {
                    key: "trendingScoreM5",
                    order: "desc"
                }
            }
        }, {
            id: "trending:h1",
            name: "1H",
            query: {
                rankBy: {
                    key: "trendingScoreH1",
                    order: "desc"
                }
            }
        }, {
            id: "trending:h6",
            name: "6H",
            isDefault: !0,
            query: {
                rankBy: {
                    key: "trendingScoreH6",
                    order: "desc"
                }
            }
        }, {
            id: "trending:h24",
            name: "24H",
            query: {
                rankBy: {
                    key: "trendingScoreH24",
                    order: "desc"
                }
            }
        }]
    }, {
        id: "top",
        icon: n.jsx(L, {
            as: Vu
        }),
        label: "Top",
        presets: [{
            id: "top:volume",
            name: "Volume",
            isDefault: !0,
            query: {
                rankBy: {
                    key: "volume",
                    order: "desc"
                },
                filters: {
                    txns: {
                        h24: {
                            min: 50
                        }
                    },
                    liquidity: {
                        min: 25e3
                    }
                }
            }
        }, {
            id: "top:txns",
            name: "Txns",
            query: {
                rankBy: {
                    key: "txns",
                    order: "desc"
                }
            }
        }]
    }, {
        id: "gainers",
        icon: n.jsx(L, {
            as: Ql
        }),
        label: "Gainers",
        presets: [{
            id: "gainers:5m",
            name: "5M",
            query: {
                rankBy: {
                    key: "priceChangeM5",
                    order: "desc"
                },
                filters: {
                    txns: {
                        h24: {
                            min: 50
                        }
                    },
                    liquidity: {
                        min: 25e3
                    },
                    volume: {
                        h24: {
                            min: 1e4
                        }
                    }
                }
            }
        }, {
            id: "gainers:1h",
            name: "1H",
            query: {
                rankBy: {
                    key: "priceChangeH1",
                    order: "desc"
                },
                filters: {
                    txns: {
                        h24: {
                            min: 50
                        }
                    },
                    liquidity: {
                        min: 25e3
                    },
                    volume: {
                        h24: {
                            min: 1e4
                        }
                    }
                }
            }
        }, {
            id: "gainers:6h",
            name: "6H",
            query: {
                rankBy: {
                    key: "priceChangeH6",
                    order: "desc"
                },
                filters: {
                    txns: {
                        h24: {
                            min: 50
                        }
                    },
                    liquidity: {
                        min: 25e3
                    },
                    volume: {
                        h24: {
                            min: 1e4
                        }
                    }
                }
            }
        }, {
            id: "gainers:24h",
            name: "24H",
            isDefault: !0,
            query: {
                rankBy: {
                    key: "priceChangeH24",
                    order: "desc"
                },
                filters: {
                    txns: {
                        h24: {
                            min: 50
                        }
                    },
                    liquidity: {
                        min: 25e3
                    },
                    volume: {
                        h24: {
                            min: 1e4
                        }
                    }
                }
            }
        }]
    }, {
        id: "new-pairs",
        icon: n.jsx(L, {
            as: ql
        }),
        label: "New Pairs",
        presets: [{
            id: "new-pairs:newest",
            name: "Newest",
            query: {
                rankBy: {
                    key: "pairAge",
                    order: "asc"
                }
            },
            screenerVariant: "new"
        }, {
            id: "new-pairs:1h",
            name: "1H",
            query: {
                rankBy: {
                    key: "volume",
                    order: "desc"
                },
                filters: {
                    pairAge: {
                        max: 1
                    }
                }
            }
        }, {
            id: "new-pairs:6h",
            name: "6H",
            query: {
                rankBy: {
                    key: "volume",
                    order: "desc"
                },
                filters: {
                    pairAge: {
                        max: 6
                    }
                }
            }
        }, {
            id: "new-pairs:24h",
            name: "24H",
            isDefault: !0,
            query: {
                rankBy: {
                    key: "volume",
                    order: "desc"
                },
                filters: {
                    pairAge: {
                        max: 24
                    }
                }
            }
        }, {
            id: "new-pairs:3d",
            name: "3D",
            query: {
                rankBy: {
                    key: "volume",
                    order: "desc"
                },
                filters: {
                    pairAge: {
                        max: 72
                    }
                }
            }
        }, {
            id: "new-pairs:7d",
            name: "7D",
            query: {
                rankBy: {
                    key: "volume",
                    order: "desc"
                },
                filters: {
                    pairAge: {
                        max: 168
                    }
                }
            }
        }]
    }],
    mv = {
        screenerType: "home",
        chainId: null,
        dexId: null
    },
    pv = {
        defaultParams: {
            filters: {
                liquidity: {
                    min: 1e3
                }
            }
        },
        resetToEmpty: !0
    },
    I0 = {
        rankBy: {
            key: "trendingScoreH6",
            order: "desc"
        }
    },
    xv = {
        adLocation: {
            preferredAdKind: "native",
            screen: "home",
            provider: "direct"
        },
        enabled: !0
    },
    A0 = e => {
        const t = xe($l),
            [o, r] = f.useState(e.chainId),
            [s, i] = f.useState(e.timeframeKey),
            [a, l] = f.useState(on);
        return f.useEffect(() => {
            l(on), t.getPairs({
                chainId: o,
                timeframeKey: s
            }).then(c => {
                l(Wt(c))
            }).catch(c => {
                l(d => fr(d, c))
            })
        }, [t, o, s]), {
            trending: a,
            selectedChainId: o,
            setSelectedChainId: r,
            selectedTimeframeKey: s,
            setSelectedTimeframeKey: i
        }
    },
    E0 = ({
        size: e,
        onClose: t,
        ...o
    }) => {
        var g;
        const {
            trending: r,
            selectedChainId: s,
            setSelectedChainId: i,
            selectedTimeframeKey: a,
            setSelectedTimeframeKey: l
        } = A0(o), {
            chains: c
        } = Gl(), d = xe(kn);
        f.useEffect(() => {
            d.track({
                event: "trendingModalView",
                data: {
                    chainId: s ? ? "all",
                    timeframeKey: a
                }
            })
        }, [d, s, a]);
        const u = f.useCallback(p => {
                const [b] = p;
                i(b)
            }, [i]),
            h = f.useMemo(() => {
                var j;
                let p = `/${s??""}`;
                const b = `trendingScore${a.toUpperCase()}`;
                return b !== ((j = I0.rankBy) == null ? void 0 : j.key) && (p += `?rankBy=${b}&order=desc`), p
            }, [s, a]),
            m = s ? (g = c.find(p => p.slug === s)) == null ? void 0 : g.name : void 0;
        return n.jsxs(Qs, {
            size: e,
            onClose: t,
            scrollBehavior: "inside",
            motionPreset: "none",
            isOpen: !0,
            children: [n.jsx($s, {}), n.jsxs(Ys, {
                height: "100vh",
                maxH: {
                    base: "100dvh",
                    lg: "calc(100% - 7.5rem)"
                },
                children: [n.jsx(Zs, {}), n.jsx(Yl, {
                    paddingX: {
                        base: 2,
                        md: 3
                    },
                    paddingY: {
                        base: 3,
                        md: 2
                    },
                    padding: "3",
                    children: n.jsxs(Ks, {
                        flex: 1,
                        direction: {
                            base: "column",
                            md: "row"
                        },
                        spacing: {
                            base: 3,
                            md: 4
                        },
                        children: [n.jsxs(K, {
                            spacing: "1",
                            children: [n.jsx(L, {
                                as: Js,
                                boxSize: "6",
                                color: "accent.orange"
                            }), n.jsxs(Lt, {
                                size: "2xl",
                                fontWeight: "normal",
                                children: [n.jsx(k, {
                                    fontWeight: "bold",
                                    color: "accent.orange",
                                    children: "Trending"
                                }), " ", "on DEX Screener"]
                            })]
                        }), n.jsxs(I, {
                            display: "flex",
                            gap: {
                                base: 1,
                                md: 3
                            },
                            justifyContent: {
                                base: "space-between",
                                md: "initial"
                            },
                            overflowX: "auto",
                            children: [n.jsx(C0, {
                                variant: "outline",
                                size: "sm",
                                selectedChainIds: s ? [s] : [],
                                onChange: u
                            }), n.jsx(I, {
                                display: "flex",
                                sx: {
                                    button: {
                                        borderRadius: "none"
                                    },
                                    "button:first-of-type": {
                                        borderLeftRadius: "md"
                                    },
                                    "button:last-of-type": {
                                        borderRightRadius: "md"
                                    },
                                    "button:not(:last-of-type)": {
                                        borderRightWidth: 0
                                    }
                                },
                                children: Object.entries(Zl).map(([p, {
                                    shorthand: b
                                }]) => n.jsx(ue, {
                                    onClick: () => l(p),
                                    variant: a === p ? "solid" : "outline",
                                    borderWidth: 1,
                                    size: "sm",
                                    children: b
                                }, p))
                            })]
                        })]
                    })
                }), n.jsx(ei, {
                    fontSize: "md",
                    padding: "3",
                    children: be({
                        value: r,
                        onPending: () => n.jsx(he, {
                            alignItems: "stretch",
                            spacing: "3",
                            children: [...Array(30)].map((p, b) => n.jsx(T0, {
                                index: b
                            }, b))
                        }),
                        onFailure: () => n.jsx(Ae, {
                            opacity: .5,
                            h: "100%",
                            children: "Failed loading trending tokens :("
                        }),
                        onSuccess: p => p.length > 0 ? n.jsx(he, {
                            alignItems: "stretch",
                            spacing: "3",
                            children: p.map((b, j) => n.jsx(k0, {
                                pair: b,
                                index: j,
                                showChainIcon: !s
                            }, b.pairAddress))
                        }) : n.jsx(Ae, {
                            opacity: .5,
                            h: "100%",
                            children: "Nothing to see here..."
                        })
                    })
                }, `${s}:${a}`), n.jsxs(Jl, {
                    fontSize: {
                        base: "xs",
                        md: "md"
                    },
                    gap: {
                        base: 2,
                        md: 4
                    },
                    px: "1",
                    children: [n.jsx(Qt, {
                        to: h,
                        leftIcon: n.jsx(L, {
                            as: Kl
                        }),
                        rightIcon: n.jsx(L, {
                            as: ti
                        }),
                        colorScheme: "accent",
                        size: "sm",
                        children: n.jsxs(k, {
                            isTruncated: !0,
                            children: ["All Trending Tokens", m ? ` on ${m}` : ""]
                        })
                    }), n.jsx(we, {
                        href: "https://docs.dexscreener.com/trending",
                        target: "_blank",
                        fontSize: {
                            base: "2xs",
                            md: "md"
                        },
                        opacity: .75,
                        sx: {
                            "@media (hover: hover)": {
                                _hover: {
                                    opacity: 1
                                }
                            }
                        },
                        children: n.jsxs(K, {
                            spacing: {
                                base: .5,
                                md: 1
                            },
                            children: [n.jsx(L, {
                                as: Ao
                            }), n.jsx(k, {
                                children: "About"
                            })]
                        })
                    })]
                })]
            })]
        })
    },
    P0 = f.memo(e => {
        const {
            ad: {
                chainId: t,
                tokenAddress: o,
                impressionURL: r,
                image: s,
                title: i
            }
        } = e, a = xe(ec), l = f.useRef(null);
        f.useEffect(() => {
            let u;
            return l.current && (u = new IntersectionObserver(h => {
                for (const m of h)
                    if (m.isIntersecting) {
                        u.disconnect(), a.fetchImpression(r);
                        break
                    }
            }), u.observe(l.current)), () => {
                u && u.disconnect()
            }
        }, [r, a]);
        const {
            colorMode: c
        } = pe(), d = ee("gray.50", "blue.875");
        return n.jsx(Qt, {
            ref: l,
            to: `/${encodeURIComponent(t)}/${encodeURIComponent(o)}`,
            rel: "sponsored noreferrer noopener",
            variant: "unstyled",
            display: "block",
            height: "auto",
            marginX: "0.5",
            textDecoration: "none !important",
            onClick: () => void a.fetchImpression(r),
            children: n.jsxs(K, {
                spacing: {
                    base: .5,
                    md: 1
                },
                paddingX: {
                    base: 1,
                    lg: 2
                },
                paddingY: "1.5",
                background: void 0,
                borderRadius: "md",
                transition: "background-color 0.2s",
                sx: {
                    "@media (hover: hover)": {
                        _hover: {
                            background: d
                        }
                    }
                },
                children: [n.jsx(k, {
                    fontSize: "xs",
                    fontWeight: "normal",
                    color: T("gray.400", "blue.500", c),
                    children: "Ad"
                }), n.jsx(Ze, {
                    src: s.toString(),
                    w: "15px",
                    maxW: "15px",
                    h: "16px",
                    loading: "lazy"
                }), n.jsx(k, {
                    maxWidth: "125px",
                    overflow: "hidden",
                    isTruncated: !0,
                    children: i
                })]
            })
        })
    }),
    Ba = {
        drag: 1,
        wheel: 1
    },
    R0 = ({
        children: e,
        childRef: t,
        scrollSpeed: o,
        scrollShadeBackground: r,
        scrollShadeForceVisibility: s,
        trapMouseWheel: i
    }) => {
        const a = f.useRef(null),
            l = f.useRef(null),
            [c, d] = f.useState(),
            [u, h] = f.useState(!1),
            m = f.useRef(),
            [g] = tc("(hover: hover) and (pointer: fine)"),
            p = f.useCallback(w => {
                if (t != null && t.current) {
                    const v = t.current.style.pointerEvents;
                    w ? v !== "none" && (t.current.style.pointerEvents = "none") : v === "none" && (t.current.style.pointerEvents = "auto")
                }
            }, [t]),
            b = f.useCallback(w => {
                if (!m.current) return;
                w.preventDefault();
                const v = document.getElementsByTagName("iframe");
                for (const R of Array.from(v)) R.style.pointerEvents = "none";
                document.body.style.userSelect = "none", m.current.didSetIsDragging || (p(!0), m.current.didSetIsDragging = !0);
                const x = l.current;
                if (!x) return;
                const E = (w.pageX - x.offsetLeft - m.current.startX) * (o ? ? Ba.drag);
                x.scrollLeft = m.current.scrollLeft - E
            }, [o, p]),
            j = f.useCallback(() => {
                m.current && (m.current.didSetIsDragging && p(!1), m.current = void 0);
                const w = document.getElementsByTagName("iframe");
                for (const v of Array.from(w)) v.style.pointerEvents = "auto";
                document.body.style.userSelect = "auto", document.removeEventListener("mousemove", b), document.removeEventListener("mouseup", j), document.removeEventListener("mouseleave", j)
            }, [b, p]),
            y = f.useCallback(w => {
                if (!t.current) return;
                const v = l.current;
                v && (m.current || (m.current = {
                    startX: w.pageX - v.offsetLeft,
                    scrollLeft: v.scrollLeft,
                    didSetIsDragging: !1
                }, document.addEventListener("mousemove", b), document.addEventListener("mouseup", j), document.addEventListener("mouseleave", j)))
            }, [t, b, j]),
            S = f.useCallback(w => {
                w.deltaX === 0 && (i && w.stopPropagation(), w.preventDefault(), !m.current && l.current && (l.current.scrollLeft += w.deltaY * Ba.wheel))
            }, [i]);
        return f.useEffect(() => {
            if (!t.current) return;
            const w = l.current;
            if (w) {
                if (w.scrollWidth === w.offsetWidth || !g) {
                    u && h(!1);
                    return
                }
                u || h(!0)
            }
        }, [t, g, u, c]), f.useEffect(() => {
            if (!g) return;
            const w = a.current;
            let v;
            return w && (v = uf({
                strategy: "scroll"
            }), v.listenTo(w, x => {
                d(x.getBoundingClientRect().width)
            })), () => {
                w && v && v.uninstall(w)
            }
        }, [g]), f.useEffect(() => {
            const w = l.current;
            return w == null || w.addEventListener("wheel", S, {
                passive: !1
            }), () => {
                w == null || w.removeEventListener("wheel", S)
            }
        }, [S]), n.jsxs(I, {
            ref: a,
            display: "flex",
            width: "100%",
            overflowX: "hidden",
            children: [n.jsx(I, {
                ref: l,
                display: "flex",
                width: "100%",
                overflowX: "auto",
                cursor: u ? "move" : void 0,
                onMouseDown: g ? y : void 0,
                sx: {
                    "&::-webkit-scrollbar": {
                        display: "none"
                    },
                    msOverflowStyle: "none",
                    scrollbarWidth: "none"
                },
                children: e
            }), n.jsx(I, {
                position: "relative",
                children: n.jsx(wf, {
                    background: r,
                    scrollContainerRef: l,
                    forceVisibility: s
                })
            })]
        })
    },
    z0 = () => {
        const {
            value: e,
            enable: t,
            disable: o
        } = Yt(!1);
        return {
            trending: Zt(s => s.trendingPairs),
            isModalOpened: e,
            openModal: t,
            closeModal: o
        }
    },
    qc = 46,
    Gc = "h6",
    M0 = f.memo(({
        activeChainId: e,
        activePairAddress: t,
        activeTokenAddress: o,
        isActivePairMoonshot: r
    }) => {
        const {
            trending: s,
            openModal: i,
            closeModal: a,
            isModalOpened: l
        } = z0(), c = f.useRef(null), d = f.useCallback(() => n.jsx(K, {
            px: 2,
            overflow: "hidden",
            children: [...Array(30)].map((g, p) => n.jsx(S0, {}, p))
        }), []), u = f.useCallback(() => n.jsx(k, {
            fontSize: "sm",
            opacity: .5,
            paddingX: "2",
            children: "Failed loading trending tokens :("
        }), []), h = gr({
            base: "full",
            md: "4xl"
        }), m = Xu({
            chainId: e,
            tokenAddress: o,
            isMoonshotPair: r
        });
        return n.jsxs(n.Fragment, {
            children: [n.jsxs(I, {
                display: "flex",
                alignItems: "center",
                borderTopWidth: {
                    base: "1px",
                    lg: "0"
                },
                borderBottomWidth: {
                    base: "0",
                    lg: "1px"
                },
                borderColor: ee("gray.75", "blue.900"),
                background: ee("white", "blue.975"),
                width: "100%",
                height: `${qc}px`,
                children: [n.jsx(I, {
                    flex: "1",
                    overflow: "hidden",
                    pointerEvents: s.kind === "AsyncPending" ? "none" : void 0,
                    children: n.jsx(R0, {
                        childRef: c,
                        scrollSpeed: 1,
                        scrollShadeBackground: ee("white", "blue.975"),
                        scrollShadeForceVisibility: !0,
                        children: n.jsx(I, {
                            ref: c,
                            position: "relative",
                            display: "flex",
                            alignItems: "center",
                            height: "100%",
                            children: n.jsxs(I, {
                                flex: "1",
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "space-between",
                                paddingLeft: {
                                    base: 0,
                                    lg: .5
                                },
                                children: [m && m.kind === "hardcoded" && n.jsx(y0, {
                                    ad: m,
                                    chainId: e,
                                    activeTokenAddress: o
                                }), m && m.kind !== "hardcoded" && n.jsx(P0, {
                                    ad: m
                                }), be({
                                    value: s,
                                    onPending: d,
                                    onFailure: u,
                                    onSuccess: g => n.jsx(n.Fragment, {
                                        children: g && g.length > 0 ? g.map((p, b) => n.jsx(j0, {
                                            rank: b + 1,
                                            pair: p,
                                            isActive: p.pairAddress === t
                                        }, p.pairAddress)) : n.jsx(k, {
                                            fontSize: "sm",
                                            opacity: .5,
                                            paddingX: "2",
                                            children: "Nothing to see here..."
                                        })
                                    })
                                })]
                            })
                        })
                    })
                }), r !== !0 ? n.jsx(I, {
                    flexShrink: "0",
                    display: "flex",
                    alignItems: "center",
                    children: n.jsx(ue, {
                        variant: "unstyled",
                        background: "accent.orange",
                        color: "white",
                        borderLeftRadius: "md",
                        borderRightRadius: "0",
                        paddingLeft: "2",
                        paddingRight: "2",
                        size: "sm",
                        sx: {
                            "@media (hover: hover)": {
                                _hover: {
                                    background: "accent.orangeDark",
                                    cursor: "pointer"
                                }
                            }
                        },
                        onClick: i,
                        children: n.jsxs(K, {
                            spacing: "1",
                            children: [n.jsx(L, {
                                as: Js,
                                boxSize: "18px"
                            }), n.jsx(L, {
                                as: ti,
                                boxSize: "12px"
                            })]
                        })
                    })
                }) : null]
            }), l && n.jsx(E0, {
                size: h,
                onClose: a,
                chainId: e,
                timeframeKey: Gc
            })]
        })
    }),
    B0 = 30 * 60 * 1e3,
    F0 = 30 * 1e3,
    W0 = 3 * 60 * 1e3,
    D0 = 30 * 1e3,
    L0 = 30 * 1e3,
    Fa = 30 * 1e3,
    Wa = e => {
        var t, o;
        return e ? ((t = e.gp) == null ? void 0 : t.dataStatus) === "partial" || ((o = e.ts) == null ? void 0 : o.status) === "pending" || e.gp === null || e.ts === null ? "partial-data" : "full-data" : "no-data"
    },
    N0 = e => {
        if (e.isMoonshot) return L0;
        switch (e.type) {
            case "no-data":
            case "partial-data":
                return e.isNewPair ? D0 : F0;
            case "full-data":
                return e.isNewPair ? W0 : B0
        }
    },
    H0 = e => {
        const {
            chainId: t,
            pairAddress: o,
            screenerPairs: r
        } = e;
        if (!r) return;
        const s = r.find(i => i.chainId === t && i.pairAddress === o);
        return s || r.find(i => i.chainId === t && i.baseToken.address === o)
    },
    [Zt, _0] = nc("DEXPairDetail"),
    Da = (e, t) => e.pipe(dt(o => {
        if (!t) return;
        if (!o) return t;
        const {
            pairIdentity: r
        } = o;
        if (r.chainId === t.chainId && (r.pairId.toLowerCase() === t.pairAddress.toLowerCase() || r.pairId.toLowerCase() === t.baseToken.address.toLowerCase())) {
            const s = o.data.priceUsd ? ? t.priceUsd;
            if (Ye(t)) {
                if (t.moonshot.progress >= 100) return t;
                const i = o.data.moonshot ? { ...t.moonshot,
                    ...o.data.moonshot
                } : t.moonshot;
                return { ...t,
                    moonshot: i,
                    priceUsd: s
                }
            }
            return { ...t,
                priceUsd: s
            }
        }
        return t
    })),
    bv = ({
        chainId: e,
        pairAddress: t,
        screenerPairs: o,
        initialData: r,
        children: s
    }) => {
        const i = xe(ni),
            a = xe(kn),
            l = xe(Os),
            c = xe(x0),
            d = xe(pi),
            u = xe($l),
            h = _n(z => z.embedSettings),
            [m, g] = f.useState(h.inverted ? ? !1),
            p = f.useCallback(() => g(z => !z), []);
        f.useEffect(() => g(h.inverted ? ? !1), [h.inverted]);
        const b = H0({
                screenerPairs: o,
                chainId: e,
                pairAddress: t
            }),
            j = sr(b),
            y = f.useMemo(() => ({
                chainId: e,
                pairId: t
            }), [e, t]),
            S = De(y),
            w = De(m),
            v = f.useMemo(() => new js(void 0), []),
            x = f.useCallback(z => {
                v.next({
                    data: z,
                    pairIdentity: S.current,
                    isInverted: w.current
                })
            }, [w, v, S]),
            [C, E] = f.useState(r != null && r.pair.pair ? Wt({
                data: r.pair.pair,
                status: "idle"
            }) : b ? Wt({
                data: b,
                status: "idle"
            }) : on),
            R = sr(C),
            B = sr(h.isEmbed && !h.info);
        mr(() => B.pipe(Qe(z => z ? To({
            data: void 0,
            status: "idle"
        }) : j.pipe(Qe(H => H ? Da(v, H).pipe(dt(oe => ({
            data: oe,
            status: "connected"
        }))) : c.getPair(y).pipe(Qe(oe => Da(v, oe.data).pipe(dt(re => ({
            data: re,
            status: oe.status
        })))))))), an({
            next: z => E(H => _f(H, z)),
            error: z => E(H => fr(H, z))
        })), [B, j, l, y, c, v]);
        const A = f.useMemo(() => new js(Wa(r == null ? void 0 : r.pairDetails)), [r == null ? void 0 : r.pairDetails]),
            P = fo(() => R.pipe(dt(z => z.kind === "AsyncSuccess" || z.kind === "AsyncPendingWithData" ? z.value.data : void 0), Ss(), an(z => {
                z || l.error({
                    event: {
                        id: "pairDetailNotFound",
                        data: { ...S.current
                        }
                    }
                })
            }), tr(ra), dt(z => ({
                chainId: z.chainId,
                pairId: z.pairAddress,
                isInverted: !1,
                isNewPair: d({
                    pair: z
                }).find(H => H.type === "new-pair") !== void 0,
                isMoonshot: Ye(z)
            })), sa(), ws, Qe(z => A.pipe(Qe(H => {
                const oe = N0({
                    type: H,
                    isNewPair: z.isNewPair,
                    isMoonshot: z.isMoonshot
                });
                return lr(H === "no-data" ? 0 : oe, oe).pipe(Qe(() => i.get(z)))
            })))), [R, l, S, d, A, i], r != null && r.pairDetails ? Wt(r.pairDetails) : void 0),
            D = fo(() => {
                const z = (r == null ? void 0 : r.trendingPairs) !== void 0 ? Fa : 0;
                return R.pipe(dt(H => be({
                    value: H,
                    onPending: () => null,
                    onFailure: () => null,
                    onSuccess: oe => {
                        var re;
                        return (re = oe.data) == null ? void 0 : re.dexId
                    }
                })), tr(H => H !== null), Ss(), Qe(H => lr(z, Fa).pipe(Qe(() => u.getPairs({
                    chainId: y.chainId,
                    dexId: H === "moonshot" ? H : void 0,
                    timeframeKey: Gc
                })))))
            }, [r == null ? void 0 : r.trendingPairs, R, u, y.chainId], r != null && r.trendingPairs ? Wt(r.trendingPairs) : void 0),
            O = f.useMemo(() => Nt(P, z => (z == null ? void 0 : z.su) ? ? void 0), [P]);
        f.useEffect(() => {
            be({
                value: P,
                onPending: () => {},
                onFailure: () => {},
                onSuccess: z => A.next(Wa(z))
            })
        }, [P, A]), mr(() => R.pipe(dt(z => z.kind === "AsyncSuccess" ? z.value.data : void 0), tr(ra), dt(z => ({
            chainId: z.chainId,
            dexId: z.dexId,
            pairAddress: z.pairAddress,
            isMoonshot: oi(z),
            isMoonshotBC: Ye(z),
            isMoonshotFinalized: oc(z)
        })), sa(), ws, an(z => {
            a.track({
                event: "pairDetail",
                data: z
            })
        })), [R, a]);
        const V = {
            pair: C,
            pairDetails: P,
            isInverted: m,
            invert: p,
            updatePairValues: x,
            trendingPairs: D,
            tokenSupplies: O,
            isMoonshot: be({
                value: C,
                onPending: () => !1,
                onFailure: () => !1,
                onSuccess: z => !!z.data && Ye(z.data)
            })
        };
        return n.jsx(_0, {
            value: V,
            children: s
        })
    },
    Kc = ({
        children: e,
        ...t
    }) => n.jsxs(Cs, { ...t,
        emoji: "⌛",
        title: "You're using an outdated version of DEX Screener",
        children: [n.jsxs(q, {
            children: ["Please", " ", n.jsx(ue, {
                variant: "link",
                onClick: () => window.location.reload(),
                colorScheme: "accent",
                children: "refresh this page"
            }), " ", "to update to the latest version"]
        }), e]
    }),
    [vv, O0] = nc("DEXScreenerPair"),
    U0 = e => {
        const t = xe(qu),
            o = xe(kn),
            r = "dexPair",
            s = `${e.pairIdentity.chainId}:${e.pairIdentity.pairId}`,
            [i, a] = f.useState({
                items: [{
                    stat: {
                        value: rn.Values.rocket
                    },
                    value: on
                }, {
                    stat: {
                        value: rn.Values.fire
                    },
                    value: on
                }, {
                    stat: {
                        value: rn.Values.poop
                    },
                    value: on
                }, {
                    stat: {
                        value: rn.Values.triangular_flag_on_post
                    },
                    value: on
                }]
            });
        mr(() => (a(gn(d => {
            for (const u of d.items) u.value = ia(u.value)
        })), t.getReactions({
            entityType: r,
            entityId: s
        }).pipe(an(d => {
            a(gn(u => {
                for (const h of u.items) h.value = Wt({
                    isSelected: d.userReaction.reaction === h.stat.value,
                    count: d.reactions[h.stat.value] ? ? {
                        total: 0
                    }
                })
            }))
        }), wa(d => (a(gn(u => {
            for (const h of u.items) h.value = fr(h.value, d)
        })), aa)))), [s, t]);
        const l = ri(d => d.pipe(an(u => {
                o.track({
                    event: "pairDetail:react"
                }), a(gn(h => {
                    for (const m of h.items) m.stat.value === u.value && (m.value = ia(m.value))
                }))
            }), Qe(u => t.createReaction({
                entityType: r,
                entityId: s,
                emoji: u.value
            }).pipe(an(h => {
                if (!h) {
                    a(gn(m => {
                        for (const g of m.items) g.value = Wt({
                            isSelected: !1,
                            count: {
                                total: 0
                            }
                        })
                    }));
                    return
                }
                a(gn(m => {
                    for (const g of m.items) g.value = Wt({
                        isSelected: h.userReaction.reaction === g.stat.value,
                        count: h.reactions[g.stat.value] ? ? {
                            total: 0
                        }
                    })
                }))
            }), wa(h => (a(gn(m => {
                for (const g of m.items) g.stat.value === u.value && (g.value = fr(g.value, h))
            })), aa))))), [o, s, t]),
            c = i.items.every(d => be({
                value: d.value,
                onPending: vn,
                onPendingWithData: Mn,
                onFailure: vn,
                onSuccess: u => !u.isSelected
            }));
        return {
            state: i,
            isInteractive: c,
            react: l
        }
    },
    V0 = e => {
        const {
            data: t,
            pair: o,
            onClose: r,
            onOpen: s
        } = e, {
            value: i,
            toggle: a
        } = Yt(!1), l = xe(ni), c = De(be({
            value: t,
            onPending: () => !1,
            onFailure: () => !1,
            onSuccess: () => !0
        })), d = De(i), u = f.useCallback(() => {
            c.current !== !1 && (d.current ? r == null || r() : s == null || s(), a())
        }, [c, a, d, r, s]);
        return be({
            value: t,
            onPending: () => ({
                state: "pending"
            }),
            onFailure: () => ({
                state: "failure"
            }),
            onSuccess: h => {
                if (!h) return {
                    state: "notAvailable"
                };
                const {
                    result: m,
                    auditValues: g
                } = l.validateGoPlus(h);
                return {
                    state: "success",
                    data: h,
                    pairIdentity: o,
                    validationResult: m,
                    auditValues: g,
                    issuesCount: m.filter(p => p.status === "error" || p.status === "warning").length,
                    isOpen: i,
                    toggleCollapse: u
                }
            }
        })
    },
    X0 = e => {
        const {
            data: t,
            pair: o,
            onClose: r,
            onOpen: s
        } = e, {
            value: i,
            toggle: a
        } = Yt(!1), l = xe(ni), c = De(be({
            value: t,
            onPending: () => !1,
            onFailure: () => !1,
            onSuccess: () => !0
        })), d = De(i), u = f.useCallback(() => {
            c.current !== !1 && (d.current ? r == null || r() : s == null || s(), a())
        }, [c, a, d, r, s]);
        return be({
            value: t,
            onPending: () => ({
                state: "pending"
            }),
            onFailure: () => ({
                state: "failure"
            }),
            onSuccess: h => {
                if (!h) return {
                    state: "notAvailable"
                };
                const {
                    result: m,
                    auditValues: g
                } = l.validateQuickIntel(h);
                return {
                    state: "success",
                    data: h,
                    pairIdentity: o,
                    auditValues: g,
                    validationResult: m,
                    issuesCount: m.filter(p => p.status === "error" || p.status === "warning").length,
                    isOpen: i,
                    toggleCollapse: u
                }
            }
        })
    },
    q0 = ({
        chain: e
    }) => {
        const t = f.useMemo(() => {
                var r, s, i, a, l, c, d, u;
                return {
                    goPlus: {
                        isEnabled: ((s = (r = e == null ? void 0 : e.integrations) == null ? void 0 : r.goPlus) == null ? void 0 : s.isEnabled) === !0
                    },
                    tokenSniffer: {
                        isEnabled: ((a = (i = e == null ? void 0 : e.integrations) == null ? void 0 : i.tokenSniffer) == null ? void 0 : a.isEnabled) === !0,
                        networkId: (c = (l = e == null ? void 0 : e.integrations) == null ? void 0 : l.tokenSniffer) == null ? void 0 : c.networkId
                    },
                    quickIntel: {
                        isEnabled: ((u = (d = e == null ? void 0 : e.integrations) == null ? void 0 : d.quickIntel) == null ? void 0 : u.isEnabled) === !0
                    }
                }
            }, [e]),
            o = f.useMemo(() => t.tokenSniffer.isEnabled || t.goPlus.isEnabled || t.quickIntel.isEnabled, [t]);
        return {
            tokenSecuritySupport: t,
            isSecurityAnalysisVisible: o
        }
    },
    G0 = e => {
        const {
            networkId: t,
            data: o,
            tokenAddress: r
        } = e, s = Ec({
            networkId: t,
            tokenAddress: r
        }).toString();
        return be({
            value: o,
            onPending: () => ({
                state: "pending",
                tokenURL: s
            }),
            onFailure: () => ({
                state: "failure",
                tokenURL: s
            }),
            onSuccess: i => i ? i.status === "pending" ? {
                state: "pendingAnalysis",
                tokenURL: s
            } : {
                state: "success",
                data: i,
                tokenURL: s
            } : {
                state: "notAvailable",
                tokenURL: s
            }
        })
    };

function Qc(e, t, o) {
    return Sn(gr(e, "UNKNOWN_BREAKPOINT") ? ? t, o)
}

function Hr() {
    return Qc({
        base: !1,
        lg: !0
    }, !0, !0)
}

function K0(e) {
    return Kn({
        tag: "svg",
        attr: {
            viewBox: "0 0 256 256",
            fill: "currentColor"
        },
        child: [{
            tag: "path",
            attr: {
                d: "M216,56v60a4,4,0,0,1-4,4H44a4,4,0,0,1-4-4V56A16,16,0,0,1,56,40H200A16,16,0,0,1,216,56Zm-4,80H44a4,4,0,0,0-4,4v60a16,16,0,0,0,16,16H200a16,16,0,0,0,16-16V140A4,4,0,0,0,212,136Z"
            }
        }]
    })(e)
}
const $c = 50,
    no = ({
        variant: e,
        label: t,
        labelFontSize: o,
        icon: r,
        iconSize: s,
        iconSpacing: i,
        pt: a,
        onClick: l,
        isActive: c,
        grow: d,
        newIndicator: u
    }) => n.jsxs(ue, {
        pos: "relative",
        onClick: l,
        variant: "unstyled",
        borderRadius: "none",
        fontSize: o,
        flex: "auto",
        pt: a,
        flexDir: e === "vertical" ? "column" : "row",
        height: "100%",
        leftIcon: n.jsx(L, {
            as: r,
            minH: "16px",
            boxSize: s.base,
            sx: e === "horizontal" ? {
                "@media (max-width: 330px)": {
                    boxSize: s.xs
                }
            } : void 0
        }),
        iconSpacing: e === "vertical" ? 0 : i ? ? "3px",
        display: "flex",
        alignItems: "center",
        bg: c ? "accent.600" : "transparent",
        color: "white",
        borderRightWidth: 1,
        borderColor: "transparent",
        sx: {
            "&:not(:last-of-type)": {
                borderColor: "gray.900"
            },
            "@media (max-width: 330px)": {
                fontSize: "sm"
            }
        },
        flexGrow: d ? ? 1,
        children: [t, u && n.jsx(k, {
            pos: "absolute",
            top: "4px",
            right: "2px",
            bg: "accent.lightGreen",
            color: "blackAlpha.800",
            fontSize: "8px",
            px: "2px",
            py: "1px",
            borderRadius: "md",
            children: "new!"
        })]
    }),
    Q0 = f.memo(e => {
        const {
            includesInfo: t,
            includesChart: o,
            includesTxns: r,
            includesChat: s,
            tabId: i,
            onTabIdChange: a
        } = e, {
            setSettings: l,
            toggleMobileChartOrTxnsVisible: c,
            isMobileChartOrTxnsVisible: d
        } = $t(Tn), u = m => {
            if (i !== m) switch (a(m), m) {
                case "info":
                    {
                        d && c();
                        break
                    }
                case "chartTxns":
                    {
                        d || c(),
                        l({
                            chart: !0,
                            trades: !0
                        });
                        break
                    }
                case "chart":
                    {
                        d || c(),
                        l({
                            chart: !0,
                            trades: !1
                        });
                        break
                    }
                case "txns":
                    {
                        d || c(),
                        l({
                            chart: !1,
                            trades: !0
                        });
                        break
                    }
                case "chat":
                    {
                        d && c();
                        break
                    }
            }
        }, h = s ? "vertical" : "horizontal";
        return n.jsxs(I, {
            display: {
                base: "flex",
                lg: "none"
            },
            alignItems: "center",
            flexShrink: 0,
            w: "100%",
            h: `${$c}px`,
            bg: "gray.975",
            children: [t && n.jsx(no, {
                variant: h,
                label: "Info",
                icon: Ao,
                iconSize: {
                    base: "17px",
                    xs: "13px"
                },
                pt: "2px",
                onClick: () => u("info"),
                isActive: i === "info"
            }), o && r && n.jsx(no, {
                variant: h,
                label: "Chart+Txns",
                icon: K0,
                iconSize: {
                    base: "19px",
                    xs: "14px"
                },
                onClick: () => u("chartTxns"),
                isActive: i === "chartTxns",
                grow: s ? .33 : void 0
            }), o && n.jsx(no, {
                variant: h,
                label: "Chart",
                icon: rc,
                iconSize: {
                    base: "18px",
                    xs: "14px"
                },
                onClick: () => u("chart"),
                isActive: i === "chart"
            }), r && n.jsx(no, {
                variant: h,
                label: "Txns",
                icon: Gu,
                iconSize: {
                    base: "13px",
                    xs: "11px"
                },
                iconSpacing: "4px",
                onClick: () => u("txns"),
                isActive: i === "txns"
            }), s && n.jsx(no, {
                variant: h,
                label: "Chat",
                icon: ks,
                iconSize: {
                    base: "13px",
                    xs: "11px"
                },
                iconSpacing: "4px",
                onClick: () => u("chat"),
                isActive: i === "chat",
                newIndicator: !0
            })]
        })
    }),
    Ms = ({
        children: e,
        icon: t,
        iconProps: o,
        href: r,
        ...s
    }) => n.jsxs(n.Fragment, {
        children: [e && n.jsx(ue, {
            as: we,
            href: r,
            target: "_blank",
            rel: "noopener noreferrer",
            leftIcon: n.jsx(L, {
                as: t ? ? yt,
                ...o
            }),
            textDecoration: "none !important",
            fontWeight: "normal",
            iconSpacing: e ? void 0 : 0,
            ...s,
            children: e
        }), !e && n.jsx(Je, {
            as: we,
            "aria-label": "External Link",
            href: r,
            target: "_blank",
            rel: "noopener noreferrer",
            icon: n.jsx(L, {
                as: t ? ? yt
            }),
            textDecoration: "none !important",
            iconSpacing: e ? void 0 : 0,
            ...s
        })]
    }),
    Yc = ({
        children: e,
        labelContainerProps: t,
        ...o
    }) => {
        const [r, s] = f.useState(!1);
        return n.jsx(St, {
            isOpen: o.isDisabled ? void 0 : r,
            bg: "gray.950",
            borderColor: "gray.975",
            color: "white",
            ...o,
            children: n.jsx(I, {
                onMouseEnter: () => s(!0),
                onMouseLeave: () => s(!1),
                onClick: () => s(!0),
                ...t,
                children: e
            })
        })
    },
    La = {
        py: "2px"
    },
    Rn = {
        height: "8px",
        borderRadius: "100px"
    },
    wn = ({
        left: e,
        right: t,
        isJoined: o,
        disableTooltip: r,
        invert: s,
        containerProps: i
    }) => {
        const {
            colorMode: a
        } = pe(), l = e.value + t.value;
        if (l === 0) return n.jsx(n.Fragment, {
            children: n.jsx(I, {
                display: "flex",
                w: "100%",
                h: Rn.height,
                borderRadius: Rn.borderRadius,
                py: La.py,
                ...i,
                children: n.jsx(I, {
                    w: "100%",
                    bg: T("gray.100", "gray.825", a),
                    borderRadius: Rn.borderRadius
                })
            })
        });
        let c = Math.floor((s ? t.value : e.value) * 100 / l);
        c === 0 && e.value > 0 && (c = 1);
        const d = Ct({
                number: c,
                significantDigits: 0,
                maxDecimalPrecision: 0
            }),
            u = Ct({
                number: 100 - c,
                significantDigits: 0,
                maxDecimalPrecision: 0
            });
        return n.jsx(Yc, {
            w: "100%",
            bg: T("white", "gray.950", a),
            borderWidth: 1,
            borderColor: T("gray.75", "gray.975", a),
            color: "white",
            label: n.jsxs(q, {
                display: "flex",
                flexDir: "column",
                textAlign: "center",
                children: [n.jsx(q, {
                    as: "span",
                    color: "accent.lightGreen",
                    fontWeight: "semibold",
                    children: `${d}% ${e.label}`
                }), n.jsx(q, {
                    mt: 1,
                    as: "span",
                    color: "accent.red",
                    fontWeight: "semibold",
                    children: `${u}% ${t.label}`
                })]
            }),
            placement: "bottom-start",
            isDisabled: r,
            children: n.jsxs(K, {
                w: "100%",
                alignItems: "stretch",
                spacing: o ? "0" : "2px",
                h: Rn.height,
                py: La.py,
                ...i,
                children: [c > 0 && n.jsx(I, {
                    bg: e.bg ? ? "accent.lightGreen",
                    w: `${c}%`,
                    minW: "4%",
                    maxW: c < 100 ? "96%" : void 0,
                    flexShrink: 0,
                    borderRadius: Rn.borderRadius,
                    borderRightRadius: o ? 0 : void 0
                }), c < 100 && n.jsx(I, {
                    bg: t.bg ? ? "accent.red",
                    flex: 1,
                    borderRadius: Rn.borderRadius,
                    borderLeftRadius: o && c > 0 ? 0 : void 0
                })]
            })
        })
    },
    Kt = () => n.jsx(q, {
        as: "span",
        color: ee("gray.300", "gray.600"),
        fontWeight: "normal",
        children: "N/A"
    }),
    $0 = {
        borderless: {
            borderWidth: 0,
            padding: 0,
            textAlign: void 0,
            alignItems: "flex-start"
        },
        outline: {
            borderWidth: 1,
            paddingX: "5px",
            paddingY: "3px",
            textAlign: "center"
        }
    },
    Zc = ({
        children: e,
        label: t,
        labelProps: o,
        tooltipProps: r,
        variant: s = "borderless",
        ...i
    }) => {
        const {
            colorMode: a
        } = pe();
        return n.jsxs(he, {
            borderColor: T("gray.75", "blue.900", a),
            borderRadius: "md",
            spacing: "2px",
            flex: 1,
            alignItems: "stretch",
            ...$0[s],
            ...i,
            children: [t && n.jsx(gi, {
                if: r !== void 0,
                with: l => n.jsx(Yc, {
                    fontSize: "xs",
                    textAlign: "center",
                    labelContainerProps: {
                        lineHeight: "14px"
                    },
                    ...r,
                    children: l
                }),
                children: n.jsx(q, {
                    as: "span",
                    fontSize: "xs",
                    fontWeight: "normal",
                    mt: "1px",
                    lineHeight: "14px",
                    color: T("gray.350", "gray.525", a),
                    textTransform: "uppercase",
                    ...r !== void 0 ? {
                        cursor: "help",
                        borderBottomWidth: 1,
                        borderBottomColor: T("gray.300", "gray.600", a),
                        borderBottomStyle: "dashed"
                    } : void 0,
                    ...o,
                    children: t
                })
            }), e ? ? n.jsx(Kt, {})]
        })
    },
    rt = ({
        children: e,
        label: t,
        labelProps: o,
        tooltipProps: r,
        fontSize: s,
        variant: i = "borderless",
        ...a
    }) => n.jsx(Zc, {
        variant: i,
        label: t,
        labelProps: o,
        tooltipProps: r,
        ...a,
        children: e && n.jsx(q, {
            as: "span",
            fontSize: s,
            children: e
        })
    }),
    Na = "57px 57px auto",
    Y0 = ({
        pair: e,
        isInverted: t
    }) => {
        const o = _n(h => h.pairDetailTimeframeKey),
            {
                setPairDetailTimeframeKey: r
            } = _n(h => h.actions),
            s = ee("gray.100", "blue.850"),
            i = ee("gray.50", "blue.950"),
            a = ee("gray.100", "blue.850"),
            l = ee("gray.500", "blue.500"),
            c = ee("black", "white"),
            d = s,
            u = s;
        return n.jsxs(Ci, {
            variant: "unstyled",
            size: "sm",
            defaultIndex: {
                m5: 0,
                h1: 1,
                h6: 2,
                h24: 3
            }[o],
            onChange: h => {
                const m = {
                    0: "m5",
                    1: "h1",
                    2: "h6",
                    3: "h24"
                }[h];
                m !== void 0 && r(m)
            },
            isLazy: !0,
            children: [n.jsx(ki, {
                justifyContent: "space-between",
                children: la.map(h => n.jsx(Ti, {
                    px: 0,
                    py: "5px",
                    flex: 1,
                    textTransform: "uppercase",
                    fontSize: "xs",
                    borderWidth: 1,
                    borderBottomWidth: 0,
                    borderColor: s,
                    color: l,
                    _hover: {
                        bg: i
                    },
                    _selected: {
                        bg: a,
                        fontWeight: "semibold",
                        color: c,
                        _hover: {}
                    },
                    _focus: {
                        boxShadow: "none"
                    },
                    sx: {
                        "&:not(:last-of-type)": {
                            borderRightWidth: 0
                        },
                        "&:first-of-type": {
                            borderTopLeftRadius: "base"
                        },
                        "&:last-of-type": {
                            borderTopRightRadius: "base"
                        }
                    },
                    children: n.jsxs(Ae, {
                        flexDir: "column",
                        children: [n.jsx(k, {
                            children: Zl[h].shorthand
                        }), n.jsx(k, {
                            fontWeight: "semibold",
                            fontSize: "md",
                            children: n.jsx(ur, {
                                colorScheme: "accent",
                                value: t ? null : e.priceChange[h],
                                empty: n.jsx(Kt, {})
                            })
                        })]
                    })
                }, h))
            }), n.jsx(Oc, {
                children: la.map(h => {
                    var p, b, j, y, S, w, v, x, C;
                    const m = (p = e.volumeBuy) == null ? void 0 : p[h],
                        g = (b = e.volumeSell) == null ? void 0 : b[h];
                    return n.jsxs(_c, {
                        m: 0,
                        display: "flex",
                        pl: "10px",
                        pr: "12px",
                        py: "12px",
                        borderWidth: 1,
                        borderColor: d,
                        borderBottomLeftRadius: "base",
                        borderBottomRightRadius: "base",
                        children: [n.jsxs(I, {
                            display: "grid",
                            gridTemplateRows: Na,
                            minW: "27%",
                            flexShrink: 0,
                            pr: 1,
                            mr: 4,
                            borderRightWidth: 1,
                            borderColor: u,
                            children: [n.jsx(rt, {
                                label: "Txns",
                                fontSize: "lg",
                                fontWeight: "semibold",
                                children: Gt(e.txns[h].buys + e.txns[h].sells)
                            }), n.jsxs(rt, {
                                label: "Volume",
                                fontSize: "lg",
                                fontWeight: "semibold",
                                children: [e.volume[h] && xn(e.volume[h] ? ? 0), !e.volume[h] && n.jsx(Kt, {})]
                            }), n.jsx(rt, {
                                label: "Makers",
                                tooltipProps: {
                                    label: "Unique wallets that bought or sold this pair"
                                },
                                labelProps: {
                                    mb: "2px"
                                },
                                fontSize: "lg",
                                fontWeight: "semibold",
                                children: Gt(((j = e.makers) == null ? void 0 : j[h]) ? ? 0)
                            })]
                        }), n.jsxs(I, {
                            flex: 1,
                            display: "grid",
                            gridTemplateRows: Na,
                            children: [n.jsxs(I, {
                                children: [n.jsxs(I, {
                                    display: "grid",
                                    gridTemplateColumns: "1fr 1fr",
                                    gridGap: 1,
                                    children: [n.jsx(rt, {
                                        label: "Buys",
                                        children: Gt(t ? e.txns[h].sells : e.txns[h].buys)
                                    }), n.jsx(rt, {
                                        label: "Sells",
                                        alignItems: "flex-end",
                                        children: Gt(t ? e.txns[h].buys : e.txns[h].sells)
                                    })]
                                }), n.jsx(wn, {
                                    left: {
                                        label: "buys",
                                        value: e.txns[h].buys
                                    },
                                    right: {
                                        label: "sells",
                                        value: e.txns[h].sells
                                    },
                                    invert: t
                                })]
                            }), n.jsxs(I, {
                                children: [n.jsxs(I, {
                                    display: "grid",
                                    gridTemplateColumns: "1fr 1fr",
                                    gridGap: 1,
                                    children: [n.jsxs(rt, {
                                        label: "Buy Vol",
                                        children: [!t && (m ? xn(m) : n.jsx(Kt, {})), t && (g ? xn(g) : n.jsx(Kt, {}))]
                                    }), n.jsxs(rt, {
                                        label: "Sell Vol",
                                        alignItems: "flex-end",
                                        children: [!t && (g ? xn(g) : n.jsx(Kt, {})), t && (m ? xn(m) : n.jsx(Kt, {}))]
                                    })]
                                }), n.jsx(wn, {
                                    left: {
                                        label: "buy volume",
                                        value: m ? ? 0
                                    },
                                    right: {
                                        label: "sell volume",
                                        value: g ? ? 0
                                    },
                                    invert: t,
                                    containerProps: {
                                        gridColumn: "span 2"
                                    }
                                })]
                            }), n.jsxs(I, {
                                children: [n.jsxs(I, {
                                    display: "grid",
                                    gridTemplateColumns: "1fr 1fr",
                                    gridGap: 1,
                                    children: [n.jsx(rt, {
                                        label: "Buyers",
                                        children: Gt((t ? (S = e.sellers) == null ? void 0 : S[h] : (y = e.buyers) == null ? void 0 : y[h]) ? ? 0)
                                    }), n.jsx(rt, {
                                        label: "Sellers",
                                        alignItems: "flex-end",
                                        children: Gt((t ? (v = e.buyers) == null ? void 0 : v[h] : (w = e.sellers) == null ? void 0 : w[h]) ? ? 0)
                                    })]
                                }), n.jsx(wn, {
                                    left: {
                                        label: "buyers",
                                        value: ((x = e.buyers) == null ? void 0 : x[h]) ? ? 0
                                    },
                                    right: {
                                        label: "sellers",
                                        value: ((C = e.sellers) == null ? void 0 : C[h]) ? ? 0
                                    },
                                    invert: t,
                                    containerProps: {
                                        gridColumn: "span 2"
                                    }
                                })]
                            })]
                        })]
                    }, h)
                })
            })]
        })
    },
    Z0 = f.memo(({
        platformId: e,
        pairAddress: t
    }) => {
        const {
            state: o,
            react: r,
            isInteractive: s
        } = U0({
            pairIdentity: {
                chainId: e,
                pairId: t
            }
        }), {
            colorMode: i
        } = pe();
        return n.jsx(Tr, {
            w: "100%",
            spacing: 2,
            children: o.items.map(a => {
                const l = be({
                        value: a.value,
                        onPendingWithData: vn,
                        onPending: Mn,
                        onFailure: Mn,
                        onSuccess: Mn
                    }),
                    c = be({
                        value: a.value,
                        onPending: Mn,
                        onFailure: Mn,
                        onSuccess: u => u.isSelected
                    }),
                    d = be({
                        value: a.value,
                        onPending: () => .7,
                        onPendingWithData: () => .7,
                        onFailure: ln,
                        onSuccess: ln
                    });
                return n.jsx(ue, {
                    flex: 1,
                    variant: "outline",
                    fontWeight: "normal",
                    paddingY: 2,
                    height: "auto",
                    _focus: {
                        boxShadow: "none"
                    },
                    isLoading: l,
                    pointerEvents: s ? void 0 : "none",
                    opacity: d,
                    onClick: () => r(a.stat),
                    sx: c ? {
                        bg: T("gray.50", "blue.850", i),
                        fontWeight: "bold",
                        _active: {}
                    } : void 0,
                    children: n.jsxs(he, {
                        spacing: 1,
                        children: [n.jsxs(q, {
                            as: "span",
                            children: [a.stat.value === rn.Values.rocket && n.jsx(i0, {
                                width: 20,
                                height: 20
                            }), a.stat.value === rn.Values.fire && n.jsx(r0, {
                                width: 20,
                                height: 20
                            }), a.stat.value === rn.Values.poop && n.jsx(s0, {
                                width: 20,
                                height: 20
                            }), a.stat.value === rn.Values.triangular_flag_on_post && n.jsx(Vc, {
                                width: 20,
                                height: 20
                            })]
                        }), n.jsx(q, {
                            as: "span",
                            children: be({
                                value: a.value,
                                onPending: () => "-",
                                onFailure: () => "-",
                                onSuccess: u => u.count.total.toLocaleString()
                            })
                        })]
                    })
                }, a.stat.value)
            })
        })
    }),
    J0 = ({
        pair: e,
        containerProps: t
    }) => {
        const {
            colorMode: o
        } = pe();
        return sc({
            chainId: e.chainId,
            tokenAddress: e.baseToken.address
        }) ? n.jsx(St, {
            label: "Recently advertised on DEX Screener!",
            "aria-label": "Recently advertised on DEX Screener!",
            children: n.jsxs(Ae, {
                color: T("accent.darkGreen", "accent.lightGreen", o),
                fontSize: "xs",
                fontWeight: "semibold",
                ...t,
                children: [n.jsx(L, {
                    as: mi,
                    mr: "2px"
                }), "Ads"]
            })
        }) : null
    },
    em = ({
        labels: e
    }) => n.jsx(K, {
        spacing: "1",
        children: e.map(t => n.jsx(I, {
            as: "span",
            children: n.jsx(hf, {
                fontSize: "2xs",
                children: t
            })
        }, t))
    }),
    tm = ({
        baseToken: e,
        pair: t,
        quoteToken: o
    }) => {
        const {
            isEmbed: r
        } = _n(c => c.embedSettings), s = ic(t.dexId), {
            trending: i,
            isMoonshot: a
        } = Zt(({
            trendingPairs: c,
            isMoonshot: d
        }) => ({
            trending: c,
            isMoonshot: d
        })), l = f.useMemo(() => {
            if (!("value" in i) || !i.value) return;
            const c = i.value.findIndex(d => d.pairAddress === t.pairAddress);
            if (c >= 0) return c + 1
        }, [i, t.pairAddress]);
        return {
            baseToken: e,
            dex: s,
            isEmbed: r,
            pair: t,
            quoteToken: o,
            trendingRank: l,
            isMoonshot: a
        }
    },
    nm = e => {
        const {
            colorMode: t
        } = pe(), [, o] = Ar(), r = Qn(), {
            dex: s,
            pair: i,
            isEmbed: a,
            quoteToken: l,
            baseToken: c,
            trendingRank: d,
            isMoonshot: u
        } = tm(e), h = () => {
            o(c.address), r({
                status: "success",
                description: "Address copied to clipboard!",
                isClosable: !0
            })
        }, m = xe(Ir), g = xe(Ku), p = ac(i.chainId), b = lc(i.dexId), j = Er(i.chainId);
        return n.jsxs(he, {
            spacing: "3px",
            children: [n.jsxs(K, {
                width: "100%",
                justifyContent: "center",
                children: [n.jsxs(Lt, {
                    display: "flex",
                    justifyContent: "center",
                    size: "md",
                    textAlign: "center",
                    overflow: "hidden",
                    fontWeight: "semibold",
                    children: [n.jsxs(k, {
                        onClick: h,
                        display: "flex",
                        alignItems: "center",
                        _hover: {
                            cursor: "pointer",
                            svg: {
                                opacity: 1
                            }
                        },
                        children: [n.jsx(q, {
                            as: "span",
                            whiteSpace: "nowrap",
                            textOverflow: "ellipsis",
                            overflow: "hidden",
                            fontWeight: "bold",
                            children: c.symbol
                        }), n.jsx(L, {
                            as: si,
                            ml: "3px",
                            fontSize: "xs",
                            opacity: .4,
                            transition: "opacity 0.1s",
                            title: "Copy token address"
                        })]
                    }), n.jsx(q, {
                        as: "span",
                        mx: "1.5",
                        opacity: .8,
                        children: "/"
                    }), n.jsx(q, {
                        as: "span",
                        whiteSpace: "nowrap",
                        textOverflow: "ellipsis",
                        overflow: "hidden",
                        children: l.symbol
                    })]
                }), n.jsx(Ai, {
                    pairCreatedAt: i.pairCreatedAt
                }), d !== void 0 && n.jsxs(Ae, {
                    color: T("accent.orangeDark", "accent.orangeLight", t),
                    fontSize: "xs",
                    fontWeight: "semibold",
                    fontFamily: "mono",
                    children: [n.jsx(L, {
                        as: Js,
                        mr: "3px"
                    }), "#", d]
                }), n.jsx(J0, {
                    pair: i
                }), oc(i) && n.jsx(k, {
                    color: "moonshot.accent.text",
                    children: n.jsx(Dn, {
                        width: "12px",
                        height: "12px"
                    })
                })]
            }), n.jsxs(Ro, {
                as: "div",
                align: "center",
                spacing: "6px",
                color: T("gray.500", "blue.350", t),
                children: [n.jsxs(to, {
                    as: nr,
                    to: ca({
                        platformId: i.chainId
                    }),
                    display: "flex",
                    alignItems: "center",
                    ...a ? {
                        target: "_blank",
                        rel: "noopener noreferrer"
                    } : void 0,
                    children: [n.jsx(Ze, {
                        src: m(i.chainId),
                        w: "16px",
                        h: "16px",
                        mr: 1,
                        loading: "lazy"
                    }), p]
                }), !(j != null && j.isChainAndDEX) && n.jsxs(n.Fragment, {
                    children: [n.jsx(to, {
                        as: "span",
                        children: n.jsx(L, {
                            as: ti,
                            boxSize: "10px"
                        })
                    }), u ? n.jsxs(to, {
                        as: nr,
                        to: "/moonshot",
                        alignItems: "center",
                        ...a ? {
                            target: "_blank",
                            rel: "noopener noreferrer"
                        } : void 0,
                        children: [n.jsx(k, {
                            color: "moonshot.accent.text",
                            children: n.jsx(Dn, {
                                width: "1em",
                                height: "1em"
                            })
                        }), n.jsx(k, {
                            ml: 1,
                            children: "Moonshot"
                        })]
                    }) : n.jsxs(to, {
                        as: nr,
                        to: s !== void 0 ? ca({
                            platformId: i.chainId,
                            dexId: s.slug
                        }) : `/${i.chainId}/f:${i.dexId}`,
                        display: "flex",
                        alignItems: "center",
                        ...a ? {
                            target: "_blank",
                            rel: "noopener noreferrer"
                        } : void 0,
                        children: [n.jsx(Ze, {
                            src: g(i.dexId),
                            w: "16px",
                            h: "16px",
                            mr: 1,
                            loading: "lazy"
                        }), b]
                    })]
                }), i.labels && i.labels.length > 0 && n.jsx(to, {
                    textAlign: "center",
                    wordBreak: "break-word",
                    children: n.jsx(em, {
                        labels: i.labels
                    })
                })]
            })]
        })
    };
var om = function() {
        var e = function(t, o) {
            return e = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(r, s) {
                r.__proto__ = s
            } || function(r, s) {
                for (var i in s) Object.prototype.hasOwnProperty.call(s, i) && (r[i] = s[i])
            }, e(t, o)
        };
        return function(t, o) {
            e(t, o);

            function r() {
                this.constructor = t
            }
            t.prototype = o === null ? Object.create(o) : (r.prototype = o.prototype, new r)
        }
    }(),
    Xe = function() {
        return Xe = Object.assign || function(e) {
            for (var t, o = 1, r = arguments.length; o < r; o++) {
                t = arguments[o];
                for (var s in t) Object.prototype.hasOwnProperty.call(t, s) && (e[s] = t[s])
            }
            return e
        }, Xe.apply(this, arguments)
    },
    Ha = {
        width: "100%",
        height: "10px",
        top: "0px",
        left: "0px",
        cursor: "row-resize"
    },
    _a = {
        width: "10px",
        height: "100%",
        top: "0px",
        left: "0px",
        cursor: "col-resize"
    },
    Xo = {
        width: "20px",
        height: "20px",
        position: "absolute"
    },
    rm = {
        top: Xe(Xe({}, Ha), {
            top: "-5px"
        }),
        right: Xe(Xe({}, _a), {
            left: void 0,
            right: "-5px"
        }),
        bottom: Xe(Xe({}, Ha), {
            top: void 0,
            bottom: "-5px"
        }),
        left: Xe(Xe({}, _a), {
            left: "-5px"
        }),
        topRight: Xe(Xe({}, Xo), {
            right: "-10px",
            top: "-10px",
            cursor: "ne-resize"
        }),
        bottomRight: Xe(Xe({}, Xo), {
            right: "-10px",
            bottom: "-10px",
            cursor: "se-resize"
        }),
        bottomLeft: Xe(Xe({}, Xo), {
            left: "-10px",
            bottom: "-10px",
            cursor: "sw-resize"
        }),
        topLeft: Xe(Xe({}, Xo), {
            left: "-10px",
            top: "-10px",
            cursor: "nw-resize"
        })
    },
    sm = function(e) {
        om(t, e);

        function t() {
            var o = e !== null && e.apply(this, arguments) || this;
            return o.onMouseDown = function(r) {
                o.props.onResizeStart(r, o.props.direction)
            }, o.onTouchStart = function(r) {
                o.props.onResizeStart(r, o.props.direction)
            }, o
        }
        return t.prototype.render = function() {
            return f.createElement("div", {
                className: this.props.className || "",
                style: Xe(Xe({
                    position: "absolute",
                    userSelect: "none"
                }, rm[this.props.direction]), this.props.replaceStyles || {}),
                onMouseDown: this.onMouseDown,
                onTouchStart: this.onTouchStart
            }, this.props.children)
        }, t
    }(f.PureComponent),
    im = function() {
        var e = function(t, o) {
            return e = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(r, s) {
                r.__proto__ = s
            } || function(r, s) {
                for (var i in s) Object.prototype.hasOwnProperty.call(s, i) && (r[i] = s[i])
            }, e(t, o)
        };
        return function(t, o) {
            e(t, o);

            function r() {
                this.constructor = t
            }
            t.prototype = o === null ? Object.create(o) : (r.prototype = o.prototype, new r)
        }
    }(),
    Bt = function() {
        return Bt = Object.assign || function(e) {
            for (var t, o = 1, r = arguments.length; o < r; o++) {
                t = arguments[o];
                for (var s in t) Object.prototype.hasOwnProperty.call(t, s) && (e[s] = t[s])
            }
            return e
        }, Bt.apply(this, arguments)
    },
    am = {
        width: "auto",
        height: "auto"
    },
    qo = function(e, t, o) {
        return Math.max(Math.min(e, o), t)
    },
    Oa = function(e, t) {
        return Math.round(e / t) * t
    },
    zn = function(e, t) {
        return new RegExp(e, "i").test(t)
    },
    Go = function(e) {
        return !!(e.touches && e.touches.length)
    },
    lm = function(e) {
        return !!((e.clientX || e.clientX === 0) && (e.clientY || e.clientY === 0))
    },
    Ua = function(e, t, o) {
        o === void 0 && (o = 0);
        var r = t.reduce(function(i, a, l) {
                return Math.abs(a - e) < Math.abs(t[i] - e) ? l : i
            }, 0),
            s = Math.abs(t[r] - e);
        return o === 0 || s < o ? t[r] : e
    },
    as = function(e) {
        return e = e.toString(), e === "auto" || e.endsWith("px") || e.endsWith("%") || e.endsWith("vh") || e.endsWith("vw") || e.endsWith("vmax") || e.endsWith("vmin") ? e : e + "px"
    },
    Ko = function(e, t, o, r) {
        if (e && typeof e == "string") {
            if (e.endsWith("px")) return Number(e.replace("px", ""));
            if (e.endsWith("%")) {
                var s = Number(e.replace("%", "")) / 100;
                return t * s
            }
            if (e.endsWith("vw")) {
                var s = Number(e.replace("vw", "")) / 100;
                return o * s
            }
            if (e.endsWith("vh")) {
                var s = Number(e.replace("vh", "")) / 100;
                return r * s
            }
        }
        return e
    },
    cm = function(e, t, o, r, s, i, a) {
        return r = Ko(r, e.width, t, o), s = Ko(s, e.height, t, o), i = Ko(i, e.width, t, o), a = Ko(a, e.height, t, o), {
            maxWidth: typeof r > "u" ? void 0 : Number(r),
            maxHeight: typeof s > "u" ? void 0 : Number(s),
            minWidth: typeof i > "u" ? void 0 : Number(i),
            minHeight: typeof a > "u" ? void 0 : Number(a)
        }
    },
    dm = ["as", "style", "className", "grid", "snap", "bounds", "boundsByDirection", "size", "defaultSize", "minWidth", "minHeight", "maxWidth", "maxHeight", "lockAspectRatio", "lockAspectRatioExtraWidth", "lockAspectRatioExtraHeight", "enable", "handleStyles", "handleClasses", "handleWrapperStyle", "handleWrapperClass", "children", "onResizeStart", "onResize", "onResizeStop", "handleComponent", "scale", "resizeRatio", "snapGap"],
    Va = "__resizable_base__",
    Jc = function(e) {
        im(t, e);

        function t(o) {
            var r = e.call(this, o) || this;
            return r.ratio = 1, r.resizable = null, r.parentLeft = 0, r.parentTop = 0, r.resizableLeft = 0, r.resizableRight = 0, r.resizableTop = 0, r.resizableBottom = 0, r.targetLeft = 0, r.targetTop = 0, r.appendBase = function() {
                if (!r.resizable || !r.window) return null;
                var s = r.parentNode;
                if (!s) return null;
                var i = r.window.document.createElement("div");
                return i.style.width = "100%", i.style.height = "100%", i.style.position = "absolute", i.style.transform = "scale(0, 0)", i.style.left = "0", i.style.flex = "0 0 100%", i.classList ? i.classList.add(Va) : i.className += Va, s.appendChild(i), i
            }, r.removeBase = function(s) {
                var i = r.parentNode;
                i && i.removeChild(s)
            }, r.ref = function(s) {
                s && (r.resizable = s)
            }, r.state = {
                isResizing: !1,
                width: typeof(r.propsSize && r.propsSize.width) > "u" ? "auto" : r.propsSize && r.propsSize.width,
                height: typeof(r.propsSize && r.propsSize.height) > "u" ? "auto" : r.propsSize && r.propsSize.height,
                direction: "right",
                original: {
                    x: 0,
                    y: 0,
                    width: 0,
                    height: 0
                },
                backgroundStyle: {
                    height: "100%",
                    width: "100%",
                    backgroundColor: "rgba(0,0,0,0)",
                    cursor: "auto",
                    opacity: 0,
                    position: "fixed",
                    zIndex: 9999,
                    top: "0",
                    left: "0",
                    bottom: "0",
                    right: "0"
                },
                flexBasis: void 0
            }, r.onResizeStart = r.onResizeStart.bind(r), r.onMouseMove = r.onMouseMove.bind(r), r.onMouseUp = r.onMouseUp.bind(r), r
        }
        return Object.defineProperty(t.prototype, "parentNode", {
            get: function() {
                return this.resizable ? this.resizable.parentNode : null
            },
            enumerable: !1,
            configurable: !0
        }), Object.defineProperty(t.prototype, "window", {
            get: function() {
                return !this.resizable || !this.resizable.ownerDocument ? null : this.resizable.ownerDocument.defaultView
            },
            enumerable: !1,
            configurable: !0
        }), Object.defineProperty(t.prototype, "propsSize", {
            get: function() {
                return this.props.size || this.props.defaultSize || am
            },
            enumerable: !1,
            configurable: !0
        }), Object.defineProperty(t.prototype, "size", {
            get: function() {
                var o = 0,
                    r = 0;
                if (this.resizable && this.window) {
                    var s = this.resizable.offsetWidth,
                        i = this.resizable.offsetHeight,
                        a = this.resizable.style.position;
                    a !== "relative" && (this.resizable.style.position = "relative"), o = this.resizable.style.width !== "auto" ? this.resizable.offsetWidth : s, r = this.resizable.style.height !== "auto" ? this.resizable.offsetHeight : i, this.resizable.style.position = a
                }
                return {
                    width: o,
                    height: r
                }
            },
            enumerable: !1,
            configurable: !0
        }), Object.defineProperty(t.prototype, "sizeStyle", {
            get: function() {
                var o = this,
                    r = this.props.size,
                    s = function(l) {
                        if (typeof o.state[l] > "u" || o.state[l] === "auto") return "auto";
                        if (o.propsSize && o.propsSize[l] && o.propsSize[l].toString().endsWith("%")) {
                            if (o.state[l].toString().endsWith("%")) return o.state[l].toString();
                            var c = o.getParentSize(),
                                d = Number(o.state[l].toString().replace("px", "")),
                                u = d / c[l] * 100;
                            return u + "%"
                        }
                        return as(o.state[l])
                    },
                    i = r && typeof r.width < "u" && !this.state.isResizing ? as(r.width) : s("width"),
                    a = r && typeof r.height < "u" && !this.state.isResizing ? as(r.height) : s("height");
                return {
                    width: i,
                    height: a
                }
            },
            enumerable: !1,
            configurable: !0
        }), t.prototype.getParentSize = function() {
            if (!this.parentNode) return this.window ? {
                width: this.window.innerWidth,
                height: this.window.innerHeight
            } : {
                width: 0,
                height: 0
            };
            var o = this.appendBase();
            if (!o) return {
                width: 0,
                height: 0
            };
            var r = !1,
                s = this.parentNode.style.flexWrap;
            s !== "wrap" && (r = !0, this.parentNode.style.flexWrap = "wrap"), o.style.position = "relative", o.style.minWidth = "100%", o.style.minHeight = "100%";
            var i = {
                width: o.offsetWidth,
                height: o.offsetHeight
            };
            return r && (this.parentNode.style.flexWrap = s), this.removeBase(o), i
        }, t.prototype.bindEvents = function() {
            this.window && (this.window.addEventListener("mouseup", this.onMouseUp), this.window.addEventListener("mousemove", this.onMouseMove), this.window.addEventListener("mouseleave", this.onMouseUp), this.window.addEventListener("touchmove", this.onMouseMove, {
                capture: !0,
                passive: !1
            }), this.window.addEventListener("touchend", this.onMouseUp))
        }, t.prototype.unbindEvents = function() {
            this.window && (this.window.removeEventListener("mouseup", this.onMouseUp), this.window.removeEventListener("mousemove", this.onMouseMove), this.window.removeEventListener("mouseleave", this.onMouseUp), this.window.removeEventListener("touchmove", this.onMouseMove, !0), this.window.removeEventListener("touchend", this.onMouseUp))
        }, t.prototype.componentDidMount = function() {
            if (!(!this.resizable || !this.window)) {
                var o = this.window.getComputedStyle(this.resizable);
                this.setState({
                    width: this.state.width || this.size.width,
                    height: this.state.height || this.size.height,
                    flexBasis: o.flexBasis !== "auto" ? o.flexBasis : void 0
                })
            }
        }, t.prototype.componentWillUnmount = function() {
            this.window && this.unbindEvents()
        }, t.prototype.createSizeForCssProperty = function(o, r) {
            var s = this.propsSize && this.propsSize[r];
            return this.state[r] === "auto" && this.state.original[r] === o && (typeof s > "u" || s === "auto") ? "auto" : o
        }, t.prototype.calculateNewMaxFromBoundary = function(o, r) {
            var s = this.props.boundsByDirection,
                i = this.state.direction,
                a = s && zn("left", i),
                l = s && zn("top", i),
                c, d;
            if (this.props.bounds === "parent") {
                var u = this.parentNode;
                u && (c = a ? this.resizableRight - this.parentLeft : u.offsetWidth + (this.parentLeft - this.resizableLeft), d = l ? this.resizableBottom - this.parentTop : u.offsetHeight + (this.parentTop - this.resizableTop))
            } else this.props.bounds === "window" ? this.window && (c = a ? this.resizableRight : this.window.innerWidth - this.resizableLeft, d = l ? this.resizableBottom : this.window.innerHeight - this.resizableTop) : this.props.bounds && (c = a ? this.resizableRight - this.targetLeft : this.props.bounds.offsetWidth + (this.targetLeft - this.resizableLeft), d = l ? this.resizableBottom - this.targetTop : this.props.bounds.offsetHeight + (this.targetTop - this.resizableTop));
            return c && Number.isFinite(c) && (o = o && o < c ? o : c), d && Number.isFinite(d) && (r = r && r < d ? r : d), {
                maxWidth: o,
                maxHeight: r
            }
        }, t.prototype.calculateNewSizeFromDirection = function(o, r) {
            var s = this.props.scale || 1,
                i = this.props.resizeRatio || 1,
                a = this.state,
                l = a.direction,
                c = a.original,
                d = this.props,
                u = d.lockAspectRatio,
                h = d.lockAspectRatioExtraHeight,
                m = d.lockAspectRatioExtraWidth,
                g = c.width,
                p = c.height,
                b = h || 0,
                j = m || 0;
            return zn("right", l) && (g = c.width + (o - c.x) * i / s, u && (p = (g - j) / this.ratio + b)), zn("left", l) && (g = c.width - (o - c.x) * i / s, u && (p = (g - j) / this.ratio + b)), zn("bottom", l) && (p = c.height + (r - c.y) * i / s, u && (g = (p - b) * this.ratio + j)), zn("top", l) && (p = c.height - (r - c.y) * i / s, u && (g = (p - b) * this.ratio + j)), {
                newWidth: g,
                newHeight: p
            }
        }, t.prototype.calculateNewSizeFromAspectRatio = function(o, r, s, i) {
            var a = this.props,
                l = a.lockAspectRatio,
                c = a.lockAspectRatioExtraHeight,
                d = a.lockAspectRatioExtraWidth,
                u = typeof i.width > "u" ? 10 : i.width,
                h = typeof s.width > "u" || s.width < 0 ? o : s.width,
                m = typeof i.height > "u" ? 10 : i.height,
                g = typeof s.height > "u" || s.height < 0 ? r : s.height,
                p = c || 0,
                b = d || 0;
            if (l) {
                var j = (m - p) * this.ratio + b,
                    y = (g - p) * this.ratio + b,
                    S = (u - b) / this.ratio + p,
                    w = (h - b) / this.ratio + p,
                    v = Math.max(u, j),
                    x = Math.min(h, y),
                    C = Math.max(m, S),
                    E = Math.min(g, w);
                o = qo(o, v, x), r = qo(r, C, E)
            } else o = qo(o, u, h), r = qo(r, m, g);
            return {
                newWidth: o,
                newHeight: r
            }
        }, t.prototype.setBoundingClientRect = function() {
            if (this.props.bounds === "parent") {
                var o = this.parentNode;
                if (o) {
                    var r = o.getBoundingClientRect();
                    this.parentLeft = r.left, this.parentTop = r.top
                }
            }
            if (this.props.bounds && typeof this.props.bounds != "string") {
                var s = this.props.bounds.getBoundingClientRect();
                this.targetLeft = s.left, this.targetTop = s.top
            }
            if (this.resizable) {
                var i = this.resizable.getBoundingClientRect(),
                    a = i.left,
                    l = i.top,
                    c = i.right,
                    d = i.bottom;
                this.resizableLeft = a, this.resizableRight = c, this.resizableTop = l, this.resizableBottom = d
            }
        }, t.prototype.onResizeStart = function(o, r) {
            if (!(!this.resizable || !this.window)) {
                var s = 0,
                    i = 0;
                if (o.nativeEvent && lm(o.nativeEvent) ? (s = o.nativeEvent.clientX, i = o.nativeEvent.clientY) : o.nativeEvent && Go(o.nativeEvent) && (s = o.nativeEvent.touches[0].clientX, i = o.nativeEvent.touches[0].clientY), this.props.onResizeStart && this.resizable) {
                    var a = this.props.onResizeStart(o, r, this.resizable);
                    if (a === !1) return
                }
                this.props.size && (typeof this.props.size.height < "u" && this.props.size.height !== this.state.height && this.setState({
                    height: this.props.size.height
                }), typeof this.props.size.width < "u" && this.props.size.width !== this.state.width && this.setState({
                    width: this.props.size.width
                })), this.ratio = typeof this.props.lockAspectRatio == "number" ? this.props.lockAspectRatio : this.size.width / this.size.height;
                var l, c = this.window.getComputedStyle(this.resizable);
                if (c.flexBasis !== "auto") {
                    var d = this.parentNode;
                    if (d) {
                        var u = this.window.getComputedStyle(d).flexDirection;
                        this.flexDir = u.startsWith("row") ? "row" : "column", l = c.flexBasis
                    }
                }
                this.setBoundingClientRect(), this.bindEvents();
                var h = {
                    original: {
                        x: s,
                        y: i,
                        width: this.size.width,
                        height: this.size.height
                    },
                    isResizing: !0,
                    backgroundStyle: Bt(Bt({}, this.state.backgroundStyle), {
                        cursor: this.window.getComputedStyle(o.target).cursor || "auto"
                    }),
                    direction: r,
                    flexBasis: l
                };
                this.setState(h)
            }
        }, t.prototype.onMouseMove = function(o) {
            var r = this;
            if (!(!this.state.isResizing || !this.resizable || !this.window)) {
                if (this.window.TouchEvent && Go(o)) try {
                    o.preventDefault(), o.stopPropagation()
                } catch {}
                var s = this.props,
                    i = s.maxWidth,
                    a = s.maxHeight,
                    l = s.minWidth,
                    c = s.minHeight,
                    d = Go(o) ? o.touches[0].clientX : o.clientX,
                    u = Go(o) ? o.touches[0].clientY : o.clientY,
                    h = this.state,
                    m = h.direction,
                    g = h.original,
                    p = h.width,
                    b = h.height,
                    j = this.getParentSize(),
                    y = cm(j, this.window.innerWidth, this.window.innerHeight, i, a, l, c);
                i = y.maxWidth, a = y.maxHeight, l = y.minWidth, c = y.minHeight;
                var S = this.calculateNewSizeFromDirection(d, u),
                    w = S.newHeight,
                    v = S.newWidth,
                    x = this.calculateNewMaxFromBoundary(i, a);
                this.props.snap && this.props.snap.x && (v = Ua(v, this.props.snap.x, this.props.snapGap)), this.props.snap && this.props.snap.y && (w = Ua(w, this.props.snap.y, this.props.snapGap));
                var C = this.calculateNewSizeFromAspectRatio(v, w, {
                    width: x.maxWidth,
                    height: x.maxHeight
                }, {
                    width: l,
                    height: c
                });
                if (v = C.newWidth, w = C.newHeight, this.props.grid) {
                    var E = Oa(v, this.props.grid[0]),
                        R = Oa(w, this.props.grid[1]),
                        B = this.props.snapGap || 0;
                    v = B === 0 || Math.abs(E - v) <= B ? E : v, w = B === 0 || Math.abs(R - w) <= B ? R : w
                }
                var A = {
                    width: v - g.width,
                    height: w - g.height
                };
                if (p && typeof p == "string") {
                    if (p.endsWith("%")) {
                        var P = v / j.width * 100;
                        v = P + "%"
                    } else if (p.endsWith("vw")) {
                        var D = v / this.window.innerWidth * 100;
                        v = D + "vw"
                    } else if (p.endsWith("vh")) {
                        var O = v / this.window.innerHeight * 100;
                        v = O + "vh"
                    }
                }
                if (b && typeof b == "string") {
                    if (b.endsWith("%")) {
                        var P = w / j.height * 100;
                        w = P + "%"
                    } else if (b.endsWith("vw")) {
                        var D = w / this.window.innerWidth * 100;
                        w = D + "vw"
                    } else if (b.endsWith("vh")) {
                        var O = w / this.window.innerHeight * 100;
                        w = O + "vh"
                    }
                }
                var V = {
                    width: this.createSizeForCssProperty(v, "width"),
                    height: this.createSizeForCssProperty(w, "height")
                };
                this.flexDir === "row" ? V.flexBasis = V.width : this.flexDir === "column" && (V.flexBasis = V.height), Qu.flushSync(function() {
                    r.setState(V)
                }), this.props.onResize && this.props.onResize(o, m, this.resizable, A)
            }
        }, t.prototype.onMouseUp = function(o) {
            var r = this.state,
                s = r.isResizing,
                i = r.direction,
                a = r.original;
            if (!(!s || !this.resizable)) {
                var l = {
                    width: this.size.width - a.width,
                    height: this.size.height - a.height
                };
                this.props.onResizeStop && this.props.onResizeStop(o, i, this.resizable, l), this.props.size && this.setState(this.props.size), this.unbindEvents(), this.setState({
                    isResizing: !1,
                    backgroundStyle: Bt(Bt({}, this.state.backgroundStyle), {
                        cursor: "auto"
                    })
                })
            }
        }, t.prototype.updateSize = function(o) {
            this.setState({
                width: o.width,
                height: o.height
            })
        }, t.prototype.renderResizer = function() {
            var o = this,
                r = this.props,
                s = r.enable,
                i = r.handleStyles,
                a = r.handleClasses,
                l = r.handleWrapperStyle,
                c = r.handleWrapperClass,
                d = r.handleComponent;
            if (!s) return null;
            var u = Object.keys(s).map(function(h) {
                return s[h] !== !1 ? f.createElement(sm, {
                    key: h,
                    direction: h,
                    onResizeStart: o.onResizeStart,
                    replaceStyles: i && i[h],
                    className: a && a[h]
                }, d && d[h] ? d[h] : null) : null
            });
            return f.createElement("div", {
                className: c,
                style: l
            }, u)
        }, t.prototype.render = function() {
            var o = this,
                r = Object.keys(this.props).reduce(function(a, l) {
                    return dm.indexOf(l) !== -1 || (a[l] = o.props[l]), a
                }, {}),
                s = Bt(Bt(Bt({
                    position: "relative",
                    userSelect: this.state.isResizing ? "none" : "auto"
                }, this.props.style), this.sizeStyle), {
                    maxWidth: this.props.maxWidth,
                    maxHeight: this.props.maxHeight,
                    minWidth: this.props.minWidth,
                    minHeight: this.props.minHeight,
                    boxSizing: "border-box",
                    flexShrink: 0
                });
            this.state.flexBasis && (s.flexBasis = this.state.flexBasis);
            var i = this.props.as || "div";
            return f.createElement(i, Bt({
                ref: this.ref,
                style: s,
                className: this.props.className
            }, r), this.state.isResizing && f.createElement("div", {
                style: this.state.backgroundStyle
            }), this.props.children, this.renderResizer())
        }, t.defaultProps = {
            as: "div",
            onResizeStart: function() {},
            onResize: function() {},
            onResizeStop: function() {},
            enable: {
                top: !0,
                right: !0,
                bottom: !0,
                left: !0,
                topRight: !0,
                bottomRight: !0,
                bottomLeft: !0,
                topLeft: !0
            },
            style: {},
            grid: [1, 1],
            lockAspectRatio: !1,
            lockAspectRatioExtraWidth: 0,
            lockAspectRatioExtraHeight: 0,
            scale: 1,
            resizeRatio: 1,
            snapGap: 0
        }, t
    }(f.PureComponent);
const ed = ({
        hideArrows: e
    }) => n.jsxs(he, {
        position: "absolute",
        alignItems: "flex-start",
        top: "50%",
        transform: "translateY(-50%)",
        width: "100%",
        zIndex: "docked",
        spacing: 0,
        sx: {
            div: {
                borderTopColor: ee("accent.300", "blue.800")
            },
            svg: {
                color: ee("accent.300", "blue.700"),
                position: "relative",
                left: "calc(50% + 30px)",
                transform: "translateX(-50%)"
            }
        },
        _hover: {
            "@media (hover: hover)": {
                div: {
                    borderTopColor: ee("accent.400", "blue.700")
                },
                svg: {
                    color: ee("accent.400", "blue.600")
                }
            }
        },
        _active: {
            div: {
                borderTopColor: ee("accent.500", "blue.500")
            },
            svg: {
                color: ee("accent.500", "blue.450")
            }
        },
        children: [!e && n.jsx(L, {
            as: Ql,
            boxSize: "9px"
        }), n.jsx(I, {
            w: "calc(100% + 60px)",
            h: "0px",
            borderTopWidth: "3px",
            pointerEvents: "none"
        }), !e && n.jsx(L, {
            as: $u,
            boxSize: "9px"
        })]
    }),
    ls = e => {
        const t = ee("gray.600", "gray.400"),
            o = ee("gray.900", "gray.50");
        return n.jsx(Je, {
            flexShrink: 0,
            onClick: e.onClick,
            borderRadius: 0,
            display: "flex",
            variant: "unstyled",
            icon: e.icon,
            "aria-label": e["aria-label"],
            color: t,
            minWidth: "auto",
            height: "100%",
            paddingInline: 1.5,
            _hover: {
                "@media (hover: hover)": {
                    color: o
                }
            },
            _active: {
                color: o
            }
        })
    },
    um = Pr(async () => {
        const {
            ChatLoader: e
        } = await zr(() =>
            import ("./chat-loader-5JT5oj45.js"), __vite__mapDeps([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19]));
        return {
            default: e
        }
    }),
    cs = Yu().optional().json.catchDecode(ln),
    hm = f.memo(e => {
        const {
            state: t,
            chainId: o,
            tokenAddress: r,
            onStateChange: s,
            sidebarHeaderHeight: i,
            isMobileTabBarVisible: a,
            isTrendingBarVisible: l,
            isMobileChatVisible: c
        } = e, d = ii(), {
            colorMode: u
        } = pe(), {
            headerHeight: h
        } = Zu(), [m, g] = n0("@dexscreener/web/dex-pair-details-sidebar-chat/height"), p = f.useMemo(() => cs.decode(m), [m]), b = kc(), j = Sn(Math.min(b.height * .66, 1e3), void 0), y = Sn(Math.max(b.height * .2, 300), void 0), S = Hr(), w = Sn(b.height - (S ? 0 : h) - (S ? i : 0) - (S ? 0 : l && !a ? qc : 0) - (S ? 0 : a ? $c : 0), void 0), [v, x] = f.useState(), C = f.useMemo(() => v === void 0 ? void 0 : {
            width: "100%",
            height: v
        }, [v]), E = De(p), R = De(j);
        t0(() => {
            if (S) switch (t) {
                case "minimized":
                    {
                        x("auto");
                        break
                    }
                case "expanded":
                    {
                        x(E.current ? ? R.current);
                        break
                    }
                case "maximized":
                    {
                        x(void 0);
                        break
                    }
            } else x(c ? void 0 : 0)
        }, [S, t, c, E, R]);
        const B = T("white", "blue.950", u),
            A = f.useMemo(() => {
                const re = S ? t === "maximized" ? 1 : void 0 : c ? 1 : void 0;
                return n.jsxs(he, {
                    spacing: 0,
                    align: "stretch",
                    flexShrink: 0,
                    height: "100%",
                    flex: re,
                    children: [t === "minimized" && n.jsxs(ue, {
                        backgroundColor: T("gray.175", "black", u),
                        borderTopWidth: 1,
                        borderColor: T("gray.200", "blue.900", u),
                        borderRadius: 0,
                        onClick: () => s("expanded"),
                        flexShrink: 0,
                        height: "40px",
                        _hover: {
                            bg: T("gray.225", "gray.950", u)
                        },
                        display: {
                            base: "none",
                            lg: "flex"
                        },
                        leftIcon: n.jsx(L, {
                            as: ks,
                            boxSize: "1.1em"
                        }),
                        rightIcon: n.jsx(L, {
                            as: cc
                        }),
                        iconSpacing: "1.5",
                        children: [n.jsx(k, {
                            children: "Chat"
                        }), n.jsx(k, {
                            ml: "2",
                            bg: "accent.lightGreen",
                            color: "blackAlpha.800",
                            fontSize: "xs",
                            px: "1",
                            py: "0.5",
                            borderRadius: "md",
                            children: "new!"
                        })]
                    }), (!S && c || t !== "minimized") && n.jsxs(n.Fragment, {
                        children: [n.jsxs(K, {
                            color: T("gray.800", "gray.50", u),
                            backgroundColor: T("white", "blue.975", u),
                            borderBottomWidth: 1,
                            borderColor: T("gray.100", "blue.875", u),
                            paddingLeft: 4,
                            spacing: 1,
                            height: "40px",
                            flexShrink: 0,
                            display: {
                                base: "none",
                                lg: "flex"
                            },
                            children: [n.jsxs(K, {
                                spacing: 1,
                                flex: 1,
                                fontWeight: "semibold",
                                fontSize: "sm",
                                children: [n.jsx(ks, {}), n.jsx(k, {
                                    children: "Chat"
                                })]
                            }), n.jsx(ls, {
                                icon: n.jsx(dc, {}),
                                "aria-label": "Minimize",
                                onClick: () => s("minimized")
                            }), t === "expanded" && n.jsx(ls, {
                                icon: n.jsx(uc, {}),
                                "aria-label": "Maximize",
                                onClick: () => s("maximized")
                            }), t === "maximized" && n.jsx(ls, {
                                icon: n.jsx(hc, {}),
                                "aria-label": "Minimize",
                                onClick: () => s("expanded")
                            })]
                        }), n.jsx(I, {
                            flex: 1,
                            display: "flex",
                            flexDirection: "column",
                            children: d && n.jsx(Ju, {
                                id: "chat",
                                FallbackComponent: ({
                                    resetErrorBoundary: ye
                                }) => n.jsx(Ae, {
                                    flex: 1,
                                    children: n.jsxs(q, {
                                        as: "span",
                                        display: "block",
                                        fontSize: "xs",
                                        m: 3,
                                        color: "white",
                                        textAlign: "center",
                                        children: ["Error rendering chat. Please", " ", n.jsx(ue, {
                                            onClick: ye,
                                            variant: "link",
                                            size: "xs",
                                            color: "white",
                                            fontWeight: "semibold",
                                            children: "click here to retry"
                                        }), " ", "or refresh this page."]
                                    })
                                }),
                                children: n.jsx(f.Suspense, {
                                    fallback: n.jsx(Ae, {
                                        flex: 1,
                                        display: "flex",
                                        children: n.jsx(Cn, {
                                            size: "sm"
                                        })
                                    }),
                                    children: n.jsx(um, {
                                        chainId: o,
                                        tokenAddress: r
                                    })
                                })
                            })
                        })]
                    })]
                })
            }, [u, o, d, S, c, s, t, r]),
            P = f.useMemo(() => ({
                top: n.jsx(ed, {
                    hideArrows: !0
                })
            }), []),
            D = f.useMemo(() => ({
                top: {
                    top: "-7px",
                    height: "14px",
                    width: "calc(100% - 60px)"
                }
            }), []),
            O = f.useMemo(() => ({
                top: S && t === "expanded"
            }), [S, t]),
            V = f.useCallback((re, ye, fe) => {
                var ze;
                const je = cs.decode((ze = fe.style.height.match(/^(\d+)px$/)) == null ? void 0 : ze[1]);
                x(je)
            }, []),
            z = De(v),
            H = f.useCallback(() => {
                z.current !== "auto" && g(cs.encode(z.current))
            }, [g, z]),
            oe = f.useMemo(() => S ? t === "maximized" ? 1 : void 0 : c ? 1 : void 0, [S, c, t]);
        return n.jsx(I, {
            as: Jc,
            flex: oe,
            enable: O,
            minHeight: S && t === "expanded" ? y : void 0,
            maxHeight: S && t === "expanded" ? w : void 0,
            handleStyles: D,
            handleComponent: P,
            size: C,
            onResize: V,
            onResizeStop: H,
            backgroundColor: B,
            children: A
        })
    }),
    _r = e => {
        const {
            colorMode: t
        } = pe();
        switch (e) {
            case "error":
                return T("red.600", "red.400", t);
            case "success":
                return T("green.600", "green.400", t);
            case "warning":
                return T("orange.600", "orange.400", t);
            case "neutral":
                return
        }
    },
    td = e => {
        switch (e) {
            case "error":
            case "warning":
                return cn;
            case "success":
                return Po;
            case "neutral":
                return
        }
    },
    fm = e => e ? Po : cn,
    Or = ({
        label: e,
        hint: t
    }) => {
        const {
            isOpen: o,
            onToggle: r
        } = pr(), {
            colorMode: s
        } = pe();
        return n.jsxs(n.Fragment, {
            children: [n.jsxs(K, {
                spacing: 1,
                onClick: r,
                color: T("gray.650", "blue.200", s),
                children: [t && n.jsx(St, {
                    label: t,
                    display: {
                        base: "none",
                        md: "block"
                    },
                    fontSize: "xs",
                    children: n.jsx(I, {
                        display: "flex",
                        children: n.jsx(L, {
                            as: Ao
                        })
                    })
                }), n.jsx(q, {
                    children: e
                })]
            }), o && t && n.jsx(I, {
                onClick: r,
                order: 3,
                gridArea: "hint",
                display: {
                    base: "block",
                    md: "none"
                },
                color: T("gray.400", "blue.500", s),
                fontStyle: "italic",
                fontSize: "xs",
                marginTop: 1,
                children: t
            })]
        })
    },
    Ur = ({
        children: e
    }) => n.jsx(Pf, {
        columnGap: "1",
        gridTemplateAreas: "'label value' 'hint hint'",
        justifyContent: "space-between",
        children: e
    }),
    Vr = ({
        children: e
    }) => n.jsx(K, {
        spacing: 1,
        justifySelf: "flex-end",
        children: e
    }),
    ht = ({
        label: e,
        hint: t,
        value: o,
        status: r
    }) => {
        const s = _r(r),
            i = td(r) ? ? (o !== void 0 ? fm(o) : void 0);
        return o === void 0 ? null : n.jsxs(Ur, {
            children: [n.jsx(Or, {
                label: e,
                hint: t
            }), n.jsxs(Vr, {
                children: [i && n.jsx(L, {
                    as: i,
                    color: s
                }), n.jsx(q, {
                    color: s,
                    fontWeight: "semibold",
                    children: o ? "Yes" : "No"
                })]
            })]
        })
    },
    Xr = ({
        label: e,
        hint: t,
        value: o,
        status: r,
        title: s,
        showIcon: i
    }) => {
        const a = _r(r),
            l = i ? td(r) : void 0;
        return o ? n.jsxs(Ur, {
            children: [n.jsx(Or, {
                label: e,
                hint: t
            }), n.jsxs(Vr, {
                children: [l && n.jsx(L, {
                    as: l,
                    color: a
                }), n.jsx(q, {
                    color: a,
                    fontWeight: "semibold",
                    title: s,
                    children: o
                })]
            })]
        }) : null
    },
    nd = ({
        label: e,
        hint: t,
        address: o,
        status: r,
        pair: s
    }) => {
        const [, i] = Ar(), a = Qn(), l = _r(r), c = f.useCallback(() => {
            o && (i(o), a({
                status: "success",
                description: "Address copied to clipboard!",
                isClosable: !0
            }))
        }, [i, a, o]), d = In(s.chainId);
        if (!o) return null;
        const u = d == null ? void 0 : d.accountURL(o);
        return n.jsxs(Ur, {
            children: [n.jsx(Or, {
                label: e,
                hint: t
            }), n.jsx(Vr, {
                children: n.jsx(ue, {
                    height: "auto",
                    display: "flex",
                    alignItems: "center",
                    color: l,
                    variant: "unstyled",
                    fontSize: "sm",
                    fontFamily: "mono",
                    fontWeight: "semibold",
                    title: "Go to explorer",
                    iconSpacing: 1,
                    ...u === void 0 ? {
                        onClick: c,
                        leftIcon: n.jsx(L, {
                            as: si,
                            boxSize: "10px"
                        })
                    } : {
                        as: we,
                        href: u,
                        rel: "noopener noreferrer",
                        target: "_blank",
                        leftIcon: n.jsx(L, {
                            as: yt,
                            boxSize: "10px"
                        })
                    },
                    children: Eo(o)
                })
            })]
        })
    },
    gm = e => Ct({
        number: new mt(e).times(100),
        suffix: "%",
        min001: new mt(e).eq(0) === !1,
        significantDigits: 2
    }),
    od = ({
        label: e,
        hint: t,
        balance: o,
        percent: r,
        tokenSymbol: s,
        status: i
    }) => {
        const a = _r(i);
        if (!o) return null;
        const l = Ct({
            number: o,
            significantDigits: 2,
            suffix: s ? ` ${s}` : "",
            addCommas: !0
        });
        return n.jsxs(Ur, {
            children: [n.jsx(Or, {
                label: e,
                hint: t
            }), n.jsx(Vr, {
                children: n.jsxs(q, {
                    color: a,
                    fontWeight: "semibold",
                    title: l,
                    textAlign: "right",
                    children: [It(o, void 0, {
                        significantDigits: c => c.eq(0) ? 0 : c.lt(1) ? 4 : c.lt(1e4) ? 2 : 0,
                        largeNumberSuffix: {
                            threshold: "million",
                            significantDigits: 2
                        }
                    }), r ? ` (${gm(r)})` : ""]
                })
            })]
        })
    },
    qr = ({
        label: e,
        hint: t,
        value: o,
        format: r,
        status: s,
        showIcon: i
    }) => {
        const a = o === void 0 ? void 0 : Ct({
            number: o,
            ...r
        });
        return n.jsx(Xr, {
            label: e,
            hint: t,
            value: a,
            status: s,
            showIcon: i
        })
    },
    mm = ({
        status: e,
        value: t
    }) => n.jsx(ht, {
        label: "Honeypot",
        hint: "Whether the token is a honeypot, a token that can't be sold due to malicious code on its contract",
        value: t,
        status: e
    }),
    pm = ({
        status: e,
        value: t
    }) => n.jsx(ht, {
        label: "Owner can change balance",
        hint: "Whether the contract owner can change token holder balances",
        value: t,
        status: e
    }),
    xm = ({
        status: e,
        value: t
    }) => n.jsx(ht, {
        label: "Is anti whale",
        hint: "Whether the contract has the function to limit the maximum amount of transactions or the maximum token position for a single address",
        value: t,
        status: e
    }),
    bm = ({
        status: e,
        value: t
    }) => n.jsx(ht, {
        label: "Can't sell all",
        hint: "Whether the contract has the function to restrict token holders from selling their entire position",
        value: t,
        status: e
    }),
    vm = ({
        status: e,
        value: t
    }) => n.jsx(ht, {
        label: "Transfer pausable",
        hint: "Whether trading can be paused by the token contract",
        value: t,
        status: e
    }),
    ym = ({
        status: e,
        value: t
    }) => n.jsx(ht, {
        label: "Trading cooldown",
        hint: "Whether the contract has a trading-cool-down mechanism that can limit the minimum time between two transactions.",
        value: t,
        status: e
    }),
    jm = ({
        status: e,
        value: t
    }) => n.jsx(ht, {
        label: "Tax modifiable",
        hint: "Whether buy/sell tax can be modified in the token contract",
        value: t,
        status: e
    }),
    Sm = ({
        status: e,
        value: t
    }) => n.jsx(ht, {
        label: "External call",
        hint: "Whether the contract can call functions in other contracts during the execution of primary methods",
        value: t,
        status: e
    }),
    wm = ({
        status: e,
        value: t
    }) => n.jsx(ht, {
        label: "Open source",
        hint: "Whether the contract for this token is open source. Contracts that aren't open source may hide various unknown mechanisms and can increase risks significantly",
        value: t,
        status: e
    }),
    Cm = ({
        status: e,
        value: t
    }) => n.jsx(ht, {
        label: "Has blacklist",
        hint: "Whether the blacklist function is included in the contract. If there is a blacklist, some addresses may not be able to trade this token",
        value: t,
        status: e
    }),
    km = ({
        status: e,
        value: t
    }) => n.jsx(ht, {
        label: "Has whitelist",
        hint: "Whether the whitelist function is included in the contract. Whitelisting is mostly used to allow specific addresses to make early transactions, tax-free, and not affected by transaction suspension",
        value: t,
        status: e
    }),
    Tm = ({
        status: e,
        value: t
    }) => n.jsx(ht, {
        label: "Mintable",
        hint: "Whether this contract has the function to mint new tokens",
        value: t,
        status: e
    }),
    Im = ({
        status: e,
        value: t
    }) => n.jsx(ht, {
        label: "Proxy contract",
        hint: "Whether this token uses a proxy contract. Most proxy contracts are accompanied by modifiable implementation contracts, which may contain significant potential risk",
        value: t,
        status: e
    }),
    Am = ({
        data: e,
        status: t,
        pair: o
    }) => {
        const {
            creatorAddress: r
        } = e;
        return n.jsx(nd, {
            label: "Creator address",
            hint: "Wallet address of contract creator",
            address: r,
            status: t,
            pair: o
        })
    },
    Em = ({
        data: e,
        status: t
    }) => {
        const {
            creatorBalance: o,
            creatorPercent: r,
            tokenSymbol: s
        } = e;
        return n.jsx(od, {
            label: "Creator balance",
            hint: "The balance of the contract creator",
            status: t,
            balance: o,
            percent: r,
            tokenSymbol: s
        })
    },
    Pm = ({
        data: e,
        status: t,
        pair: o
    }) => {
        const {
            ownerAddress: r
        } = e;
        return n.jsx(nd, {
            label: "Owner address",
            hint: "Wallet address of contract owner",
            address: r,
            status: t,
            pair: o
        })
    },
    Rm = ({
        data: e,
        status: t
    }) => {
        const {
            ownerBalance: o,
            ownerPercent: r,
            tokenSymbol: s
        } = e;
        return n.jsx(od, {
            label: "Owner balance",
            hint: "Tokens held by the contract owner",
            status: t,
            balance: o,
            percent: r,
            tokenSymbol: s
        })
    },
    zm = ({
        data: e,
        status: t
    }) => n.jsx(qr, {
        label: "Holder count",
        hint: "Number of token holders",
        value: e.holderCount,
        status: t,
        format: {
            significantDigits: 0,
            addCommas: !0
        }
    }),
    Mm = ({
        data: e,
        status: t
    }) => n.jsx(qr, {
        label: "LP Holder count",
        hint: "Number of liquidity holders",
        value: e.lpHolderCount,
        status: t,
        format: {
            significantDigits: 0,
            addCommas: !0
        }
    }),
    Xa = "Buy tax",
    qa = "Buy tax will cause the actual value received when buying a token to be less than expected",
    Bm = ({
        data: e,
        status: t
    }) => e.buyTax === null ? n.jsx(Xr, {
        label: Xa,
        hint: qa,
        value: "Unknown",
        status: t,
        showIcon: !0
    }) : n.jsx(qr, {
        label: Xa,
        hint: qa,
        value: e.buyTax !== void 0 ? e.buyTax * 100 : void 0,
        status: t,
        showIcon: !0,
        format: {
            suffix: "%",
            significantDigits: 0
        }
    }),
    Ga = "Sell tax",
    Ka = "Sell tax will cause the actual value received when selling a token to be less than expected",
    Fm = ({
        data: e,
        status: t
    }) => e.sellTax === null ? n.jsx(Xr, {
        label: Ga,
        hint: Ka,
        value: "Unknown",
        status: t,
        showIcon: !0
    }) : n.jsx(qr, {
        label: Ga,
        hint: Ka,
        value: e.sellTax !== void 0 ? e.sellTax * 100 : void 0,
        status: t,
        showIcon: !0,
        format: {
            suffix: "%",
            significantDigits: 0
        }
    }),
    Qa = "Ownership renounced",
    $a = "Whether the contract creator has renounced ownership of this token and has no special privileges to control it",
    Wm = ({
        status: e
    }) => e === "neutral" ? n.jsx(Xr, {
        label: Qa,
        hint: $a,
        value: "Unknown",
        status: e
    }) : n.jsx(ht, {
        label: Qa,
        hint: $a,
        value: e === "success",
        status: e
    }),
    Dm = ({
        data: e,
        status: t
    }) => n.jsx(ht, {
        label: "Hidden owner",
        hint: "Whether the contract has hidden owners",
        value: e.hiddenOwner,
        status: t
    }),
    rd = {
        antiWhaleModifiable: void 0,
        canTakeBackOwnership: void 0,
        isTrueToken: void 0,
        trustList: void 0,
        ownerPercent: void 0,
        creatorPercent: void 0,
        tokenName: void 0,
        tokenSymbol: void 0,
        buyTax: ({
            data: e,
            status: t
        }) => n.jsx(Bm, {
            data: e,
            status: t
        }),
        sellTax: ({
            data: e,
            status: t
        }) => n.jsx(Fm, {
            data: e,
            status: t
        }),
        slippageModifiable: ({
            status: e,
            value: t
        }) => n.jsx(jm, {
            value: t,
            status: e
        }),
        externalCall: ({
            status: e,
            value: t
        }) => n.jsx(Sm, {
            value: t,
            status: e
        }),
        isOpenSource: ({
            status: e,
            value: t
        }) => n.jsx(wm, {
            value: t,
            status: e
        }),
        isHoneypot: ({
            status: e,
            value: t
        }) => n.jsx(mm, {
            value: t,
            status: e
        }),
        ownerChangeBalance: ({
            status: e,
            value: t
        }) => n.jsx(pm, {
            value: t,
            status: e
        }),
        isProxy: ({
            status: e,
            value: t
        }) => n.jsx(Im, {
            value: t,
            status: e
        }),
        isMintable: ({
            status: e,
            value: t
        }) => n.jsx(Tm, {
            value: t,
            status: e
        }),
        transferPausable: ({
            status: e,
            value: t
        }) => n.jsx(vm, {
            value: t,
            status: e
        }),
        tradingCooldown: ({
            status: e,
            value: t
        }) => n.jsx(ym, {
            value: t,
            status: e
        }),
        cannotSellAll: ({
            status: e,
            value: t
        }) => n.jsx(bm, {
            value: t,
            status: e
        }),
        isBlacklisted: ({
            status: e,
            value: t
        }) => n.jsx(Cm, {
            value: t,
            status: e
        }),
        isAntiWhale: ({
            status: e,
            value: t
        }) => n.jsx(xm, {
            value: t,
            status: e
        }),
        isWhitelisted: ({
            status: e,
            value: t
        }) => n.jsx(km, {
            value: t,
            status: e
        }),
        holderCount: ({
            data: e,
            status: t
        }) => n.jsx(zm, {
            data: e,
            status: t
        }),
        lpHolderCount: ({
            data: e,
            status: t
        }) => n.jsx(Mm, {
            data: e,
            status: t
        }),
        creatorAddress: ({
            data: e,
            pair: t,
            status: o
        }) => n.jsx(Am, {
            data: e,
            pair: t,
            status: o
        }),
        creatorBalance: ({
            data: e,
            status: t
        }) => n.jsx(Em, {
            data: e,
            status: t
        }),
        ownerAddress: ({
            data: e,
            pair: t,
            status: o
        }) => n.jsx(Pm, {
            data: e,
            pair: t,
            status: o
        }),
        ownerBalance: ({
            data: e,
            status: t
        }) => n.jsx(Rm, {
            data: e,
            status: t
        }),
        ownershipRenounced: ({
            status: e
        }) => n.jsx(Wm, {
            status: e
        }),
        hiddenOwner: ({
            data: e,
            status: t
        }) => n.jsx(Dm, {
            data: e,
            status: t
        })
    },
    Lm = e => rd[e],
    Nm = f.memo(f.forwardRef((e, t) => {
        const {
            data: o,
            pair: r,
            onOpen: s,
            onClose: i
        } = e, a = V0({
            data: o,
            pair: r,
            onOpen: s,
            onClose: i
        }), {
            colorMode: l
        } = pe();
        return n.jsxs(I, {
            ref: t,
            overflow: "hidden",
            children: [n.jsxs(K, {
                spacing: "1",
                onClick: a.state === "success" ? a.toggleCollapse : void 0,
                height: "42px",
                userSelect: "none",
                transitionDuration: "fast",
                transitionProperty: "common",
                _hover: {
                    "@media (hover: hover)": a.state === "success" ? {
                        cursor: "pointer",
                        background: T("gray.100", "whiteAlpha.200", l)
                    } : {}
                },
                children: [n.jsx(I, {
                    flex: 1,
                    fontSize: "sm",
                    fontWeight: "semibold",
                    px: 3,
                    children: "Go+ Security"
                }), a.state === "pending" && n.jsx(I, {
                    padding: "2",
                    children: n.jsx(L, {
                        as: xr
                    })
                }), (a.state === "failure" || a.state === "notAvailable") && n.jsx(I, {
                    padding: "2",
                    fontSize: "sm",
                    children: n.jsx(k, {
                        color: T("gray.500", "blue.500", l),
                        children: "Not available"
                    })
                }), a.state === "success" && n.jsxs(n.Fragment, {
                    children: [n.jsxs(I, {
                        fontSize: "sm",
                        padding: "2",
                        children: [a.issuesCount === 0 && n.jsxs(K, {
                            children: [n.jsx(k, {
                                children: "No issues"
                            }), n.jsx(L, {
                                as: Po,
                                color: T("green.600", "green.400", l)
                            })]
                        }), a.issuesCount > 0 && n.jsxs(K, {
                            color: T("red.600", "red.400", l),
                            children: [n.jsxs(k, {
                                fontWeight: "semibold",
                                children: [a.issuesCount, " ", fc({
                                    value: a.issuesCount,
                                    single: "issue",
                                    zeroOrMany: "issues"
                                })]
                            }), n.jsx(L, {
                                as: cn
                            })]
                        })]
                    }), n.jsx(I, {
                        display: "flex",
                        padding: "2",
                        alignItems: "center",
                        alignSelf: "stretch",
                        borderLeftWidth: "1px",
                        borderColor: T("gray.200", "whiteAlpha.300", l),
                        children: a.isOpen ? n.jsx(br, {}) : n.jsx(Rr, {})
                    })]
                })]
            }), a.state === "success" && a.isOpen && n.jsxs(he, {
                padding: 2.5,
                alignItems: "stretch",
                borderColor: T("gray.200", "whiteAlpha.300", l),
                borderTopWidth: "1px",
                children: [n.jsx(he, {
                    spacing: 1.5,
                    alignItems: "stretch",
                    fontSize: "sm",
                    divider: n.jsx(Mr, {
                        marginY: 1
                    }),
                    children: a.validationResult.map(c => {
                        const d = Lm(c.key);
                        return d ? n.jsx(d, {
                            pair: a.pairIdentity,
                            data: a.auditValues,
                            status: c.status,
                            value: c.value
                        }, c.key) : null
                    })
                }), n.jsx(ue, {
                    variant: "ghost",
                    size: "xs",
                    onClick: a.toggleCollapse,
                    children: n.jsx(L, {
                        as: br
                    })
                })]
            })]
        })
    })),
    ds = {
        variant: "link",
        size: "xs",
        fontWeight: "normal",
        iconSpacing: 1
    },
    oo = ({
        containerProps: e,
        chainId: t,
        pairContext: o,
        contractType: r,
        label: s,
        address: i
    }) => {
        const [, a] = Ar(), l = Qn(), c = In(t), {
            shortAddress: d,
            holdersLink: u,
            explorerLink: h
        } = f.useMemo(() => {
            var y, S;
            const g = eh(i);
            let p = i;
            o === "b" ? p = i.slice(0, 42) : t === "aptos" && (p = i.split("::")[0] ? ? i);
            const b = (y = c == null ? void 0 : c.holdersURL) == null ? void 0 : y.call(c, p),
                j = r === "token" ? (S = c == null ? void 0 : c.assetURL) == null ? void 0 : S.call(c, p) : c == null ? void 0 : c.accountURL(p);
            return {
                shortAddress: g,
                linkAddress: p,
                holdersLink: b,
                explorerLink: j
            }
        }, [i, o, t, c, r]), m = () => {
            a(i), l({
                status: "success",
                description: "Address copied to clipboard!",
                isClosable: !0
            })
        };
        return n.jsxs(K, {
            justifyContent: "space-between",
            ...e,
            children: [n.jsx(q, {
                as: "span",
                title: i,
                whiteSpace: "nowrap",
                textOverflow: "ellipsis",
                overflow: "hidden",
                children: s
            }), n.jsxs(K, {
                spacing: 2,
                children: [n.jsx(ue, { ...ds,
                    title: "Copy",
                    variant: "solid",
                    fontSize: "sm",
                    fontFamily: "mono",
                    leftIcon: n.jsx(L, {
                        as: si
                    }),
                    onClick: m,
                    children: d
                }), u && n.jsx(ue, { ...ds,
                    as: we,
                    title: r === "pair" ? "Show liquidity providers" : "Show holders",
                    href: u,
                    target: "_blank",
                    rel: "noopener noreferrer nofollow",
                    minW: "40px",
                    rightIcon: n.jsx(L, {
                        as: yt,
                        boxSize: "10px"
                    }),
                    fontWeight: "normal",
                    children: r === "pair" ? "LPs" : "HLD"
                }), h && n.jsx(ue, { ...ds,
                    as: we,
                    title: "Open in block explorer",
                    href: h,
                    target: "_blank",
                    rel: "noopener noreferrer nofollow",
                    rightIcon: n.jsx(L, {
                        as: yt,
                        boxSize: "10px"
                    }),
                    fontWeight: "normal",
                    children: "EXP"
                })]
            })]
        })
    },
    Hm = e => {
        var c;
        const {
            pair: t,
            isMoonshot: o
        } = e, r = ((c = dr().current) == null ? void 0 : c.time) || Date.now(), s = t.pairCreatedAt ? Xl(t.pairCreatedAt, {
            now: r
        }) : void 0, i = f.useMemo(() => {
            if (!t.priceUsd || !t.liquidity) return;
            const d = t.priceUsd.replace(/,/g, ""),
                u = new mt(t.liquidity.base).multipliedBy(d),
                h = new mt(d).dividedBy(t.price.replace(/,/g, "")).multipliedBy(t.liquidity.quote);
            return {
                base: u.isFinite() && !u.isNaN() && !u.eq(0) ? u : void 0,
                quote: h.isFinite() && !h.isNaN() && !h.eq(0) ? h : void 0
            }
        }, [t.price, t.liquidity, t.priceUsd]), a = ["osmosis", "aptos", "acala", "near"].includes(t.chainId) === !1 && !o, l = t.chainId !== "osmosis" && t.chainId !== "acala";
        return {
            pair: t,
            timeAgo: s ? ? void 0,
            showPairContract: a,
            showTokenContracts: l,
            liquidityUsd: i
        }
    },
    Xt = 9,
    _m = e => {
        var c;
        const {
            pair: t,
            timeAgo: o,
            liquidityUsd: r,
            showPairContract: s,
            showTokenContracts: i
        } = Hm(e), a = th(), l = () => {
            a({
                query: t.baseToken.address,
                filters: {
                    moonshot: Ye(t)
                }
            })
        };
        return n.jsxs(I, {
            children: [n.jsxs(he, {
                spacing: 0,
                divider: n.jsx(bf, {
                    borderColor: ee("gray.125", "blue.900")
                }),
                alignItems: "stretch",
                fontSize: "sm",
                children: [o && n.jsxs(K, {
                    h: Xt,
                    children: [n.jsxs(q, {
                        as: "span",
                        flex: 1,
                        children: [e.isMoonshot ? "Token" : "Pair", " created"]
                    }), n.jsxs(q, {
                        as: "span",
                        fontWeight: "semibold",
                        children: [o, " ago"]
                    })]
                }), "moonshot" in t && t.moonshot && n.jsx(oo, {
                    containerProps: {
                        h: Xt
                    },
                    chainId: t.chainId,
                    pairContext: t.c,
                    contractType: "account",
                    label: "Creator",
                    address: (c = t.moonshot) == null ? void 0 : c.creator
                }), t.liquidity && n.jsxs(K, {
                    h: Xt,
                    spacing: "4",
                    children: [n.jsxs(q, {
                        as: "span",
                        flex: 1,
                        textOverflow: "ellipsis",
                        overflow: "hidden",
                        whiteSpace: "nowrap",
                        children: ["Pooled ", t.baseToken.symbol]
                    }), n.jsx(q, {
                        as: "span",
                        fontWeight: "semibold",
                        textAlign: "right",
                        children: It(t.liquidity.base)
                    }), (r == null ? void 0 : r.base) && n.jsx(q, {
                        as: "span",
                        fontWeight: "semibold",
                        textAlign: "right",
                        children: hr(r.base)
                    })]
                }), t.liquidity && n.jsxs(K, {
                    h: Xt,
                    spacing: "4",
                    children: [n.jsxs(q, {
                        as: "span",
                        flex: 1,
                        textOverflow: "ellipsis",
                        overflow: "hidden",
                        whiteSpace: "nowrap",
                        children: ["Pooled ", t.quoteTokenSymbol]
                    }), n.jsx(q, {
                        as: "span",
                        fontWeight: "semibold",
                        textAlign: "right",
                        children: It(t.liquidity.quote)
                    }), (r == null ? void 0 : r.quote) && n.jsx(q, {
                        as: "span",
                        fontWeight: "semibold",
                        textAlign: "right",
                        children: hr(r.quote)
                    })]
                }), t.c === "b" && n.jsxs(I, {
                    display: "flex",
                    h: Xt,
                    alignItems: "center",
                    justifyContent: "space-between",
                    children: [n.jsx(q, {
                        as: "span",
                        children: "Pool"
                    }), n.jsx(q, {
                        as: "span",
                        children: t.pn
                    })]
                }), s && n.jsx(oo, {
                    containerProps: {
                        h: Xt
                    },
                    chainId: t.chainId,
                    pairContext: t.c,
                    contractType: "pair",
                    label: "Pair",
                    address: t.pairAddress
                }), i && n.jsx(oo, {
                    containerProps: {
                        h: Xt
                    },
                    chainId: t.chainId,
                    pairContext: t.c,
                    contractType: "token",
                    label: t.baseToken.symbol,
                    address: t.baseToken.address
                }), !e.isMoonshot && i && n.jsx(oo, {
                    containerProps: {
                        h: Xt
                    },
                    chainId: t.chainId,
                    pairContext: t.c,
                    contractType: "token",
                    label: t.quoteToken.symbol,
                    address: t.quoteToken.address
                }), e.isMoonshot && n.jsx(oo, {
                    containerProps: {
                        h: Xt
                    },
                    chainId: t.chainId,
                    pairContext: t.c,
                    contractType: "account",
                    label: "Bonding curve",
                    address: t.pairAddress
                })]
            }), !e.isMoonshot && n.jsxs(K, {
                mt: 1,
                children: [n.jsx(ue, {
                    flex: "auto",
                    as: we,
                    href: `https://twitter.com/search?q=%24${encodeURIComponent(t.baseToken.symbol)}`,
                    target: "_blank",
                    rel: "nofollow",
                    variant: "outline",
                    size: "sm",
                    leftIcon: n.jsx(L, {
                        as: gc
                    }),
                    textDecor: "none !important",
                    children: "Search on Twitter"
                }), n.jsx(ue, {
                    flex: "auto",
                    variant: "outline",
                    size: "sm",
                    leftIcon: n.jsx(L, {
                        as: nh
                    }),
                    onClick: l,
                    _focus: {
                        boxShadow: "none"
                    },
                    children: "Other pairs"
                })]
            })]
        })
    },
    Om = {
        backgroundColor: ["rgba(255, 255, 255, 0)", "rgba(255, 215, 13, 0.3)", "rgba(255, 255, 255, 0)"],
        transition: {
            ease: "easeOut",
            duration: 1
        }
    },
    io = ({
        children: e,
        display: t,
        animateOn: o = "update",
        value: r,
        animationDefinition: s = Om
    }) => {
        const [i, a] = cg(), l = f.useRef(!0);
        return f.useEffect(() => {
            (o === "mount" && l.current === !0 || o === "update" && l.current === !1) && a(i.current, s), l.current === !0 && (l.current = !1)
        }, [r, a, i, s, o, l]), n.jsx(I, {
            ref: i,
            display: t,
            children: e
        })
    },
    Um = Z.enum(["telegram", "twitter", "discord", "facebook", "tiktok"]),
    Vm = Z.object({
        type: Um,
        url: Z.string().url()
    }),
    Xm = Z.object({
        label: Z.string(),
        url: Z.string().url()
    }),
    qm = Z.object({
        chainId: Z.string(),
        dexId: Z.string(),
        url: Z.string(),
        pairAddress: Z.string(),
        labels: or(Z.string()).optional(),
        baseToken: Z.object({
            address: Z.string(),
            name: Z.string(),
            symbol: Z.string()
        }),
        quoteToken: Z.object({
            address: Z.string().optional(),
            name: Z.string().optional(),
            symbol: Z.string().optional()
        }).optional(),
        priceNative: Z.string(),
        priceUsd: Z.string().optional(),
        txns: Z.object({
            m5: Z.object({
                buys: Z.number(),
                sells: Z.number()
            }),
            h1: Z.object({
                buys: Z.number(),
                sells: Z.number()
            }),
            h6: Z.object({
                buys: Z.number(),
                sells: Z.number()
            }),
            h24: Z.object({
                buys: Z.number(),
                sells: Z.number()
            })
        }),
        volume: Z.object({
            m5: Z.number(),
            h1: Z.number(),
            h6: Z.number(),
            h24: Z.number()
        }),
        priceChange: Z.object({
            m5: Z.number().optional(),
            h1: Z.number().optional(),
            h6: Z.number().optional(),
            h24: Z.number().optional()
        }),
        liquidity: Z.object({
            usd: Z.number().optional(),
            base: Z.number(),
            quote: Z.number()
        }).optional(),
        fdv: Z.number().optional(),
        pairCreatedAt: Z.number().optional(),
        info: Z.object({
            imageUrl: Z.string().url().optional(),
            websites: or(Xm).optional(),
            socials: or(Vm).optional()
        }).optional()
    }),
    Ya = Z.object({
        schemaVersion: Z.string(),
        pairs: or(qm).nullable()
    }),
    Gm = Ve("@dexscreener/data-access-dex-api/dexAPIDataSource", oh(), qs, (e, t) => ({
        getTokenPairs: async ({
            bustCache: o,
            signal: r,
            tokenAddresses: s
        }) => {
            const i = new URL(e.DS_DEX_API_PUBLIC_ORIGIN);
            return i.pathname = `/latest/dex/tokens/${s.map(encodeURIComponent).join(",")}`, e.DS_DEX_API_FULL_ACCESS_TOKEN && i.searchParams.append("fullAccessToken", e.DS_DEX_API_FULL_ACCESS_TOKEN), o && i.searchParams.append("timestamp", `${Date.now()}`), await t.get(i.toString(), Ya, {
                signal: r
            })
        },
        getChainPairs: async ({
            bustCache: o,
            chainId: r,
            signal: s,
            tokenAddresses: i
        }) => {
            const a = new URL(e.DS_DEX_API_PUBLIC_ORIGIN);
            return a.pathname = `/latest/dex/pairs/${r}/${i.map(encodeURIComponent).join(",")}`, e.DS_DEX_API_FULL_ACCESS_TOKEN && a.searchParams.append("fullAccessToken", e.DS_DEX_API_FULL_ACCESS_TOKEN), o && a.searchParams.append("timestamp", `${Date.now()}`), await t.get(a.toString(), Ya, {
                signal: s
            })
        }
    })),
    Km = ["No pre-sale, no insiders, max 1B supply", "Ownership renounced, immutable", "Fully audited smart contracts", "Buy and sell at any time"],
    Qm = [{
        emoji: "💪",
        component: function(t) {
            return n.jsxs(n.Fragment, {
                children: ["Once market cap reaches", " ", n.jsxs(k, {
                    fontWeight: "semibold",
                    children: [Ct({
                        number: pt(t.marketCapThreshold).dividedBy(10 ** go.DEFEAULT_CONFIG.collateralDecimalsNr),
                        significantDigits: 0,
                        maxDecimalPrecision: 0
                    }), " ", "SOL (~", Ct({
                        number: pt(t.marketCapThreshold).dividedBy(10 ** go.DEFEAULT_CONFIG.collateralDecimalsNr).multipliedBy(t.solPriceUsd).dividedBy(1e3),
                        significantDigits: 1,
                        maxDecimalPrecision: 1,
                        suffix: "k",
                        prefix: "$"
                    }), ")"]
                }), " ", "all remaining tokens and liquidity migrate to Raydium"]
            })
        }
    }, {
        emoji: "🔥",
        component: () => n.jsxs(n.Fragment, {
            children: [n.jsx(k, {
                fontWeight: "semibold",
                children: "~150M-200M"
            }), " tokens burned for a ", n.jsx(k, {
                fontWeight: "semibold",
                children: "deflationary boost"
            })]
        })
    }, {
        emoji: "🔒",
        component: () => n.jsxs(n.Fragment, {
            children: ["All ", n.jsx(k, {
                fontWeight: "semibold",
                children: "liquidity is locked"
            }), " by burning the LP token"]
        })
    }, {
        emoji: "🚀",
        component: () => n.jsxs(n.Fragment, {
            children: ["Free ", n.jsx(k, {
                fontWeight: "semibold",
                children: "Enhanced Token Info"
            }), " gives all Moonshot tokens the best chance to", " ", n.jsx(k, {
                fontWeight: "semibold",
                children: "trend on DEX Screener"
            }), "!"]
        })
    }],
    $m = ({
        source: e,
        marketCapThreshold: t = go.DEFEAULT_CONFIG.marketCapThreshold,
        ...o
    }) => {
        const r = xe(Gm),
            [s, i] = f.useState(130);
        return f.useEffect(() => {
            o.isOpen && r.getChainPairs({
                chainId: "ethereum",
                tokenAddresses: ["0x127452F3f9cDc0389b0Bf59ce6131aA3Bd763598"]
            }).then(({
                pairs: a
            }) => {
                var c;
                const l = (c = a == null ? void 0 : a.at(0)) == null ? void 0 : c.priceUsd;
                l && i(l)
            }).catch(ho)
        }, [o.isOpen, r]), n.jsxs(Qs, {
            motionPreset: "none",
            size: gr({
                base: "full",
                sm: "2xl"
            }),
            blockScrollOnMount: !1,
            isCentered: gr({
                base: !1,
                md: !0
            }),
            ...o,
            children: [n.jsx($s, {}), n.jsxs(Ys, {
                children: [n.jsx(Zs, {}), n.jsxs(ei, {
                    pt: 6,
                    pb: 10,
                    px: 10,
                    display: "flex",
                    flexDir: "column",
                    alignItems: "center",
                    textAlign: "center",
                    children: [n.jsx(k, {
                        color: "moonshot.accent.text",
                        children: n.jsx(Dn, {
                            width: "30px",
                            height: "30px"
                        })
                    }), n.jsxs(Lt, {
                        size: "4xl",
                        lineHeight: 7,
                        mt: 3,
                        children: [e === "token" && "This token was launched on ", n.jsx(k, {
                            color: "moonshot.accent.text",
                            children: "Moonshot"
                        }), e === "token" ? ", " : " is", " the best place to discover (and launch) the next trending token!"]
                    }), n.jsxs(he, {
                        mt: "7",
                        spacing: "8",
                        children: [n.jsxs(he, {
                            spacing: "3",
                            children: [n.jsx(Lt, {
                                as: "h2",
                                size: "3xl",
                                color: "moonshot.accent.text",
                                children: "Fair Launch"
                            }), n.jsx(Ta, {
                                display: "flex",
                                spacing: "3",
                                flexDir: "column",
                                textAlign: "center",
                                alignItems: "center",
                                fontSize: "xl",
                                children: Km.map(a => n.jsxs(Ia, {
                                    children: [n.jsx(zf, {
                                        as: ai,
                                        color: "moonshot.accent.text",
                                        pos: "relative",
                                        top: "-3px"
                                    }), n.jsx(k, {
                                        children: a
                                    })]
                                }, a))
                            })]
                        }), n.jsxs(he, {
                            spacing: "4",
                            children: [n.jsx(Lt, {
                                as: "h2",
                                size: "3xl",
                                color: "moonshot.accent.text",
                                children: "Wen Moon?"
                            }), n.jsx(Ta, {
                                display: "flex",
                                spacing: "4",
                                flexDir: "column",
                                textAlign: "center",
                                alignItems: "center",
                                fontSize: "xl",
                                children: Qm.map(a => {
                                    const l = a.component;
                                    return n.jsxs(Ia, {
                                        children: [n.jsx(k, {
                                            pr: "1.5",
                                            children: a.emoji
                                        }), n.jsx(l, {
                                            solPriceUsd: s,
                                            marketCapThreshold: t
                                        })]
                                    }, a.emoji)
                                })
                            })]
                        }), n.jsxs(he, {
                            children: [n.jsxs(I, {
                                bg: ee("gray.50", "whiteAlpha.50"),
                                p: "3",
                                borderRadius: "md",
                                children: [n.jsx(Lt, {
                                    size: "sm",
                                    children: "Disclaimer"
                                }), n.jsxs(q, {
                                    fontSize: "xs",
                                    mt: "1",
                                    children: ["Tokens launched on this platform are not endorsed by Moonshot. Moonshot is not an investment platform; your tokens could lose significant value at any time. By using Moonshot, you acknowledge all risks involved and agree to our", " ", n.jsx(we, {
                                        href: "https://docs.moonshot.cc/terms-and-conditions",
                                        target: "_blank",
                                        textDecor: "underline",
                                        children: "Terms and Conditions"
                                    }), "."]
                                })]
                            }), n.jsxs(K, {
                                fontSize: "sm",
                                children: [n.jsx(we, {
                                    href: "https://docs.moonshot.cc/faq",
                                    target: "_blank",
                                    textDecor: "underline",
                                    children: "FAQ"
                                }), n.jsx(we, {
                                    href: "https://docs.moonshot.cc/developers/data-api",
                                    target: "_blank",
                                    textDecor: "underline",
                                    children: "Data API"
                                }), n.jsx(we, {
                                    href: "https://docs.moonshot.cc/developers/bot-api",
                                    target: "_blank",
                                    textDecor: "underline",
                                    children: "Bot API"
                                })]
                            })]
                        }), n.jsxs(Ks, {
                            direction: {
                                base: "column",
                                md: "row"
                            },
                            spacing: {
                                base: 3,
                                md: 5
                            },
                            sx: {
                                "a:hover": {
                                    textDecor: "none"
                                }
                            },
                            children: [e === "screener" && n.jsx(ue, {
                                leftIcon: n.jsx(L, {
                                    as: Dn
                                }),
                                colorScheme: "moonshot",
                                size: "sm",
                                onClick: o.onClose,
                                children: "Explore Moonshot"
                            }), e === "token" && n.jsx(Qt, {
                                to: "/moonshot",
                                leftIcon: n.jsx(L, {
                                    as: Dn
                                }),
                                colorScheme: "moonshot",
                                size: "sm",
                                children: "Explore Moonshot"
                            }), n.jsx(Qt, {
                                to: "/moonshot/launch",
                                leftIcon: n.jsx(L, {
                                    as: rh
                                }),
                                colorScheme: "moonshot",
                                size: "sm",
                                children: "Launch your token"
                            }), n.jsx(ue, {
                                as: we,
                                href: sh,
                                target: "_blank",
                                leftIcon: n.jsx(L, {
                                    as: ih
                                }),
                                size: "sm",
                                children: "Telegram"
                            }), n.jsx(ue, {
                                as: we,
                                href: ah,
                                target: "_blank",
                                leftIcon: n.jsx(L, {
                                    as: gc
                                }),
                                size: "sm",
                                children: "Twitter"
                            })]
                        })]
                    })]
                })]
            })]
        })
    },
    Ym = ko `
  0% {
    transform:  translateX(0) scaleX(0);
  }
  40% {
    transform:  translateX(0) scaleX(0.4);
  }
  100% {
    transform:  translateX(100%) scaleX(0.5);
  }
`,
    Zm = ({
        progress: e,
        isIndeterminate: t,
        containerProps: o,
        trackColor: r,
        barColor: s
    }) => {
        const {
            colorMode: i
        } = pe(), a = e >= 100 ? 100 : Math.min(Math.floor(e), 98), l = f.useRef(t), c = l.current === !0 && t === !1 ? void 0 : "width 0.5s";
        return l.current = t, n.jsxs(I, {
            w: "100%",
            h: "8px",
            bg: r ? ? T("gray.100", "gray.700", i),
            borderRadius: "full",
            overflow: "hidden",
            textAlign: "left",
            ...o,
            children: [e > 0 && !t && n.jsx(I, {
                bg: s ? ? "moonshot.progress",
                h: "100%",
                transition: c,
                w: `${a}%`,
                minW: "4%",
                borderRadius: "full"
            }), t && n.jsx(I, {
                bg: s ? ? "moonshot.progress",
                w: "100%",
                h: "100%",
                borderRadius: "full",
                animation: `${Ym} 0.5s infinite linear`,
                transformOrigin: "0% 50%"
            })]
        })
    },
    Jm = ({
        pair: e
    }) => {
        const {
            value: t,
            disable: o,
            enable: r
        } = Yt(!1);
        return n.jsxs(n.Fragment, {
            children: [n.jsxs(he, {
                alignItems: "stretch",
                children: [n.jsx(Zc, {
                    variant: "outline",
                    children: n.jsxs(he, {
                        alignItems: "center",
                        spacing: "1",
                        marginTop: "0.5",
                        marginBottom: "2",
                        paddingX: "2",
                        children: [n.jsxs(I, {
                            display: "flex",
                            w: "100%",
                            justifyContent: "space-between",
                            children: [n.jsxs(K, {
                                children: [n.jsx(k, {
                                    color: "moonshot.accent.text",
                                    fontWeight: "bold",
                                    children: Ct({
                                        number: e.moonshot.progress,
                                        significantDigits: 1,
                                        maxDecimalPrecision: 1,
                                        suffix: "%"
                                    })
                                }), n.jsxs(k, {
                                    color: "gray.500",
                                    children: [n.jsx(k, {
                                        color: ee("black", "white"),
                                        fontWeight: "semibold",
                                        children: e.moonshot.quoteMcap
                                    }), " ", "of", " ", Ct({
                                        number: pt(e.moonshot.mcapThreshold).dividedBy(10 ** go.DEFEAULT_CONFIG.collateralDecimalsNr),
                                        significantDigits: 0,
                                        maxDecimalPrecision: 0
                                    }), " ", e.quoteToken.symbol]
                                })]
                            }), n.jsxs(k, {
                                as: "button",
                                display: "flex",
                                alignItems: "center",
                                gap: "1",
                                fontSize: "xs",
                                transition: "opacity 0.5s",
                                opacity: .7,
                                _hover: {
                                    opacity: 1
                                },
                                onClick: r,
                                children: [n.jsx(L, {
                                    as: lh,
                                    pos: "relative",
                                    top: "-1px"
                                }), "What's this?"]
                            })]
                        }), n.jsx(Zm, {
                            progress: e.moonshot.progress
                        })]
                    })
                }), e.moonshot.curvePos !== "0" && n.jsxs(K, {
                    fontWeight: "semibold",
                    fontSize: "lg",
                    children: [n.jsx(rt, {
                        variant: "outline",
                        label: "Price",
                        children: e.priceUsd && n.jsx(io, {
                            display: "inline-block",
                            value: e.priceUsd,
                            children: mo(e.priceUsd)
                        })
                    }), n.jsx(rt, {
                        variant: "outline",
                        label: "Market Cap",
                        children: e.fdv && rr(e.fdv)
                    })]
                })]
            }), n.jsx($m, {
                source: "token",
                isOpen: t,
                onClose: o,
                marketCapThreshold: e.moonshot.mcapThreshold
            })]
        })
    },
    ep = ({
        copyText: e,
        onClick: t,
        toastText: o,
        ...r
    }) => {
        const s = De(e),
            [, i] = Ar(),
            a = Qn(),
            l = f.useCallback(c => {
                t == null || t(c), i(s.current), o && a({
                    status: "success",
                    description: o,
                    isClosable: !0
                })
            }, [s, i, t, a, o]);
        return n.jsx(ue, {
            rightIcon: n.jsx(L, {
                as: ch
            }),
            ...r,
            onClick: l
        })
    },
    tp = e => {
        switch (e) {
            case "lg":
                return "4";
            case "md":
                return "3";
            case "sm":
                return "2";
            case "xs":
                return "1";
            default:
                return "2"
        }
    },
    sd = f.forwardRef((e, t) => {
        const {
            size: o,
            leftElementProps: r,
            rightElementProps: s,
            leftElement: i,
            rightElement: a,
            ...l
        } = e, c = !!i, d = c ? "100px" : void 0, u = tp(o);
        return n.jsxs(On, {
            size: o,
            children: [c ? n.jsx(vi, {
                width: "auto",
                maxWidth: d,
                pl: u,
                pointerEvents: "none",
                ...r,
                children: i
            }) : null, n.jsx(dh, {
                ref: t,
                size: o,
                fontSize: "1rem",
                fontWeight: "semibold",
                paddingLeft: d,
                ...l
            }), a ? n.jsx(Wr, {
                width: "auto",
                maxWidth: "24",
                paddingX: u,
                ...s,
                children: a
            }) : null]
        })
    }),
    np = f.forwardRef((e, t) => {
        const {
            direction: o,
            buyType: r,
            onBuyTypeToggle: s,
            currentTokenImageURL: i,
            quoteTokenSymbol: a,
            baseTokenSymbol: l,
            leftElementProps: c,
            rightElementProps: d,
            ...u
        } = e, h = o === "buy" && r === "quote" ? a : l, m = h || i, g = `Switch to ${r==="quote"?l:a}`;
        return n.jsx(sd, {
            ref: t,
            leftElement: m ? n.jsxs(K, {
                spacing: "1",
                overflow: "hidden",
                textOverflow: "ellipsis",
                whiteSpace: "nowrap",
                mr: 2,
                children: [i && n.jsx(Ze, {
                    src: i,
                    w: "16px",
                    h: "16px",
                    flexShrink: 0,
                    loading: "lazy"
                }), h && n.jsx(k, {
                    fontWeight: "semibold",
                    children: h
                })]
            }) : null,
            leftElementProps: c,
            rightElement: o === "buy" ? n.jsx(Je, {
                onClick: s,
                icon: n.jsx(L, {
                    as: mc
                }),
                title: g,
                "aria-label": g,
                size: "xs",
                isDisabled: u.isDisabled
            }) : null,
            rightElementProps: d,
            ...u
        })
    }),
    op = () => {
        const {
            walletState: e,
            connectWallet: t,
            disconnectWallet: o,
            walletAddress: r
        } = li(s => {
            var i;
            return {
                walletState: s.state,
                connectWallet: s.connect,
                disconnectWallet: s.disconnect,
                walletAddress: (i = s.wallet) == null ? void 0 : i.publicKey
            }
        });
        return {
            walletState: e,
            connectWallet: t,
            disconnectWallet: o,
            walletAddress: r
        }
    },
    rp = ({
        type: e,
        state: t,
        onSubmit: o,
        isDisabled: r
    }) => {
        const {
            walletState: s,
            connectWallet: i,
            disconnectWallet: a,
            walletAddress: l
        } = op();
        return n.jsx(uh, {
            children: s !== "connected" ? n.jsx(ue, {
                size: "sm",
                colorScheme: e === "buy" ? "moonshot" : "red",
                textTransform: "uppercase",
                isDisabled: s !== "disconnected" || r,
                isLoading: s !== "disconnected",
                leftIcon: n.jsx(L, {
                    as: Ca
                }),
                onClick: i,
                children: "Connect wallet"
            }) : n.jsxs(Tr, {
                size: "sm",
                colorScheme: e === "buy" ? "moonshot" : "red",
                width: "100%",
                isAttached: !0,
                children: [n.jsx(ue, {
                    isDisabled: t === "error" || t === "pending" || r,
                    isLoading: t === "pending",
                    loadingText: "Processing...",
                    textTransform: "uppercase",
                    flex: "1",
                    onClick: o,
                    children: e
                }), n.jsxs(Xn, {
                    children: [n.jsx(qn, {
                        as: Je,
                        icon: n.jsx(L, {
                            as: Ca
                        }),
                        "aria-label": "More",
                        opacity: t === "error" || t === "pending" || r ? .4 : void 0
                    }), n.jsx(pc, {
                        children: n.jsxs(Gn, {
                            children: [l && n.jsx(bn, {
                                closeOnSelect: !1,
                                children: hh(l, 6, 6)
                            }), n.jsx(bn, {
                                icon: n.jsx(L, {
                                    as: fh
                                }),
                                onClick: a,
                                children: "Disconnect"
                            })]
                        })
                    })]
                })]
            })
        })
    },
    Za = ({
        presets: e,
        onPresetClick: t,
        presetIsPercentage: o,
        isPresetsDisabled: r,
        children: s
    }) => {
        const {
            colorMode: i
        } = pe(), a = T("gray.100", "blue.850", i);
        return n.jsxs(he, {
            alignItems: "stretch",
            flex: "1",
            spacing: "0",
            children: [s, e.length > 0 && n.jsx(Tr, {
                isAttached: !0,
                borderWidth: 1,
                borderTopWidth: 1,
                borderColor: a,
                borderTopColor: T("gray.75", "whiteAlpha.100", i),
                borderBottomRadius: "md",
                overflow: "hidden",
                isDisabled: r,
                sx: {
                    button: {
                        borderRadius: 0
                    },
                    "button:not(:last-of-type)": {
                        borderRightWidth: 1,
                        borderRightColor: T("gray.125", "blackAlpha.400", i)
                    }
                },
                children: e.map(l => n.jsxs(ue, {
                    size: "xs",
                    flex: "1",
                    bg: T("gray.25", "whiteAlpha.50", i),
                    color: T("gray.500", "blue.400", i),
                    fontSize: "2xs",
                    borderRadius: "md",
                    fontWeight: "normal",
                    _hover: {
                        bg: T("gray.75", "whiteAlpha.200", i)
                    },
                    onClick: () => t(l),
                    children: [l, o && "%"]
                }, l))
            })]
        })
    },
    sp = Z.enum(["buy", "sell"]),
    Qo = {
        idle: {
            kind: "idle"
        },
        pending: {
            kind: "pending"
        }
    },
    Bs = .005,
    id = .001,
    Fs = .1,
    ip = (e, t, o) => o ? e.multipliedBy(t.dividedBy(100).plus(1)) : e.dividedBy(t.dividedBy(100).plus(1)),
    ap = {
        buy: [.1, .25, .5, 1, 2, 5],
        sell: [10, 20, 25, 50, 75, 100]
    },
    lp = {
        buy: [5, 10, 15, 20, 25, 50],
        sell: [5, 10, 15, 20, 25, 50]
    },
    Ja = "0.1",
    cp = ({
        pair: e,
        curvePosition: t,
        marketCapThreshold: o
    }) => {
        const r = xe(yh),
            s = xe(rg),
            i = xe(Os),
            a = f.useMemo(() => new go({
                config: {
                    marketCapThreshold: pt(o),
                    coefficientBMinimalUnits: parseInt(e.moonshot.coefB)
                }
            }), [o, e.moonshot.coefB]),
            [l, c] = f.useState("buy"),
            [d, u] = f.useState("quote"),
            [h, m] = f.useState(Ja),
            [g, p] = f.useState(() => {
                const N = s.calculateCost({
                    amount: et(Ja),
                    buyType: "quote",
                    direction: "buy",
                    curvePosition: t,
                    curve: a
                });
                return N && N.isNaN() === !1 ? new Jn(eo(N, a.getConfig().tokenDecimalsNr)).toString() : "10000"
            }),
            [b, j] = f.useState("0"),
            [y, S] = f.useState("15"),
            [w, v] = f.useState(Qo.idle),
            x = In(e.chainId),
            {
                wallet: C,
                signTransaction: E,
                getTokenBalance: R,
                balance: B,
                getCollateralBalance: A
            } = li(N => ({
                wallet: N.wallet,
                signTransaction: N.signTransaction,
                balance: N.balance,
                getTokenBalance: N.getTokenBalance,
                getCollateralBalance: N.getBalance
            })),
            P = fo(() => R({
                chainId: e.chainId,
                tokenAddress: e.baseToken.address
            }), [R, e.baseToken.address, e.chainId]),
            D = l === "buy" && d === "quote",
            O = l === "buy" ? d === "quote" ? et(h) : et(g) : et(b),
            V = et(y),
            z = s.calculateCost({
                amount: O,
                buyType: d,
                direction: l,
                curvePosition: t,
                curve: a
            }),
            H = z ? eo(z, D ? a.getConfig().collateralDecimalsNr : a.getConfig().tokenDecimalsNr) : void 0,
            oe = H ? ip(H, V, l === "buy" && d === "base") : void 0,
            re = [],
            ye = !O.isNaN() && O.toNumber() >= 0,
            fe = !V.isNaN(),
            je = V.gte(Fs),
            ze = l === "buy" && ye ? be({
                value: B,
                onPending: vn,
                onFailure: vn,
                onSuccess: N => N === void 0 ? !0 : d === "quote" ? O.lte(N) : et(h).lte(N)
            }) : void 0,
            Me = l === "sell" && ye ? be({
                value: P,
                onPending: vn,
                onFailure: vn,
                onSuccess: N => N ? O.lte(N) : !0
            }) : void 0,
            Fe = l === "buy" ? pt(h).gte(Bs) || pt(h).eq(0) : void 0,
            Be = l === "sell" && H ? H.gte(id) || H.eq(0) : void 0;
        ye || re.push("invalid-amount"), fe || re.push("invalid-slippage"), je || re.push("min-slippage"), oe !== void 0 && oe.isNaN() && re.push("invalid-amount-with-slippage"), ze === !1 && re.push("not-enough-collateral"), Me === !1 && re.push("not-enough-token"), Fe === !1 && re.push("min-buy-amount"), Be === !1 && re.push("min-sell-amount");
        const W = re.length > 0,
            se = re.findIndex(N => N === "not-enough-collateral" || N === "not-enough-token") === -1,
            J = De(l),
            de = De(d),
            ie = De(a),
            U = De(t),
            F = f.useCallback(N => {
                m(N);
                const ne = s.calculateCost({
                    amount: et(N),
                    buyType: "quote",
                    direction: "buy",
                    curvePosition: U.current,
                    curve: ie.current
                });
                ne && ne.isNaN() === !1 && p(new Jn(eo(ne, ie.current.getConfig().tokenDecimalsNr)).toString())
            }, [s, U, ie]),
            G = f.useCallback(N => {
                be({
                    value: P,
                    onPending: ho,
                    onFailure: ho,
                    onSuccess: ne => {
                        if (ne === void 0) return;
                        const Pe = new Jn(ne).multipliedBy(N / 100);
                        Pe.isNaN() || (N === 100 && Pe.gt(1) ? j(Pe.minus(1).toFixed(0, mt.ROUND_DOWN)) : j(Pe.toFixed(0, mt.ROUND_DOWN)))
                    }
                })
            }, [P]),
            ce = f.useCallback(N => {
                switch (J.current) {
                    case "buy":
                        {
                            if (de.current === "quote") {
                                m(N);
                                const ne = s.calculateCost({
                                    amount: et(N),
                                    buyType: de.current,
                                    direction: J.current,
                                    curvePosition: U.current,
                                    curve: ie.current
                                });
                                ne && ne.isNaN() === !1 && p(new Jn(eo(ne, ie.current.getConfig().tokenDecimalsNr)).toString());
                                return
                            }
                            if (de.current === "base") {
                                p(N);
                                const ne = s.calculateCost({
                                    amount: et(N),
                                    buyType: de.current,
                                    direction: J.current,
                                    curvePosition: U.current,
                                    curve: ie.current
                                });
                                ne && ne.isNaN() === !1 && m(new Jn(eo(ne, ie.current.getConfig().collateralDecimalsNr)).toString())
                            }
                            return
                        }
                    case "sell":
                        return j(N)
                }
            }, [J, de, U, ie, s]),
            Q = ri(N => N.pipe(Lf(1), an(ne => {
                v(Qo.idle), ne.success === !0 && J.current === "sell" && j("0")
            })), [J]),
            le = f.useCallback(async () => {
                var ne, Pe;
                if (!(C != null && C.publicKey)) return;
                v(Qo.pending);
                const N = gh();
                try {
                    const Ke = new mt(y).multipliedBy(100).toNumber(),
                        Ne = J.current === "buy" ? de.current === "quote" ? et(h) : et(g) : et(b),
                        ct = J.current === "buy" && de.current === "quote" ? s.getTokensNumberFromCollateral({
                            curvePosition: new mt(t),
                            direction: J.current,
                            amount: Ne,
                            curve: ie.current
                        }) : Bn(Ne, ie.current.getConfig().tokenDecimalsNr),
                        kt = J.current === "buy" && de.current === "quote" ? Bn(Ne, ie.current.getConfig().collateralDecimalsNr) : s.calculateCost({
                            curvePosition: new mt(t),
                            direction: J.current,
                            buyType: de.current,
                            amount: Ne,
                            curve: ie.current
                        });
                    if (!ct || !kt) return;
                    const zt = await r.txPrepare({
                            traceId: N,
                            direction: J.current,
                            creatorPK: C == null ? void 0 : C.publicKey,
                            amount: ct.toString(),
                            collateralAmount: kt.toString(),
                            slippageBps: Ke,
                            mintAddress: e.baseToken.address,
                            curveType: ie.current.getConfig().type,
                            coefB: ie.current.getConfig().coefficientBMinimalUnits
                        }),
                        Mt = await E(zt.transaction);
                    if (!Mt) {
                        v({
                            kind: "error",
                            message: "Transaction signing failed"
                        });
                        return
                    }
                    const nt = await r.txSubmit({
                        traceId: N,
                        direction: J.current,
                        signedTransaction: Mt,
                        token: zt.token
                    });
                    if (nt.status === "success" || nt.status === "pending") {
                        v({
                            kind: "success",
                            txnHash: nt.transactionSignature,
                            blockExplorerLink: (ne = x == null ? void 0 : x.txnsURL) == null ? void 0 : ne.call(x, nt.transactionSignature),
                            isConfirmed: nt.status === "success"
                        }), A(), R({
                            chainId: e.chainId,
                            tokenAddress: e.baseToken.address
                        }), Q({
                            success: !0
                        });
                        return
                    }
                    v({
                        kind: "error",
                        message: nt.status,
                        txnHash: nt.transactionSignature,
                        blockExplorerLink: (Pe = x == null ? void 0 : x.txnsURL) == null ? void 0 : Pe.call(x, nt.transactionSignature)
                    }), Q({
                        success: !1
                    })
                } catch (Ke) {
                    const Ne = jh(Ke);
                    if (Ne instanceof mh) {
                        v(Qo.idle);
                        return
                    }
                    if (i.error({
                            event: {
                                id: "initiateTransactionError",
                                data: {
                                    traceId: N,
                                    error: Ne
                                }
                            }
                        }), Ne instanceof ph || Ne instanceof xh || Ne instanceof bh) {
                        v({
                            kind: "error",
                            message: "Client/server mismatch, please refresh the page and try again!"
                        });
                        return
                    } else if (Ne instanceof vh) {
                        v({
                            kind: "error",
                            message: Ne.message,
                            traceId: N
                        });
                        return
                    }
                    v({
                        kind: "error"
                    }), Q({
                        success: !1
                    })
                }
            }, [C == null ? void 0 : C.publicKey, y, J, de, h, g, b, s, t, ie, r, e.baseToken.address, e.chainId, E, x, Q, A, R, i]),
            te = f.useCallback(() => {
                u(N => N === "quote" ? "base" : "quote")
            }, []);
        return {
            activeTab: l,
            setActiveTab: c,
            buyType: d,
            toggleBuyType: te,
            receiveOrSpend: oe == null ? void 0 : oe.toNumber(),
            amountPresets: ap[l],
            slippagePresets: lp[l],
            amount: l === "buy" ? d === "quote" ? h : g : b,
            setAmount: ce,
            setBuyAmountInQuoteValue: F,
            slippage: y,
            setSlippage: S,
            errors: re,
            hasError: W,
            hasFunds: se,
            isSlippageValid: fe,
            isAmountValid: ye,
            initiateTransaction: le,
            txState: w,
            balance: B,
            tokenBalance: P,
            setSellAmountAsPercentage: G,
            isAmountPresetsDisabled: l === "sell" && C === void 0
        }
    },
    us = ["buy", "sell"],
    el = e => {
        const {
            colorMode: t
        } = pe(), o = T("red.400", "red.300", t), r = e.variant === "success" ? T("moonshot.650", "moonshot.850", t) : o, s = e.variant === "success" ? "moonshot.accent.text" : o;
        return n.jsxs(I, {
            background: T("moonshot.25", "moonshot.1000", t),
            padding: {
                base: 2,
                md: 3
            },
            borderRadius: "md",
            borderWidth: "1px",
            borderColor: r,
            position: "relative",
            children: [e.isClosable && n.jsx(Fn, {
                onClick: e.onClose,
                size: "sm",
                position: "absolute",
                right: "1",
                top: "1",
                border: "0"
            }), n.jsxs(he, {
                spacing: "1",
                children: [e.title && n.jsx(k, {
                    fontWeight: "semibold",
                    color: s,
                    children: e.title
                }), e.description && n.jsx(k, {
                    children: e.description
                }), n.jsxs(Ro, {
                    justify: "center",
                    children: [e.blockExplorerLink && n.jsx(ue, {
                        as: we,
                        size: "sm",
                        href: e.blockExplorerLink,
                        target: "_blank",
                        variant: "ghost",
                        rel: "noopener noreferrer",
                        sx: {
                            "&:hover": {
                                textDecoration: "none"
                            }
                        },
                        rightIcon: n.jsx(L, {
                            as: yt
                        }),
                        iconSpacing: "1.5",
                        fontWeight: "normal",
                        children: "Open in block explorer"
                    }), e.variant === "error" && e.traceId ? n.jsx(ep, {
                        size: "sm",
                        variant: "outline",
                        copyText: e.traceId,
                        toastText: "Trace ID copied!",
                        children: "Copy Trace ID"
                    }) : null]
                })]
            })]
        })
    },
    dp = ({
        pair: e,
        curvePosition: t,
        marketCapThreshold: o,
        isDisabled: r
    }) => {
        const {
            activeTab: s,
            setActiveTab: i,
            buyType: a,
            receiveOrSpend: l,
            amountPresets: c,
            slippagePresets: d,
            amount: u,
            slippage: h,
            setAmount: m,
            setSlippage: g,
            hasError: p,
            hasFunds: b,
            tokenBalance: j,
            balance: y,
            isSlippageValid: S,
            isAmountValid: w,
            initiateTransaction: v,
            txState: x,
            toggleBuyType: C,
            setBuyAmountInQuoteValue: E,
            setSellAmountAsPercentage: R,
            isAmountPresetsDisabled: B,
            errors: A
        } = cp({
            pair: e,
            curvePosition: t,
            marketCapThreshold: o
        }), P = xe(Ir), D = xe(jc), {
            colorMode: O
        } = pe(), V = T("gray.100", "blue.850", O), z = T("gray.50", "blue.950", O), H = T("gray.100", "blue.850", O), oe = {
            buy: T("accent.darkGreen", "accent.lightGreen", O),
            sell: T("red.500", "red.300", O)
        }, re = V, ye = T("gray.500", "blue.500", O), fe = T("red.400", "red.300", O), je = T("gray.700", "blue.300", O), ze = T("gray.100", "blue.850", O), Me = T("white", "blackAlpha.150", O), Fe = T("white", "blackAlpha.300", O), Be = T("gray.975", "white", O), W = Qn(), se = f.useRef(null), J = f.useRef(null), de = f.useMemo(() => s === "buy" && a === "quote" ? P(e.chainId) : e.cmsProfile ? D({
            assetId: e.cmsProfile.iconId,
            size: "lg",
            fit: "crop"
        }) : void 0, [s, P, D, a, e.chainId, e.cmsProfile]), ie = N => ({
            color: N ? je : fe,
            borderRadius: "md",
            borderColor: ze,
            borderBottomRadius: 0,
            borderBottomWidth: 0,
            _hover: {
                bg: Me
            },
            _focus: {
                boxShadow: "none",
                borderColor: ze,
                bg: Fe,
                color: N ? Be : fe
            },
            leftElementProps: {
                color: je
            }
        }), U = De(s), F = f.useCallback(N => {
            var Pe;
            const ne = sp.safeParse(us[N]);
            ne.success && (i(ne.data), (Pe = se.current) == null || Pe.focus())
        }, [i]), G = f.useCallback(N => m(N), [m]), ce = f.useCallback(N => {
            var ne;
            if ((ne = se.current) == null || ne.focus(), U.current === "buy") {
                E(`${N}`);
                return
            }
            R(N)
        }, [U, E, R]), Q = f.useCallback(N => g(N), [g]), le = f.useCallback(N => {
            var ne;
            g(`${N}`), (ne = J.current) == null || ne.focus()
        }, [g]), te = f.useCallback(() => {
            var N;
            C(), (N = se.current) == null || N.focus()
        }, [C]);
        return f.useEffect(() => {
            switch (x.kind) {
                case "idle":
                case "pending":
                    return;
                case "success":
                    {
                        W({
                            status: "success",
                            isClosable: !0,
                            position: "bottom-right",
                            duration: 3e4,
                            render: N => n.jsx(el, { ...N,
                                variant: "success",
                                title: x.isConfirmed ? "Transaction confirmed!" : "Transaction pending!",
                                description: x.isConfirmed ? void 0 : "Your transaction is pending! Please check block explorer for updates.",
                                blockExplorerLink: x.blockExplorerLink,
                                txnHash: x.txnHash
                            })
                        });
                        return
                    }
                case "error":
                    {
                        W({
                            status: "error",
                            isClosable: !0,
                            duration: 3e4,
                            position: "bottom-right",
                            render: N => n.jsx(el, { ...N,
                                variant: "error",
                                title: "Transaction failed!",
                                description: x.message ? ? "Please try again!",
                                blockExplorerLink: x.blockExplorerLink,
                                txnHash: x.txnHash,
                                traceId: x.traceId
                            })
                        });
                        return
                    }
            }
        }, [W, x]), r ? null : n.jsxs(Ci, {
            id: "moonshot-trade-widget",
            variant: "unstyled",
            size: "sm",
            index: us.indexOf(s),
            defaultIndex: 0,
            onChange: F,
            isLazy: !0,
            isManual: !0,
            opacity: r ? .6 : void 0,
            children: [n.jsx(ki, {
                justifyContent: "space-between",
                children: us.map(N => n.jsx(Ti, {
                    px: 0,
                    py: "7px",
                    flex: 1,
                    textTransform: "uppercase",
                    fontSize: "xs",
                    fontWeight: "semibold",
                    borderWidth: 1,
                    borderBottomWidth: 0,
                    borderColor: V,
                    color: oe[N],
                    _hover: {
                        bg: z
                    },
                    _selected: {
                        bg: H,
                        fontWeight: "semibold",
                        _hover: {}
                    },
                    _focus: {
                        boxShadow: "none"
                    },
                    sx: {
                        "&:not(:last-of-type)": {
                            borderRightWidth: 0
                        },
                        "&:first-of-type": {
                            borderTopLeftRadius: "base"
                        },
                        "&:last-of-type": {
                            borderTopRightRadius: "base"
                        }
                    },
                    children: N
                }, N))
            }), n.jsx(I, {
                m: 0,
                display: "flex",
                padding: "2.5",
                borderWidth: 1,
                borderColor: re,
                borderBottomLeftRadius: "base",
                borderBottomRightRadius: "base",
                children: n.jsxs(he, {
                    alignItems: "stretch",
                    flex: "1",
                    spacing: "2.5",
                    children: [n.jsx(Za, {
                        presets: c,
                        onPresetClick: ce,
                        presetIsPercentage: s === "sell",
                        isPresetsDisabled: B || r,
                        children: n.jsx(np, {
                            ref: se,
                            baseTokenSymbol: e.baseToken.symbol,
                            quoteTokenSymbol: e.quoteToken.symbol,
                            currentTokenImageURL: de,
                            onBuyTypeToggle: te,
                            direction: s,
                            buyType: a,
                            value: u,
                            onValueChange: G,
                            isInvalid: !w,
                            step: s === "buy" && a === "quote" ? "0.01" : "1",
                            min: s === "buy" ? Bs : 1,
                            isDisabled: r,
                            ...ie(w)
                        })
                    }), n.jsx(Za, {
                        presets: d,
                        onPresetClick: le,
                        presetIsPercentage: !0,
                        isPresetsDisabled: r,
                        children: n.jsx(sd, {
                            ref: J,
                            size: "sm",
                            leftElement: n.jsx(k, {
                                fontSize: "xs",
                                children: "Slippage %"
                            }),
                            value: h,
                            onValueChange: Q,
                            isInvalid: !S,
                            isDisabled: r,
                            min: Fs,
                            ...ie(S)
                        })
                    }), n.jsxs(he, {
                        alignItems: "stretch",
                        flex: "1",
                        spacing: "1",
                        children: [n.jsx(rp, {
                            state: p || !b || pt(u).eq(0) ? "error" : x.kind === "idle" || x.kind === "pending" ? x.kind : "idle",
                            type: s,
                            onSubmit: v,
                            isDisabled: r
                        }), n.jsx(I, {
                            fontSize: "xs",
                            children: n.jsx(I, {
                                minHeight: "24px",
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                                children: A[0] !== void 0 ? n.jsxs(k, {
                                    color: fe,
                                    fontSize: "xs",
                                    textAlign: "center",
                                    children: [A[0] === "invalid-amount" ? "Invalid amount!" : null, A[0] === "invalid-slippage" ? "Invalid slippage!" : null, A[0] === "min-slippage" ? `Min. slippage is ${Fs}!` : null, A[0] === "invalid-amount-with-slippage" ? "Invalid amount or slippage!" : null, A[0] === "min-sell-amount" ? `Min. sell amount is ${id} SOL` : null, A[0] === "min-buy-amount" ? `Min. buy amount is ${Bs} SOL` : null, A[0] === "not-enough-collateral" || A[0] === "not-enough-token" ? n.jsxs(n.Fragment, {
                                        children: ["Insufficient funds!", be({
                                            value: s === "buy" ? y : j,
                                            onPending: () => null,
                                            onFailure: () => null,
                                            onSuccess: N => N === void 0 ? null : n.jsxs(n.Fragment, {
                                                children: [" ", "(", Ct({
                                                    number: N,
                                                    significantDigits: {
                                                        lt1: 4,
                                                        gte1: 2
                                                    },
                                                    largeNumberSuffix: {
                                                        threshold: "million",
                                                        significantDigits: 2
                                                    }
                                                }), " ", s === "buy" ? e.quoteToken.symbol : e.baseToken.symbol, " avail.)"]
                                            })
                                        })]
                                    }) : null]
                                }) : l !== void 0 ? n.jsx(he, {
                                    children: n.jsxs(k, {
                                        color: ye,
                                        fontSize: "xs",
                                        textAlign: "center",
                                        children: ["you ", s === "buy" && a === "base" ? "spend max." : "receive min.", " ", n.jsxs(k, {
                                            fontWeight: "semibold",
                                            color: T("gray.600", "blue.300", O),
                                            children: [Ct({
                                                number: l,
                                                significantDigits: {
                                                    lt1: 4,
                                                    gte1: 2
                                                },
                                                largeNumberSuffix: {
                                                    threshold: "million",
                                                    significantDigits: 2
                                                }
                                            }), " "]
                                        }), s === "buy" && a === "quote" ? e.baseToken.symbol : e.quoteToken.symbol]
                                    })
                                }) : null
                            })
                        })]
                    })]
                })
            })]
        })
    },
    up = e => n.jsx("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 1190 1280",
        fill: "currentColor",
        ...e,
        children: n.jsx("path", {
            d: "M561 80.1c-109.6 8.8-192.4 62.6-237.5 154.4-8 16.2-15.5 34.7-15.5 38 0 .8-.4 1.5-.8 1.5s-.8.8-.9 1.7c-.1 1.9-.6 3.8-1.6 6.3-1.7 4.7-7.8 28.7-9.1 36-.3 1.9-.8 4.6-1.1 5.9-.2 1.4-.7 4.7-1 7.4-.3 2.8-.8 5.3-1 5.6-.8 1.3-2.4 18.9-2.8 31.3-.1 2.7-.5 4.8-1 4.8-.4 0-.3.9.3 2 .8 1.4.8 2 0 2-.7 0-.8.6-.1 1.9.6 1 .8 2.1.5 2.4-.3.3-.5 39.2-.4 86.5l.1 86-2.6 2c-1.4 1.1-6.9 3-12.3 4.3-15.9 3.6-26.6 7.4-36.4 12.8-10.9 6-14.9 9.1-24 18.3-20.6 20.8-33.4 56-35.3 96.8-.5 9.9-.4 302.2.1 312.5.8 17.5 2.8 31.9 4.6 34.3.7.8.7 1.2-.1 1.2-.7 0-.9.5-.4 1.3.4.6.8 1.6.9 2.2.1.5 1.1 3.4 2.3 6.2 1.1 2.9 1.7 5.3 1.3 5.3-.4 0-.2.4.3.8 1 .7 3.7 6.1 3.7 7.2 0 .3.6 1.2 1.4 2.1.8.9 1.2 1.8.9 2.1-.3.3.6 1.7 2 3.2 1.3 1.4 2.5 2.9 2.5 3.1 0 1.4 8.4 11.7 12.2 15 2.4 2.1 3.4 3.2 2.3 2.4-1.8-1.3-1.9-1.3-.6.3.7 1 1.7 1.8 2.2 1.8.5 0 1.7.8 2.7 1.7 3.9 3.7 6.7 5.7 12.1 8.6 17.5 9.4 26.7 12.1 52.1 15.3 11.1 1.3 46.1 1.5 312.1 1.4 310.6 0 312.3 0 331.4-3.9 22.1-4.5 39.7-13.4 53.1-27 16.1-16.2 23.8-34.2 26.9-62.6 1.2-10.7 1.5-40.7 1.5-169.6 0-86.2-.2-157.3-.4-158-.3-.8-.7-6.3-1-12.2-.4-6-.8-11.2-1-11.6-.3-.4-.7-2.7-1-5.1-1.7-14.3-7.6-34.2-13.7-46.3-3-5.7-10.7-17.6-13.8-21.1-6.2-6.9-15.9-16-17.4-16.4-1.3-.3-3.7-3-3.8-4.4 0-.7-.4-.4-.8.7-.8 1.9-.8 1.9-1.5-.3-.5-1.4-1.3-2.1-2.1-1.8-.8.3-1.9-.2-2.5-1-.7-.8-1.9-1.4-2.6-1.4-.8 0-1.4-.5-1.4-1 0-.6-.7-1-1.5-1s-1.5-.5-1.5-1c0-.6-.9-1-2-1s-2-.5-2-1.1c0-.5-.4-.7-1-.4-.5.3-1 .1-1-.5s-.4-.8-1-.5c-.5.3-1 .2-1-.4 0-.5-.8-.8-1.7-.6-1 .1-3-.4-4.5-1.1-1.5-.8-3.1-1.3-3.5-1.3-.4.1-1.6-.1-2.5-.4-4.6-1.8-5.4-2-6.9-2.3-.9-.2-2.7-.8-4-1.3-1.3-.5-2.7-.8-3-.7-.4 0-1.7-.8-3-1.9-1.4-1.3-2-1.4-1.5-.5.4.8-.4.2-1.8-1.3l-2.6-2.8v-84.7c-.1-46.6-.3-88.3-.5-92.7-.7-11.7-1.4-20.6-1.9-24-.3-2.4-2.6-16.9-4-25.5-2.1-12.5-3-17-3.6-17-.4 0-.6-1-.5-2.3.1-1.2-.1-2.7-.5-3.2-.5-.6-1.1-2.4-1.3-4-.9-4.6-1.4-6.8-2.5-9.6-.6-1.5-.8-2.9-.6-3.2.3-.3-.2-2.2-1-4.2-.9-2.1-1.6-4.7-1.6-5.9 0-1.6-.2-1.8-.9-.7-.7 1-1.1.1-1.6-3.2-.4-2.6-1.2-4.7-1.7-4.7-.6 0-.8-.9-.5-2 .3-1.1.1-2-.4-2s-.9-.7-.9-1.5-.4-1.5-1-1.5c-.5 0-.6-.7-.3-1.7.5-1.1.3-1.4-.6-.8-1 .6-1.1.2-.6-1.5.5-1.7.4-2.1-.5-1.5-.8.5-1.1.4-.6-.3.7-1.1-2.8-9.3-9.6-22.7-2.2-4.4-5.5-10.7-7.1-14-1.7-3.3-3.4-6.2-3.8-6.5-.3-.3-1.6-2.5-2.9-4.9-1.2-2.4-2.6-4.9-3.1-5.5-3-3.6-8.4-11.3-10.5-14.9-1.3-2.3-2.4-3.8-2.4-3.4 0 .4-.6.2-1.4-.5-.8-.7-1.2-1.6-.9-2 .2-.4-.7-1.9-2.1-3.3-1.5-1.4-2.6-3.1-2.6-3.7 0-.6-.3-.8-.7-.5-.3.4-1.3-.2-2-1.3-.8-1.1-1.9-1.8-2.4-1.5-.5.4-.9-.2-.9-1.2 0-1.1-2-3.9-4.5-6.3-2.4-2.4-4.2-4.7-3.9-5.2.3-.4-.4-.8-1.5-.8s-2.2-.9-2.6-2c-.3-1.1-1.3-2-2.1-2s-1.4-.7-1.4-1.5-.7-1.5-1.6-1.5c-.8 0-1.2-.5-.9-1 .3-.6-.1-1-.9-1-.9 0-1.6-.5-1.6-1.1 0-.5-.3-.8-.7-.6-.5.3-1.4-.1-2.1-.9-.7-.8-.9-1.4-.5-1.4.4-.1-.4-.8-1.9-1.6-1.6-.8-2.8-1.9-2.8-2.4 0-.6-.7-1-1.5-1s-1.5-.5-1.5-1c0-.6-.5-1-1-1-.6 0-2.1-1.1-3.4-2.5-1.3-1.4-2.6-2.5-3-2.5-.7 0-6.7-4.1-7.6-5.1-.3-.3-1.9-1.3-3.7-2.2-1.7-.9-3.7-2.2-4.5-2.9-1.8-1.7-5.9-4.2-14.3-8.5-3.8-1.9-7.3-4-7.6-4.5-.3-.5-.9-.9-1.2-.9-.4 0-2.6-.8-4.9-1.8-37.4-15.8-66.5-22.9-107.2-26.1-15-1.2-50.4-1.1-65.6.1zm47.5 121.4c10.3 1 14 1.5 24 3.1 9 1.5 28.3 6.7 31.4 8.5 1.7.9 7.4 3.1 7.9 3 1-.4 27.3 14.8 29.2 17 .3.3 2.3 1.8 4.4 3.5 2.2 1.6 4.9 3.8 6 4.9 1.2 1.1 3.5 3.1 5.1 4.3 1.7 1.3 2.3 2.1 1.5 1.7-.8-.4-.1.6 1.6 2.2 2.7 2.4 9.8 10.7 15.7 18.4 1 1.3 2.7 4 3.8 5.9 1.1 1.9 2.8 4.8 3.9 6.5 1.9 3 7.3 12.6 7.5 13.5.1.3 1 2.3 2 4.5s1.8 4.3 1.7 4.7c-.1.5.2.8.6.8.5 0 .9.6 1 1.2.2 2.9 2.9 8.8 3.7 8.1.4-.5.5-.3.1.4s.7 5 2.3 9.7c1.6 4.6 2.7 8.7 2.4 9-.3.3 0 1.2.7 2.1.7.9 1 1.8.7 2.2-.4.3-.2 1.2.4 2 .9 1 .8 1.3-.2 1.3-.9.1-.8.5.5 1.5 1.1.8 1.5 1.5.8 1.5-.8 0-.9.7-.1 2.7.6 1.6 1.2 3.7 1.4 4.8.8 4.9 2.7 20.3 2.9 23 0 1.6.5 3.3 1.1 3.7.7.5.6.8 0 .8s-1.1.9-1.1 2 .4 2 .9 2 .4.6-.2 1.4c-.9 1.1-.9 1.5.1 2s1 .7.1 1.2c-1.9.8-1.6 2.4.5 2.4 1 0 1.3.3.6.8-1.6 1-1.8 22.2-.3 22.2.8 0 .9.4 0 1.3-.8 1-1.2 21.5-1.3 70.7l-.3 69.4-3.4 2c-3.4 2-5.6 2-171.7 2.4-121.6.3-168.3.1-168.8-.7-.4-.6-2.2-1.1-4-1.1-6.9 0-6.5 5.9-6.6-90.5-.1-47.9-.1-87.2 0-87.5.1-.3.3-3.2.5-6.5.4-6.5 1-11.7 2.6-21 .6-3.3 1.2-7.1 1.3-8.5.2-1.4.6-3.2 1-4.1.4-.9.8-2.7 1-4.1.1-1.3.5-2.8.8-3.3.3-.6.9-2.8 1.3-5 .8-4.2 4.7-15.9 7.1-21.2.8-1.7 1.4-3.4 1.4-3.9 0-3.3 18.8-35.6 24.7-42.4 3.6-4.2 19.7-20 23.9-23.5 11-9.3 39.8-24 50.7-25.9.7-.1 2.8-.7 4.7-1.4 5.8-1.9 27.3-5.2 38.2-5.8 5.7-.4 10.4-.7 10.5-.8.4-.3 15.6.3 21.8.9z"
        })
    }),
    hp = e => n.jsxs("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 24.9 24.9",
        ...e,
        children: [n.jsx("defs", {
            children: n.jsxs("linearGradient", {
                id: "a",
                x1: 12.45,
                x2: 12.45,
                y1: 24.9,
                y2: 0,
                gradientUnits: "userSpaceOnUse",
                children: [n.jsx("stop", {
                    offset: 0,
                    stopColor: "#00c68d"
                }), n.jsx("stop", {
                    offset: 1,
                    stopColor: "#00f847"
                })]
            })
        }), n.jsx("path", {
            d: "M24.89 11.92c-.05-1.22-.28-2.4-.67-3.51-.03-.11-.08-.22-.12-.31C22.33 3.37 17.78 0 12.45 0 5.59 0 0 5.59 0 12.45S5.59 24.9 12.45 24.9c.54 0 1.08-.03 1.6-.11h.03c6-.79 10.65-5.86 10.8-12.03.01-.1.01-.21.01-.31v-.27c0-.09 0-.17-.01-.26Zm-22.72.53c0-5.67 4.61-10.28 10.28-10.28 3.18 0 6.03 1.45 7.94 3.72-.7-.14-1.47-.11-2.22.27L18 4.22a.177.177 0 0 0-.28-.13l-2.23 1.66-.6-1.07a.172.172 0 0 0-.31 0l-.75 1.36c-.79.26-1.52.69-2.13 1.35L5.65 5.73c-.18-.08-.31.17-.16.28 1.95 1.41 4.74 3.09 4.77 3.12 0 0-4.04 6.35-4.04 6.37-.62 1-.28 1.84.76 2.38.58.29 1.25.41 1.89.35.91-.1 2.72-.42 5.48-1.34.28.48.44 1.12.44 1.8 0 1.29-.57 2.77-2.02 3.77-.13.1-.28.18-.43.28-5.62-.06-10.17-4.66-10.17-10.28Zm10.77.25s-1.02.91-2.35.27l2.57-2.31s.81 1.1-.22 2.04Z",
            style: {
                fill: "url(#a)",
                strokeWidth: 0
            }
        })]
    }),
    fp = ({
        lockType: e,
        tokenLocks: t
    }) => {
        const o = ee("gray.500", "blue.100"),
            r = ee("gray.100", "blue.600"),
            s = f.useMemo(() => {
                let i = 0,
                    a;
                return t == null || t.locks.forEach(l => {
                    l.tag === "UNCX" && (i += l.percentage, a || (a = l.url))
                }), {
                    combinedPercentage: i,
                    lockUrl: a
                }
            }, [t]);
        return n.jsxs(K, {
            spacing: "3px",
            children: [n.jsxs(Si, {
                strategy: "fixed",
                isLazy: !0,
                children: [n.jsx(ji, {
                    children: n.jsx(I, {
                        cursor: "pointer",
                        minW: "auto",
                        h: "auto",
                        color: t ? o : r,
                        pos: "relative",
                        top: "-0.5px",
                        lineHeight: "5px",
                        children: n.jsx(Lc, {
                            value: t ? t.totalPercentage >= 95 ? 100 : Math.floor(t.totalPercentage) : 0,
                            size: "20px",
                            thickness: "12px",
                            color: "accent.lightGreen",
                            trackColor: ee("gray.150", "blue.600"),
                            capIsRound: !0,
                            children: n.jsx(Wc, {
                                children: n.jsx(up, {
                                    width: "10px",
                                    height: "10px",
                                    style: {
                                        marginLeft: "5px"
                                    }
                                })
                            })
                        })
                    })
                }), n.jsxs(wi, {
                    bg: "gray.950",
                    color: "white",
                    borderWidth: 0,
                    fontSize: "xs",
                    w: "200px",
                    p: "3",
                    textAlign: "left",
                    _focus: {
                        boxShadow: "none"
                    },
                    children: [t && n.jsxs(he, {
                        align: "stretch",
                        spacing: "4",
                        children: [n.jsxs(I, {
                            children: [n.jsxs(k, {
                                fontWeight: "semibold",
                                children: ["Total locked ", e]
                            }), n.jsxs(K, {
                                spacing: "1",
                                children: [n.jsxs(k, {
                                    children: [Ts(t.totalPercentage), "%"]
                                }), n.jsx(I, {
                                    flex: 1,
                                    mt: "0.5",
                                    children: n.jsx(wn, {
                                        containerProps: {
                                            w: "100%"
                                        },
                                        left: {
                                            label: "Unlocked",
                                            value: t.totalPercentage,
                                            bg: "accent.lightGreen"
                                        },
                                        right: {
                                            label: "Locked",
                                            value: 100 - t.totalPercentage,
                                            bg: "blue.600"
                                        },
                                        isJoined: !0,
                                        disableTooltip: !0
                                    })
                                })]
                            })]
                        }), t.locks.map(i => n.jsx(gi, {
                            if: i.url !== void 0,
                            with: a => n.jsx(we, {
                                href: i.url,
                                target: "_blank",
                                variant: "unstyled",
                                color: "blue.200",
                                _hover: {
                                    textDecor: "none",
                                    color: "blue.25"
                                },
                                children: a
                            }),
                            children: n.jsxs(k, {
                                color: i.url === void 0 ? "blue.200" : void 0,
                                children: [n.jsxs(k, {
                                    textDecor: i.url === void 0 ? void 0 : "underline",
                                    children: [i.tag, i.tag === "Burned" && i.address.startsWith("0x") && n.jsx(k, {
                                        ml: "2",
                                        color: "blue.500",
                                        fontWeight: "normal",
                                        fontFamily: "mono",
                                        children: Eo(i.address)
                                    })]
                                }), n.jsxs(K, {
                                    spacing: "1",
                                    children: [n.jsxs(k, {
                                        children: [Ts(i.percentage), "%"]
                                    }), n.jsx(I, {
                                        flex: 1,
                                        mt: "0.5",
                                        children: n.jsx(wn, {
                                            containerProps: {
                                                w: "100%"
                                            },
                                            left: {
                                                label: "Unlocked",
                                                value: i.percentage,
                                                bg: "accent.lightGreen"
                                            },
                                            right: {
                                                label: "Locked",
                                                value: 100 - i.percentage,
                                                bg: "blue.600"
                                            },
                                            isJoined: !0,
                                            disableTooltip: !0
                                        })
                                    })]
                                })]
                            })
                        }, i.address))]
                    }), !t && n.jsxs(k, {
                        children: ["No ", e, " locks found"]
                    })]
                })]
            }), s.combinedPercentage > 50 && n.jsx(we, {
                display: "flex",
                href: s.lockUrl,
                target: "_blank",
                pos: "relative",
                top: "-0.5px",
                children: n.jsx(L, {
                    as: hp,
                    width: "18px",
                    height: "18px"
                })
            })]
        })
    },
    gp = ({
        pair: e,
        marketCapInfo: t,
        liquidityLock: o,
        isInverted: r
    }) => {
        let s, i;
        return r && (e.priceUsd && (s = vf({
            priceUsd: e.priceUsd,
            price: e.price
        })), i = yf({
            price: e.price
        })), n.jsxs(he, {
            alignItems: "stretch",
            children: [n.jsxs(K, {
                fontWeight: "semibold",
                fontSize: "lg",
                children: [n.jsx(rt, {
                    variant: "outline",
                    label: "Price USD",
                    children: e.priceUsd && n.jsxs(n.Fragment, {
                        children: [!r && e.priceUsd && n.jsx(io, {
                            display: "inline-block",
                            value: e.priceUsd,
                            children: mo(e.priceUsd)
                        }), r && s && n.jsx(io, {
                            display: "inline-block",
                            value: s,
                            children: mo(s)
                        })]
                    })
                }), n.jsxs(rt, {
                    variant: "outline",
                    label: "Price",
                    wordBreak: "break-all",
                    lineHeight: "18px",
                    children: [!r && n.jsx(io, {
                        display: "inline-block",
                        value: e.price,
                        children: n.jsx(q, {
                            as: "span",
                            noOfLines: 1,
                            children: da(e.price, e.quoteTokenSymbol)
                        })
                    }), r && i && n.jsx(io, {
                        display: "inline-block",
                        value: i,
                        children: n.jsx(q, {
                            as: "span",
                            noOfLines: 1,
                            children: da(i, e.baseToken.symbol)
                        })
                    })]
                })]
            }), n.jsxs(K, {
                fontSize: "lg",
                fontWeight: "semibold",
                children: [n.jsx(rt, {
                    variant: "outline",
                    label: "Liquidity",
                    position: "relative",
                    children: e.liquidity && n.jsxs(K, {
                        justifyContent: "center",
                        spacing: "1",
                        children: [hr(e.liquidity.usd), o && n.jsx(fp, {
                            lockType: "liquidity",
                            tokenLocks: o
                        })]
                    })
                }), n.jsx(rt, {
                    variant: "outline",
                    label: "FDV",
                    tooltipProps: {
                        placement: "top-start",
                        label: n.jsxs(n.Fragment, {
                            children: [n.jsx(q, {
                                as: "span",
                                fontWeight: "semibold",
                                children: "Fully diluted valuation:"
                            }), n.jsx(q, {
                                as: "span",
                                display: "block",
                                fontFamily: "mono",
                                children: "(total supply - burned supply) * price"
                            })]
                        })
                    },
                    children: !r && e.fdv ? rr(e.fdv) : void 0
                }), n.jsx(rt, {
                    variant: "outline",
                    label: "Mkt Cap",
                    tooltipProps: t ? {
                        placement: "top-start",
                        label: n.jsxs(he, {
                            spacing: "1",
                            margin: "1",
                            children: [n.jsxs(he, {
                                spacing: "0",
                                children: [n.jsx(q, {
                                    children: "Total supply:"
                                }), n.jsx(q, {
                                    as: "span",
                                    fontWeight: "semibold",
                                    children: It(t.totalSupply, e.baseToken.symbol)
                                })]
                            }), t.totalSupply !== t.circulatingSupply && n.jsxs(he, {
                                spacing: "0",
                                children: [n.jsx(q, {
                                    children: "Self-reported circulating supply:"
                                }), n.jsx(q, {
                                    as: "span",
                                    fontWeight: "semibold",
                                    children: It(t.circulatingSupply, e.baseToken.symbol)
                                })]
                            })]
                        })
                    } : {
                        placement: "top-start",
                        label: n.jsxs(n.Fragment, {
                            children: ["Assuming circulating supply = total supply", n.jsx("br", {}), "(includes locked, excludes burned)"]
                        })
                    },
                    children: r ? n.jsx(Kt, {}) : t ? rr(t.usdValue) : e.marketCap ? rr(e.marketCap) : n.jsx(Kt, {})
                })]
            })]
        })
    },
    hs = e => Ct({
        number: e,
        significantDigits: {
            lt1: 4,
            gte1: 2
        },
        addCommas: !0
    }),
    mp = (e, t) => new po(e).dividedBy(t),
    tl = (e, t) => new po(e).multipliedBy(t),
    nl = "USD",
    ol = 1,
    pp = e => {
        const {
            baseToken: t,
            priceUsd: o,
            price: r,
            quoteToken: s,
            initialBaseTokenAmount: i = ol
        } = e, a = i === 0 ? ol : i, l = f.useRef("base"), [c, d] = f.useState(`${a}`), [u, h] = f.useState(hs(tl(a, mn(o ? ? r)))), [m, g] = f.useState(!1), p = De(m), b = De(o), j = De(r), y = f.useMemo(() => {
            const R = [s.symbol];
            return o && R.unshift(nl), R
        }, [s, o]), [S, w] = f.useState(y[0]), v = f.useMemo(() => S === nl, [S]), x = f.useCallback(R => {
            if (h(R), !R) {
                d(""), p.current && g(!1);
                return
            }
            const B = v && b.current ? mn(b.current) : j.current,
                A = mp(mn(R), B);
            if (A.isNaN()) {
                g(!0);
                return
            }
            p.current && g(!1), d(hs(A))
        }, [v, p, j, b]), C = f.useCallback(R => {
            if (d(R), !R) {
                h(""), p.current && g(!1);
                return
            }
            const B = v && b.current ? mn(b.current) : mn(j.current),
                A = tl(mn(R), B);
            if (A.isNaN()) {
                g(!0);
                return
            }
            p.current && g(!1), h(hs(A))
        }, [v, p, j, b]), E = f.useCallback(R => l.current = R, [l]);
        return ag(() => {
            if (l.current === "base") {
                C(c);
                return
            }
            x(u)
        }, [r, o, v]), {
            baseValue: c,
            baseTokenSymbol: t.symbol,
            currentToken: S,
            quoteValue: u,
            isQuoteUsd: v,
            hasError: m,
            quoteTokens: y,
            setCurrentToken: w,
            changeBaseValue: C,
            changeQuoteValue: x,
            setLastFocusedToken: E,
            lastFocusedRef: l
        }
    },
    xp = sg(function(t) {
        const {
            value: o,
            values: r,
            onChange: s
        } = t, i = ee("gray.300", "gray.600");
        return r.length === 1 ? n.jsx(k, {
            children: o
        }) : n.jsx(K, {
            spacing: "1",
            children: r.map(a => {
                const l = a === o;
                return n.jsx(ue, {
                    size: "sm",
                    paddingX: "2",
                    fontWeight: "normal",
                    color: l ? void 0 : i,
                    onClick: () => s == null ? void 0 : s(a),
                    variant: "ghost",
                    children: n.jsxs(K, {
                        spacing: "1",
                        children: [n.jsx(L, {
                            as: ai,
                            boxSize: "10px",
                            color: l ? "green.600" : i
                        }), n.jsx(k, {
                            children: a
                        })]
                    })
                }, a)
            })
        })
    }),
    fs = e => {
        const {
            onBaseTokenChange: t,
            isDisabled: o
        } = e, {
            hasError: r,
            baseTokenSymbol: s,
            baseValue: i,
            quoteValue: a,
            quoteTokens: l,
            currentToken: c,
            setCurrentToken: d,
            setLastFocusedToken: u,
            changeQuoteValue: h,
            changeBaseValue: m,
            lastFocusedRef: g
        } = pp(e), p = f.useRef(null), b = f.useRef(null), j = f.useCallback(x => {
            const C = x.target.value.trim();
            t == null || t(C === "" ? void 0 : new po(mn(C))), m(C)
        }, [m, t]), y = f.useCallback(x => {
            h(x.target.value.trim())
        }, [h]), S = f.useCallback(() => u("base"), [u]), w = f.useCallback(() => u("quote"), [u]), v = f.useCallback(x => {
            var C, E;
            switch (d(x), g.current) {
                case "base":
                    (C = p.current) == null || C.focus();
                    break;
                case "quote":
                    (E = b.current) == null || E.focus();
                    break
            }
        }, [d, g, p, b]);
        return n.jsxs(he, {
            display: "flex",
            flexDir: "column",
            alignItems: "center",
            children: [n.jsxs(On, {
                children: [n.jsx(Hn, {
                    ref: p,
                    value: i,
                    onFocus: S,
                    onChange: j,
                    fontSize: {
                        base: "1rem",
                        lg: "sm"
                    },
                    isInvalid: r,
                    borderRadius: "md",
                    isDisabled: o
                }), n.jsx(vr, {
                    borderRightRadius: "md",
                    px: 2,
                    maxWidth: "180px",
                    children: n.jsx(q, {
                        as: "span",
                        textOverflow: "ellipsis",
                        whiteSpace: "nowrap",
                        overflow: "hidden",
                        title: s,
                        children: s
                    })
                })]
            }), n.jsx(L, {
                as: Sh,
                boxSize: "20px",
                color: ee("gray.300", "blue.200")
            }), n.jsxs(On, {
                children: [n.jsx(Hn, {
                    ref: b,
                    value: a,
                    onFocus: w,
                    onChange: y,
                    fontSize: {
                        base: "1rem",
                        lg: "sm"
                    },
                    isInvalid: r,
                    borderRadius: "md",
                    isDisabled: o
                }), n.jsx(vr, {
                    px: "1",
                    borderRightRadius: "md",
                    maxWidth: "180px",
                    children: n.jsx(xp, {
                        values: l,
                        value: c,
                        onChange: v
                    })
                })]
            })]
        })
    },
    bp = e => {
        const {
            pair: t
        } = e, o = xe(o0), r = f.useMemo(() => ({
            chainId: t.chainId,
            pairId: t.pairAddress
        }), [t.chainId, t.pairAddress]), s = f.useMemo(() => t.baseToken.address, [t.baseToken.address]), i = fo(() => o.getTokenValueAmount(r, s), [o, r, s]), a = ri(l => l.pipe(Qe(c => c === void 0 ? o.setTokenValueAmount(r, s, void 0) : To(new po(c)).pipe(dt(d => new po(d)), tr(d => !d.isNaN()), wh(500), dt(d => d.toNumber()), Ss(), Qe(d => o.setTokenValueAmount(r, s, d))))), [o, r, s]);
        return {
            baseTokenAmount: i,
            saveTokenAmount: a
        }
    },
    vp = ({
        pair: e
    }) => {
        const {
            baseTokenAmount: t,
            saveTokenAmount: o
        } = bp({
            pair: e
        });
        return be({
            value: t,
            onFailure: () => n.jsx(fs, {
                baseToken: e.baseToken,
                quoteToken: e.quoteToken,
                price: e.price,
                priceUsd: e.priceUsd,
                onBaseTokenChange: o
            }),
            onPending: () => n.jsx(fs, {
                isDisabled: !0,
                baseToken: e.baseToken,
                quoteToken: e.quoteToken,
                price: e.price,
                priceUsd: e.priceUsd,
                onBaseTokenChange: o
            }),
            onSuccess: r => n.jsx(fs, {
                baseToken: e.baseToken,
                quoteToken: e.quoteToken,
                price: e.price,
                priceUsd: e.priceUsd,
                onBaseTokenChange: o,
                initialBaseTokenAmount: r
            }, "loaded")
        })
    },
    yp = e => rd[e],
    jp = f.memo(f.forwardRef((e, t) => {
        const {
            data: o,
            pair: r,
            onOpen: s,
            onClose: i
        } = e, a = X0({
            data: o,
            pair: r,
            onOpen: s,
            onClose: i
        }), {
            colorMode: l
        } = pe();
        return n.jsxs(I, {
            ref: t,
            overflow: "hidden",
            children: [n.jsxs(K, {
                spacing: "1",
                onClick: a.state === "success" ? a.toggleCollapse : void 0,
                height: "42px",
                userSelect: "none",
                transitionDuration: "fast",
                transitionProperty: "common",
                _hover: {
                    "@media (hover: hover)": a.state === "success" ? {
                        cursor: "pointer",
                        background: T("gray.100", "whiteAlpha.200", l)
                    } : {}
                },
                children: [n.jsx(I, {
                    flex: 1,
                    fontSize: "sm",
                    fontWeight: "semibold",
                    px: 3,
                    children: "Quick Intel"
                }), a.state === "pending" && n.jsx(I, {
                    padding: "2",
                    children: n.jsx(L, {
                        as: xr
                    })
                }), (a.state === "failure" || a.state === "notAvailable") && n.jsx(I, {
                    padding: "2",
                    fontSize: "sm",
                    children: n.jsx(k, {
                        color: T("gray.500", "blue.500", l),
                        children: "Not available"
                    })
                }), a.state === "success" && n.jsxs(n.Fragment, {
                    children: [n.jsxs(I, {
                        fontSize: "sm",
                        padding: "2",
                        children: [a.issuesCount === 0 && n.jsxs(K, {
                            children: [n.jsx(k, {
                                children: "No issues"
                            }), n.jsx(L, {
                                as: Po,
                                color: T("green.600", "green.400", l)
                            })]
                        }), a.issuesCount > 0 && n.jsxs(K, {
                            color: T("red.600", "red.400", l),
                            children: [n.jsxs(k, {
                                fontWeight: "semibold",
                                children: [a.issuesCount, " ", fc({
                                    value: a.issuesCount,
                                    single: "issue",
                                    zeroOrMany: "issues"
                                })]
                            }), n.jsx(L, {
                                as: cn
                            })]
                        })]
                    }), n.jsx(I, {
                        display: "flex",
                        padding: "2",
                        alignItems: "center",
                        alignSelf: "stretch",
                        borderLeftWidth: "1px",
                        borderColor: T("gray.200", "whiteAlpha.300", l),
                        children: a.isOpen ? n.jsx(br, {}) : n.jsx(Rr, {})
                    })]
                })]
            }), a.state === "success" && a.isOpen && n.jsxs(he, {
                padding: 2.5,
                alignItems: "stretch",
                borderColor: T("gray.200", "whiteAlpha.300", l),
                borderTopWidth: "1px",
                children: [n.jsx(he, {
                    spacing: 1.5,
                    alignItems: "stretch",
                    fontSize: "sm",
                    divider: n.jsx(Mr, {
                        marginY: 1
                    }),
                    children: a.validationResult.map(c => {
                        const d = yp(c.key);
                        return d ? n.jsx(d, {
                            pair: a.pairIdentity,
                            data: a.auditValues,
                            status: c.status,
                            value: c.value
                        }, c.key) : null
                    })
                }), n.jsx(ue, {
                    variant: "ghost",
                    size: "xs",
                    onClick: a.toggleCollapse,
                    children: n.jsx(L, {
                        as: br
                    })
                })]
            })]
        })
    })),
    en = f.forwardRef(({
        children: e,
        ...t
    }, o) => n.jsx(I, {
        padding: 3,
        ...t,
        ref: o,
        children: e
    })),
    Sp = () => {
        const {
            value: e,
            toggle: t
        } = Yt(!0), {
            colorMode: o
        } = pe();
        return n.jsxs(k, {
            fontSize: "xs",
            color: T("gray.500", "blue.500", o),
            children: [n.jsx(k, {
                as: "span",
                fontWeight: "semibold",
                children: "Warning!"
            }), " ", "Audits may not be 100% accurate!", e ? "" : n.jsxs(k, {
                children: [" ", "They are not intended as advice and should be considered in conjunction with other factors. DEX Screener does not validate nor assume responsibility for the accuracy of data obtained from these external auditors."]
            }), " ", n.jsxs(k, {
                as: "span",
                onClick: t,
                _hover: {
                    "@media (hover: hover)": {
                        cursor: "pointer"
                    }
                },
                color: T("gray.800", "blue.200", o),
                children: [e ? "More" : "Less", "."]
            })]
        })
    },
    wp = ({
        pair: e,
        pairDetails: t
    }) => {
        const o = xe(Ch),
            r = xe(jc);
        return be({
            value: t,
            onPending: () => ({
                state: "loading"
            }),
            onFailure: () => ({
                state: "failure"
            }),
            onSuccess: s => {
                var i, a;
                if (s && s.ti !== null) return {
                    state: "success",
                    source: "dexscreener",
                    pair: e,
                    description: s.ti.description,
                    imageUrl: s.ti.image,
                    websites: s.ti.websites ? ? Oo,
                    socials: s.ti.socials ? ? Oo
                };
                if (s && s.cms) {
                    const l = s.cms.links ? ? [],
                        c = l.filter(u => u.type !== void 0),
                        d = l.filter(u => u.label !== void 0);
                    return {
                        state: "success",
                        source: "dexscreener",
                        pair: e,
                        description: s.cms.description,
                        imageUrl: r({
                            assetId: s.cms.icon.id,
                            fit: "crop"
                        }),
                        websites: d,
                        socials: c
                    }
                }
                return s && s.cg !== null ? {
                    state: "success",
                    source: "coingecko",
                    pair: e,
                    description: s.cg.description,
                    imageUrl: s.cg.imageUrl ? o.buildUrl({
                        src: s.cg.imageUrl
                    }) : void 0,
                    websites: s.cg.websites ? ? Oo,
                    socials: ((a = (i = s == null ? void 0 : s.cg) == null ? void 0 : i.social) == null ? void 0 : a.reduce((l, c) => {
                        const d = $f(c.type);
                        return d ? [...l, {
                            url: c.url,
                            type: d
                        }] : l
                    }, [])) ? ? Oo
                } : {
                    state: "not-found"
                }
            }
        })
    },
    ad = () => n.jsxs(he, {
        spacing: "1",
        children: [n.jsx(ue, {
            as: we,
            href: "https://marketplace.dexscreener.com/product/token-info",
            target: "_blank",
            variant: "outline",
            size: "sm",
            leftIcon: n.jsx(L, {
                as: kh
            }),
            _hover: {
                "@media (hover: hover)": {
                    textDecoration: "none",
                    background: ee("gray.100", "whiteAlpha.200")
                }
            },
            children: "Update Token Info"
        }), n.jsx(q, {
            fontSize: "xs",
            color: ee("gray.500", "blue.600"),
            children: n.jsx(we, {
                href: "https://docs.dexscreener.com/token-listing",
                target: "_blank",
                children: "Learn more"
            })
        })]
    }),
    Cp = () => n.jsxs(he, {
        children: [n.jsx(L, {
            as: a0,
            color: ee("gray.500", "blue.600"),
            width: 12,
            height: 12
        }), n.jsx(q, {
            children: "Additional token info not available."
        }), n.jsx(ad, {})]
    }),
    kp = e => {
        const t = wp(e),
            {
                colorMode: o
            } = pe();
        switch (t.state) {
            case "loading":
                return n.jsx(Cn, {
                    size: "xs",
                    label: "Loading token info..."
                });
            case "failure":
            case "not-found":
                return n.jsx(Cp, {});
            case "success":
                {
                    const {
                        description: r,
                        imageUrl: s,
                        websites: i,
                        socials: a,
                        pair: l,
                        source: c
                    } = t;
                    return n.jsxs(he, {
                        alignItems: "stretch",
                        spacing: 4,
                        children: [s && n.jsx(I, {
                            display: "flex",
                            justifyContent: "center",
                            children: n.jsx(Ze, {
                                src: s,
                                alt: l.baseToken.name,
                                w: "48px",
                                h: "48px",
                                loading: "lazy"
                            })
                        }), r && n.jsx(q, {
                            whiteSpace: "pre-line",
                            children: r
                        }), (i.length > 0 || a.length > 0) && n.jsxs(Ro, {
                            spacing: 2,
                            children: [i && i.map(({
                                label: d,
                                url: u
                            }) => n.jsx(Ms, {
                                icon: xc,
                                href: u,
                                size: "sm",
                                children: d
                            }, u)), a && a.map(({
                                type: d,
                                url: u
                            }) => n.jsx(Ms, {
                                icon: Sc[d],
                                href: u,
                                size: "sm",
                                textTransform: "capitalize",
                                children: d
                            }, u))]
                        }), c !== "dexscreener" && n.jsx(I, {
                            borderTopWidth: 1,
                            borderTopColor: T("gray.100", "blue.850", o),
                            paddingTop: "3",
                            children: n.jsx(ad, {})
                        })]
                    })
                }
        }
    },
    Tp = ({
        date: e,
        format: t,
        ...o
    }) => {
        const s = ii() ? ci : Th;
        return n.jsx(k, { ...o,
            children: s(e, t)
        })
    },
    Ei = {
        xs: 27
    },
    Ip = {
        website: "Website",
        telegram: "Telegram",
        twitter: "Twitter",
        discord: "Discord",
        facebook: "Facebook",
        tiktok: "TikTok"
    },
    Un = ({
        variant: e,
        size: t,
        type: o,
        label: r,
        url: s,
        showLabels: i = !0
    }) => {
        const a = r ? ? Ip[o] ? ? o,
            l = o === "website" ? xc : Sc[o];
        return n.jsx(ue, {
            as: we,
            href: s,
            target: "_blank",
            rel: "noopener noreferrer",
            size: t,
            leftIcon: n.jsx(L, {
                as: l
            }),
            iconSpacing: i ? t == "xs" ? "1" : "2" : 0,
            textDecoration: "none !important",
            minH: Ei[t],
            shadow: "md",
            justifyContent: "center",
            ...e === "alpha" ? {
                bg: "whiteAlpha.200",
                color: "whiteAlpha.900",
                _hover: {
                    bg: "whiteAlpha.300"
                }
            } : void 0,
            children: i && n.jsx(I, {
                as: "span",
                overflow: "hidden",
                children: a
            })
        })
    },
    gs = ({
        websites: e,
        socials: t,
        size: o = "sm",
        containerProps: r,
        showLabels: s = !0
    }) => e.length === 0 && t.length === 0 ? null : n.jsxs(Ro, {
        spacing: 2,
        justify: "center",
        ...r,
        children: [e.map(({
            label: i,
            url: a
        }) => n.jsx(Un, {
            size: o,
            type: "website",
            label: i,
            url: a.toString(),
            variant: "alpha",
            showLabels: s
        }, a.toString())), t.map(({
            type: i,
            url: a
        }) => n.jsx(Un, {
            size: o,
            type: i,
            url: a.toString(),
            variant: "alpha",
            showLabels: s
        }, a.toString()))]
    }),
    Ap = ({
        buttonProps: e,
        text: t,
        length: o,
        textProps: r
    }) => {
        const s = t.length * .95 > o,
            {
                value: i,
                toggle: a
            } = Yt(!0),
            {
                onClick: l,
                ...c
            } = e ? ? {},
            d = f.useCallback(u => {
                a(), l == null || l(u)
            }, [l, a]);
        return n.jsxs(I, {
            children: [n.jsx(k, { ...r,
                children: s && i ? qt(t, o, {
                    separator: " "
                }) : t
            }), s && n.jsx(ue, {
                variant: "link",
                size: "xs",
                ml: "2",
                display: "inline-flex",
                rightIcon: n.jsx(L, {
                    as: Ih,
                    transform: i ? void 0 : "rotate(180deg)",
                    transition: "ease-in"
                }),
                iconSpacing: "0.5",
                color: "inherit",
                ...c,
                onClick: d,
                children: i ? "More" : "Less"
            })]
        })
    },
    rl = () => {
        const {
            value: e,
            toggle: t
        } = Yt(!1);
        return n.jsx(I, {
            marginTop: 4,
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            children: n.jsxs(he, {
                spacing: 0,
                children: [n.jsxs(K, {
                    as: ue,
                    flex: "1",
                    alignItems: "center",
                    justifyContent: "center",
                    onClick: t,
                    py: 1.5,
                    borderWidth: 2,
                    borderColor: "accent.lightGreen",
                    background: "accent.lightGreen",
                    width: e ? "100%" : void 0,
                    color: "gray.850",
                    size: "sm",
                    _hover: {
                        bg: "accent.lightGreen"
                    },
                    borderRadius: "md",
                    borderBottomRadius: e ? "none" : "md",
                    children: [n.jsx(L, {
                        as: mi,
                        boxSize: "4"
                    }), n.jsx(k, {
                        children: "Marketing Boost"
                    }), n.jsx(L, {
                        as: e ? Rf : Ao,
                        boxSize: "4"
                    })]
                }), e && n.jsx(I, {
                    paddingX: "0",
                    paddingTop: "2",
                    borderWidth: 2,
                    borderBottomRadius: "md",
                    borderColor: "accent.lightGreen",
                    px: 4,
                    py: 4,
                    children: n.jsxs(he, {
                        spacing: "5",
                        children: [n.jsx(q, {
                            textAlign: "center",
                            children: "This token has recently advertised on DEX Screener!"
                        }), n.jsxs(q, {
                            textAlign: "center",
                            children: ["Ads help tokens get more exposure and increase their", " ", n.jsx(ue, {
                                as: we,
                                variant: "link",
                                fontWeight: "normal",
                                color: "inherit",
                                size: "sm",
                                textDecor: "underline",
                                _active: {},
                                href: "https://docs.dexscreener.com/trending",
                                target: "_blank",
                                children: "Trending Score"
                            }), "."]
                        }), n.jsx(ue, {
                            flex: 1,
                            as: we,
                            variant: "link",
                            fontWeight: "normal",
                            color: "inherit",
                            size: "sm",
                            textDecor: "underline",
                            _active: {},
                            rightIcon: n.jsx(L, {
                                as: yt,
                                boxSize: "12px"
                            }),
                            href: "https://marketplace.dexscreener.com/product/ad",
                            target: "_blank",
                            iconSpacing: "1",
                            children: n.jsx(k, {
                                children: n.jsx(q, {
                                    children: "Advertise on DEX Screener"
                                })
                            })
                        })]
                    })
                })]
            })
        })
    },
    Ep = ({
        pair: e,
        pairDetails: t,
        isMoonshot: o
    }) => {
        const [r, s] = di("colors", ["gray.1000", "moonshot.900"]), i = ee(o ? "#90937b" : "#606c66", r), a = ee("rgba(255, 255, 255, 0.05)", "rgba(0, 0, 0, 0.3)"), l = `radial-gradient(100% 110% at 50% 0%,${o?s:"#202f27"} 10%, ${i} 90%)`, c = sc({
            chainId: e.chainId,
            tokenAddress: e.baseToken.address
        }), d = xe(fi), u = m => {
            var g;
            return m.ti ? [...m.ti.claims ? ? []].reverse() : [...((g = m.cms) == null ? void 0 : g.claims) ? ? []].reverse().map(p => {
                const {
                    socials: b,
                    websites: j
                } = gf(p);
                return {
                    id: p.id,
                    claimDate: p.claimDate,
                    claimDescription: p.claimDescription,
                    description: p.description,
                    socials: b,
                    websites: j
                }
            })
        }, h = m => {
            const {
                socials: g,
                websites: p
            } = wc({
                includeClaims: !1,
                dsDataToken: m.ti,
                cmsToken: m.cms
            });
            if (m.ti) return {
                description: m.ti.description,
                socials: g,
                websites: p
            };
            if (m.cms) return {
                description: m.cms.description,
                socials: g,
                websites: p
            }
        };
        return be({
            value: t,
            onPending: yn,
            onFailure: yn,
            onSuccess: m => {
                var j;
                if (!m || !(m != null && m.ti) && !(m != null && m.cms)) return null;
                const g = u(m),
                    p = h(m),
                    b = d({
                        dsDataParams: m != null && m.ti ? {
                            chainId: e.chainId,
                            tokenAddress: e.baseToken.address,
                            size: "lg",
                            cacheKey: (j = e.profile) == null ? void 0 : j.imgKey
                        } : void 0,
                        cmsParams: e.cmsProfile ? {
                            assetId: e.cmsProfile.iconId,
                            size: {
                                width: 150,
                                height: 150
                            },
                            fit: "crop"
                        } : void 0
                    });
                return n.jsxs(I, {
                    display: "flex",
                    flexDir: "column",
                    pos: "relative",
                    pt: "6",
                    mb: "40px",
                    sx: {
                        top: "calc(0 * 1580px)"
                    },
                    children: [o ? n.jsx(Qt, {
                        flex: 1,
                        to: Ah({
                            routeId: "moonshot"
                        }),
                        target: "_blank",
                        variant: "solid",
                        size: "xs",
                        textDecor: "none !important",
                        fontWeight: "normal",
                        borderTopRadius: "none",
                        borderBottomRadius: "xl",
                        w: "100%",
                        pt: "21px",
                        h: "auto",
                        pb: "12px",
                        order: 2,
                        position: "absolute",
                        bottom: "-40px",
                        children: n.jsxs(K, {
                            children: [n.jsx(k, {
                                children: "This token was created on"
                            }), n.jsxs(K, {
                                spacing: "1",
                                fontWeight: "semibold",
                                color: "moonshot.accent.text",
                                children: [n.jsx(L, {
                                    as: Dn
                                }), n.jsx(k, {
                                    children: "Moonshot"
                                })]
                            })]
                        })
                    }) : n.jsx(ue, {
                        flex: 1,
                        as: we,
                        href: "https://marketplace.dexscreener.com/product/token-info",
                        target: "_blank",
                        variant: "solid",
                        size: "xs",
                        leftIcon: n.jsx(L, {
                            as: ff,
                            boxSize: "16px"
                        }),
                        iconSpacing: "1",
                        textDecor: "none !important",
                        fontWeight: "normal",
                        borderTopRadius: "none",
                        borderBottomRadius: "xl",
                        w: "100%",
                        pt: "21px",
                        h: "auto",
                        pb: "12px",
                        order: 2,
                        position: "absolute",
                        bottom: "-40px",
                        children: n.jsxs(k, {
                            children: ["Claim Your DEX Screener ", n.jsx("strong", {
                                children: "Token Profile"
                            })]
                        })
                    }), n.jsxs(I, {
                        pos: "relative",
                        alignItems: "stretch",
                        px: "4",
                        pb: "6",
                        textAlign: "center",
                        fontSize: "sm",
                        borderColor: "gray.1000",
                        boxShadow: `0px 2px 13px 7px ${a}`,
                        borderRadius: "xl",
                        bg: l,
                        color: "white",
                        children: [b && n.jsx(I, {
                            display: "flex",
                            justifyContent: "center",
                            mb: "62px",
                            children: n.jsx(Ze, {
                                src: b,
                                alt: e.baseToken.name,
                                w: "75px",
                                h: "75px",
                                pos: "absolute",
                                top: "-6",
                                loading: "lazy"
                            })
                        }), n.jsx(Lt, {
                            as: "h3",
                            color: "white",
                            children: e.baseToken.name
                        }), g.length === 0 ? n.jsxs(n.Fragment, {
                            children: [n.jsx(gs, {
                                websites: (p == null ? void 0 : p.websites) ? ? [],
                                socials: (p == null ? void 0 : p.socials) ? ? [],
                                size: "sm",
                                containerProps: {
                                    mt: "3"
                                }
                            }), c && n.jsx(rl, {}), (p == null ? void 0 : p.description) && n.jsx(q, {
                                display: "block",
                                mt: "4",
                                whiteSpace: "pre-line",
                                color: "blue.100",
                                fontSize: "md",
                                children: p.description
                            })]
                        }) : n.jsxs(Rc, {
                            defaultIndex: [0],
                            mt: "2",
                            borderColor: "transparent",
                            children: [g.map(y => {
                                const S = Z.coerce.date().safeParse(y.claimDate),
                                    w = S.success ? S.data : void 0;
                                return n.jsx(Ps, {
                                    borderTopColor: "whiteAlpha.200",
                                    children: ({
                                        isExpanded: v
                                    }) => n.jsxs(n.Fragment, {
                                        children: [n.jsxs(As, {
                                            paddingX: "2",
                                            paddingY: "1",
                                            justifyContent: "space-between",
                                            bg: v ? "whiteAlpha.200" : "whiteAlpha.50",
                                            _hover: {
                                                bg: v ? void 0 : "whiteAlpha.100"
                                            },
                                            fontSize: "md",
                                            fontFamily: "heading",
                                            fontWeight: "semibold",
                                            children: [n.jsxs(K, {
                                                flex: "1",
                                                alignItems: "center",
                                                justifyContent: "center",
                                                children: [n.jsx(L, {
                                                    as: Eh,
                                                    boxSize: "4"
                                                }), n.jsx(k, {
                                                    children: "Community Takeover"
                                                })]
                                            }), n.jsx(Es, {})]
                                        }), n.jsx(Rs, {
                                            paddingX: "0",
                                            paddingTop: "2",
                                            children: n.jsxs(he, {
                                                spacing: "2",
                                                children: [n.jsxs(I, {
                                                    as: he,
                                                    spacing: "1",
                                                    background: "blackAlpha.500",
                                                    borderRadius: "lg",
                                                    padding: "2",
                                                    fontSize: "xs",
                                                    children: [w ? n.jsxs(q, {
                                                        color: "whiteAlpha.700",
                                                        children: ["A community claimed ownership for this token on", " ", n.jsx(Tp, {
                                                            fontWeight: "semibold",
                                                            date: w,
                                                            format: "MMM dd yyyy"
                                                        })]
                                                    }) : n.jsx(q, {
                                                        color: "whiteAlpha.800",
                                                        children: "A community claimed ownership for this token"
                                                    }), y.claimDescription && n.jsxs(he, {
                                                        spacing: "2px",
                                                        children: [n.jsx(q, {
                                                            as: "strong",
                                                            children: "Community Claim"
                                                        }), n.jsx(Ap, {
                                                            text: y.claimDescription,
                                                            length: 92
                                                        })]
                                                    })]
                                                }), n.jsx(gs, {
                                                    websites: y.websites ? ? [],
                                                    socials: y.socials ? ? []
                                                }), c && n.jsx(rl, {}), y.description && n.jsx(q, {
                                                    color: "blue.100",
                                                    fontSize: "md",
                                                    children: y.description
                                                })]
                                            })
                                        })]
                                    })
                                }, y.id)
                            }), n.jsx(Ps, {
                                borderTopColor: "whiteAlpha.200",
                                borderBottomColor: "transparent",
                                children: ({
                                    isExpanded: y
                                }) => n.jsxs(n.Fragment, {
                                    children: [n.jsxs(As, {
                                        paddingX: "2",
                                        paddingY: "1",
                                        justifyContent: "space-between",
                                        bg: y ? "whiteAlpha.200" : "whiteAlpha.50",
                                        _hover: {
                                            bg: y ? void 0 : "whiteAlpha.100"
                                        },
                                        fontSize: "md",
                                        fontFamily: "heading",
                                        fontWeight: "semibold",
                                        children: [n.jsxs(K, {
                                            flex: "1",
                                            alignItems: "center",
                                            justifyContent: "center",
                                            children: [n.jsx(L, {
                                                as: Ph,
                                                boxSize: "3"
                                            }), n.jsx(k, {
                                                children: "Original Profile"
                                            })]
                                        }), n.jsx(Es, {})]
                                    }), n.jsx(Rs, {
                                        paddingX: "0",
                                        children: n.jsxs(he, {
                                            spacing: "2",
                                            paddingTop: "2",
                                            children: [n.jsx(gs, {
                                                websites: (p == null ? void 0 : p.websites) ? ? [],
                                                socials: (p == null ? void 0 : p.socials) ? ? []
                                            }), (p == null ? void 0 : p.description) && n.jsx(q, {
                                                color: "blue.100",
                                                fontSize: "md",
                                                children: p.description
                                            })]
                                        })
                                    })]
                                })
                            })]
                        })]
                    })]
                })
            }
        })
    },
    Pp = ({
        pairDetails: e
    }) => Nt(e, t => t ? wc({
        includeClaims: !0,
        dsDataToken: t.ti,
        cmsToken: t.cms
    }) : {
        socials: [],
        websites: [],
        website: void 0
    }),
    sl = ({
        pairDetails: e,
        onMoreClick: t
    }) => {
        const o = Pp({
                pairDetails: e
            }),
            r = {
                justifyContent: "center",
                alignItems: "stretch",
                spacing: 0,
                sx: {
                    "> a, > button, > div": {
                        bg: ee("gray.100", "blue.850"),
                        flex: 1,
                        h: `${Ei.xs}px`,
                        shadow: "md",
                        borderRadius: 0,
                        borderRightWidth: 1,
                        borderColor: ee("gray.150", "blue.900")
                    },
                    "> a:first-child, > button:first-child, > div:first-child": {
                        borderLeftRadius: "md"
                    },
                    "> a:last-child, > button:last-child, > div:last-child": {
                        borderRightRadius: "md",
                        flex: 0
                    },
                    "> a:hover, > button:hover": {
                        bg: ee("gray.175", "blue.750")
                    }
                }
            },
            s = ee("blackAlpha.100", "whiteAlpha.50");
        return be({
            value: o,
            onPending: () => n.jsxs(K, { ...r,
                children: [n.jsxs(K, {
                    spacing: "1",
                    justify: "center",
                    px: "2",
                    children: [n.jsx(so, {
                        size: "2",
                        bg: s
                    }), n.jsx(I, {
                        w: "100%",
                        h: "2",
                        bg: s,
                        borderRadius: "md"
                    })]
                }), n.jsxs(K, {
                    spacing: "1",
                    justify: "center",
                    px: "2",
                    children: [n.jsx(so, {
                        size: "2",
                        bg: s
                    }), n.jsx(I, {
                        w: "100%",
                        h: "2",
                        bg: s,
                        borderRadius: "md"
                    })]
                }), n.jsxs(K, {
                    spacing: "1",
                    justify: "center",
                    px: "2",
                    children: [n.jsx(so, {
                        size: "2",
                        bg: s
                    }), n.jsx(I, {
                        w: "100%",
                        h: "2",
                        bg: s,
                        borderRadius: "md"
                    })]
                }), n.jsx(Ae, {
                    minW: "6",
                    children: n.jsx(so, {
                        size: "2",
                        bg: s
                    })
                })]
            }),
            onFailure: () => null,
            onSuccess: i => n.jsxs(K, { ...r,
                children: [i.website && n.jsx(Un, {
                    size: "xs",
                    type: "website",
                    url: i.website.url
                }), i.socials.slice(0, i.website ? 2 : 3).map(a => n.jsx(Un, {
                    size: "xs",
                    type: a.type,
                    url: a.url
                }, a.type)), n.jsx(Je, {
                    onClick: t,
                    size: "xs",
                    icon: n.jsx(L, {
                        as: Rr
                    }),
                    "aria-label": "More",
                    flex: "0"
                })]
            })
        })
    },
    Rp = (e, t) => e < 50 ? T("red.600", "red.400", t) : e < 100 ? T("orange.600", "orange.400", t) : T("green.600", "green.400", t),
    zp = f.memo(f.forwardRef((e, t) => {
        const {
            networkId: o,
            tokenAddress: r,
            data: s
        } = e, i = G0({
            networkId: o,
            tokenAddress: r,
            data: s
        }), {
            colorMode: a
        } = pe();
        return n.jsx(I, {
            ref: t,
            overflow: "hidden",
            children: n.jsxs(K, {
                spacing: "1",
                height: "42px",
                userSelect: "none",
                transitionDuration: "fast",
                transitionProperty: "common",
                children: [n.jsx(I, {
                    flex: 1,
                    fontSize: "sm",
                    fontWeight: "semibold",
                    px: 3,
                    children: "Token Sniffer"
                }), i.state === "pending" && n.jsx(I, {
                    padding: "2",
                    children: n.jsx(L, {
                        as: xr
                    })
                }), (i.state === "failure" || i.state === "notAvailable") && n.jsx(I, {
                    padding: "2",
                    fontSize: "sm",
                    children: n.jsx(k, {
                        color: T("gray.500", "blue.500", a),
                        children: "Not available"
                    })
                }), i.state === "pendingAnalysis" && n.jsxs(K, {
                    padding: "2",
                    fontSize: "sm",
                    color: T("gray.500", "blue.500", a),
                    children: [n.jsx(k, {
                        children: "In progress"
                    }), n.jsx(L, {
                        as: xr
                    })]
                }), i.state === "success" && n.jsx(I, {
                    fontSize: "sm",
                    padding: "2",
                    children: i.data.score === void 0 ? n.jsxs(K, {
                        children: [n.jsx(k, {
                            children: "Unknown score"
                        }), n.jsx(L, {
                            as: cn,
                            color: T("orange.600", "orange.400", a)
                        })]
                    }) : n.jsxs(K, {
                        children: [n.jsxs(k, {
                            fontWeight: "semibold",
                            children: [i.data.score, "/100"]
                        }), i.data.isFlagged ? n.jsx(k, {
                            fontSize: "sm",
                            width: "4",
                            title: "Flagged manually by Token Sniffer due to evidence of a bug, hack, or scam.",
                            children: n.jsx(Vc, {})
                        }) : n.jsx(L, {
                            as: i.data.score === 100 ? Po : cn,
                            color: Rp(i.data.score, a)
                        })]
                    })
                }), n.jsx(I, {
                    as: we,
                    href: i.tokenURL,
                    target: "_blank",
                    rel: "noopener noreferrer",
                    display: "flex",
                    padding: "2",
                    alignItems: "center",
                    alignSelf: "stretch",
                    borderLeftWidth: "1px",
                    borderColor: T("gray.200", "whiteAlpha.300", a),
                    _hover: {
                        "@media (hover: hover)": {
                            cursor: "pointer",
                            background: T("gray.100", "whiteAlpha.200", a)
                        }
                    },
                    children: n.jsx(yt, {})
                })]
            })
        })
    })),
    Mp = e => {
        const {
            pair: t,
            pairDetails: o
        } = e, s = xe(og)({
            pair: t,
            pairDetails: o
        }), [i, a] = f.useState([]), l = f.useCallback(d => {
            a(u => Nf([...u, d]))
        }, []);
        return {
            warnings: s.filter(({
                type: d
            }) => i.includes(d) === !1),
            closeWarning: l
        }
    },
    Bp = ({
        wrapper: e,
        componentMap: t,
        pair: o,
        isInverted: r,
        pairDetails: s
    }) => {
        const {
            warnings: i,
            closeWarning: a
        } = Mp({
            pair: o,
            pairDetails: s
        });
        if (i.length === 0) return null;
        const l = i.flatMap(({
            type: c,
            status: d
        }) => {
            switch (c) {
                case "goplus-honey-pot":
                case "ds-token":
                case "low-liquidity":
                case "unknown-dex":
                case "unknown-liquidity":
                case "high-tax":
                case "scam-tax":
                case "moonshot-token":
                case "significant-holder":
                case "significant-top-10-holders":
                    {
                        if (c === "high-tax" && i.find(({
                                type: h
                            }) => h === "scam-tax")) return [];
                        if (!t) return [];
                        const u = t[c];
                        return u ? n.jsx(u, {
                            pair: o,
                            isInverted: r,
                            type: d,
                            onClose: () => a(c)
                        }, c) : []
                    }
                default:
                    return []
            }
        });
        return l.length === 0 ? null : e ? e(l) : l
    },
    Fp = {
        warning: {
            dark: "yellow.900",
            light: "yellow.125"
        },
        error: {
            dark: "#301616",
            light: "red.100"
        },
        info: {
            dark: "nativeBlue.900",
            light: "nativeBlue.100"
        }
    },
    Wp = {
        warning: {
            dark: "yellow.150",
            light: "yellow.825"
        },
        error: {
            dark: "red.50",
            light: "red.800"
        },
        info: {
            dark: "nativeBlue.100",
            light: "nativeBlue.800"
        }
    },
    Dp = {
        warning: {
            dark: "yellow.950",
            light: "yellow.300"
        },
        error: {
            dark: "#211212",
            light: "red.200"
        },
        info: {
            dark: "nativeBlue.900",
            light: "nativeBlue.300"
        }
    },
    Lp = {
        warning: {
            dark: "yellow.400",
            light: "yellow.550"
        },
        error: {
            dark: "red.400",
            light: "red.500"
        },
        info: {
            dark: "nativeBlue.300",
            light: "nativeBlue.500"
        }
    },
    Np = {
        warning: cn,
        error: cn,
        info: Ao
    },
    ut = ({
        children: e,
        onClose: t,
        type: o = "warning",
        icon: r
    }) => {
        const {
            colorMode: s
        } = pe(), i = !!t, a = Fp[o][s], l = Wp[o][s], c = Lp[o][s], d = Dp[o][s];
        return n.jsxs(I, {
            w: "100%",
            display: "flex",
            bg: a,
            color: l,
            px: 3,
            py: 2,
            fontSize: "xs",
            justifyContent: i ? "space-between" : void 0,
            gap: "2",
            borderRadius: "md",
            borderBottomWidth: 1,
            borderColor: d,
            children: [r ? ? n.jsx(L, {
                flexShrink: 0,
                as: Np[o],
                boxSize: "18px",
                color: c
            }), n.jsx(I, {
                flex: 1,
                overflow: "hidden",
                children: e
            }), t && n.jsx(Je, {
                mt: "3px",
                flexShrink: 0,
                onClick: t,
                icon: n.jsx(Rh, {}),
                boxSize: "14px",
                minWidth: "auto",
                variant: "unstyled",
                cursor: "pointer",
                opacity: .7,
                "aria-label": "Hide",
                _hover: {
                    opacity: 1
                }
            })]
        })
    },
    Hp = ({
        pair: e,
        type: t,
        onClose: o
    }) => n.jsxs(ut, {
        type: t,
        onClose: o,
        children: [n.jsxs(q, {
            children: ["Unknown DEX - See", " ", n.jsx(we, {
                href: "https://docs.dexscreener.com/dex-listing",
                target: "_blank",
                textDecor: "underline",
                fontWeight: "semibold",
                children: "DEX Listing"
            })]
        }), n.jsxs(q, {
            mt: 1,
            fontSize: "10px",
            wordBreak: "break-all",
            noOfLines: 1,
            children: ["Factory:", " ", n.jsx(nr, {
                to: `/${e.chainId}/f:${e.dexId}`,
                textDecor: "underline",
                fontFamily: "mono",
                children: e.dexId
            })]
        })]
    }),
    _p = ({
        type: e,
        onClose: t
    }) => n.jsx(ut, {
        type: e,
        onClose: t,
        children: n.jsx(q, {
            children: "This pair has very little liquidity"
        })
    }),
    Op = ({
        type: e,
        onClose: t
    }) => n.jsx(ut, {
        type: e,
        onClose: t,
        children: n.jsx(q, {
            children: "This pair has unknown liquidity"
        })
    }),
    Up = ({
        type: e,
        onClose: t
    }) => n.jsxs(ut, {
        type: e,
        onClose: t,
        children: [n.jsxs(q, {
            children: ["DEX Screener ", n.jsx("strong", {
                children: "does not have a token"
            })]
        }), n.jsx(q, {
            fontWeight: "semibold",
            children: "Watch out for scams!"
        })]
    }),
    Vp = ({
        type: e,
        onClose: t
    }) => n.jsxs(ut, {
        type: e,
        onClose: t,
        children: [n.jsxs(q, {
            children: ["Moonshot ", n.jsx("strong", {
                children: "does not have a token"
            })]
        }), n.jsx(q, {
            fontWeight: "semibold",
            children: "Watch out for scams!"
        })]
    }),
    Xp = ({
        type: e
    }) => n.jsx(ut, {
        type: e,
        children: n.jsx(q, {
            children: "GoPlus flagged this token as a honeypot"
        })
    }),
    qp = ({
        type: e
    }) => n.jsx(ut, {
        type: e,
        children: n.jsx(q, {
            children: "QuickIntel flagged this token as a honeypot"
        })
    }),
    Gp = ({
        type: e,
        onClose: t
    }) => n.jsx(ut, {
        type: e,
        onClose: t,
        children: n.jsx(q, {
            children: "Single holder holds more than 30% of supply!"
        })
    }),
    Kp = ({
        type: e,
        onClose: t
    }) => n.jsx(ut, {
        type: e,
        onClose: t,
        children: n.jsx(q, {
            children: "Top 10 holders hold more than 60% of supply!"
        })
    }),
    Qp = ({
        type: e,
        pair: t
    }) => {
        var s, i;
        const o = Er(t.chainId),
            r = Ec({
                networkId: (i = (s = o == null ? void 0 : o.integrations) == null ? void 0 : s.tokenSniffer) == null ? void 0 : i.networkId,
                tokenAddress: t.baseToken.address
            });
        return n.jsx(ut, {
            type: e,
            children: n.jsxs(q, {
                children: ["Token Sniffer has", " ", n.jsx(we, {
                    href: r.toString(),
                    target: "_blank",
                    textDecor: "underline",
                    children: "flagged this token"
                })]
            })
        })
    },
    $p = ({
        type: e
    }) => n.jsx(ut, {
        type: e,
        children: n.jsx(q, {
            children: "Token Sniffer score for this token is 0"
        })
    }),
    Yp = ({
        type: e
    }) => n.jsx(ut, {
        type: e,
        children: n.jsxs(q, {
            children: ["This token has high taxes ", "(>=25%)"]
        })
    }),
    Zp = ({
        type: e
    }) => n.jsx(ut, {
        type: e,
        children: n.jsxs(q, {
            children: ["This token has excessive taxes ", "(>=80%)"]
        })
    }),
    Jp = {
        "ds-token": Up,
        "goplus-honey-pot": Xp,
        "quickintel-honey-pot": qp,
        "low-liquidity": _p,
        "tokensniffer-flagged": Qp,
        "tokensniffer-score": $p,
        "unknown-dex": Hp,
        "unknown-liquidity": Op,
        "high-tax": Yp,
        "scam-tax": Zp,
        "moonshot-token": Vp,
        "significant-holder": Gp,
        "significant-top-10-holders": Kp
    },
    ex = e => n.jsx(Bp, {
        componentMap: Jp,
        ...e
    }),
    tx = f.memo(e => {
        const t = bc(),
            {
                ad: o,
                onHide: r
            } = e,
            s = xe(ec),
            i = {
                default: ee("white", "gray.975"),
                hover: ee("gray.25", "gray.1000")
            },
            a = ee("gray.150", "transparent"),
            l = o.impressionURL.toString(),
            c = f.useRef(null);
        return f.useEffect(() => {
            let d;
            return c.current && (d = new IntersectionObserver(u => {
                for (const h of u)
                    if (h.isIntersecting) {
                        d.disconnect(), s.fetchImpression(l);
                        break
                    }
            }), d.observe(c.current)), () => {
                d && d.disconnect()
            }
        }, [l, s]), n.jsxs(I, {
            display: "flex",
            flexDir: "column",
            alignItems: "center",
            gap: "2px",
            mt: 1,
            children: [n.jsxs(I, {
                ref: c,
                borderWidth: 1,
                borderColor: a,
                backgroundColor: i.default,
                width: "100%",
                minH: {
                    lg: "140px"
                },
                position: "relative",
                borderRadius: "md",
                px: "3",
                py: "3",
                display: "flex",
                flexDirection: "column",
                gap: "3",
                cursor: "pointer",
                transition: "background-color 0.2s",
                _hover: {
                    bg: i.hover
                },
                onClick: () => t(`/${o.chainId}/${o.tokenAddress}`),
                children: [n.jsx(k, {
                    pos: "absolute",
                    top: "1.5",
                    right: "1.5",
                    bg: ee("gray.75", "gray.900"),
                    color: ee("gray.500", "gray.300"),
                    fontSize: "2xs",
                    px: "2",
                    borderRadius: "lg",
                    fontWeight: "semibold",
                    children: "Ad"
                }), n.jsxs(I, {
                    display: "flex",
                    flex: 1,
                    flexDirection: "row",
                    gap: "3",
                    alignItems: "center",
                    h: "100%",
                    overflow: "hidden",
                    children: [n.jsx(Ze, {
                        src: o.image.toString(),
                        w: "60px",
                        h: "60px",
                        borderRadius: "full",
                        flexShrink: 0,
                        loading: "lazy"
                    }), n.jsxs(I, {
                        flex: 1,
                        display: "flex",
                        flexDirection: "column",
                        gap: "1",
                        overflow: "hidden",
                        wordBreak: "break-word",
                        children: [n.jsx(q, {
                            fontWeight: "semibold",
                            fontSize: "md",
                            mr: "9",
                            fontFamily: "heading",
                            children: o.title
                        }), n.jsx(q, {
                            fontSize: "xs",
                            children: o.description
                        })]
                    })]
                }), n.jsxs(Ro, {
                    spacing: 1,
                    onClick: d => d.stopPropagation(),
                    children: [n.jsx(Qt, {
                        to: `/${o.chainId}/${o.tokenAddress}`,
                        size: "xs",
                        minH: Ei.xs,
                        flex: 1,
                        fontWeight: "normal",
                        leftIcon: n.jsx(rc, {
                            size: 18
                        }),
                        iconSpacing: 1,
                        children: "Chart"
                    }), nx(o).map(d => n.jsx(Un, {
                        size: "xs",
                        type: "website",
                        label: d.label,
                        url: d.url.toString(),
                        showLabels: !1
                    }, d.url.toString())), ox(o).map(d => n.jsx(Un, {
                        size: "xs",
                        type: d.type,
                        url: d.url.toString(),
                        showLabels: !1
                    }, d.url.toString()))]
                })]
            }), n.jsxs(K, {
                justifyContent: "space-between",
                w: "100%",
                opacity: .7,
                children: [n.jsx(ue, {
                    as: we,
                    variant: "link",
                    target: "_blank",
                    href: "https://marketplace.dexscreener.com/product/ad",
                    size: "xs",
                    leftIcon: n.jsx(L, {
                        as: mi
                    }),
                    iconSpacing: "3px",
                    children: "Advertise your token"
                }), n.jsx(ue, {
                    variant: "link",
                    size: "xs",
                    fontWeight: "normal",
                    onClick: r,
                    children: "Hide ad"
                })]
            })]
        })
    });

function nx(e) {
    var r;
    const t = [],
        o = (r = e.websites) == null ? void 0 : r[0];
    return o && t.push(o), t
}

function ox(e) {
    var i, a, l;
    const t = [],
        o = (i = e.socials) == null ? void 0 : i.find(c => c.type === "twitter");
    o && t.push(o);
    const r = (a = e.socials) == null ? void 0 : a.find(c => c.type === "discord");
    r && t.push(r);
    const s = (l = e.socials) == null ? void 0 : l.find(c => c.type === "telegram");
    return s && t.push(s), t
}
const rx = ({
        pair: e
    }) => {
        const {
            colorMode: t
        } = pe(), o = zh(i => i), r = Mh();
        let s;
        return (o == null ? void 0 : o.id) === "pairDetail" ? s = o.pairAddress : r && (s = r.pairAddress), s ? s.toLowerCase() === e.baseToken.address.toLowerCase() && e.dexId === "moonshot" && e.moonshot.progress >= 100 ? n.jsxs(ut, {
            type: "info",
            icon: n.jsx(Bh, {
                size: "xs"
            }),
            children: [n.jsx(q, {
                fontWeight: "semibold",
                children: "Finalized!"
            }), n.jsx(q, {
                children: "Liquidity is now being migrated to Raydium and this page will automatically update once the migration is complete."
            })]
        }) : s.toLowerCase() !== e.baseToken.address.toLowerCase() && e.dexId === "moonshot" && e.moonshot.progress >= 100 ? n.jsx(ut, {
            type: "info",
            children: n.jsxs(he, {
                alignItems: "flex-start",
                children: [n.jsx(q, {
                    children: "This token has successfully migrated to Raydium and is no longer available to trade on Moonshot."
                }), n.jsxs(Qt, {
                    to: Gs({
                        platformId: e.chainId,
                        pairAddress: e.baseToken.address
                    }),
                    size: "xs",
                    variant: "link",
                    rightIcon: n.jsx(L, {
                        as: Fh
                    }),
                    iconSpacing: "0.5",
                    color: T("gray.850", "white", t),
                    children: ["Check out ", e.baseToken.symbol, " on Raydium"]
                })]
            })
        }) : null : null
    },
    sx = e => {
        var ct, kt, zt, Mt, nt;
        const {
            chainId: t,
            dexId: o,
            pair: r
        } = e, s = xe(fi), i = xe(mf), {
            isOpen: a,
            onClose: l,
            onOpen: c
        } = pr(), d = Er(t), u = ic(o), h = lc(o), {
            settings: m,
            setSettings: g
        } = $t(Tn), {
            tokenSecuritySupport: p,
            isSecurityAnalysisVisible: b
        } = q0({
            chain: d
        }), j = ac(t), {
            pairDetails: y,
            invert: S,
            isInverted: w,
            tokenSupplies: v,
            isMoonshot: x
        } = Zt(({
            pairDetails: Y,
            invert: He,
            isInverted: gt,
            tokenSupplies: Tt,
            isMoonshot: Jt
        }) => ({
            pairDetails: Y,
            invert: He,
            isInverted: gt,
            tokenSupplies: Tt,
            isMoonshot: Jt
        })), {
            circulatingSupply: C,
            marketCap: E,
            totalSupply: R
        } = f.useMemo(() => be({
            value: v,
            onPending: () => ({
                circulatingSupply: void 0,
                marketCap: void 0,
                totalSupply: void 0
            }),
            onFailure: () => ({
                circulatingSupply: void 0,
                marketCap: void 0,
                totalSupply: void 0
            }),
            onSuccess: Y => {
                const He = Yf({
                    priceUsd: r.priceUsd,
                    tokenSupplies: Y
                });
                return {
                    circulatingSupply: Y == null ? void 0 : Y.circulatingSupply,
                    totalSupply: Y == null ? void 0 : Y.totalSupply,
                    marketCap: He
                }
            }
        }), [r.priceUsd, v]), B = f.useMemo(() => be({
            value: y,
            onPending: () => {},
            onFailure: () => {},
            onSuccess: Y => (Y == null ? void 0 : Y.ll) ? ? void 0
        }), [y]), {
            baseToken: A,
            quoteToken: P
        } = f.useMemo(() => w ? {
            baseToken: r.quoteToken,
            quoteToken: r.baseToken
        } : {
            baseToken: r.baseToken,
            quoteToken: r.quoteToken
        }, [w, r.quoteToken, r.baseToken]);
        let D = "";
        D += A.symbol, w ? D += ` ${r.priceUsd?ua(new mt(r.priceUsd.replace(/,/g,"")).dividedBy(r.price.replace(/,/g,""))):ha({price:new mt(1).dividedBy(r.price.replace(/,/g,"")),options:{suffix:` ${P.symbol}`}})} - ` : D += ` ${r.priceUsd?ua(r.priceUsd):ha({price:r.price,options:{suffix:` ${P.symbol}`}})} - `, D += `${qt(A.name,48)} / ${qt(P.symbol,48)} on ${j} / ${h} - DEX Screener`;
        const O = `${r.priceUsd?`${Wh(r.priceUsd)} `:""}${qt(A.name,48)} (${qt(A.symbol,48)}) realtime price charts, trading history and info - ${qt(A.symbol,48)} / ${qt(P.symbol,48)} on ${j} / ${h}`,
            V = xe(Nh),
            z = ((ct = dr().current) == null ? void 0 : ct.time) || Date.now(),
            H = 1200,
            oe = 600,
            re = f.useMemo(() => V.buildChartScreenshotUrl({
                chainId: t,
                pairId: r.pairAddress,
                width: H,
                height: oe,
                timestamp: z
            }).toString(), [z, r.pairAddress, t, V]),
            fe = !_n(Y => Y.embedSettings).isEmbed,
            je = (kt = dr().current) == null ? void 0 : kt.random,
            {
                clientRandom: ze
            } = f.useMemo(() => ({
                chainId: t,
                clientRandom: Math.random()
            }), [t]),
            Me = je ? ? ze,
            Fe = f.useMemo(() => {
                var Y;
                return t === "arbitrum" ? "persona" : ((Y = Dh({
                    items: [{
                        weight: .7,
                        preferredAdsProvider: "direct"
                    }, {
                        weight: .2,
                        preferredAdsProvider: "persona"
                    }, {
                        weight: .2,
                        preferredAdsProvider: "coinzilla"
                    }, {
                        weight: .2,
                        preferredAdsProvider: "a-ads"
                    }],
                    random: Me
                })) == null ? void 0 : Y.preferredAdsProvider) ? ? "a-ads"
            }, [t, Me]),
            Be = Lh({
                chainId: t,
                tokenAddress: A.address
            }),
            W = Be !== void 0,
            se = f.useMemo(() => {
                if (W) return jt({
                    enabled: !1,
                    adLocation: {
                        preferredAdKind: "native",
                        screen: "pair",
                        provider: "coinzilla"
                    }
                });
                if (t === "arbitrum") return jt({
                    enabled: fe,
                    adLocation: {
                        preferredAdKind: "display",
                        screen: "pair",
                        provider: "persona",
                        size: {
                            width: 300,
                            height: 250
                        },
                        chainId: t
                    }
                });
                switch (Fe) {
                    case "persona":
                        return jt({
                            enabled: fe,
                            adLocation: {
                                preferredAdKind: "display",
                                screen: "pair",
                                provider: "persona",
                                size: {
                                    width: 300,
                                    height: 250
                                }
                            }
                        });
                    case "coinzilla":
                        return jt({
                            enabled: fe,
                            adLocation: {
                                preferredAdKind: "display",
                                screen: "pair",
                                provider: "coinzilla",
                                size: {
                                    width: 300,
                                    height: 250
                                }
                            }
                        });
                    case "a-ads":
                        return jt({
                            enabled: fe,
                            adLocation: {
                                preferredAdKind: "display",
                                screen: "pair",
                                provider: "a-ads",
                                size: {
                                    width: 300,
                                    height: 250
                                }
                            }
                        });
                    case "direct":
                        return jt({
                            enabled: fe,
                            adLocation: {
                                preferredAdKind: "display",
                                screen: "pair",
                                provider: "direct",
                                size: {
                                    width: 300,
                                    height: 250
                                },
                                chainId: t
                            }
                        })
                }
            }, [t, W, fe, Fe]),
            J = f.useMemo(() => {
                if (W) return jt({
                    enabled: !1,
                    adLocation: {
                        preferredAdKind: "native",
                        screen: "pair",
                        provider: "coinzilla"
                    }
                });
                if (t === "arbitrum") return jt({
                    enabled: fe,
                    adLocation: {
                        preferredAdKind: "display",
                        screen: "pair",
                        provider: "persona",
                        size: {
                            width: 321,
                            height: 101
                        },
                        chainId: t
                    }
                });
                switch (Fe) {
                    case "persona":
                        return jt({
                            enabled: fe,
                            adLocation: {
                                preferredAdKind: "display",
                                screen: "pair",
                                provider: "persona",
                                size: {
                                    width: 321,
                                    height: 101
                                }
                            }
                        });
                    case "coinzilla":
                        return jt({
                            enabled: fe,
                            adLocation: {
                                preferredAdKind: "display",
                                screen: "pair",
                                provider: "coinzilla",
                                size: "responsive"
                            }
                        });
                    case "a-ads":
                        return jt({
                            enabled: fe,
                            adLocation: {
                                preferredAdKind: "display",
                                screen: "pair",
                                provider: "a-ads",
                                size: {
                                    width: 320,
                                    height: 100
                                }
                            }
                        });
                    case "direct":
                        return jt({
                            enabled: fe,
                            adLocation: {
                                preferredAdKind: "display",
                                screen: "pair",
                                provider: "direct",
                                size: {
                                    width: 320,
                                    height: 100
                                },
                                chainId: t
                            }
                        })
                }
            }, [t, W, fe, Fe]),
            de = f.useMemo(() => ({
                chainId: r.chainId,
                pairId: r.pairAddress
            }), [r.chainId, r.pairAddress]),
            ie = f.useMemo(() => be({
                value: y,
                onPending: () => {
                    var Y;
                    return r.eti === !0 || ((Y = r.profile) == null ? void 0 : Y.eti) === !0
                },
                onFailure: () => {
                    var Y;
                    return r.eti === !0 || ((Y = r.profile) == null ? void 0 : Y.eti) === !0
                },
                onSuccess: Y => {
                    var He;
                    return r.eti === !0 || ((He = r.profile) == null ? void 0 : He.eti) === !0 || !!(Y != null && Y.ti)
                }
            }), [y, r.eti, r.profile]),
            U = r.c === "a" && !!r.cmsProfile,
            F = f.useMemo(() => be({
                value: y,
                onPending: () => U,
                onFailure: () => U,
                onSuccess: Y => U && !!(Y != null && Y.cms)
            }), [y, U]),
            G = f.useMemo(() => ie || F, [F, ie]),
            ce = f.useMemo(() => {
                var Y;
                return s({
                    dsDataParams: ie ? {
                        chainId: r.chainId,
                        tokenAddress: r.baseToken.address,
                        cacheKey: (Y = r.profile) == null ? void 0 : Y.imgKey
                    } : void 0,
                    cmsParams: r.cmsProfile ? {
                        size: {
                            width: 56,
                            height: 56
                        },
                        fit: "crop",
                        assetId: r.cmsProfile.iconId
                    } : void 0
                })
            }, [s, ie, r]),
            Q = f.useMemo(() => {
                var Y;
                return i({
                    dsDataParams: ie ? {
                        chainId: r.chainId,
                        tokenAddress: r.baseToken.address,
                        cacheKey: (Y = r.profile) == null ? void 0 : Y.imgKey
                    } : void 0,
                    cmsParams: r.cmsProfile && r.cmsProfile.headerId ? {
                        assetId: r.cmsProfile.headerId,
                        size: "lg",
                        fit: "crop"
                    } : void 0
                })
            }, [i, ie, r.baseToken.address, r.chainId, r.cmsProfile, (zt = r.profile) == null ? void 0 : zt.imgKey]),
            le = f.useMemo(() => be({
                value: y,
                onPending: () => {
                    var Y, He;
                    return ((Y = r.profile) == null ? void 0 : Y.header) === !0 || !!((He = r.cmsProfile) != null && He.headerId)
                },
                onFailure: () => {
                    var Y, He;
                    return ((Y = r.profile) == null ? void 0 : Y.header) === !0 || !!((He = r.cmsProfile) != null && He.headerId)
                },
                onSuccess: Y => {
                    var Tt, Jt, Wo, Do, Lo, No;
                    const He = fa((Tt = Y == null ? void 0 : Y.ti) == null ? void 0 : Tt.claims);
                    if (He) return !!He.headerImage;
                    const gt = fa((Jt = Y == null ? void 0 : Y.cms) == null ? void 0 : Jt.claims);
                    return gt ? !!gt.header : !!((Wo = r.profile) != null && Wo.header) || !!((Do = r.cmsProfile) != null && Do.headerId) || !!((Lo = Y == null ? void 0 : Y.ti) != null && Lo.headerImage) || !!((No = Y == null ? void 0 : Y.cms) != null && No.header)
                }
            }), [(Mt = r.cmsProfile) == null ? void 0 : Mt.headerId, (nt = r.profile) == null ? void 0 : nt.header, y]),
            te = De(m),
            N = f.useCallback(() => {
                g({
                    sidebarPosition: te.current.sidebarPosition === "left" ? "right" : "left"
                })
            }, [g, te]),
            ne = f.useCallback(() => {
                g({
                    sidebar: !te.current.sidebar
                })
            }, [g, te]),
            Pe = f.useCallback(() => {
                g({
                    trendingBar: !te.current.trendingBar
                })
            }, [g, te]),
            Ke = f.useCallback(() => {
                g({
                    tokenHeaderImage: !te.current.tokenHeaderImage
                })
            }, [g, te]),
            Ne = pr({
                defaultIsOpen: !0
            });
        return {
            chainId: t,
            chain: d,
            isEmbedModalOpened: a,
            closeEmbedModal: l,
            openEmbedModal: c,
            pair: r,
            pairIdentity: de,
            dex: u,
            tokenSecuritySupport: p,
            isSecurityAnalysisVisible: b,
            pairDetails: y,
            circulatingSupply: C,
            totalSupply: R,
            marketCap: E,
            liquidityLock: B,
            baseToken: A,
            quoteToken: P,
            isMoonshot: x,
            displayTokenProfile: G,
            tokenIconURL: ce,
            hasHeaderImage: le,
            tokenHeaderURL: Q,
            meta: {
                title: D,
                description: O,
                image: {
                    type: "image/png",
                    width: H,
                    height: oe,
                    alt: `${qt(A.symbol,48)} / ${qt(P.symbol,48)} chart`,
                    url: re.toString()
                }
            },
            mobileAds: J,
            desktopAds: se,
            toggleInvert: S,
            isInverted: w,
            sidebarPosition: m.sidebarPosition,
            toggleSidebarPosition: N,
            toggleSidebarVisibility: ne,
            trendingBarVisibility: m.trendingBar,
            toggleTrendingBarVisibility: Pe,
            tokenHeaderImageVisibility: m.tokenHeaderImage,
            toggleTokenHeaderImageVisibility: Ke,
            dsDataAd: Be,
            dsDataAdDisclosure: Ne
        }
    },
    ix = Pr(() => zr(() =>
        import ("./AMMPairTrading-Q6o0IJBD.js"), __vite__mapDeps([20, 1, 2, 3, 7, 15, 16, 8, 9, 10, 11, 12, 6, 13, 14, 17, 18, 19]))),
    ax = Pr(() => zr(() =>
        import ("./embed-modal-MOuOuiws.js"), __vite__mapDeps([21, 1, 2, 3, 7, 15, 16, 8, 9, 10, 11, 12, 22]))),
    lx = Pr(() => zr(() =>
        import ("./AMMPairIframe-Tn9A6u-V.js"), __vite__mapDeps([23, 1, 2, 3]))),
    il = () => n.jsx(vc, {
        containerProps: {
            position: "absolute",
            top: 0,
            left: 0,
            background: "blackAlpha.400",
            zIndex: 1e4
        }
    }),
    Ws = {
        thumbBorderRadius: "10px",
        thumbBorderWidth: "1px",
        scrollbarWidth: "10px",
        scrollbarWidthFirefox: "thin"
    },
    al = (e, t) => {
        const [o, r] = f.useState({
            scrollTop: 0,
            height: 0
        }), s = De(o), i = f.useCallback(() => {
            !e.current || !t.current || r({
                scrollTop: e.current.scrollTop,
                height: t.current.offsetHeight
            })
        }, [e, t]), a = f.useCallback(() => {
            if (!e.current || !t.current) return;
            const {
                scrollTop: l,
                height: c
            } = s.current, d = t.current.offsetTop, u = t.current.offsetHeight;
            l > d && e.current.scrollTo({
                top: l - c + u,
                behavior: "auto"
            })
        }, [s, e, t]);
        return {
            savePosition: i,
            restorePosition: a
        }
    },
    ll = f.useLayoutEffect,
    cl = 46,
    cx = e => {
        const {
            onClose: t,
            isMobileTabBarVisible: o,
            isTrendingBarVisible: r,
            isMobileChatVisible: s
        } = e, {
            chainId: i,
            chain: a,
            closeEmbedModal: l,
            dex: c,
            isEmbedModalOpened: d,
            openEmbedModal: u,
            pair: h,
            pairIdentity: m,
            pairDetails: g,
            circulatingSupply: p,
            totalSupply: b,
            marketCap: j,
            liquidityLock: y,
            baseToken: S,
            quoteToken: w,
            meta: v,
            mobileAds: x,
            desktopAds: C,
            tokenSecuritySupport: E,
            isSecurityAnalysisVisible: R,
            isMoonshot: B,
            displayTokenProfile: A,
            tokenIconURL: P,
            tokenHeaderURL: D,
            hasHeaderImage: O,
            toggleInvert: V,
            isInverted: z,
            sidebarPosition: H,
            toggleSidebarPosition: oe,
            toggleSidebarVisibility: re,
            trendingBarVisibility: ye,
            toggleTrendingBarVisibility: fe,
            tokenHeaderImageVisibility: je,
            toggleTokenHeaderImageVisibility: ze,
            dsDataAd: Me,
            dsDataAdDisclosure: Fe
        } = sx(e), Be = (c == null ? void 0 : c.slug) ? ? "_unknown", {
            colorMode: W
        } = pe(), se = xe(kn), J = f.useRef(null), de = f.useRef(null), ie = f.useRef(null), U = f.useRef(null), {
            restorePosition: F,
            savePosition: G
        } = al(J, de), [ce, Q] = f.useState(!1), {
            restorePosition: le,
            savePosition: te
        } = al(J, ie), [N, ne] = f.useState(!1), Pe = f.useCallback(() => {
            Q(!0)
        }, []), Ke = f.useCallback(() => {
            G(), Q(!1)
        }, [G]), Ne = f.useCallback(() => {
            ne(!0)
        }, []), ct = f.useCallback(() => {
            te(), ne(!1)
        }, [te]), kt = f.useCallback(() => {
            !J.current || !U.current || J.current.scrollTo({
                top: U.current.offsetTop - 50,
                behavior: "smooth"
            })
        }, [J, U]);
        ll(() => {
            ce || F()
        }, [F, ce]), ll(() => {
            N || le()
        }, [le, N]);
        const {
            value: zt,
            enable: Mt,
            disable: nt
        } = Yt(!1), Y = h.pairAddress, He = h.baseToken.address, gt = h.quoteToken.address, Tt = f.useMemo(() => {
            if (!(!a || !c)) return Hh({
                chain: a,
                dex: c,
                pairAddress: Y,
                baseTokenAddress: He,
                labels: h.labels,
                inputCurrency: gt
            })
        }, [a, c, gt, He, h.labels, Y]), [Jt, Wo] = f.useState(), Do = () => {
            se.track({
                event: "pairDetail:embed"
            }), u()
        }, Lo = f.useCallback(() => {
            z || se.track({
                event: "pairDetail:invert"
            }), V()
        }, [z, se, V]), No = ii(), qd = Sn(typeof window < "u" && "Notification" in window, !1), Gd = f.useMemo(() => be({
            value: g,
            onPending: ln,
            onFailure: ln,
            onSuccess: Tn
        }), [g]), Kd = f.useMemo(() => Nt(g, Ue => (Ue == null ? void 0 : Ue.gp) ? ? void 0), [g]), Qd = f.useMemo(() => Nt(g, Ue => (Ue == null ? void 0 : Ue.ts) ? ? void 0), [g]), $d = f.useMemo(() => Nt(g, Ue => (Ue == null ? void 0 : Ue.qi) ? ? void 0), [g]), Ho = f.useMemo(() => !a || !c ? void 0 : _h({
            chain: a,
            dex: c,
            pairAddress: Y,
            baseTokenAddress: He,
            labels: h.labels,
            inputCurrency: gt
        }).map(es => ({
            title: `Trade on ${es.name}`,
            url: es.url,
            mode: es.slug
        })), [a, c, Y, He, h.labels, gt]), Zn = f.useMemo(() => {
            if (!(!Tt || !c)) return Ho && Ho.length > 0 ? {
                title: `Trade on ${c.name}`,
                url: Tt,
                mode: "dex"
            } : {
                title: `Trade ${h.baseToken.symbol}/${h.quoteToken.symbol}`,
                url: Tt,
                mode: "dex"
            }
        }, [c, h.baseToken.symbol, h.quoteToken.symbol, Ho, Tt]), Yd = ui({
            colorMode: W,
            overrides: Ws
        }), Yi = $t(({
            settings: Ue
        }) => Ue.chatState), Zi = $t(({
            setSettings: Ue
        }) => Ue), [Ji, Zd] = f.useState(() => {
            switch (Yi) {
                case "minimized":
                case "expanded":
                    return Yi;
                case "maximized":
                    return "expanded"
            }
        }), ea = Hr(), Jd = f.useCallback(Ue => {
            Zd(Ue), Zi({
                chatState: Ue
            })
        }, [Zi]);
        return n.jsxs(n.Fragment, {
            children: [n.jsxs(Oh, {
                defer: !1,
                children: [n.jsx("title", {
                    children: v.title
                }), n.jsx("meta", {
                    name: "description",
                    content: v.description
                }), n.jsx("meta", {
                    name: "twitter:card",
                    content: "summary_large_image"
                }), n.jsx("meta", {
                    name: "twitter:title",
                    content: v.title
                }), n.jsx("meta", {
                    name: "twitter:description",
                    content: v.description
                }), n.jsx("meta", {
                    name: "twitter:image",
                    content: v.image.url
                }), n.jsx("meta", {
                    name: "twitter:image:alt",
                    content: v.image.alt
                }), n.jsx("meta", {
                    property: "og:title",
                    content: v.title
                }), n.jsx("meta", {
                    property: "og:description",
                    content: v.description
                }), n.jsx("meta", {
                    property: "og:image",
                    content: v.image.url
                }), n.jsx("meta", {
                    property: "og:image:type",
                    content: v.image.type
                }), n.jsx("meta", {
                    property: "og:image:width",
                    content: v.image.width.toString()
                }), n.jsx("meta", {
                    property: "og:image:height",
                    content: v.image.height.toString()
                }), n.jsx("meta", {
                    property: "og:image:alt",
                    content: v.image.alt
                })]
            }), n.jsxs(I, {
                pos: "relative",
                display: "flex",
                flex: 1,
                flexDir: "column",
                w: "100%",
                h: "100%",
                children: [(ea || !s) && n.jsxs(K, {
                    flexShrink: 0,
                    as: "header",
                    position: "sticky",
                    display: "flex",
                    alignItems: "center",
                    bg: T("gray.25", "blue.925", W),
                    zIndex: 1,
                    px: 2,
                    height: `${cl}px`,
                    borderBottomWidth: 1,
                    borderBottomColor: T("gray.75", "blue.900", W),
                    children: [P ? n.jsx(Ze, {
                        src: P,
                        w: "28px",
                        h: "28px",
                        loading: "lazy"
                    }) : null, n.jsx(Lt, {
                        size: "md",
                        flex: 1,
                        whiteSpace: "nowrap",
                        textOverflow: "ellipsis",
                        overflow: "hidden",
                        title: S.name,
                        children: S.name
                    }), n.jsxs(K, {
                        display: "flex",
                        alignItems: "center",
                        children: [n.jsx(I, {
                            children: n.jsxs(Xn, {
                                isLazy: !0,
                                children: [n.jsx(qn, {
                                    as: Je,
                                    variant: "outline",
                                    size: "sm",
                                    minW: "30px",
                                    h: "30px",
                                    icon: n.jsx(L, {
                                        as: Uh
                                    }),
                                    title: "More",
                                    "aria-label": "More"
                                }), n.jsxs(Gn, {
                                    w: "300px",
                                    maxW: "90vw",
                                    children: [!Ye(h) && n.jsxs(n.Fragment, {
                                        children: [n.jsx(bn, {
                                            onClick: Lo,
                                            children: n.jsxs(he, {
                                                alignItems: "stretch",
                                                spacing: "0",
                                                children: [n.jsxs(K, {
                                                    children: [n.jsx(L, {
                                                        as: mc
                                                    }), n.jsx(k, {
                                                        children: "Invert Pair"
                                                    })]
                                                }), n.jsxs(K, {
                                                    opacity: .5,
                                                    spacing: "1",
                                                    fontSize: "xs",
                                                    children: [n.jsxs(q, {
                                                        as: "span",
                                                        whiteSpace: "nowrap",
                                                        textOverflow: "ellipsis",
                                                        overflow: "hidden",
                                                        children: [S.symbol, "/", w.symbol]
                                                    }), n.jsx(L, {
                                                        as: ga,
                                                        boxSize: "8px",
                                                        mx: 1
                                                    }), n.jsxs(q, {
                                                        as: "span",
                                                        whiteSpace: "nowrap",
                                                        textOverflow: "ellipsis",
                                                        overflow: "hidden",
                                                        children: [w.symbol, "/", S.symbol]
                                                    })]
                                                })]
                                            })
                                        }), n.jsx(er, {})]
                                    }), n.jsx(bn, {
                                        onClick: oe,
                                        display: {
                                            base: "none",
                                            lg: "block"
                                        },
                                        children: n.jsxs(K, {
                                            children: [n.jsx(L, {
                                                as: H === "right" ? Vh : ga
                                            }), n.jsxs(k, {
                                                children: ["Move sidebar to the ", H === "right" ? "left" : "right"]
                                            })]
                                        })
                                    }), n.jsx(bn, {
                                        onClick: re,
                                        display: {
                                            base: "none",
                                            lg: "block"
                                        },
                                        children: n.jsxs(K, {
                                            children: [n.jsx(L, {
                                                as: os
                                            }), n.jsx(k, {
                                                children: "Hide sidebar"
                                            })]
                                        })
                                    }), n.jsx(er, {
                                        display: {
                                            base: "none",
                                            lg: "block"
                                        }
                                    }), n.jsx(bn, {
                                        onClick: fe,
                                        children: n.jsxs(K, {
                                            children: [n.jsx(L, {
                                                as: ye ? os : ma
                                            }), n.jsxs(k, {
                                                children: [ye ? "Hide" : "Show", " trending bar"]
                                            })]
                                        })
                                    }), O && n.jsxs(n.Fragment, {
                                        children: [n.jsx(er, {}), n.jsx(bn, {
                                            onClick: ze,
                                            children: n.jsxs(K, {
                                                children: [n.jsx(L, {
                                                    as: je ? os : ma
                                                }), n.jsxs(k, {
                                                    children: [je ? "Hide" : "Show", " header image"]
                                                })]
                                            })
                                        })]
                                    })]
                                })]
                            }, `${z}`)
                        }), t && n.jsx(Fn, {
                            onClick: t,
                            title: "Close",
                            w: "30px",
                            h: "30px",
                            autoFocus: !0
                        })]
                    })]
                }), n.jsxs(I, {
                    display: ea ? Ji === "maximized" ? "none" : "block" : s ? "none" : "block",
                    flex: 1,
                    overflowY: "scroll",
                    ref: J,
                    bg: ee("white", "blue.975"),
                    sx: Yd,
                    children: [n.jsxs(en, {
                        pos: "relative",
                        bgColor: T("gray.25", "blue.1000", W),
                        borderBottomWidth: 1,
                        borderColor: T("gray.75", "blue.950", W),
                        py: "2",
                        ...g.kind !== "AsyncFailure" && A && (!je || !O) ? {
                            pb: 5,
                            mb: 3
                        } : void 0,
                        children: [n.jsx(nm, {
                            pair: h,
                            baseToken: S,
                            quoteToken: w
                        }), g.kind !== "AsyncFailure" && A && (!je || !O) && n.jsx(I, {
                            pos: "absolute",
                            left: "0",
                            bottom: "-13px",
                            w: "100%",
                            px: "3",
                            children: n.jsx(sl, {
                                pairDetails: g,
                                onMoreClick: kt
                            })
                        })]
                    }), g.kind !== "AsyncFailure" && je && O && n.jsx(I, {
                        w: "100%",
                        aspectRatio: "3 / 1",
                        pos: "relative",
                        borderBottomWidth: 1,
                        borderColor: T("gray.75", "blue.950", W),
                        bgColor: T("gray.175", "gray.975", W),
                        bgImage: ["linear-gradient(rgba(0,0,0,0.2) 0%,rgba(0,0,0, 0) 10%)", "linear-gradient(rgba(0,0,0, 0) 60%,rgba(0,0,0,0.25) 90%)", `url(${D})`].join(","),
                        bgSize: "100%",
                        bgPosition: "center",
                        bgRepeat: "no-repeat",
                        transition: "background-size 0.5s",
                        mb: 2,
                        _hover: {
                            bgSize: "105%"
                        },
                        children: n.jsx(I, {
                            pos: "absolute",
                            bottom: "-13px",
                            w: "100%",
                            px: "3",
                            children: n.jsx(sl, {
                                pairDetails: g,
                                onMoreClick: kt
                            })
                        })
                    }), n.jsx(en, {
                        pb: 0,
                        children: n.jsxs(he, {
                            spacing: 2,
                            alignItems: "stretch",
                            children: [n.jsx(ex, {
                                wrapper: Ue => n.jsx(he, {
                                    spacing: 1,
                                    children: Ue
                                }),
                                pair: h,
                                isInverted: z,
                                pairDetails: Gd
                            }), Ye(h) ? n.jsxs(n.Fragment, {
                                children: [h.moonshot.progress >= 100 ? n.jsx(rx, {
                                    pair: h
                                }) : null, n.jsx(Jm, {
                                    pair: h
                                }), n.jsx(dp, {
                                    pair: h,
                                    curvePosition: h.moonshot.curvePos,
                                    marketCapThreshold: h.moonshot.mcapThreshold,
                                    isDisabled: h.moonshot.progress === 100
                                })]
                            }) : n.jsx(gp, {
                                pair: h,
                                marketCapInfo: p && j && b ? {
                                    circulatingSupply: p,
                                    usdValue: j,
                                    totalSupply: b
                                } : null,
                                liquidityLock: y,
                                isInverted: z
                            }), !B && n.jsxs(n.Fragment, {
                                children: [Me && Fe.isOpen && n.jsx(I, {
                                    order: {
                                        base: 1
                                    },
                                    children: n.jsx(tx, {
                                        ad: Me,
                                        onHide: Fe.onClose
                                    })
                                }), n.jsx(Sa, {
                                    value: x,
                                    children: n.jsx(ya, {
                                        variant: "pair",
                                        containerProps: {
                                            display: {
                                                base: "flex",
                                                lg: "none"
                                            }
                                        }
                                    })
                                })]
                            }), n.jsx(Y0, {
                                pair: h,
                                isInverted: z
                            }), n.jsxs(he, {
                                alignItems: "stretch",
                                children: [n.jsxs(K, {
                                    children: [!B && n.jsx(pf, {
                                        buttonProps: {
                                            flex: 1
                                        },
                                        menuContainerProps: {
                                            flex: 1
                                        },
                                        watchlistPair: {
                                            type: "dexPair",
                                            chainId: i,
                                            dexId: Be,
                                            pairId: h.pairAddress,
                                            baseTokenName: h.baseToken.name,
                                            baseTokenSymbol: h.baseToken.symbol,
                                            quoteTokenSymbol: h.quoteToken.symbol
                                        }
                                    }), h.priceUsd && n.jsx(jf, {
                                        pair: h,
                                        isInverted: z,
                                        buttonProps: {
                                            display: {
                                                base: "none",
                                                lg: "flex"
                                            },
                                            w: B ? "100%" : "50%",
                                            flexShrink: 0,
                                            isDisabled: !qd
                                        }
                                    })]
                                }), !B && Zn && n.jsxs(K, {
                                    spacing: 0,
                                    alignItems: "stretch",
                                    children: [n.jsx(ue, {
                                        onClick: Mt,
                                        flex: 1,
                                        leftIcon: n.jsx(L, {
                                            as: Xh
                                        }),
                                        fontWeight: "normal",
                                        borderRightRadius: 0,
                                        paddingRight: 2,
                                        children: Zn.title
                                    }), n.jsx(Ms, {
                                        href: Zn.url,
                                        onClick: () => {
                                            se.track({
                                                event: "externalLink:trade",
                                                data: {
                                                    chainId: i,
                                                    dexId: Be,
                                                    pairId: h.pairAddress,
                                                    pair: `${h.baseToken.symbol}/${h.quoteToken.symbol}`,
                                                    source: "pairDetailSidebar"
                                                }
                                            })
                                        },
                                        w: "50px",
                                        height: "initial",
                                        size: "sm",
                                        title: "Open DEX website in new window",
                                        borderLeftRadius: 0,
                                        borderLeftWidth: 1,
                                        borderLeftColor: T("gray.150", "blue.850", W)
                                    })]
                                })]
                            }), !B && n.jsx(Sa, {
                                value: C,
                                children: n.jsx(ya, {
                                    variant: "pair",
                                    containerProps: x.enabled ? {
                                        display: {
                                            base: "none",
                                            lg: "flex"
                                        }
                                    } : void 0
                                })
                            })]
                        })
                    }), n.jsx(en, {
                        children: n.jsx(_m, {
                            pair: h,
                            isMoonshot: B
                        })
                    }), n.jsx(en, {
                        children: n.jsxs(he, {
                            alignItems: "stretch",
                            children: [R && n.jsxs(n.Fragment, {
                                children: [n.jsxs(he, {
                                    alignItems: "stretch",
                                    spacing: "0",
                                    borderRadius: "md",
                                    borderColor: T("gray.200", "whiteAlpha.300", W),
                                    borderWidth: "1px",
                                    divider: n.jsx(I, {
                                        height: "0",
                                        borderColor: T("gray.200", "whiteAlpha.300", W),
                                        borderBottomWidth: "1px"
                                    }),
                                    children: [E.goPlus.isEnabled && n.jsx(Nm, {
                                        ref: de,
                                        data: Kd,
                                        pair: m,
                                        onClose: Ke,
                                        onOpen: Pe
                                    }), E.quickIntel.isEnabled && n.jsx(jp, {
                                        ref: ie,
                                        data: $d,
                                        pair: m,
                                        onClose: ct,
                                        onOpen: Ne
                                    }), E.tokenSniffer.isEnabled && n.jsx(zp, {
                                        data: Qd,
                                        networkId: E.tokenSniffer.networkId,
                                        tokenAddress: h.baseToken.address
                                    })]
                                }), n.jsx(I, {
                                    marginBottom: "4",
                                    children: n.jsx(Sp, {})
                                })]
                            }), n.jsx(Z0, {
                                platformId: i,
                                pairAddress: h.pairAddress
                            })]
                        })
                    }), A && n.jsx(en, {
                        borderWidth: 0,
                        pt: "0",
                        pb: "5",
                        ref: U,
                        sx: {
                            top: "calc(0 * 1580px)"
                        },
                        children: n.jsx(Ep, {
                            pair: h,
                            pairDetails: g,
                            isMoonshot: oi(h)
                        })
                    }), h.priceUsd !== void 0 && n.jsx(en, {
                        py: 6,
                        borderTopWidth: 1,
                        borderTopColor: T("gray.100", "blue.850", W),
                        children: n.jsx(vp, {
                            pair: h
                        })
                    }), !A && n.jsx(en, {
                        fontSize: "sm",
                        borderTopWidth: 1,
                        borderTopColor: T("gray.100", "blue.850", W),
                        ref: U,
                        children: n.jsx(kp, {
                            pair: h,
                            pairDetails: g
                        })
                    }), No && n.jsx(en, {
                        borderTopWidth: 1,
                        borderTopColor: T("gray.100", "blue.850", W),
                        children: n.jsxs(he, {
                            children: [n.jsx(ue, {
                                w: "100%",
                                onClick: Do,
                                variant: "outline",
                                size: "sm",
                                leftIcon: n.jsx(L, {
                                    as: qh
                                }),
                                children: "Embed this chart"
                            }), n.jsx(k, {
                                textAlign: "center",
                                fontSize: "xs",
                                color: T("gray.400", "blue.600", W),
                                children: n.jsx(we, {
                                    href: "https://www.tradingview.com/markets/cryptocurrencies/",
                                    target: "_blank",
                                    children: "Crypto charts by TradingView"
                                })
                            })]
                        })
                    })]
                }), n.jsx(hm, {
                    sidebarHeaderHeight: cl,
                    isMobileTabBarVisible: o,
                    isTrendingBarVisible: r,
                    isMobileChatVisible: s,
                    state: Ji,
                    onStateChange: Jd,
                    chainId: i,
                    tokenAddress: He
                })]
            }), zt && Zn && n.jsx(f.Suspense, {
                fallback: null,
                children: n.jsx(ix, {
                    primaryLink: Zn,
                    secondaryLinks: Ho,
                    onClose: nt,
                    chainId: i,
                    dexId: Be,
                    pair: h
                })
            }), d && n.jsx(f.Suspense, {
                fallback: n.jsx(il, {}),
                children: n.jsx(ax, {
                    platformId: i,
                    screenerPair: h,
                    onClose: l
                })
            }), Jt && n.jsx(f.Suspense, {
                fallback: n.jsx(il, {}),
                children: n.jsx(lx, {
                    title: Jt.title,
                    url: Jt.url,
                    onClose: () => Wo(void 0)
                })
            })]
        })
    },
    Gr = 0,
    un = 1,
    $n = 2,
    ld = 4;

function xo(e, t) {
    return o => e(t(o))
}

function dx(e, t) {
    return t(e)
}

function cd(e, t) {
    return o => e(t, o)
}

function dl(e, t) {
    return () => e(t)
}

function Kr(e, t) {
    return t(e), e
}

function Le(...e) {
    return e
}

function ux(e) {
    e()
}

function ul(e) {
    return () => e
}

function hx(...e) {
    return () => {
        e.map(ux)
    }
}

function Pi(e) {
    return e !== void 0
}

function An() {}

function Ee(e, t) {
    return e(un, t)
}

function ve(e, t) {
    e(Gr, t)
}

function Ri(e) {
    e($n)
}

function st(e) {
    return e(ld)
}

function ae(e, t) {
    return Ee(e, cd(t, Gr))
}

function Ot(e, t) {
    const o = e(un, r => {
        o(), t(r)
    });
    return o
}

function ke() {
    const e = [];
    return (t, o) => {
        switch (t) {
            case $n:
                e.splice(0, e.length);
                return;
            case un:
                return e.push(o), () => {
                    const r = e.indexOf(o);
                    r > -1 && e.splice(r, 1)
                };
            case Gr:
                e.slice().forEach(r => {
                    r(o)
                });
                return;
            default:
                throw new Error(`unrecognized action ${t}`)
        }
    }
}

function X(e) {
    let t = e;
    const o = ke();
    return (r, s) => {
        switch (r) {
            case un:
                s(t);
                break;
            case Gr:
                t = s;
                break;
            case ld:
                return t
        }
        return o(r, s)
    }
}

function fx(e) {
    let t, o;
    const r = () => t && t();
    return function(s, i) {
        switch (s) {
            case un:
                return i ? o === i ? void 0 : (r(), o = i, t = Ee(e, i), t) : (r(), An);
            case $n:
                r(), o = null;
                return;
            default:
                throw new Error(`unrecognized action ${s}`)
        }
    }
}

function bt(e) {
    return Kr(ke(), t => ae(e, t))
}

function it(e, t) {
    return Kr(X(t), o => ae(e, o))
}

function gx(...e) {
    return t => e.reduceRight(dx, t)
}

function _(e, ...t) {
    const o = gx(...t);
    return (r, s) => {
        switch (r) {
            case un:
                return Ee(e, o(s));
            case $n:
                Ri(e);
                return
        }
    }
}

function dd(e, t) {
    return e === t
}

function We(e = dd) {
    let t;
    return o => r => {
        e(t, r) || (t = r, o(r))
    }
}

function ge(e) {
    return t => o => {
        e(o) && t(o)
    }
}

function $(e) {
    return t => xo(t, e)
}

function Ft(e) {
    return t => () => t(e)
}

function _t(e, t) {
    return o => r => o(t = e(t, r))
}

function Vn(e) {
    return t => o => {
        e > 0 ? e-- : t(o)
    }
}

function sn(e) {
    let t = null,
        o;
    return r => s => {
        t = s, !o && (o = setTimeout(() => {
            o = void 0, r(t)
        }, e))
    }
}

function hl(e) {
    let t, o;
    return r => s => {
        t = s, o && clearTimeout(o), o = setTimeout(() => {
            r(t)
        }, e)
    }
}

function Se(...e) {
    const t = new Array(e.length);
    let o = 0,
        r = null;
    const s = Math.pow(2, e.length) - 1;
    return e.forEach((i, a) => {
        const l = Math.pow(2, a);
        Ee(i, c => {
            const d = o;
            o = o | l, t[a] = c, d !== s && o === s && r && (r(), r = null)
        })
    }), i => a => {
        const l = () => i([a].concat(t));
        o === s ? l() : r = l
    }
}

function fl(...e) {
    return function(t, o) {
        switch (t) {
            case un:
                return hx(...e.map(r => Ee(r, o)));
            case $n:
                return;
            default:
                throw new Error(`unrecognized action ${t}`)
        }
    }
}

function me(e, t = dd) {
    return _(e, We(t))
}

function $e(...e) {
    const t = ke(),
        o = new Array(e.length);
    let r = 0;
    const s = Math.pow(2, e.length) - 1;
    return e.forEach((i, a) => {
            const l = Math.pow(2, a);
            Ee(i, c => {
                o[a] = c, r = r | l, r === s && ve(t, o)
            })
        }),
        function(i, a) {
            switch (i) {
                case un:
                    return r === s && a(o), Ee(t, a);
                case $n:
                    return Ri(t);
                default:
                    throw new Error(`unrecognized action ${i}`)
            }
        }
}

function Te(e, t = [], {
    singleton: o
} = {
    singleton: !0
}) {
    return {
        id: mx(),
        constructor: e,
        dependencies: t,
        singleton: o
    }
}
const mx = () => Symbol();

function px(e) {
    const t = new Map,
        o = ({
            id: r,
            constructor: s,
            dependencies: i,
            singleton: a
        }) => {
            if (a && t.has(r)) return t.get(r);
            const l = s(i.map(c => o(c)));
            return a && t.set(r, l), l
        };
    return o(e)
}

function xx(e, t) {
    const o = {},
        r = {};
    let s = 0;
    const i = e.length;
    for (; s < i;) r[e[s]] = 1, s += 1;
    for (const a in t) r.hasOwnProperty(a) || (o[a] = t[a]);
    return o
}
const $o = typeof document < "u" ? M.useLayoutEffect : M.useEffect;

function zi(e, t, o) {
    const r = Object.keys(t.required || {}),
        s = Object.keys(t.optional || {}),
        i = Object.keys(t.methods || {}),
        a = Object.keys(t.events || {}),
        l = M.createContext({});

    function c(y, S) {
        y.propsReady && ve(y.propsReady, !1);
        for (const w of r) {
            const v = y[t.required[w]];
            ve(v, S[w])
        }
        for (const w of s)
            if (w in S) {
                const v = y[t.optional[w]];
                ve(v, S[w])
            }
        y.propsReady && ve(y.propsReady, !0)
    }

    function d(y) {
        return i.reduce((S, w) => (S[w] = v => {
            const x = y[t.methods[w]];
            ve(x, v)
        }, S), {})
    }

    function u(y) {
        return a.reduce((S, w) => (S[w] = fx(y[t.events[w]]), S), {})
    }
    const h = M.forwardRef((y, S) => {
            const {
                children: w,
                ...v
            } = y, [x] = M.useState(() => Kr(px(e), E => c(E, v))), [C] = M.useState(dl(u, x));
            return $o(() => {
                for (const E of a) E in v && Ee(C[E], v[E]);
                return () => {
                    Object.values(C).map(Ri)
                }
            }, [v, C, x]), $o(() => {
                c(x, v)
            }), M.useImperativeHandle(S, ul(d(x))), M.createElement(l.Provider, {
                value: x
            }, o ? M.createElement(o, xx([...r, ...s, ...a], v), w) : w)
        }),
        m = y => M.useCallback(cd(ve, M.useContext(l)[y]), [y]),
        g = y => {
            const w = M.useContext(l)[y],
                v = M.useCallback(x => Ee(w, x), [w]);
            return M.useSyncExternalStore(v, () => st(w), () => st(w))
        },
        p = y => {
            const w = M.useContext(l)[y],
                [v, x] = M.useState(dl(st, w));
            return $o(() => Ee(w, C => {
                C !== v && x(ul(C))
            }), [w, v]), v
        },
        b = M.version.startsWith("18") ? g : p;
    return {
        Component: h,
        usePublisher: m,
        useEmitterValue: b,
        useEmitter: (y, S) => {
            const v = M.useContext(l)[y];
            $o(() => Ee(v, S), [S, v])
        }
    }
}
const bx = typeof document < "u" ? M.useLayoutEffect : M.useEffect,
    vx = bx;
var vt = (e => (e[e.DEBUG = 0] = "DEBUG", e[e.INFO = 1] = "INFO", e[e.WARN = 2] = "WARN", e[e.ERROR = 3] = "ERROR", e))(vt || {});
const yx = {
        0: "debug",
        1: "log",
        2: "warn",
        3: "error"
    },
    jx = () => typeof globalThis > "u" ? window : globalThis,
    hn = Te(() => {
        const e = X(3);
        return {
            log: X((o, r, s = 1) => {
                var i;
                const a = (i = jx().VIRTUOSO_LOG_LEVEL) != null ? i : st(e);
                s >= a && console[yx[s]]("%creact-virtuoso: %c%s %o", "color: #0253b3; font-weight: bold", "color: initial", o, r)
            }),
            logLevel: e
        }
    }, [], {
        singleton: !0
    });

function Mi(e, t = !0) {
    const o = M.useRef(null);
    let r = s => {};
    if (typeof ResizeObserver < "u") {
        const s = M.useMemo(() => new ResizeObserver(i => {
            requestAnimationFrame(() => {
                const a = i[0].target;
                a.offsetParent !== null && e(a)
            })
        }), [e]);
        r = i => {
            i && t ? (s.observe(i), o.current = i) : (o.current && s.unobserve(o.current), o.current = null)
        }
    }
    return {
        ref: o,
        callbackRef: r
    }
}

function Ut(e, t = !0) {
    return Mi(e, t).callbackRef
}

function ud(e, t, o, r, s, i, a) {
    const l = M.useCallback(c => {
        const d = Sx(c.children, t, "offsetHeight", s);
        let u = c.parentElement;
        for (; !u.dataset.virtuosoScroller;) u = u.parentElement;
        const h = u.lastElementChild.dataset.viewportType === "window",
            m = a ? a.scrollTop : h ? window.pageYOffset || document.documentElement.scrollTop : u.scrollTop,
            g = a ? a.scrollHeight : h ? document.documentElement.scrollHeight : u.scrollHeight,
            p = a ? a.offsetHeight : h ? window.innerHeight : u.offsetHeight;
        r({
            scrollTop: Math.max(m, 0),
            scrollHeight: g,
            viewportHeight: p
        }), i == null || i(wx("row-gap", getComputedStyle(c).rowGap, s)), d !== null && e(d)
    }, [e, t, s, i, a, r]);
    return Mi(l, o)
}

function Sx(e, t, o, r) {
    const s = e.length;
    if (s === 0) return null;
    const i = [];
    for (let a = 0; a < s; a++) {
        const l = e.item(a);
        if (!l || l.dataset.index === void 0) continue;
        const c = parseInt(l.dataset.index),
            d = parseFloat(l.dataset.knownSize),
            u = t(l, o);
        if (u === 0 && r("Zero-sized element, this should not happen", {
                child: l
            }, vt.ERROR), u === d) continue;
        const h = i[i.length - 1];
        i.length === 0 || h.size !== u || h.endIndex !== c - 1 ? i.push({
            startIndex: c,
            endIndex: c,
            size: u
        }) : i[i.length - 1].endIndex++
    }
    return i
}

function wx(e, t, o) {
    return t !== "normal" && !(t != null && t.endsWith("px")) && o(`${e} was not resolved to pixel value correctly`, t, vt.WARN), t === "normal" ? 0 : parseInt(t ? ? "0", 10)
}

function Pt(e, t) {
    return Math.round(e.getBoundingClientRect()[t])
}

function hd(e, t) {
    return Math.abs(e - t) < 1.01
}

function fd(e, t, o, r = An, s) {
    const i = M.useRef(null),
        a = M.useRef(null),
        l = M.useRef(null),
        c = M.useCallback(h => {
            const m = h.target,
                g = m === window || m === document,
                p = g ? window.pageYOffset || document.documentElement.scrollTop : m.scrollTop,
                b = g ? document.documentElement.scrollHeight : m.scrollHeight,
                j = g ? window.innerHeight : m.offsetHeight,
                y = () => {
                    e({
                        scrollTop: Math.max(p, 0),
                        scrollHeight: b,
                        viewportHeight: j
                    })
                };
            h.suppressFlushSync ? y() : Gh.flushSync(y), a.current !== null && (p === a.current || p <= 0 || p === b - j) && (a.current = null, t(!0), l.current && (clearTimeout(l.current), l.current = null))
        }, [e, t]);
    M.useEffect(() => {
        const h = s || i.current;
        return r(s || i.current), c({
            target: h,
            suppressFlushSync: !0
        }), h.addEventListener("scroll", c, {
            passive: !0
        }), () => {
            r(null), h.removeEventListener("scroll", c)
        }
    }, [i, c, o, r, s]);

    function d(h) {
        const m = i.current;
        if (!m || "offsetHeight" in m && m.offsetHeight === 0) return;
        const g = h.behavior === "smooth";
        let p, b, j;
        m === window ? (b = Math.max(Pt(document.documentElement, "height"), document.documentElement.scrollHeight), p = window.innerHeight, j = document.documentElement.scrollTop) : (b = m.scrollHeight, p = Pt(m, "height"), j = m.scrollTop);
        const y = b - p;
        if (h.top = Math.ceil(Math.max(Math.min(y, h.top), 0)), hd(p, b) || h.top === j) {
            e({
                scrollTop: j,
                scrollHeight: b,
                viewportHeight: p
            }), g && t(!0);
            return
        }
        g ? (a.current = h.top, l.current && clearTimeout(l.current), l.current = setTimeout(() => {
            l.current = null, a.current = null, t(!0)
        }, 1e3)) : a.current = null, m.scrollTo(h)
    }

    function u(h) {
        i.current.scrollBy(h)
    }
    return {
        scrollerRef: i,
        scrollByCallback: u,
        scrollToCallback: d
    }
}
const ft = Te(() => {
        const e = ke(),
            t = ke(),
            o = X(0),
            r = ke(),
            s = X(0),
            i = ke(),
            a = ke(),
            l = X(0),
            c = X(0),
            d = X(0),
            u = X(0),
            h = ke(),
            m = ke(),
            g = X(!1);
        return ae(_(e, $(({
            scrollTop: p
        }) => p)), t), ae(_(e, $(({
            scrollHeight: p
        }) => p)), a), ae(t, s), {
            scrollContainerState: e,
            scrollTop: t,
            viewportHeight: i,
            headerHeight: l,
            fixedHeaderHeight: c,
            fixedFooterHeight: d,
            footerHeight: u,
            scrollHeight: a,
            smoothScrollTargetReached: r,
            scrollTo: h,
            scrollBy: m,
            statefulScrollTop: s,
            deviation: o,
            scrollingInProgress: g
        }
    }, [], {
        singleton: !0
    }),
    bo = {
        lvl: 0
    };

function gd(e, t, o, r = bo, s = bo) {
    return {
        k: e,
        v: t,
        lvl: o,
        l: r,
        r: s
    }
}

function Re(e) {
    return e === bo
}

function Ln() {
    return bo
}

function Ds(e, t) {
    if (Re(e)) return bo;
    const {
        k: o,
        l: r,
        r: s
    } = e;
    if (t === o) {
        if (Re(r)) return s;
        if (Re(s)) return r; {
            const [i, a] = md(r);
            return ir(Ge(e, {
                k: i,
                v: a,
                l: pd(r)
            }))
        }
    } else return t < o ? ir(Ge(e, {
        l: Ds(r, t)
    })) : ir(Ge(e, {
        r: Ds(s, t)
    }))
}

function vo(e, t) {
    if (!Re(e)) return t === e.k ? e.v : t < e.k ? vo(e.l, t) : vo(e.r, t)
}

function Rt(e, t, o = "k") {
    if (Re(e)) return [-1 / 0, void 0];
    if (Number(e[o]) === t) return [e.k, e.v];
    if (Number(e[o]) < t) {
        const r = Rt(e.r, t, o);
        return r[0] === -1 / 0 ? [e.k, e.v] : r
    }
    return Rt(e.l, t, o)
}

function xt(e, t, o) {
    return Re(e) ? gd(t, o, 1) : t === e.k ? Ge(e, {
        k: t,
        v: o
    }) : t < e.k ? gl(Ge(e, {
        l: xt(e.l, t, o)
    })) : gl(Ge(e, {
        r: xt(e.r, t, o)
    }))
}

function Ls(e, t, o) {
    if (Re(e)) return [];
    const {
        k: r,
        v: s,
        l: i,
        r: a
    } = e;
    let l = [];
    return r > t && (l = l.concat(Ls(i, t, o))), r >= t && r <= o && l.push({
        k: r,
        v: s
    }), r <= o && (l = l.concat(Ls(a, t, o))), l
}

function jn(e) {
    return Re(e) ? [] : [...jn(e.l), {
        k: e.k,
        v: e.v
    }, ...jn(e.r)]
}

function md(e) {
    return Re(e.r) ? [e.k, e.v] : md(e.r)
}

function pd(e) {
    return Re(e.r) ? e.l : ir(Ge(e, {
        r: pd(e.r)
    }))
}

function Ge(e, t) {
    return gd(t.k !== void 0 ? t.k : e.k, t.v !== void 0 ? t.v : e.v, t.lvl !== void 0 ? t.lvl : e.lvl, t.l !== void 0 ? t.l : e.l, t.r !== void 0 ? t.r : e.r)
}

function ms(e) {
    return Re(e) || e.lvl > e.r.lvl
}

function gl(e) {
    return Ns(bd(e))
}

function ir(e) {
    const {
        l: t,
        r: o,
        lvl: r
    } = e;
    if (o.lvl >= r - 1 && t.lvl >= r - 1) return e;
    if (r > o.lvl + 1) {
        if (ms(t)) return bd(Ge(e, {
            lvl: r - 1
        }));
        if (!Re(t) && !Re(t.r)) return Ge(t.r, {
            l: Ge(t, {
                r: t.r.l
            }),
            r: Ge(e, {
                l: t.r.r,
                lvl: r - 1
            }),
            lvl: r
        });
        throw new Error("Unexpected empty nodes")
    } else {
        if (ms(e)) return Ns(Ge(e, {
            lvl: r - 1
        }));
        if (!Re(o) && !Re(o.l)) {
            const s = o.l,
                i = ms(s) ? o.lvl - 1 : o.lvl;
            return Ge(s, {
                l: Ge(e, {
                    r: s.l,
                    lvl: r - 1
                }),
                r: Ns(Ge(o, {
                    l: s.r,
                    lvl: i
                })),
                lvl: s.lvl + 1
            })
        } else throw new Error("Unexpected empty nodes")
    }
}

function Qr(e, t, o) {
    if (Re(e)) return [];
    const r = Rt(e, t)[0];
    return Cx(Ls(e, r, o))
}

function xd(e, t) {
    const o = e.length;
    if (o === 0) return [];
    let {
        index: r,
        value: s
    } = t(e[0]);
    const i = [];
    for (let a = 1; a < o; a++) {
        const {
            index: l,
            value: c
        } = t(e[a]);
        i.push({
            start: r,
            end: l - 1,
            value: s
        }), r = l, s = c
    }
    return i.push({
        start: r,
        end: 1 / 0,
        value: s
    }), i
}

function Cx(e) {
    return xd(e, ({
        k: t,
        v: o
    }) => ({
        index: t,
        value: o
    }))
}

function Ns(e) {
    const {
        r: t,
        lvl: o
    } = e;
    return !Re(t) && !Re(t.r) && t.lvl === o && t.r.lvl === o ? Ge(t, {
        l: Ge(e, {
            r: t.l
        }),
        lvl: o + 1
    }) : e
}

function bd(e) {
    const {
        l: t
    } = e;
    return !Re(t) && t.lvl === e.lvl ? Ge(t, {
        r: Ge(e, {
            l: t.r
        })
    }) : e
}

function yr(e, t, o, r = 0) {
    let s = e.length - 1;
    for (; r <= s;) {
        const i = Math.floor((r + s) / 2),
            a = e[i],
            l = o(a, t);
        if (l === 0) return i;
        if (l === -1) {
            if (s - r < 2) return i - 1;
            s = i - 1
        } else {
            if (s === r) return i;
            r = i + 1
        }
    }
    throw new Error(`Failed binary finding record in array - ${e.join(",")}, searched for ${t}`)
}

function vd(e, t, o) {
    return e[yr(e, t, o)]
}

function kx(e, t, o, r) {
    const s = yr(e, t, r),
        i = yr(e, o, r, s);
    return e.slice(s, i + 1)
}
const Bi = Te(() => ({
    recalcInProgress: X(!1)
}), [], {
    singleton: !0
});

function Tx(e) {
    const {
        size: t,
        startIndex: o,
        endIndex: r
    } = e;
    return s => s.start === o && (s.end === r || s.end === 1 / 0) && s.value === t
}

function ml(e, t) {
    let o = 0,
        r = 0;
    for (; o < e;) o += t[r + 1] - t[r] - 1, r++;
    return r - (o === e ? 0 : 1)
}

function Ix(e, t) {
    let o = Re(e) ? 0 : 1 / 0;
    for (const r of t) {
        const {
            size: s,
            startIndex: i,
            endIndex: a
        } = r;
        if (o = Math.min(o, i), Re(e)) {
            e = xt(e, 0, s);
            continue
        }
        const l = Qr(e, i - 1, a + 1);
        if (l.some(Tx(r))) continue;
        let c = !1,
            d = !1;
        for (const {
                start: u,
                end: h,
                value: m
            } of l) c ? (a >= u || s === m) && (e = Ds(e, u)) : (d = m !== s, c = !0), h > a && a >= u && m !== s && (e = xt(e, a + 1, m));
        d && (e = xt(e, i, s))
    }
    return [e, o]
}

function Ax() {
    return {
        offsetTree: [],
        sizeTree: Ln(),
        groupOffsetTree: Ln(),
        lastIndex: 0,
        lastOffset: 0,
        lastSize: 0,
        groupIndices: []
    }
}

function Fi({
    index: e
}, t) {
    return t === e ? 0 : t < e ? -1 : 1
}

function Ex({
    offset: e
}, t) {
    return t === e ? 0 : t < e ? -1 : 1
}

function Px(e) {
    return {
        index: e.index,
        value: e
    }
}

function Rx(e, t, o, r = 0) {
    return r > 0 && (t = Math.max(t, vd(e, r, Fi).offset)), xd(kx(e, t, o, Ex), Px)
}

function Hs(e, t, o, r) {
    let s = e,
        i = 0,
        a = 0,
        l = 0,
        c = 0;
    if (t !== 0) {
        c = yr(s, t - 1, Fi), l = s[c].offset;
        const u = Rt(o, t - 1);
        i = u[0], a = u[1], s.length && s[c].size === Rt(o, t)[1] && (c -= 1), s = s.slice(0, c + 1)
    } else s = [];
    for (const {
            start: d,
            value: u
        } of Qr(o, t, 1 / 0)) {
        const h = d - i,
            m = h * a + l + h * r;
        s.push({
            offset: m,
            size: u,
            index: d
        }), i = d, l = m, a = u
    }
    return {
        offsetTree: s,
        lastIndex: i,
        lastOffset: l,
        lastSize: a
    }
}

function zx(e, [t, o, r, s]) {
    t.length > 0 && r("received item sizes", t, vt.DEBUG);
    const i = e.sizeTree;
    let a = i,
        l = 0;
    if (o.length > 0 && Re(i) && t.length === 2) {
        const m = t[0].size,
            g = t[1].size;
        a = o.reduce((p, b) => xt(xt(p, b, m), b + 1, g), a)
    } else [a, l] = Ix(a, t);
    if (a === i) return e;
    const {
        offsetTree: c,
        lastIndex: d,
        lastSize: u,
        lastOffset: h
    } = Hs(e.offsetTree, l, a, s);
    return {
        sizeTree: a,
        offsetTree: c,
        lastIndex: d,
        lastOffset: h,
        lastSize: u,
        groupOffsetTree: o.reduce((m, g) => xt(m, g, yo(g, c, s)), Ln()),
        groupIndices: o
    }
}

function yo(e, t, o) {
    if (t.length === 0) return 0;
    const {
        offset: r,
        index: s,
        size: i
    } = vd(t, e, Fi), a = e - s, l = i * a + (a - 1) * o + r;
    return l > 0 ? l + o : l
}

function Mx(e) {
    return typeof e.groupIndex < "u"
}

function yd(e, t, o) {
    if (Mx(e)) return t.groupIndices[e.groupIndex] + 1; {
        const r = e.index === "LAST" ? o : e.index;
        let s = jd(r, t);
        return s = Math.max(0, s, Math.min(o, s)), s
    }
}

function jd(e, t) {
    if (!$r(t)) return e;
    let o = 0;
    for (; t.groupIndices[o] <= e + o;) o++;
    return e + o
}

function $r(e) {
    return !Re(e.groupOffsetTree)
}

function Bx(e) {
    return jn(e).map(({
        k: t,
        v: o
    }, r, s) => {
        const i = s[r + 1],
            a = i ? i.k - 1 : 1 / 0;
        return {
            startIndex: t,
            endIndex: a,
            size: o
        }
    })
}
const Fx = {
        offsetHeight: "height",
        offsetWidth: "width"
    },
    Vt = Te(([{
        log: e
    }, {
        recalcInProgress: t
    }]) => {
        const o = ke(),
            r = ke(),
            s = it(r, 0),
            i = ke(),
            a = ke(),
            l = X(0),
            c = X([]),
            d = X(void 0),
            u = X(void 0),
            h = X((x, C) => Pt(x, Fx[C])),
            m = X(void 0),
            g = X(0),
            p = Ax(),
            b = it(_(o, Se(c, e, g), _t(zx, p), We()), p),
            j = it(_(c, We(), _t((x, C) => ({
                prev: x.current,
                current: C
            }), {
                prev: [],
                current: []
            }), $(({
                prev: x
            }) => x)), []);
        ae(_(c, ge(x => x.length > 0), Se(b, g), $(([x, C, E]) => {
            const R = x.reduce((B, A, P) => xt(B, A, yo(A, C.offsetTree, E) || P), Ln());
            return { ...C,
                groupIndices: x,
                groupOffsetTree: R
            }
        })), b), ae(_(r, Se(b), ge(([x, {
            lastIndex: C
        }]) => x < C), $(([x, {
            lastIndex: C,
            lastSize: E
        }]) => [{
            startIndex: x,
            endIndex: C,
            size: E
        }])), o), ae(d, u);
        const y = it(_(d, $(x => x === void 0)), !0);
        ae(_(u, ge(x => x !== void 0 && Re(st(b).sizeTree)), $(x => [{
            startIndex: 0,
            endIndex: 0,
            size: x
        }])), o);
        const S = bt(_(o, Se(b), _t(({
            sizes: x
        }, [C, E]) => ({
            changed: E !== x,
            sizes: E
        }), {
            changed: !1,
            sizes: p
        }), $(x => x.changed)));
        Ee(_(l, _t((x, C) => ({
            diff: x.prev - C,
            prev: C
        }), {
            diff: 0,
            prev: 0
        }), $(x => x.diff)), x => {
            const {
                groupIndices: C
            } = st(b);
            if (x > 0) ve(t, !0), ve(i, x + ml(x, C));
            else if (x < 0) {
                const E = st(j);
                E.length > 0 && (x -= ml(-x, E)), ve(a, x)
            }
        }), Ee(_(l, Se(e)), ([x, C]) => {
            x < 0 && C("`firstItemIndex` prop should not be set to less than zero. If you don't know the total count, just use a very high value", {
                firstItemIndex: l
            }, vt.ERROR)
        });
        const w = bt(i);
        ae(_(i, Se(b), $(([x, C]) => {
            const E = C.groupIndices.length > 0,
                R = [],
                B = C.lastSize;
            if (E) {
                const A = vo(C.sizeTree, 0);
                let P = 0,
                    D = 0;
                for (; P < x;) {
                    const z = C.groupIndices[D],
                        H = C.groupIndices.length === D + 1 ? 1 / 0 : C.groupIndices[D + 1] - z - 1;
                    R.push({
                        startIndex: z,
                        endIndex: z,
                        size: A
                    }), R.push({
                        startIndex: z + 1,
                        endIndex: z + 1 + H - 1,
                        size: B
                    }), D++, P += H + 1
                }
                const O = jn(C.sizeTree);
                return P !== x && O.shift(), O.reduce((z, {
                    k: H,
                    v: oe
                }) => {
                    let re = z.ranges;
                    return z.prevSize !== 0 && (re = [...z.ranges, {
                        startIndex: z.prevIndex,
                        endIndex: H + x - 1,
                        size: z.prevSize
                    }]), {
                        ranges: re,
                        prevIndex: H + x,
                        prevSize: oe
                    }
                }, {
                    ranges: R,
                    prevIndex: x,
                    prevSize: 0
                }).ranges
            }
            return jn(C.sizeTree).reduce((A, {
                k: P,
                v: D
            }) => ({
                ranges: [...A.ranges, {
                    startIndex: A.prevIndex,
                    endIndex: P + x - 1,
                    size: A.prevSize
                }],
                prevIndex: P + x,
                prevSize: D
            }), {
                ranges: [],
                prevIndex: 0,
                prevSize: B
            }).ranges
        })), o);
        const v = bt(_(a, Se(b, g), $(([x, {
            offsetTree: C
        }, E]) => {
            const R = -x;
            return yo(R, C, E)
        })));
        return ae(_(a, Se(b, g), $(([x, C, E]) => {
            if (C.groupIndices.length > 0) {
                if (Re(C.sizeTree)) return C;
                let B = Ln();
                const A = st(j);
                let P = 0,
                    D = 0,
                    O = 0;
                for (; P < -x;) {
                    O = A[D];
                    const z = A[D + 1] - O - 1;
                    D++, P += z + 1
                }
                if (B = jn(C.sizeTree).reduce((z, {
                        k: H,
                        v: oe
                    }) => xt(z, Math.max(0, H + x), oe), B), P !== -x) {
                    const z = vo(C.sizeTree, O);
                    B = xt(B, 0, z);
                    const H = Rt(C.sizeTree, -x + 1)[1];
                    B = xt(B, 1, H)
                }
                return { ...C,
                    sizeTree: B,
                    ...Hs(C.offsetTree, 0, B, E)
                }
            } else {
                const B = jn(C.sizeTree).reduce((A, {
                    k: P,
                    v: D
                }) => xt(A, Math.max(0, P + x), D), Ln());
                return { ...C,
                    sizeTree: B,
                    ...Hs(C.offsetTree, 0, B, E)
                }
            }
        })), b), {
            data: m,
            totalCount: r,
            sizeRanges: o,
            groupIndices: c,
            defaultItemSize: u,
            fixedItemSize: d,
            unshiftWith: i,
            shiftWith: a,
            shiftWithOffset: v,
            beforeUnshiftWith: w,
            firstItemIndex: l,
            gap: g,
            sizes: b,
            listRefresh: S,
            statefulTotalCount: s,
            trackItemSizes: y,
            itemSize: h
        }
    }, Le(hn, Bi), {
        singleton: !0
    }),
    Wx = typeof document < "u" && "scrollBehavior" in document.documentElement.style;

function Sd(e) {
    const t = typeof e == "number" ? {
        index: e
    } : e;
    return t.align || (t.align = "start"), (!t.behavior || !Wx) && (t.behavior = "auto"), t.offset || (t.offset = 0), t
}
const Mo = Te(([{
    sizes: e,
    totalCount: t,
    listRefresh: o,
    gap: r
}, {
    scrollingInProgress: s,
    viewportHeight: i,
    scrollTo: a,
    smoothScrollTargetReached: l,
    headerHeight: c,
    footerHeight: d,
    fixedHeaderHeight: u,
    fixedFooterHeight: h
}, {
    log: m
}]) => {
    const g = ke(),
        p = ke(),
        b = X(0);
    let j = null,
        y = null,
        S = null;

    function w() {
        j && (j(), j = null), S && (S(), S = null), y && (clearTimeout(y), y = null), ve(s, !1)
    }
    return ae(_(g, Se(e, i, t, b, c, d, m), Se(r, u, h), $(([
        [v, x, C, E, R, B, A, P], D, O, V
    ]) => {
        const z = Sd(v),
            {
                align: H,
                behavior: oe,
                offset: re
            } = z,
            ye = E - 1,
            fe = yd(z, x, ye);
        let je = yo(fe, x.offsetTree, D) + B;
        H === "end" ? (je += O + Rt(x.sizeTree, fe)[1] - C + V, fe === ye && (je += A)) : H === "center" ? je += (O + Rt(x.sizeTree, fe)[1] - C + V) / 2 : je -= R, re && (je += re);
        const ze = Me => {
            w(), Me ? (P("retrying to scroll to", {
                location: v
            }, vt.DEBUG), ve(g, v)) : (ve(p, !0), P("list did not change, scroll successful", {}, vt.DEBUG))
        };
        if (w(), oe === "smooth") {
            let Me = !1;
            S = Ee(o, Fe => {
                Me = Me || Fe
            }), j = Ot(l, () => {
                ze(Me)
            })
        } else j = Ot(_(o, Dx(150)), ze);
        return y = setTimeout(() => {
            w()
        }, 1200), ve(s, !0), P("scrolling from index to", {
            index: fe,
            top: je,
            behavior: oe
        }, vt.DEBUG), {
            top: je,
            behavior: oe
        }
    })), a), {
        scrollToIndex: g,
        scrollTargetReached: p,
        topListHeight: b
    }
}, Le(Vt, ft, hn), {
    singleton: !0
});

function Dx(e) {
    return t => {
        const o = setTimeout(() => {
            t(!1)
        }, e);
        return r => {
            r && (t(!0), clearTimeout(o))
        }
    }
}
const jo = "up",
    ao = "down",
    Lx = "none",
    Nx = {
        atBottom: !1,
        notAtBottomBecause: "NOT_SHOWING_LAST_ITEM",
        state: {
            offsetBottom: 0,
            scrollTop: 0,
            viewportHeight: 0,
            scrollHeight: 0
        }
    },
    Hx = 0,
    Bo = Te(([{
        scrollContainerState: e,
        scrollTop: t,
        viewportHeight: o,
        headerHeight: r,
        footerHeight: s,
        scrollBy: i
    }]) => {
        const a = X(!1),
            l = X(!0),
            c = ke(),
            d = ke(),
            u = X(4),
            h = X(Hx),
            m = it(_(fl(_(me(t), Vn(1), Ft(!0)), _(me(t), Vn(1), Ft(!1), hl(100))), We()), !1),
            g = it(_(fl(_(i, Ft(!0)), _(i, Ft(!1), hl(200))), We()), !1);
        ae(_($e(me(t), me(h)), $(([S, w]) => S <= w), We()), l), ae(_(l, sn(50)), d);
        const p = bt(_($e(e, me(o), me(r), me(s), me(u)), _t((S, [{
                scrollTop: w,
                scrollHeight: v
            }, x, C, E, R]) => {
                const B = w + x - v > -R,
                    A = {
                        viewportHeight: x,
                        scrollTop: w,
                        scrollHeight: v
                    };
                if (B) {
                    let D, O;
                    return w > S.state.scrollTop ? (D = "SCROLLED_DOWN", O = S.state.scrollTop - w) : (D = "SIZE_DECREASED", O = S.state.scrollTop - w || S.scrollTopDelta), {
                        atBottom: !0,
                        state: A,
                        atBottomBecause: D,
                        scrollTopDelta: O
                    }
                }
                let P;
                return A.scrollHeight > S.state.scrollHeight ? P = "SIZE_INCREASED" : x < S.state.viewportHeight ? P = "VIEWPORT_HEIGHT_DECREASING" : w < S.state.scrollTop ? P = "SCROLLING_UPWARDS" : P = "NOT_FULLY_SCROLLED_TO_LAST_ITEM_BOTTOM", {
                    atBottom: !1,
                    notAtBottomBecause: P,
                    state: A
                }
            }, Nx), We((S, w) => S && S.atBottom === w.atBottom))),
            b = it(_(e, _t((S, {
                scrollTop: w,
                scrollHeight: v,
                viewportHeight: x
            }) => {
                if (hd(S.scrollHeight, v)) return {
                    scrollTop: w,
                    scrollHeight: v,
                    jump: 0,
                    changed: !1
                }; {
                    const C = v - (w + x) < 1;
                    return S.scrollTop !== w && C ? {
                        scrollHeight: v,
                        scrollTop: w,
                        jump: S.scrollTop - w,
                        changed: !0
                    } : {
                        scrollHeight: v,
                        scrollTop: w,
                        jump: 0,
                        changed: !0
                    }
                }
            }, {
                scrollHeight: 0,
                jump: 0,
                scrollTop: 0,
                changed: !1
            }), ge(S => S.changed), $(S => S.jump)), 0);
        ae(_(p, $(S => S.atBottom)), a), ae(_(a, sn(50)), c);
        const j = X(ao);
        ae(_(e, $(({
            scrollTop: S
        }) => S), We(), _t((S, w) => st(g) ? {
            direction: S.direction,
            prevScrollTop: w
        } : {
            direction: w < S.prevScrollTop ? jo : ao,
            prevScrollTop: w
        }, {
            direction: ao,
            prevScrollTop: 0
        }), $(S => S.direction)), j), ae(_(e, sn(50), Ft(Lx)), j);
        const y = X(0);
        return ae(_(m, ge(S => !S), Ft(0)), y), ae(_(t, sn(100), Se(m), ge(([S, w]) => !!w), _t(([S, w], [v]) => [w, v], [0, 0]), $(([S, w]) => w - S)), y), {
            isScrolling: m,
            isAtTop: l,
            isAtBottom: a,
            atBottomState: p,
            atTopStateChange: d,
            atBottomStateChange: c,
            scrollDirection: j,
            atBottomThreshold: u,
            atTopThreshold: h,
            scrollVelocity: y,
            lastJumpDueToItemResize: b
        }
    }, Le(ft)),
    fn = Te(([{
        log: e
    }]) => {
        const t = X(!1),
            o = bt(_(t, ge(r => r), We()));
        return Ee(t, r => {
            r && st(e)("props updated", {}, vt.DEBUG)
        }), {
            propsReady: t,
            didMount: o
        }
    }, Le(hn), {
        singleton: !0
    });

function Wi(e, t) {
    e == 0 ? t() : requestAnimationFrame(() => Wi(e - 1, t))
}

function Di(e, t) {
    const o = t - 1;
    return typeof e == "number" ? e : e.index === "LAST" ? o : e.index
}
const Fo = Te(([{
    sizes: e,
    listRefresh: t,
    defaultItemSize: o
}, {
    scrollTop: r
}, {
    scrollToIndex: s,
    scrollTargetReached: i
}, {
    didMount: a
}]) => {
    const l = X(!0),
        c = X(0),
        d = X(!0);
    return ae(_(a, Se(c), ge(([u, h]) => !!h), Ft(!1)), l), ae(_(a, Se(c), ge(([u, h]) => !!h), Ft(!1)), d), Ee(_($e(t, a), Se(l, e, o, d), ge(([
        [, u], h, {
            sizeTree: m
        },
        g, p
    ]) => u && (!Re(m) || Pi(g)) && !h && !p), Se(c)), ([, u]) => {
        Ot(i, () => {
            ve(d, !0)
        }), Wi(4, () => {
            Ot(r, () => {
                ve(l, !0)
            }), ve(s, u)
        })
    }), {
        scrolledToInitialItem: l,
        initialTopMostItemIndex: c,
        initialItemFinalLocationReached: d
    }
}, Le(Vt, ft, Mo, fn), {
    singleton: !0
});

function pl(e) {
    return e ? e === "smooth" ? "smooth" : "auto" : !1
}
const _x = (e, t) => typeof e == "function" ? pl(e(t)) : t && pl(e),
    Ox = Te(([{
        totalCount: e,
        listRefresh: t
    }, {
        isAtBottom: o,
        atBottomState: r
    }, {
        scrollToIndex: s
    }, {
        scrolledToInitialItem: i
    }, {
        propsReady: a,
        didMount: l
    }, {
        log: c
    }, {
        scrollingInProgress: d
    }]) => {
        const u = X(!1),
            h = ke();
        let m = null;

        function g(b) {
            ve(s, {
                index: "LAST",
                align: "end",
                behavior: b
            })
        }
        Ee(_($e(_(me(e), Vn(1)), l), Se(me(u), o, i, d), $(([
            [b, j], y, S, w, v
        ]) => {
            let x = j && w,
                C = "auto";
            return x && (C = _x(y, S || v), x = x && !!C), {
                totalCount: b,
                shouldFollow: x,
                followOutputBehavior: C
            }
        }), ge(({
            shouldFollow: b
        }) => b)), ({
            totalCount: b,
            followOutputBehavior: j
        }) => {
            m && (m(), m = null), m = Ot(t, () => {
                st(c)("following output to ", {
                    totalCount: b
                }, vt.DEBUG), g(j), m = null
            })
        });

        function p(b) {
            const j = Ot(r, y => {
                b && !y.atBottom && y.notAtBottomBecause === "SIZE_INCREASED" && !m && (st(c)("scrolling to bottom due to increased size", {}, vt.DEBUG), g("auto"))
            });
            setTimeout(j, 100)
        }
        return Ee(_($e(me(u), e, a), ge(([b, , j]) => b && j), _t(({
            value: b
        }, [, j]) => ({
            refreshed: b === j,
            value: j
        }), {
            refreshed: !1,
            value: 0
        }), ge(({
            refreshed: b
        }) => b), Se(u, e)), ([, b]) => {
            st(i) && p(b !== !1)
        }), Ee(h, () => {
            p(st(u) !== !1)
        }), Ee($e(me(u), r), ([b, j]) => {
            b && !j.atBottom && j.notAtBottomBecause === "VIEWPORT_HEIGHT_DECREASING" && g("auto")
        }), {
            followOutput: u,
            autoscrollToBottom: h
        }
    }, Le(Vt, Bo, Mo, Fo, fn, hn, ft));

function Ux(e) {
    return e.reduce((t, o) => (t.groupIndices.push(t.totalCount), t.totalCount += o + 1, t), {
        totalCount: 0,
        groupIndices: []
    })
}
const wd = Te(([{
    totalCount: e,
    groupIndices: t,
    sizes: o
}, {
    scrollTop: r,
    headerHeight: s
}]) => {
    const i = ke(),
        a = ke(),
        l = bt(_(i, $(Ux)));
    return ae(_(l, $(c => c.totalCount)), e), ae(_(l, $(c => c.groupIndices)), t), ae(_($e(r, o, s), ge(([c, d]) => $r(d)), $(([c, d, u]) => Rt(d.groupOffsetTree, Math.max(c - u, 0), "v")[0]), We(), $(c => [c])), a), {
        groupCounts: i,
        topItemsIndexes: a
    }
}, Le(Vt, ft));

function So(e, t) {
    return !!(e && e[0] === t[0] && e[1] === t[1])
}

function Cd(e, t) {
    return !!(e && e.startIndex === t.startIndex && e.endIndex === t.endIndex)
}
const jr = "top",
    Sr = "bottom",
    xl = "none";

function bl(e, t, o) {
    return typeof e == "number" ? o === jo && t === jr || o === ao && t === Sr ? e : 0 : o === jo ? t === jr ? e.main : e.reverse : t === Sr ? e.main : e.reverse
}

function vl(e, t) {
    return typeof e == "number" ? e : e[t] || 0
}
const Li = Te(([{
    scrollTop: e,
    viewportHeight: t,
    deviation: o,
    headerHeight: r,
    fixedHeaderHeight: s
}]) => {
    const i = ke(),
        a = X(0),
        l = X(0),
        c = X(0),
        d = it(_($e(me(e), me(t), me(r), me(i, So), me(c), me(a), me(s), me(o), me(l)), $(([u, h, m, [g, p], b, j, y, S, w]) => {
            const v = u - S,
                x = j + y,
                C = Math.max(m - v, 0);
            let E = xl;
            const R = vl(w, jr),
                B = vl(w, Sr);
            return g -= S, g += m + y, p += m + y, p -= S, g > u + x - R && (E = jo), p < u - C + h + B && (E = ao), E !== xl ? [Math.max(v - m - bl(b, jr, E) - R, 0), v - C - y + h + bl(b, Sr, E) + B] : null
        }), ge(u => u != null), We(So)), [0, 0]);
    return {
        listBoundary: i,
        overscan: c,
        topListHeight: a,
        increaseViewportBy: l,
        visibleRange: d
    }
}, Le(ft), {
    singleton: !0
});

function Vx(e, t, o) {
    if ($r(t)) {
        const r = jd(e, t);
        return [{
            index: Rt(t.groupOffsetTree, r)[0],
            size: 0,
            offset: 0
        }, {
            index: r,
            size: 0,
            offset: 0,
            data: o && o[0]
        }]
    }
    return [{
        index: e,
        size: 0,
        offset: 0,
        data: o && o[0]
    }]
}
const ps = {
    items: [],
    topItems: [],
    offsetTop: 0,
    offsetBottom: 0,
    top: 0,
    bottom: 0,
    topListHeight: 0,
    totalCount: 0,
    firstItemIndex: 0
};

function yl(e, t, o) {
    if (e.length === 0) return [];
    if (!$r(t)) return e.map(d => ({ ...d,
        index: d.index + o,
        originalIndex: d.index
    }));
    const r = e[0].index,
        s = e[e.length - 1].index,
        i = [],
        a = Qr(t.groupOffsetTree, r, s);
    let l, c = 0;
    for (const d of e) {
        (!l || l.end < d.index) && (l = a.shift(), c = t.groupIndices.indexOf(l.start));
        let u;
        d.index === l.start ? u = {
            type: "group",
            index: c
        } : u = {
            index: d.index - (c + 1) + o,
            groupIndex: c
        }, i.push({ ...u,
            size: d.size,
            offset: d.offset,
            originalIndex: d.index,
            data: d.data
        })
    }
    return i
}

function ar(e, t, o, r, s, i) {
    const {
        lastSize: a,
        lastOffset: l,
        lastIndex: c
    } = s;
    let d = 0,
        u = 0;
    if (e.length > 0) {
        d = e[0].offset;
        const b = e[e.length - 1];
        u = b.offset + b.size
    }
    const h = o - c,
        m = l + h * a + (h - 1) * r,
        g = d,
        p = m - u;
    return {
        items: yl(e, s, i),
        topItems: yl(t, s, i),
        topListHeight: t.reduce((b, j) => j.size + b, 0),
        offsetTop: d,
        offsetBottom: p,
        top: g,
        bottom: u,
        totalCount: o,
        firstItemIndex: i
    }
}

function kd(e, t, o, r, s, i) {
    let a = 0;
    if (o.groupIndices.length > 0)
        for (const u of o.groupIndices) {
            if (u - a >= e) break;
            a++
        }
    const l = e + a,
        c = Di(t, l),
        d = Array.from({
            length: l
        }).map((u, h) => ({
            index: h + c,
            size: 0,
            offset: 0,
            data: i[h + c]
        }));
    return ar(d, [], l, s, o, r)
}
const En = Te(([{
        sizes: e,
        totalCount: t,
        data: o,
        firstItemIndex: r,
        gap: s
    }, i, {
        visibleRange: a,
        listBoundary: l,
        topListHeight: c
    }, {
        scrolledToInitialItem: d,
        initialTopMostItemIndex: u
    }, {
        topListHeight: h
    }, m, {
        didMount: g
    }, {
        recalcInProgress: p
    }]) => {
        const b = X([]),
            j = X(0),
            y = ke();
        ae(i.topItemsIndexes, b);
        const S = it(_($e(g, p, me(a, So), me(t), me(e), me(u), d, me(b), me(r), me(s), o), ge(([C, E, , R, , , , , , , B]) => {
            const A = B && B.length !== R;
            return C && !E && !A
        }), $(([, , [C, E], R, B, A, P, D, O, V, z]) => {
            const H = B,
                {
                    sizeTree: oe,
                    offsetTree: re
                } = H,
                ye = st(j);
            if (R === 0) return { ...ps,
                totalCount: R
            };
            if (C === 0 && E === 0) return ye === 0 ? { ...ps,
                totalCount: R
            } : kd(ye, A, B, O, V, z || []);
            if (Re(oe)) return ye > 0 ? null : ar(Vx(Di(A, R), H, z), [], R, V, H, O);
            const fe = [];
            if (D.length > 0) {
                const Be = D[0],
                    W = D[D.length - 1];
                let se = 0;
                for (const J of Qr(oe, Be, W)) {
                    const de = J.value,
                        ie = Math.max(J.start, Be),
                        U = Math.min(J.end, W);
                    for (let F = ie; F <= U; F++) fe.push({
                        index: F,
                        size: de,
                        offset: se,
                        data: z && z[F]
                    }), se += de
                }
            }
            if (!P) return ar([], fe, R, V, H, O);
            const je = D.length > 0 ? D[D.length - 1] + 1 : 0,
                ze = Rx(re, C, E, je);
            if (ze.length === 0) return null;
            const Me = R - 1,
                Fe = Kr([], Be => {
                    for (const W of ze) {
                        const se = W.value;
                        let J = se.offset,
                            de = W.start;
                        const ie = se.size;
                        if (se.offset < C) {
                            de += Math.floor((C - se.offset + V) / (ie + V));
                            const F = de - W.start;
                            J += F * ie + F * V
                        }
                        de < je && (J += (je - de) * ie, de = je);
                        const U = Math.min(W.end, Me);
                        for (let F = de; F <= U && !(J >= E); F++) Be.push({
                            index: F,
                            size: ie,
                            offset: J,
                            data: z && z[F]
                        }), J += ie + V
                    }
                });
            return ar(Fe, fe, R, V, H, O)
        }), ge(C => C !== null), We()), ps);
        ae(_(o, ge(Pi), $(C => C == null ? void 0 : C.length)), t), ae(_(S, $(C => C.topListHeight)), h), ae(h, c), ae(_(S, $(C => [C.top, C.bottom])), l), ae(_(S, $(C => C.items)), y);
        const w = bt(_(S, ge(({
                items: C
            }) => C.length > 0), Se(t, o), ge(([{
                items: C
            }, E]) => C[C.length - 1].originalIndex === E - 1), $(([, C, E]) => [C - 1, E]), We(So), $(([C]) => C))),
            v = bt(_(S, sn(200), ge(({
                items: C,
                topItems: E
            }) => C.length > 0 && C[0].originalIndex === E.length), $(({
                items: C
            }) => C[0].index), We())),
            x = bt(_(S, ge(({
                items: C
            }) => C.length > 0), $(({
                items: C
            }) => {
                let E = 0,
                    R = C.length - 1;
                for (; C[E].type === "group" && E < R;) E++;
                for (; C[R].type === "group" && R > E;) R--;
                return {
                    startIndex: C[E].index,
                    endIndex: C[R].index
                }
            }), We(Cd)));
        return {
            listState: S,
            topItemsIndexes: b,
            endReached: w,
            startReached: v,
            rangeChanged: x,
            itemsRendered: y,
            initialItemCount: j,
            ...m
        }
    }, Le(Vt, wd, Li, Fo, Mo, Bo, fn, Bi), {
        singleton: !0
    }),
    Xx = Te(([{
        sizes: e,
        firstItemIndex: t,
        data: o,
        gap: r
    }, {
        initialTopMostItemIndex: s
    }, {
        initialItemCount: i,
        listState: a
    }, {
        didMount: l
    }]) => (ae(_(l, Se(i), ge(([, c]) => c !== 0), Se(s, e, t, r, o), $(([
        [, c], d, u, h, m, g = []
    ]) => kd(c, d, u, h, m, g))), a), {}), Le(Vt, Fo, En, fn), {
        singleton: !0
    }),
    Td = Te(([{
        scrollVelocity: e
    }]) => {
        const t = X(!1),
            o = ke(),
            r = X(!1);
        return ae(_(e, Se(r, t, o), ge(([s, i]) => !!i), $(([s, i, a, l]) => {
            const {
                exit: c,
                enter: d
            } = i;
            if (a) {
                if (c(s, l)) return !1
            } else if (d(s, l)) return !0;
            return a
        }), We()), t), Ee(_($e(t, e, o), Se(r)), ([
            [s, i, a], l
        ]) => s && l && l.change && l.change(i, a)), {
            isSeeking: t,
            scrollSeekConfiguration: r,
            scrollVelocity: e,
            scrollSeekRangeChanged: o
        }
    }, Le(Bo), {
        singleton: !0
    }),
    qx = Te(([{
        topItemsIndexes: e
    }]) => {
        const t = X(0);
        return ae(_(t, ge(o => o > 0), $(o => Array.from({
            length: o
        }).map((r, s) => s))), e), {
            topItemCount: t
        }
    }, Le(En)),
    Id = Te(([{
        footerHeight: e,
        headerHeight: t,
        fixedHeaderHeight: o,
        fixedFooterHeight: r
    }, {
        listState: s
    }]) => {
        const i = ke(),
            a = it(_($e(e, r, t, o, s), $(([l, c, d, u, h]) => l + c + d + u + h.offsetBottom + h.bottom)), 0);
        return ae(me(a), i), {
            totalListHeight: a,
            totalListHeightChanged: i
        }
    }, Le(ft, En), {
        singleton: !0
    });

function Ad(e) {
    let t = !1,
        o;
    return () => (t || (t = !0, o = e()), o)
}
const Gx = Ad(() => /iP(ad|od|hone)/i.test(navigator.userAgent) && /WebKit/i.test(navigator.userAgent)),
    Kx = Te(([{
        scrollBy: e,
        scrollTop: t,
        deviation: o,
        scrollingInProgress: r
    }, {
        isScrolling: s,
        isAtBottom: i,
        scrollDirection: a,
        lastJumpDueToItemResize: l
    }, {
        listState: c
    }, {
        beforeUnshiftWith: d,
        shiftWithOffset: u,
        sizes: h,
        gap: m
    }, {
        log: g
    }, {
        recalcInProgress: p
    }]) => {
        const b = bt(_(c, Se(l), _t(([, y, S, w], [{
            items: v,
            totalCount: x,
            bottom: C,
            offsetBottom: E
        }, R]) => {
            const B = C + E;
            let A = 0;
            return S === x && y.length > 0 && v.length > 0 && (v[0].originalIndex === 0 && y[0].originalIndex === 0 || (A = B - w, A !== 0 && (A += R))), [A, v, x, B]
        }, [0, [], 0, 0]), ge(([y]) => y !== 0), Se(t, a, r, i, g, p), ge(([, y, S, w, , , v]) => !v && !w && y !== 0 && S === jo), $(([
            [y], , , , , S
        ]) => (S("Upward scrolling compensation", {
            amount: y
        }, vt.DEBUG), y))));

        function j(y) {
            y > 0 ? (ve(e, {
                top: -y,
                behavior: "auto"
            }), ve(o, 0)) : (ve(o, 0), ve(e, {
                top: -y,
                behavior: "auto"
            }))
        }
        return Ee(_(b, Se(o, s)), ([y, S, w]) => {
            w && Gx() ? ve(o, S - y) : j(-y)
        }), Ee(_($e(it(s, !1), o, p), ge(([y, S, w]) => !y && !w && S !== 0), $(([y, S]) => S), sn(1)), j), ae(_(u, $(y => ({
            top: -y
        }))), e), Ee(_(d, Se(h, m), $(([y, {
            lastSize: S,
            groupIndices: w,
            sizeTree: v
        }, x]) => {
            function C(E) {
                return E * (S + x)
            }
            if (w.length === 0) return C(y); {
                let E = 0;
                const R = vo(v, 0);
                let B = 0,
                    A = 0;
                for (; B < y;) {
                    B++, E += R;
                    let P = w.length === A + 1 ? 1 / 0 : w[A + 1] - w[A] - 1;
                    B + P > y && (E -= R, P = y - B + 1), B += P, E += C(P), A++
                }
                return E
            }
        })), y => {
            ve(o, y), requestAnimationFrame(() => {
                ve(e, {
                    top: y
                }), requestAnimationFrame(() => {
                    ve(o, 0), ve(p, !1)
                })
            })
        }), {
            deviation: o
        }
    }, Le(ft, Bo, En, Vt, hn, Bi)),
    Qx = Te(([{
        didMount: e
    }, {
        scrollTo: t
    }, {
        listState: o
    }]) => {
        const r = X(0);
        return Ee(_(e, Se(r), ge(([, s]) => s !== 0), $(([, s]) => ({
            top: s
        }))), s => {
            Ot(_(o, Vn(1), ge(i => i.items.length > 1)), () => {
                requestAnimationFrame(() => {
                    ve(t, s)
                })
            })
        }), {
            initialScrollTop: r
        }
    }, Le(fn, ft, En), {
        singleton: !0
    }),
    $x = Te(([{
        viewportHeight: e
    }, {
        totalListHeight: t
    }]) => {
        const o = X(!1),
            r = it(_($e(o, e, t), ge(([s]) => s), $(([, s, i]) => Math.max(0, s - i)), sn(0), We()), 0);
        return {
            alignToBottom: o,
            paddingTopAddition: r
        }
    }, Le(ft, Id), {
        singleton: !0
    }),
    Ni = Te(([{
        scrollTo: e,
        scrollContainerState: t
    }]) => {
        const o = ke(),
            r = ke(),
            s = ke(),
            i = X(!1),
            a = X(void 0);
        return ae(_($e(o, r), $(([{
            viewportHeight: l,
            scrollTop: c,
            scrollHeight: d
        }, {
            offsetTop: u
        }]) => ({
            scrollTop: Math.max(0, c - u),
            scrollHeight: d,
            viewportHeight: l
        }))), t), ae(_(e, Se(r), $(([l, {
            offsetTop: c
        }]) => ({ ...l,
            top: l.top + c
        }))), s), {
            useWindowScroll: i,
            customScrollParent: a,
            windowScrollContainerState: o,
            windowViewportRect: r,
            windowScrollTo: s
        }
    }, Le(ft)),
    Yx = ({
        itemTop: e,
        itemBottom: t,
        viewportTop: o,
        viewportBottom: r,
        locationParams: {
            behavior: s,
            align: i,
            ...a
        }
    }) => e < o ? { ...a,
        behavior: s,
        align: i ? ? "start"
    } : t > r ? { ...a,
        behavior: s,
        align: i ? ? "end"
    } : null,
    Zx = Te(([{
        sizes: e,
        totalCount: t,
        gap: o
    }, {
        scrollTop: r,
        viewportHeight: s,
        headerHeight: i,
        fixedHeaderHeight: a,
        fixedFooterHeight: l,
        scrollingInProgress: c
    }, {
        scrollToIndex: d
    }]) => {
        const u = ke();
        return ae(_(u, Se(e, s, t, i, a, l, r), Se(o), $(([
            [h, m, g, p, b, j, y, S], w
        ]) => {
            const {
                done: v,
                behavior: x,
                align: C,
                calculateViewLocation: E = Yx,
                ...R
            } = h, B = yd(h, m, p - 1), A = yo(B, m.offsetTree, w) + b + j, P = A + Rt(m.sizeTree, B)[1], D = S + j, O = S + g - y, V = E({
                itemTop: A,
                itemBottom: P,
                viewportTop: D,
                viewportBottom: O,
                locationParams: {
                    behavior: x,
                    align: C,
                    ...R
                }
            });
            return V ? v && Ot(_(c, ge(z => z === !1), Vn(st(c) ? 1 : 2)), v) : v && v(), V
        }), ge(h => h !== null)), d), {
            scrollIntoView: u
        }
    }, Le(Vt, ft, Mo, En, hn), {
        singleton: !0
    }),
    Jx = Te(([{
        sizes: e,
        sizeRanges: t
    }, {
        scrollTop: o
    }, {
        initialTopMostItemIndex: r
    }, {
        didMount: s
    }, {
        useWindowScroll: i,
        windowScrollContainerState: a,
        windowViewportRect: l
    }]) => {
        const c = ke(),
            d = X(void 0),
            u = X(null),
            h = X(null);
        return ae(a, u), ae(l, h), Ee(_(c, Se(e, o, i, u, h)), ([m, g, p, b, j, y]) => {
            const S = Bx(g.sizeTree);
            b && j !== null && y !== null && (p = j.scrollTop - y.offsetTop), m({
                ranges: S,
                scrollTop: p
            })
        }), ae(_(d, ge(Pi), $(e1)), r), ae(_(s, Se(d), ge(([, m]) => m !== void 0), We(), $(([, m]) => m.ranges)), t), {
            getState: c,
            restoreStateFrom: d
        }
    }, Le(Vt, ft, Fo, fn, Ni));

function e1(e) {
    return {
        offset: e.scrollTop,
        index: 0,
        align: "start"
    }
}
const t1 = Te(([e, t, o, r, s, i, a, l, c, d]) => ({ ...e,
        ...t,
        ...o,
        ...r,
        ...s,
        ...i,
        ...a,
        ...l,
        ...c,
        ...d
    }), Le(Li, Xx, fn, Td, Id, Qx, $x, Ni, Zx, hn)),
    Ed = Te(([{
        totalCount: e,
        sizeRanges: t,
        fixedItemSize: o,
        defaultItemSize: r,
        trackItemSizes: s,
        itemSize: i,
        data: a,
        firstItemIndex: l,
        groupIndices: c,
        statefulTotalCount: d,
        gap: u,
        sizes: h
    }, {
        initialTopMostItemIndex: m,
        scrolledToInitialItem: g,
        initialItemFinalLocationReached: p
    }, b, j, y, {
        listState: S,
        topItemsIndexes: w,
        ...v
    }, {
        scrollToIndex: x
    }, C, {
        topItemCount: E
    }, {
        groupCounts: R
    }, B]) => (ae(v.rangeChanged, B.scrollSeekRangeChanged), ae(_(B.windowViewportRect, $(A => A.visibleHeight)), b.viewportHeight), {
        totalCount: e,
        data: a,
        firstItemIndex: l,
        sizeRanges: t,
        initialTopMostItemIndex: m,
        scrolledToInitialItem: g,
        initialItemFinalLocationReached: p,
        topItemsIndexes: w,
        topItemCount: E,
        groupCounts: R,
        fixedItemHeight: o,
        defaultItemHeight: r,
        gap: u,
        ...y,
        statefulTotalCount: d,
        listState: S,
        scrollToIndex: x,
        trackItemSizes: s,
        itemSize: i,
        groupIndices: c,
        ...v,
        ...B,
        ...b,
        sizes: h,
        ...j
    }), Le(Vt, Fo, ft, Jx, Ox, En, Mo, Kx, qx, wd, t1)),
    xs = "-webkit-sticky",
    jl = "sticky",
    Pd = Ad(() => {
        if (typeof document > "u") return jl;
        const e = document.createElement("div");
        return e.style.position = xs, e.style.position === xs ? xs : jl
    });

function Hi(e, t) {
    const o = M.useRef(null),
        r = M.useCallback(l => {
            if (l === null || !l.offsetParent) return;
            const c = l.getBoundingClientRect(),
                d = c.width;
            let u, h;
            if (t) {
                const m = t.getBoundingClientRect(),
                    g = c.top - m.top;
                u = m.height - Math.max(0, g), h = g + t.scrollTop
            } else u = window.innerHeight - Math.max(0, c.top), h = c.top + window.pageYOffset;
            o.current = {
                offsetTop: h,
                visibleHeight: u,
                visibleWidth: d
            }, e(o.current)
        }, [e, t]),
        {
            callbackRef: s,
            ref: i
        } = Mi(r),
        a = M.useCallback(() => {
            r(i.current)
        }, [r, i]);
    return M.useEffect(() => {
        if (t) {
            t.addEventListener("scroll", a);
            const l = new ResizeObserver(() => {
                requestAnimationFrame(a)
            });
            return l.observe(t), () => {
                t.removeEventListener("scroll", a), l.unobserve(t)
            }
        } else return window.addEventListener("scroll", a), window.addEventListener("resize", a), () => {
            window.removeEventListener("scroll", a), window.removeEventListener("resize", a)
        }
    }, [a, t]), s
}
const Yr = M.createContext(void 0),
    Rd = M.createContext(void 0);

function _i(e) {
    return e
}
const n1 = Te(() => {
        const e = X(c => `Item ${c}`),
            t = X(null),
            o = X(c => `Group ${c}`),
            r = X({}),
            s = X(_i),
            i = X("div"),
            a = X(An),
            l = (c, d = null) => it(_(r, $(u => u[c]), We()), d);
        return {
            context: t,
            itemContent: e,
            groupContent: o,
            components: r,
            computeItemKey: s,
            headerFooterTag: i,
            scrollerRef: a,
            FooterComponent: l("Footer"),
            HeaderComponent: l("Header"),
            TopItemListComponent: l("TopItemList"),
            ListComponent: l("List", "div"),
            ItemComponent: l("Item", "div"),
            GroupComponent: l("Group", "div"),
            ScrollerComponent: l("Scroller", "div"),
            EmptyPlaceholder: l("EmptyPlaceholder"),
            ScrollSeekPlaceholder: l("ScrollSeekPlaceholder")
        }
    }),
    o1 = Te(([e, t]) => ({ ...e,
        ...t
    }), Le(Ed, n1)),
    r1 = ({
        height: e
    }) => M.createElement("div", {
        style: {
            height: e
        }
    }),
    s1 = {
        position: Pd(),
        zIndex: 1,
        overflowAnchor: "none"
    },
    i1 = {
        overflowAnchor: "none"
    },
    Sl = M.memo(function({
        showTopList: t = !1
    }) {
        const o = Ce("listState"),
            r = wt("sizeRanges"),
            s = Ce("useWindowScroll"),
            i = Ce("customScrollParent"),
            a = wt("windowScrollContainerState"),
            l = wt("scrollContainerState"),
            c = i || s ? a : l,
            d = Ce("itemContent"),
            u = Ce("context"),
            h = Ce("groupContent"),
            m = Ce("trackItemSizes"),
            g = Ce("itemSize"),
            p = Ce("log"),
            b = wt("gap"),
            {
                callbackRef: j
            } = ud(r, g, m, t ? An : c, p, b, i),
            [y, S] = M.useState(0);
        Vi("deviation", V => {
            y !== V && S(V)
        });
        const w = Ce("EmptyPlaceholder"),
            v = Ce("ScrollSeekPlaceholder") || r1,
            x = Ce("ListComponent"),
            C = Ce("ItemComponent"),
            E = Ce("GroupComponent"),
            R = Ce("computeItemKey"),
            B = Ce("isSeeking"),
            A = Ce("groupIndices").length > 0,
            P = Ce("alignToBottom"),
            D = Ce("initialItemFinalLocationReached"),
            O = t ? {} : {
                boxSizing: "border-box",
                paddingTop: o.offsetTop,
                paddingBottom: o.offsetBottom,
                marginTop: y !== 0 ? y : P ? "auto" : 0,
                ...D ? {} : {
                    visibility: "hidden"
                }
            };
        return !t && o.totalCount === 0 && w ? M.createElement(w, Oe(w, u)) : M.createElement(x, { ...Oe(x, u),
            ref: j,
            style: O,
            "data-testid": t ? "virtuoso-top-item-list" : "virtuoso-item-list"
        }, (t ? o.topItems : o.items).map(V => {
            const z = V.originalIndex,
                H = R(z + o.firstItemIndex, V.data, u);
            return B ? M.createElement(v, { ...Oe(v, u),
                key: H,
                index: V.index,
                height: V.size,
                type: V.type || "item",
                ...V.type === "group" ? {} : {
                    groupIndex: V.groupIndex
                }
            }) : V.type === "group" ? M.createElement(E, { ...Oe(E, u),
                key: H,
                "data-index": z,
                "data-known-size": V.size,
                "data-item-index": V.index,
                style: s1
            }, h(V.index, u)) : M.createElement(C, { ...Oe(C, u),
                ...zd(C, V.data),
                key: H,
                "data-index": z,
                "data-known-size": V.size,
                "data-item-index": V.index,
                "data-item-group-index": V.groupIndex,
                style: i1
            }, A ? d(V.index, V.groupIndex, V.data, u) : d(V.index, V.data, u))
        }))
    }),
    a1 = {
        height: "100%",
        outline: "none",
        overflowY: "auto",
        position: "relative",
        WebkitOverflowScrolling: "touch"
    },
    Yn = e => ({
        width: "100%",
        height: "100%",
        position: "absolute",
        top: 0,
        ...e ? {
            display: "flex",
            flexDirection: "column"
        } : {}
    }),
    l1 = {
        width: "100%",
        position: Pd(),
        top: 0,
        zIndex: 1
    };

function Oe(e, t) {
    if (typeof e != "string") return {
        context: t
    }
}

function zd(e, t) {
    return {
        item: typeof e == "string" ? void 0 : t
    }
}
const c1 = M.memo(function() {
        const t = Ce("HeaderComponent"),
            o = wt("headerHeight"),
            r = Ce("headerFooterTag"),
            s = Ut(a => o(Pt(a, "height"))),
            i = Ce("context");
        return t ? M.createElement(r, {
            ref: s
        }, M.createElement(t, Oe(t, i))) : null
    }),
    d1 = M.memo(function() {
        const t = Ce("FooterComponent"),
            o = wt("footerHeight"),
            r = Ce("headerFooterTag"),
            s = Ut(a => o(Pt(a, "height"))),
            i = Ce("context");
        return t ? M.createElement(r, {
            ref: s
        }, M.createElement(t, Oe(t, i))) : null
    });

function Oi({
    usePublisher: e,
    useEmitter: t,
    useEmitterValue: o
}) {
    return M.memo(function({
        style: i,
        children: a,
        ...l
    }) {
        const c = e("scrollContainerState"),
            d = o("ScrollerComponent"),
            u = e("smoothScrollTargetReached"),
            h = o("scrollerRef"),
            m = o("context"),
            {
                scrollerRef: g,
                scrollByCallback: p,
                scrollToCallback: b
            } = fd(c, u, d, h);
        return t("scrollTo", b), t("scrollBy", p), M.createElement(d, {
            ref: g,
            style: { ...a1,
                ...i
            },
            "data-testid": "virtuoso-scroller",
            "data-virtuoso-scroller": !0,
            tabIndex: 0,
            ...l,
            ...Oe(d, m)
        }, a)
    })
}

function Ui({
    usePublisher: e,
    useEmitter: t,
    useEmitterValue: o
}) {
    return M.memo(function({
        style: i,
        children: a,
        ...l
    }) {
        const c = e("windowScrollContainerState"),
            d = o("ScrollerComponent"),
            u = e("smoothScrollTargetReached"),
            h = o("totalListHeight"),
            m = o("deviation"),
            g = o("customScrollParent"),
            p = o("context"),
            {
                scrollerRef: b,
                scrollByCallback: j,
                scrollToCallback: y
            } = fd(c, u, d, An, g);
        return vx(() => (b.current = g || window, () => {
            b.current = null
        }), [b, g]), t("windowScrollTo", y), t("scrollBy", j), M.createElement(d, {
            style: {
                position: "relative",
                ...i,
                ...h !== 0 ? {
                    height: h + m
                } : {}
            },
            "data-virtuoso-scroller": !0,
            ...l,
            ...Oe(d, p)
        }, a)
    })
}
const u1 = ({
        children: e
    }) => {
        const t = M.useContext(Yr),
            o = wt("viewportHeight"),
            r = wt("fixedItemHeight"),
            s = Ce("alignToBottom"),
            i = Ut(xo(o, a => Pt(a, "height")));
        return M.useEffect(() => {
            t && (o(t.viewportHeight), r(t.itemHeight))
        }, [t, o, r]), M.createElement("div", {
            style: Yn(s),
            ref: i,
            "data-viewport-type": "element"
        }, e)
    },
    h1 = ({
        children: e
    }) => {
        const t = M.useContext(Yr),
            o = wt("windowViewportRect"),
            r = wt("fixedItemHeight"),
            s = Ce("customScrollParent"),
            i = Hi(o, s),
            a = Ce("alignToBottom");
        return M.useEffect(() => {
            t && (r(t.itemHeight), o({
                offsetTop: 0,
                visibleHeight: t.viewportHeight,
                visibleWidth: 100
            }))
        }, [t, o, r]), M.createElement("div", {
            ref: i,
            style: Yn(a),
            "data-viewport-type": "window"
        }, e)
    },
    f1 = ({
        children: e
    }) => {
        const t = Ce("TopItemListComponent") || "div",
            o = Ce("headerHeight"),
            r = { ...l1,
                marginTop: `${o}px`
            },
            s = Ce("context");
        return M.createElement(t, {
            style: r,
            ...Oe(t, s)
        }, e)
    },
    g1 = M.memo(function(t) {
        const o = Ce("useWindowScroll"),
            r = Ce("topItemsIndexes").length > 0,
            s = Ce("customScrollParent"),
            i = s || o ? x1 : p1,
            a = s || o ? h1 : u1;
        return M.createElement(i, { ...t
        }, r && M.createElement(f1, null, M.createElement(Sl, {
            showTopList: !0
        })), M.createElement(a, null, M.createElement(c1, null), M.createElement(Sl, null), M.createElement(d1, null)))
    }),
    {
        Component: m1,
        usePublisher: wt,
        useEmitterValue: Ce,
        useEmitter: Vi
    } = zi(o1, {
        required: {},
        optional: {
            restoreStateFrom: "restoreStateFrom",
            context: "context",
            followOutput: "followOutput",
            itemContent: "itemContent",
            groupContent: "groupContent",
            overscan: "overscan",
            increaseViewportBy: "increaseViewportBy",
            totalCount: "totalCount",
            groupCounts: "groupCounts",
            topItemCount: "topItemCount",
            firstItemIndex: "firstItemIndex",
            initialTopMostItemIndex: "initialTopMostItemIndex",
            components: "components",
            atBottomThreshold: "atBottomThreshold",
            atTopThreshold: "atTopThreshold",
            computeItemKey: "computeItemKey",
            defaultItemHeight: "defaultItemHeight",
            fixedItemHeight: "fixedItemHeight",
            itemSize: "itemSize",
            scrollSeekConfiguration: "scrollSeekConfiguration",
            headerFooterTag: "headerFooterTag",
            data: "data",
            initialItemCount: "initialItemCount",
            initialScrollTop: "initialScrollTop",
            alignToBottom: "alignToBottom",
            useWindowScroll: "useWindowScroll",
            customScrollParent: "customScrollParent",
            scrollerRef: "scrollerRef",
            logLevel: "logLevel"
        },
        methods: {
            scrollToIndex: "scrollToIndex",
            scrollIntoView: "scrollIntoView",
            scrollTo: "scrollTo",
            scrollBy: "scrollBy",
            autoscrollToBottom: "autoscrollToBottom",
            getState: "getState"
        },
        events: {
            isScrolling: "isScrolling",
            endReached: "endReached",
            startReached: "startReached",
            rangeChanged: "rangeChanged",
            atBottomStateChange: "atBottomStateChange",
            atTopStateChange: "atTopStateChange",
            totalListHeightChanged: "totalListHeightChanged",
            itemsRendered: "itemsRendered",
            groupIndices: "groupIndices"
        }
    }, g1),
    p1 = Oi({
        usePublisher: wt,
        useEmitterValue: Ce,
        useEmitter: Vi
    }),
    x1 = Ui({
        usePublisher: wt,
        useEmitterValue: Ce,
        useEmitter: Vi
    }),
    yv = m1,
    wl = {
        items: [],
        offsetBottom: 0,
        offsetTop: 0,
        top: 0,
        bottom: 0,
        itemHeight: 0,
        itemWidth: 0
    },
    b1 = {
        items: [{
            index: 0
        }],
        offsetBottom: 0,
        offsetTop: 0,
        top: 0,
        bottom: 0,
        itemHeight: 0,
        itemWidth: 0
    },
    {
        round: Cl,
        ceil: kl,
        floor: wr,
        min: bs,
        max: lo
    } = Math;

function v1(e) {
    return { ...b1,
        items: e
    }
}

function Tl(e, t, o) {
    return Array.from({
        length: t - e + 1
    }).map((r, s) => {
        const i = o === null ? null : o[s + e];
        return {
            index: s + e,
            data: i
        }
    })
}

function y1(e, t) {
    return e && e.column === t.column && e.row === t.row
}

function Yo(e, t) {
    return e && e.width === t.width && e.height === t.height
}
const j1 = Te(([{
    overscan: e,
    visibleRange: t,
    listBoundary: o
}, {
    scrollTop: r,
    viewportHeight: s,
    scrollBy: i,
    scrollTo: a,
    smoothScrollTargetReached: l,
    scrollContainerState: c,
    footerHeight: d,
    headerHeight: u
}, h, m, {
    propsReady: g,
    didMount: p
}, {
    windowViewportRect: b,
    useWindowScroll: j,
    customScrollParent: y,
    windowScrollContainerState: S,
    windowScrollTo: w
}, v]) => {
    const x = X(0),
        C = X(0),
        E = X(wl),
        R = X({
            height: 0,
            width: 0
        }),
        B = X({
            height: 0,
            width: 0
        }),
        A = ke(),
        P = ke(),
        D = X(0),
        O = X(null),
        V = X({
            row: 0,
            column: 0
        }),
        z = ke(),
        H = ke(),
        oe = X(!1),
        re = X(0),
        ye = X(!0),
        fe = X(!1);
    Ee(_(p, Se(re), ge(([W, se]) => !!se)), () => {
        ve(ye, !1), ve(C, 0)
    }), Ee(_($e(p, ye, B, R, re, fe), ge(([W, se, J, de, , ie]) => W && !se && J.height !== 0 && de.height !== 0 && !ie)), ([, , , , W]) => {
        ve(fe, !0), Wi(1, () => {
            ve(A, W)
        }), Ot(_(r), () => {
            ve(o, [0, 0]), ve(ye, !0)
        })
    }), ae(_(H, ge(W => W != null && W.scrollTop > 0), Ft(0)), C), Ee(_(p, Se(H), ge(([, W]) => W != null)), ([, W]) => {
        W && (ve(R, W.viewport), ve(B, W == null ? void 0 : W.item), ve(V, W.gap), W.scrollTop > 0 && (ve(oe, !0), Ot(_(r, Vn(1)), se => {
            ve(oe, !1)
        }), ve(a, {
            top: W.scrollTop
        })))
    }), ae(_(R, $(({
        height: W
    }) => W)), s), ae(_($e(me(R, Yo), me(B, Yo), me(V, (W, se) => W && W.column === se.column && W.row === se.row), me(r)), $(([W, se, J, de]) => ({
        viewport: W,
        item: se,
        gap: J,
        scrollTop: de
    }))), z), ae(_($e(me(x), t, me(V, y1), me(B, Yo), me(R, Yo), me(O), me(C), me(oe), me(ye), me(re)), ge(([, , , , , , , W]) => !W), $(([W, [se, J], de, ie, U, F, G, , ce, Q]) => {
        const {
            row: le,
            column: te
        } = de, {
            height: N,
            width: ne
        } = ie, {
            width: Pe
        } = U;
        if (G === 0 && (W === 0 || Pe === 0)) return wl;
        if (ne === 0) {
            const gt = Di(Q, W),
                Tt = gt === 0 ? Math.max(G - 1, 0) : gt;
            return v1(Tl(gt, Tt, F))
        }
        const Ke = Md(Pe, ne, te);
        let Ne, ct;
        ce ? se === 0 && J === 0 && G > 0 ? (Ne = 0, ct = G - 1) : (Ne = Ke * wr((se + le) / (N + le)), ct = Ke * kl((J + le) / (N + le)) - 1, ct = bs(W - 1, lo(ct, Ke - 1)), Ne = bs(ct, lo(0, Ne))) : (Ne = 0, ct = -1);
        const kt = Tl(Ne, ct, F),
            {
                top: zt,
                bottom: Mt
            } = Il(U, de, ie, kt),
            nt = kl(W / Ke),
            He = nt * N + (nt - 1) * le - Mt;
        return {
            items: kt,
            offsetTop: zt,
            offsetBottom: He,
            top: zt,
            bottom: Mt,
            itemHeight: N,
            itemWidth: ne
        }
    })), E), ae(_(O, ge(W => W !== null), $(W => W.length)), x), ae(_($e(R, B, E, V), ge(([W, se, {
        items: J
    }]) => J.length > 0 && se.height !== 0 && W.height !== 0), $(([W, se, {
        items: J
    }, de]) => {
        const {
            top: ie,
            bottom: U
        } = Il(W, de, se, J);
        return [ie, U]
    }), We(So)), o);
    const je = X(!1);
    ae(_(r, Se(je), $(([W, se]) => se || W !== 0)), je);
    const ze = bt(_(me(E), ge(({
            items: W
        }) => W.length > 0), Se(x, je), ge(([{
            items: W
        }, se, J]) => J && W[W.length - 1].index === se - 1), $(([, W]) => W - 1), We())),
        Me = bt(_(me(E), ge(({
            items: W
        }) => W.length > 0 && W[0].index === 0), Ft(0), We())),
        Fe = bt(_(me(E), Se(oe), ge(([{
            items: W
        }, se]) => W.length > 0 && !se), $(([{
            items: W
        }]) => ({
            startIndex: W[0].index,
            endIndex: W[W.length - 1].index
        })), We(Cd), sn(0)));
    ae(Fe, m.scrollSeekRangeChanged), ae(_(A, Se(R, B, x, V), $(([W, se, J, de, ie]) => {
        const U = Sd(W),
            {
                align: F,
                behavior: G,
                offset: ce
            } = U;
        let Q = U.index;
        Q === "LAST" && (Q = de - 1), Q = lo(0, Q, bs(de - 1, Q));
        let le = _s(se, ie, J, Q);
        return F === "end" ? le = Cl(le - se.height + J.height) : F === "center" && (le = Cl(le - se.height / 2 + J.height / 2)), ce && (le += ce), {
            top: le,
            behavior: G
        }
    })), a);
    const Be = it(_(E, $(W => W.offsetBottom + W.bottom)), 0);
    return ae(_(b, $(W => ({
        width: W.visibleWidth,
        height: W.visibleHeight
    }))), R), {
        data: O,
        totalCount: x,
        viewportDimensions: R,
        itemDimensions: B,
        scrollTop: r,
        scrollHeight: P,
        overscan: e,
        scrollBy: i,
        scrollTo: a,
        scrollToIndex: A,
        smoothScrollTargetReached: l,
        windowViewportRect: b,
        windowScrollTo: w,
        useWindowScroll: j,
        customScrollParent: y,
        windowScrollContainerState: S,
        deviation: D,
        scrollContainerState: c,
        footerHeight: d,
        headerHeight: u,
        initialItemCount: C,
        gap: V,
        restoreStateFrom: H,
        ...m,
        initialTopMostItemIndex: re,
        gridState: E,
        totalListHeight: Be,
        ...h,
        startReached: Me,
        endReached: ze,
        rangeChanged: Fe,
        stateChanged: z,
        propsReady: g,
        stateRestoreInProgress: oe,
        ...v
    }
}, Le(Li, ft, Bo, Td, fn, Ni, hn));

function Il(e, t, o, r) {
    const {
        height: s
    } = o;
    if (s === void 0 || r.length === 0) return {
        top: 0,
        bottom: 0
    };
    const i = _s(e, t, o, r[0].index),
        a = _s(e, t, o, r[r.length - 1].index) + s;
    return {
        top: i,
        bottom: a
    }
}

function _s(e, t, o, r) {
    const s = Md(e.width, o.width, t.column),
        i = wr(r / s),
        a = i * o.height + lo(0, i - 1) * t.row;
    return a > 0 ? a + t.row : a
}

function Md(e, t, o) {
    return lo(1, wr((e + o) / (wr(t) + o)))
}
const S1 = Te(() => {
        const e = X(d => `Item ${d}`),
            t = X({}),
            o = X(null),
            r = X("virtuoso-grid-item"),
            s = X("virtuoso-grid-list"),
            i = X(_i),
            a = X("div"),
            l = X(An),
            c = (d, u = null) => it(_(t, $(h => h[d]), We()), u);
        return {
            context: o,
            itemContent: e,
            components: t,
            computeItemKey: i,
            itemClassName: r,
            listClassName: s,
            headerFooterTag: a,
            scrollerRef: l,
            FooterComponent: c("Footer"),
            HeaderComponent: c("Header"),
            ListComponent: c("List", "div"),
            ItemComponent: c("Item", "div"),
            ScrollerComponent: c("Scroller", "div"),
            ScrollSeekPlaceholder: c("ScrollSeekPlaceholder", "div")
        }
    }),
    w1 = Te(([e, t]) => ({ ...e,
        ...t
    }), Le(j1, S1)),
    C1 = M.memo(function() {
        const t = _e("gridState"),
            o = _e("listClassName"),
            r = _e("itemClassName"),
            s = _e("itemContent"),
            i = _e("computeItemKey"),
            a = _e("isSeeking"),
            l = At("scrollHeight"),
            c = _e("ItemComponent"),
            d = _e("ListComponent"),
            u = _e("ScrollSeekPlaceholder"),
            h = _e("context"),
            m = At("itemDimensions"),
            g = At("gap"),
            p = _e("log"),
            b = _e("stateRestoreInProgress"),
            j = Ut(y => {
                const S = y.parentElement.parentElement.scrollHeight;
                l(S);
                const w = y.firstChild;
                if (w) {
                    const {
                        width: v,
                        height: x
                    } = w.getBoundingClientRect();
                    m({
                        width: v,
                        height: x
                    })
                }
                g({
                    row: Al("row-gap", getComputedStyle(y).rowGap, p),
                    column: Al("column-gap", getComputedStyle(y).columnGap, p)
                })
            });
        return b ? null : M.createElement(d, {
            ref: j,
            className: o,
            ...Oe(d, h),
            style: {
                paddingTop: t.offsetTop,
                paddingBottom: t.offsetBottom
            },
            "data-testid": "virtuoso-item-list"
        }, t.items.map(y => {
            const S = i(y.index, y.data, h);
            return a ? M.createElement(u, {
                key: S,
                ...Oe(u, h),
                index: y.index,
                height: t.itemHeight,
                width: t.itemWidth
            }) : M.createElement(c, { ...Oe(c, h),
                className: r,
                "data-index": y.index,
                key: S
            }, s(y.index, y.data, h))
        }))
    }),
    k1 = M.memo(function() {
        const t = _e("HeaderComponent"),
            o = At("headerHeight"),
            r = _e("headerFooterTag"),
            s = Ut(a => o(Pt(a, "height"))),
            i = _e("context");
        return t ? M.createElement(r, {
            ref: s
        }, M.createElement(t, Oe(t, i))) : null
    }),
    T1 = M.memo(function() {
        const t = _e("FooterComponent"),
            o = At("footerHeight"),
            r = _e("headerFooterTag"),
            s = Ut(a => o(Pt(a, "height"))),
            i = _e("context");
        return t ? M.createElement(r, {
            ref: s
        }, M.createElement(t, Oe(t, i))) : null
    }),
    I1 = ({
        children: e
    }) => {
        const t = M.useContext(Rd),
            o = At("itemDimensions"),
            r = At("viewportDimensions"),
            s = Ut(i => {
                r(i.getBoundingClientRect())
            });
        return M.useEffect(() => {
            t && (r({
                height: t.viewportHeight,
                width: t.viewportWidth
            }), o({
                height: t.itemHeight,
                width: t.itemWidth
            }))
        }, [t, r, o]), M.createElement("div", {
            style: Yn(!1),
            ref: s
        }, e)
    },
    A1 = ({
        children: e
    }) => {
        const t = M.useContext(Rd),
            o = At("windowViewportRect"),
            r = At("itemDimensions"),
            s = _e("customScrollParent"),
            i = Hi(o, s);
        return M.useEffect(() => {
            t && (r({
                height: t.itemHeight,
                width: t.itemWidth
            }), o({
                offsetTop: 0,
                visibleHeight: t.viewportHeight,
                visibleWidth: t.viewportWidth
            }))
        }, [t, o, r]), M.createElement("div", {
            ref: i,
            style: Yn(!1)
        }, e)
    },
    E1 = M.memo(function({ ...t
    }) {
        const o = _e("useWindowScroll"),
            r = _e("customScrollParent"),
            s = r || o ? R1 : P1,
            i = r || o ? A1 : I1;
        return M.createElement(s, { ...t
        }, M.createElement(i, null, M.createElement(k1, null), M.createElement(C1, null), M.createElement(T1, null)))
    }),
    {
        Component: jv,
        usePublisher: At,
        useEmitterValue: _e,
        useEmitter: Bd
    } = zi(w1, {
        optional: {
            context: "context",
            totalCount: "totalCount",
            overscan: "overscan",
            itemContent: "itemContent",
            components: "components",
            computeItemKey: "computeItemKey",
            data: "data",
            initialItemCount: "initialItemCount",
            scrollSeekConfiguration: "scrollSeekConfiguration",
            headerFooterTag: "headerFooterTag",
            listClassName: "listClassName",
            itemClassName: "itemClassName",
            useWindowScroll: "useWindowScroll",
            customScrollParent: "customScrollParent",
            scrollerRef: "scrollerRef",
            logLevel: "logLevel",
            restoreStateFrom: "restoreStateFrom",
            initialTopMostItemIndex: "initialTopMostItemIndex"
        },
        methods: {
            scrollTo: "scrollTo",
            scrollBy: "scrollBy",
            scrollToIndex: "scrollToIndex"
        },
        events: {
            isScrolling: "isScrolling",
            endReached: "endReached",
            startReached: "startReached",
            rangeChanged: "rangeChanged",
            atBottomStateChange: "atBottomStateChange",
            atTopStateChange: "atTopStateChange",
            stateChanged: "stateChanged"
        }
    }, E1),
    P1 = Oi({
        usePublisher: At,
        useEmitterValue: _e,
        useEmitter: Bd
    }),
    R1 = Ui({
        usePublisher: At,
        useEmitterValue: _e,
        useEmitter: Bd
    });

function Al(e, t, o) {
    return t !== "normal" && !(t != null && t.endsWith("px")) && o(`${e} was not resolved to pixel value correctly`, t, vt.WARN), t === "normal" ? 0 : parseInt(t ? ? "0", 10)
}
const z1 = Te(() => {
        const e = X(c => M.createElement("td", null, "Item $", c)),
            t = X(null),
            o = X(null),
            r = X(null),
            s = X({}),
            i = X(_i),
            a = X(An),
            l = (c, d = null) => it(_(s, $(u => u[c]), We()), d);
        return {
            context: t,
            itemContent: e,
            fixedHeaderContent: o,
            fixedFooterContent: r,
            components: s,
            computeItemKey: i,
            scrollerRef: a,
            TableComponent: l("Table", "table"),
            TableHeadComponent: l("TableHead", "thead"),
            TableFooterComponent: l("TableFoot", "tfoot"),
            TableBodyComponent: l("TableBody", "tbody"),
            TableRowComponent: l("TableRow", "tr"),
            ScrollerComponent: l("Scroller", "div"),
            EmptyPlaceholder: l("EmptyPlaceholder"),
            ScrollSeekPlaceholder: l("ScrollSeekPlaceholder"),
            FillerRow: l("FillerRow")
        }
    }),
    M1 = Te(([e, t]) => ({ ...e,
        ...t
    }), Le(Ed, z1)),
    B1 = ({
        height: e
    }) => M.createElement("tr", null, M.createElement("td", {
        style: {
            height: e
        }
    })),
    F1 = ({
        height: e
    }) => M.createElement("tr", null, M.createElement("td", {
        style: {
            height: e,
            padding: 0,
            border: 0
        }
    })),
    W1 = {
        overflowAnchor: "none"
    },
    D1 = M.memo(function() {
        const t = Ie("listState"),
            o = Et("sizeRanges"),
            r = Ie("useWindowScroll"),
            s = Ie("customScrollParent"),
            i = Et("windowScrollContainerState"),
            a = Et("scrollContainerState"),
            l = s || r ? i : a,
            c = Ie("itemContent"),
            d = Ie("trackItemSizes"),
            u = Ie("itemSize"),
            h = Ie("log"),
            {
                callbackRef: m,
                ref: g
            } = ud(o, u, d, l, h, void 0, s),
            [p, b] = M.useState(0);
        Xi("deviation", H => {
            p !== H && (g.current.style.marginTop = `${H}px`, b(H))
        });
        const j = Ie("EmptyPlaceholder"),
            y = Ie("ScrollSeekPlaceholder") || B1,
            S = Ie("FillerRow") || F1,
            w = Ie("TableBodyComponent"),
            v = Ie("TableRowComponent"),
            x = Ie("computeItemKey"),
            C = Ie("isSeeking"),
            E = Ie("paddingTopAddition"),
            R = Ie("firstItemIndex"),
            B = Ie("statefulTotalCount"),
            A = Ie("context");
        if (B === 0 && j) return M.createElement(j, Oe(j, A));
        const P = t.offsetTop + E + p,
            D = t.offsetBottom,
            O = P > 0 ? M.createElement(S, {
                height: P,
                key: "padding-top",
                context: A
            }) : null,
            V = D > 0 ? M.createElement(S, {
                height: D,
                key: "padding-bottom",
                context: A
            }) : null,
            z = t.items.map(H => {
                const oe = H.originalIndex,
                    re = x(oe + R, H.data, A);
                return C ? M.createElement(y, { ...Oe(y, A),
                    key: re,
                    index: H.index,
                    height: H.size,
                    type: H.type || "item"
                }) : M.createElement(v, { ...Oe(v, A),
                    ...zd(v, H.data),
                    key: re,
                    "data-index": oe,
                    "data-known-size": H.size,
                    "data-item-index": H.index,
                    style: W1
                }, c(H.index, H.data, A))
            });
        return M.createElement(w, {
            ref: m,
            "data-testid": "virtuoso-item-list",
            ...Oe(w, A)
        }, [O, ...z, V])
    }),
    L1 = ({
        children: e
    }) => {
        const t = M.useContext(Yr),
            o = Et("viewportHeight"),
            r = Et("fixedItemHeight"),
            s = Ut(xo(o, i => Pt(i, "height")));
        return M.useEffect(() => {
            t && (o(t.viewportHeight), r(t.itemHeight))
        }, [t, o, r]), M.createElement("div", {
            style: Yn(!1),
            ref: s,
            "data-viewport-type": "element"
        }, e)
    },
    N1 = ({
        children: e
    }) => {
        const t = M.useContext(Yr),
            o = Et("windowViewportRect"),
            r = Et("fixedItemHeight"),
            s = Ie("customScrollParent"),
            i = Hi(o, s);
        return M.useEffect(() => {
            t && (r(t.itemHeight), o({
                offsetTop: 0,
                visibleHeight: t.viewportHeight,
                visibleWidth: 100
            }))
        }, [t, o, r]), M.createElement("div", {
            ref: i,
            style: Yn(!1),
            "data-viewport-type": "window"
        }, e)
    },
    H1 = M.memo(function(t) {
        const o = Ie("useWindowScroll"),
            r = Ie("customScrollParent"),
            s = Et("fixedHeaderHeight"),
            i = Et("fixedFooterHeight"),
            a = Ie("fixedHeaderContent"),
            l = Ie("fixedFooterContent"),
            c = Ie("context"),
            d = Ut(xo(s, S => Pt(S, "height"))),
            u = Ut(xo(i, S => Pt(S, "height"))),
            h = r || o ? U1 : O1,
            m = r || o ? N1 : L1,
            g = Ie("TableComponent"),
            p = Ie("TableHeadComponent"),
            b = Ie("TableFooterComponent"),
            j = a ? M.createElement(p, {
                key: "TableHead",
                style: {
                    zIndex: 2,
                    position: "sticky",
                    top: 0
                },
                ref: d,
                ...Oe(p, c)
            }, a()) : null,
            y = l ? M.createElement(b, {
                key: "TableFoot",
                style: {
                    zIndex: 1,
                    position: "sticky",
                    bottom: 0
                },
                ref: u,
                ...Oe(b, c)
            }, l()) : null;
        return M.createElement(h, { ...t
        }, M.createElement(m, null, M.createElement(g, {
            style: {
                borderSpacing: 0,
                overflowAnchor: "none"
            },
            ...Oe(g, c)
        }, [j, M.createElement(D1, {
            key: "TableBody"
        }), y])))
    }),
    {
        Component: _1,
        usePublisher: Et,
        useEmitterValue: Ie,
        useEmitter: Xi
    } = zi(M1, {
        required: {},
        optional: {
            restoreStateFrom: "restoreStateFrom",
            context: "context",
            followOutput: "followOutput",
            firstItemIndex: "firstItemIndex",
            itemContent: "itemContent",
            fixedHeaderContent: "fixedHeaderContent",
            fixedFooterContent: "fixedFooterContent",
            overscan: "overscan",
            increaseViewportBy: "increaseViewportBy",
            totalCount: "totalCount",
            topItemCount: "topItemCount",
            initialTopMostItemIndex: "initialTopMostItemIndex",
            components: "components",
            groupCounts: "groupCounts",
            atBottomThreshold: "atBottomThreshold",
            atTopThreshold: "atTopThreshold",
            computeItemKey: "computeItemKey",
            defaultItemHeight: "defaultItemHeight",
            fixedItemHeight: "fixedItemHeight",
            itemSize: "itemSize",
            scrollSeekConfiguration: "scrollSeekConfiguration",
            data: "data",
            initialItemCount: "initialItemCount",
            initialScrollTop: "initialScrollTop",
            alignToBottom: "alignToBottom",
            useWindowScroll: "useWindowScroll",
            customScrollParent: "customScrollParent",
            scrollerRef: "scrollerRef",
            logLevel: "logLevel"
        },
        methods: {
            scrollToIndex: "scrollToIndex",
            scrollIntoView: "scrollIntoView",
            scrollTo: "scrollTo",
            scrollBy: "scrollBy",
            getState: "getState"
        },
        events: {
            isScrolling: "isScrolling",
            endReached: "endReached",
            startReached: "startReached",
            rangeChanged: "rangeChanged",
            atBottomStateChange: "atBottomStateChange",
            atTopStateChange: "atTopStateChange",
            totalListHeightChanged: "totalListHeightChanged",
            itemsRendered: "itemsRendered",
            groupIndices: "groupIndices"
        }
    }, H1),
    O1 = Oi({
        usePublisher: Et,
        useEmitterValue: Ie,
        useEmitter: Xi
    }),
    U1 = Ui({
        usePublisher: Et,
        useEmitterValue: Ie,
        useEmitter: Xi
    }),
    V1 = _1,
    qi = M.createContext({
        layout: "wide",
        tradingHistory: []
    }),
    X1 = M.forwardRef(({ ...e
    }, t) => {
        const {
            colorMode: o
        } = pe(), {
            isUpdatingFilter: r,
            filters: s
        } = f.useContext(qi), i = s !== void 0 && (s.type || s.amountUsd.min !== null || s.amountUsd.max !== null || s.amount0.min !== null || s.amount0.max !== null || s.amount1.min !== null || s.amount1.max !== null || s.maker !== null);
        return n.jsx(I, {
            ref: t,
            as: "tbody",
            ...e,
            children: n.jsx(I, {
                as: "tr",
                children: n.jsxs(I, {
                    as: "td",
                    children: [r && n.jsx(Cn, {
                        p: 3,
                        size: "sm"
                    }), !r && n.jsxs(q, {
                        p: 4,
                        fontSize: "sm",
                        color: T("gray.500", "blue.600", o),
                        fontStyle: "italic",
                        children: [!i && "No transactions found", i && "No transactions found with the selected filters"]
                    })]
                })
            })
        })
    });

function q1(e) {
    return Kn({
        tag: "svg",
        attr: {
            viewBox: "0 0 24 24"
        },
        child: [{
            tag: "path",
            attr: {
                fill: "none",
                d: "M0 0h24v24H0z"
            }
        }, {
            tag: "path",
            attr: {
                d: "M16.01 11H4v2h12.01v3L20 12l-3.99-4z"
            }
        }]
    })(e)
}

function G1(e) {
    return Kn({
        tag: "svg",
        attr: {
            viewBox: "0 0 24 24"
        },
        child: [{
            tag: "path",
            attr: {
                fill: "none",
                d: "M0 0h24v24H0z"
            }
        }, {
            tag: "path",
            attr: {
                d: "M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"
            }
        }]
    })(e)
}

function K1(e) {
    return Kn({
        tag: "svg",
        attr: {
            viewBox: "0 0 16 16",
            fill: "currentColor"
        },
        child: [{
            tag: "path",
            attr: {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M15 2v1.67l-5 4.759V14H6V8.429l-5-4.76V2h14z"
            }
        }]
    })(e)
}

function Zr(e) {
    return Kn({
        tag: "svg",
        attr: {
            viewBox: "0 0 16 16",
            fill: "currentColor"
        },
        child: [{
            tag: "path",
            attr: {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M15 2v1.67l-5 4.759V14H6V8.429l-5-4.76V2h14zM7 8v5h2V8l5-4.76V3H2v.24L7 8z"
            }
        }]
    })(e)
}
const Q1 = e => ({
        light: {
            realized: {
                known: "gray.475",
                unknown: `repeating-linear-gradient(-55deg, ${e[0]}, ${e[0]} 3px, ${e[1]} 3px, ${e[1]} 6px)`
            },
            unrealized: {
                known: "gray.150",
                unknown: "transparent"
            }
        },
        dark: {
            realized: {
                known: "gray.100",
                unknown: `repeating-linear-gradient(-55deg, ${e[2]}, ${e[2]} 3px, ${e[3]} 3px, ${e[3]} 6px)`
            },
            unrealized: {
                known: "gray.600",
                unknown: "transparent"
            }
        }
    }),
    Gi = ({
        balancePercentage: e,
        colorMode: t
    }) => {
        const {
            colorMode: o
        } = pe(), r = t ? ? o, s = Q1(di("colors", ["gray.475", "gray.50", "gray.100", "gray.700"])), i = e !== null ? "known" : "unknown", a = s[r].realized[i], l = s[r].unrealized[i];
        return n.jsx(wn, {
            left: {
                label: "Realized",
                value: e !== null ? e : 100,
                bg: a
            },
            right: {
                label: "Unrealized",
                value: e !== null ? 100 - e : 0,
                bg: l
            },
            isJoined: !0,
            disableTooltip: !0,
            containerProps: {
                mt: "-2px"
            }
        })
    },
    Cr = {
        plankton: {
            icon: l0,
            label: "Plankton",
            description: "<$10 bought or sold"
        },
        fish: {
            icon: c0,
            label: "Fish",
            description: "$10-$250 bought or sold"
        },
        shrimp: {
            icon: d0,
            label: "Shrimp",
            description: "$250-$1k bought or sold"
        },
        dolphin: {
            icon: u0,
            label: "Dolphin",
            description: "$1k-$10k bought or sold"
        },
        whale: {
            icon: h0,
            label: "Whale",
            description: "$10k+ bought or sold"
        }
    },
    Fd = e => {
        const t = Math.max(e.volumeUsdBuy, e.volumeUsdSell);
        return t < 10 ? "plankton" : t < 250 ? "fish" : t <= 1e3 ? "shrimp" : t <= 1e4 ? "dolphin" : "whale"
    },
    Ki = ({
        makerType: e,
        isNew: t,
        iconProps: o,
        isNewIndicatorIconProps: r
    }) => t ? n.jsxs(k, {
        color: "transparent",
        display: "flex",
        alignItems: "center",
        pos: "relative",
        children: [n.jsx(L, {
            as: Uc,
            pos: "absolute",
            top: "-4px",
            right: "-3px",
            ...r
        }), n.jsx(Ze, {
            src: Cr[e].icon,
            loading: "lazy",
            ...o
        })]
    }) : n.jsx(Ze, {
        src: Cr[e].icon,
        loading: "lazy",
        ...o
    }),
    $1 = ({
        maker: e,
        makerScreener: t,
        makerInfo: o,
        blockExplorerUrl: r,
        isInteractive: s,
        onTouchOutside: i
    }) => {
        const a = Zt(h => h.pair),
            l = be({
                value: a,
                onPending: () => {},
                onFailure: () => {},
                onSuccess: h => {
                    var m;
                    return (m = h.data) == null ? void 0 : m.priceUsd
                }
            }),
            c = l && t.balanceAmount ? pt(l).multipliedBy(t.balanceAmount) : void 0,
            d = (Date.now() - t.firstSwap) / 1e3 / 60 / 60 / 24,
            u = f.useRef(null);
        return f.useEffect(() => {
            if (!s || typeof window > "u") return;
            const h = m => {
                var g;
                m.target instanceof HTMLElement && !((g = u.current) != null && g.contains(m.target)) && i()
            };
            return window.addEventListener("touchstart", h), () => window.removeEventListener("touchstart", h)
        }, [s]), n.jsxs(I, {
            ref: u,
            py: 3,
            px: 3,
            color: "white",
            fontFamily: "mono",
            fontSize: "sm",
            textAlign: "left",
            children: [n.jsxs(I, {
                display: "grid",
                gridTemplateColumns: "90px 1fr",
                columnGap: 2,
                rowGap: 2,
                alignItems: "center",
                children: [n.jsxs(k, {
                    textAlign: "right",
                    children: [n.jsx(k, {
                        fontWeight: "semibold",
                        fontSize: "xs",
                        opacity: .5,
                        children: "(-)"
                    }), " ", "Bought:"]
                }), n.jsxs(k, {
                    display: "grid",
                    gridTemplateColumns: "1.1fr 1fr 0.9fr",
                    alignItems: "center",
                    children: [n.jsx(k, {
                        fontSize: "md",
                        fontWeight: "semibold",
                        color: "accent.red",
                        children: t.buys > 0 ? Dt(t.volumeUsdBuy) : "$0"
                    }), n.jsx(k, {
                        opacity: t.buys === 0 ? .5 : void 0,
                        children: t.buys > 0 ? Ht(t.amountBuy) : "-"
                    }), n.jsxs(k, {
                        fontSize: "2xs",
                        opacity: .5,
                        textAlign: "right",
                        children: [t.buys < 1e3 ? t.buys : "1k+", " txns"]
                    })]
                }), n.jsxs(k, {
                    textAlign: "right",
                    children: [n.jsx(k, {
                        fontWeight: "semibold",
                        fontSize: "xs",
                        opacity: .5,
                        children: "(+)"
                    }), " ", "Sold:"]
                }), n.jsxs(k, {
                    display: "grid",
                    gridTemplateColumns: "1.1fr 1fr 0.9fr",
                    alignItems: "center",
                    children: [n.jsx(k, {
                        fontSize: "md",
                        fontWeight: "semibold",
                        color: "accent.lightGreen",
                        children: t.sells > 0 ? Dt(t.volumeUsdSell) : "$0"
                    }), n.jsx(k, {
                        opacity: t.sells === 0 ? .5 : void 0,
                        children: t.sells > 0 ? Ht(t.amountSell) : "-"
                    }), n.jsxs(k, {
                        fontSize: "2xs",
                        opacity: .5,
                        textAlign: "right",
                        children: [t.sells < 1e3 ? t.sells : "1k+", " txns"]
                    })]
                }), n.jsxs(k, {
                    textAlign: "right",
                    children: [n.jsx(k, {
                        fontWeight: "semibold",
                        fontSize: "xs",
                        opacity: .5,
                        children: "(=)"
                    }), " ", "PNL:"]
                }), n.jsx(k, {
                    display: "grid",
                    gridTemplateColumns: "1.1fr 1fr 0.9fr",
                    alignItems: "center",
                    children: n.jsx(k, {
                        fontSize: "md",
                        fontWeight: "semibold",
                        color: o.pnl >= 0 ? "accent.lightGreen" : "accent.red",
                        children: o.pnl === 0 ? "$0" : Dt(Math.abs(t.volumeUsdSell - t.volumeUsdBuy))
                    })
                }), n.jsx(k, {
                    textAlign: "right",
                    children: "Unrealized:"
                }), n.jsxs(k, {
                    display: "grid",
                    gridTemplateColumns: "1.1fr 1.9fr",
                    alignItems: "center",
                    children: [n.jsx(k, {
                        fontSize: "md",
                        fontWeight: "semibold",
                        opacity: c ? void 0 : .5,
                        children: c && c.gt(0) ? Dt(c) : "-"
                    }), n.jsxs(k, {
                        fontSize: "xs",
                        display: "flex",
                        flexDir: "column",
                        children: [n.jsxs(k, {
                            display: "flex",
                            justifyContent: "center",
                            gap: 1,
                            children: [t.balanceAmount !== null && n.jsxs(n.Fragment, {
                                children: [n.jsx(k, {
                                    children: t.balanceAmount === "0" ? "0" : Ht(t.balanceAmount)
                                }), n.jsx(k, {
                                    opacity: .5,
                                    children: "of"
                                }), n.jsx(k, {
                                    children: Ht(t.amountBuy)
                                })]
                            }), t.balanceAmount === null && n.jsx(k, {
                                opacity: .5,
                                children: "Unknown balance"
                            })]
                        }), n.jsx(Gi, {
                            balancePercentage: t.balancePercentage,
                            colorMode: "dark"
                        })]
                    })]
                })]
            }), n.jsx(Mr, {
                borderColor: "gray.875",
                my: 3
            }), n.jsxs(I, {
                fontFamily: "body",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                textAlign: "left",
                gap: 4,
                children: [n.jsx(Ki, {
                    makerType: o.type,
                    iconProps: {
                        boxSize: "42px"
                    }
                }), n.jsxs(I, {
                    display: "flex",
                    flexDir: "column",
                    gap: .5,
                    children: [n.jsx(Lt, {
                        as: "h3",
                        size: "sm",
                        children: Eo(e)
                    }), n.jsx(k, {
                        fontSize: "sm",
                        color: "gray.300",
                        mt: .5,
                        children: n.jsxs(n.Fragment, {
                            children: [Cr[o.type].label, ":", " ", n.jsx(k, {
                                fontWeight: "semibold",
                                children: Cr[o.type].description
                            })]
                        })
                    }), n.jsxs(k, {
                        fontSize: "sm",
                        color: "gray.300",
                        children: ["Holder since: ", n.jsx(k, {
                            fontWeight: "semibold",
                            children: d <= 30 ? n.jsx(Mf, {
                                timestamp: t.firstSwap
                            }) : "30+ days"
                        })]
                    }), t.new && n.jsxs(k, {
                        display: "flex",
                        alignItems: "center",
                        color: "gray.300",
                        children: [n.jsx(L, {
                            as: Uc,
                            boxSize: "14px",
                            mr: 1
                        }), "Newly active on this pair"]
                    })]
                })]
            }), s && r && n.jsx(pc, {
                children: n.jsx(ue, {
                    as: we,
                    href: r,
                    rel: "noopener noreferrer",
                    target: "_blank",
                    variant: "outline",
                    size: "sm",
                    fontFamily: "body",
                    mt: 3,
                    w: "100%",
                    rightIcon: n.jsx(L, {
                        as: yt,
                        ml: 1
                    }),
                    _hover: {
                        textDecor: "none"
                    },
                    children: "Open in block explorer"
                })
            })]
        })
    },
    Y1 = ({
        chainId: e,
        maker: t,
        makerScreener: o
    }) => {
        const r = In(e),
            s = t ? r == null ? void 0 : r.accountURL(t) : void 0;
        let i;
        if (o) {
            const a = Fd({
                    volumeUsdBuy: o.volumeUsdBuy,
                    volumeUsdSell: o.volumeUsdSell
                }),
                l = o.volumeUsdSell - o.volumeUsdBuy;
            i = {
                type: a,
                pnl: l
            }
        }
        return {
            blockExplorerUrl: s,
            makerInfo: i
        }
    },
    Wd = ({
        chainId: e,
        maker: t,
        makerScreener: o,
        isMakerFiltered: r,
        onMakerFilterChange: s,
        highlightAddresses: i
    }) => {
        const {
            colorMode: a
        } = pe(), {
            blockExplorerUrl: l,
            makerInfo: c
        } = Y1({
            chainId: e,
            maker: t,
            makerScreener: o
        }), [d, u] = f.useState(!1);
        Cf(() => {
            u(!0)
        }, 500);
        const [h] = tc("(hover: hover) and (pointer: fine)"), [m, g] = f.useState(1), p = () => {
            g(y => y + 1)
        }, b = t ? (i == null ? void 0 : i.find(({
            type: y,
            address: S
        }) => y === "creator" && S.toLowerCase() === t.toLowerCase())) !== void 0 : !1, j = t ? (i == null ? void 0 : i.find(({
            type: y,
            address: S
        }) => y === "user" && S.toLowerCase() === t.toLowerCase())) !== void 0 : !1;
        return t ? n.jsxs(n.Fragment, {
            children: [o && c && n.jsx(n.Fragment, {
                children: n.jsxs(Si, {
                    trigger: h ? "hover" : "click",
                    openDelay: d ? 0 : 500,
                    closeDelay: 0,
                    strategy: "fixed",
                    placement: h ? "right-start" : "auto",
                    isLazy: !0,
                    children: [n.jsx(ji, {
                        children: n.jsxs(I, {
                            display: "inline-flex",
                            alignItems: "center",
                            gap: "4px",
                            mr: "4px",
                            fontFamily: "mono",
                            cursor: "default",
                            children: [n.jsx(Ki, {
                                makerType: c.type,
                                isNew: o.new,
                                iconProps: {
                                    boxSize: {
                                        base: "16px",
                                        xl: "20px"
                                    }
                                },
                                isNewIndicatorIconProps: {
                                    boxSize: "12px"
                                }
                            }), n.jsx(I, {
                                children: n.jsxs(I, {
                                    display: "flex",
                                    flexDir: "column",
                                    children: [n.jsx(we, {
                                        href: l,
                                        rel: "noopener noreferrer",
                                        target: "_blank",
                                        display: "block",
                                        fontSize: {
                                            base: "2xs",
                                            xl: "sm"
                                        },
                                        color: c.pnl >= 0 ? T("accent.darkGreen", "accent.lightGreen", a) : "accent.red",
                                        _hover: {
                                            textDecor: "none",
                                            opacity: .8
                                        },
                                        pointerEvents: h ? void 0 : "none",
                                        children: pa(e, t)
                                    }), n.jsx(Gi, {
                                        balancePercentage: o.balancePercentage
                                    })]
                                })
                            })]
                        })
                    }), n.jsx(Io, {
                        children: n.jsxs(wi, {
                            borderWidth: 0,
                            borderRadius: 0,
                            bg: "gray.975",
                            variants: h ? void 0 : {},
                            children: [n.jsx(Mc, {
                                bg: "gray.975",
                                boxShadow: "none"
                            }), n.jsx(Bc, {
                                p: 0,
                                children: n.jsx($1, {
                                    maker: t,
                                    makerScreener: o,
                                    makerInfo: c,
                                    blockExplorerUrl: l,
                                    isInteractive: !h,
                                    onTouchOutside: p
                                })
                            })]
                        })
                    })]
                }, m)
            }), !o && n.jsx(we, {
                href: l,
                rel: "noopener noreferrer",
                target: "_blank",
                fontFamily: "mono",
                color: T("gray.500", "gray.300", a),
                children: pa(e, t)
            }), b || j ? n.jsxs(K, {
                spacing: "0.5",
                children: [b && n.jsx(St, {
                    label: "Token creator",
                    children: "👨‍💻"
                }), j && n.jsx(St, {
                    label: "You",
                    children: "👤"
                })]
            }) : null, s && !r && n.jsx(Je, {
                onClick: () => s(t ? ? null),
                ml: 1,
                variant: "unstyled",
                display: "flex",
                minW: "auto",
                h: "auto",
                color: T("gray.300", "gray.400", a),
                icon: n.jsx(L, {
                    as: Zr,
                    boxSize: {
                        base: "14px",
                        "2xl": "18px"
                    },
                    m: "2px"
                }),
                "aria-label": "Filter by this maker",
                _focus: {
                    boxShadow: "none"
                },
                _hover: {
                    "@media (hover: hover)": {
                        color: T("accent.500", "gray.0", a)
                    }
                },
                _active: {
                    color: T("accent.500", "gray.0", a)
                }
            }), s && r && n.jsx(Je, {
                onClick: () => s(null),
                ml: 1,
                variant: "unstyled",
                display: "flex",
                minW: "auto",
                h: "auto",
                color: T("gray.300", "gray.400", a),
                icon: n.jsx(L, {
                    as: G1,
                    boxSize: {
                        base: "14px",
                        "2xl": "18px"
                    },
                    m: "2px"
                }),
                "aria-label": "Clear filter",
                _focus: {
                    boxShadow: "none"
                },
                _hover: {
                    "@media (hover: hover)": {
                        color: T("gray.400", "gray.0", a)
                    }
                },
                _active: {
                    color: T("gray.400", "gray.0", a)
                }
            })]
        }) : n.jsx(k, {
            as: "span",
            fontWeight: "normal",
            color: "gray.500",
            opacity: .4,
            children: "-"
        })
    },
    co = {
        minW: "300px",
        gridTemplateColumns: "35fr 45fr 80fr 100fr 84fr",
        rowHeight: "35px"
    },
    Z1 = e => {
        var l, c;
        const {
            colorMode: t
        } = pe(), o = pr(), r = e.volumeUsd ? xn(e.volumeUsd, {
            min001: !0,
            min1: !1,
            prefix: "$",
            significantDigits: 0,
            maxDecimalPrecision: 0,
            largeNumberSuffix: {
                threshold: "hundred-thousand",
                significantDigits: 2
            }
        }) : void 0, s = e.priceUsd ? mo(e.priceUsd, {
            significantDigits: d => d.lt(1e3) ? 4 : 2,
            maxDecimalPrecision: d => {
                if (!d.lt(1)) return d.lt(1e3) ? 4 : 2
            },
            maxZeroes: 2
        }) : void 0;
        let i;
        s || (i = void 0);
        const a = d => d.stopPropagation();
        return n.jsxs(I, {
            as: "td",
            display: "flex",
            flexDir: "column",
            alignItems: "stretch",
            h: "100%",
            padding: "0",
            minW: co.minW,
            color: e.baseColor,
            fontSize: "sm",
            fontWeight: "semibold",
            borderBottomWidth: 1,
            borderColor: T("gray.50", "blue.900", t),
            onClick: o.onToggle,
            children: [n.jsxs(I, {
                display: "grid",
                gridTemplateColumns: co.gridTemplateColumns,
                minH: co.rowHeight,
                alignItems: "center",
                sx: {
                    "> div": {
                        display: "flex",
                        alignItems: "center"
                    }
                },
                bg: e.gradient,
                children: [n.jsx(so, {
                    size: "20px",
                    bg: e.baseColor,
                    color: "white",
                    ml: "1",
                    textTransform: "uppercase",
                    children: e.logType[0]
                }), n.jsx(Ic, {
                    as: "div",
                    timestamp: e.timestamp,
                    fontFamily: "mono",
                    fontWeight: "normal",
                    fontSize: "xs",
                    color: "gray.500",
                    compact: !0
                }), (e.logType === "buy" || e.logType === "sell") && n.jsxs(n.Fragment, {
                    children: [r ? n.jsx(I, {
                        children: r
                    }) : n.jsx(I, {
                        fontWeight: "normal",
                        color: "gray.500",
                        children: "-"
                    }), (s || i) && n.jsx(I, {
                        fontSize: "xs",
                        fontWeight: "normal",
                        children: s ? ? i
                    }), !s && !i && n.jsx(I, {
                        fontSize: "xs",
                        fontWeight: "normal",
                        color: "gray.500",
                        children: "-"
                    })]
                }), (e.logType === "add" || e.logType === "remove") && n.jsx(n.Fragment, {
                    children: n.jsxs(I, {
                        gridColumn: "span 2",
                        display: "flex",
                        alignItems: "center",
                        gap: "1",
                        fontWeight: "normal",
                        fontSize: "xs",
                        children: [n.jsx(k, {
                            fontWeight: "semibold",
                            children: e.logType === "add" ? "+" : "-"
                        }), n.jsx(k, {
                            maxW: "25vw",
                            isTruncated: !0,
                            children: It(e.amount0)
                        }), n.jsx(k, {
                            children: "/"
                        }), n.jsx(k, {
                            maxW: "25vw",
                            isTruncated: !0,
                            children: It(e.amount1)
                        })]
                    })
                }), n.jsx(I, {
                    fontWeight: "normal",
                    onClick: a,
                    children: n.jsx(Wd, {
                        chainId: e.chainId,
                        maker: e.maker,
                        makerScreener: e.makerScreener,
                        isMakerFiltered: e.isMakerFiltered,
                        onMakerFilterChange: e.onMakerFilterChange,
                        highlightAddresses: e.highlightAddresses
                    })
                })]
            }), o.isOpen && n.jsxs(I, {
                display: "flex",
                flexDir: "column",
                gap: "2",
                py: "2",
                bg: T("gray.75", "blue.975", t),
                children: [n.jsx(I, {
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    gap: "3",
                    fontWeight: "normal",
                    color: T("gray.700", "gray.200", t),
                    children: n.jsxs(k, {
                        children: [n.jsxs(k, {
                            fontWeight: "semibold",
                            children: [yc(e.logType), " ", (e.logType === "add" || e.logType === "remove") && " liquidity"]
                        }), " ", "@", " ", n.jsxs(we, {
                            href: (c = (l = e.blockExplorer) == null ? void 0 : l.txnsURL) == null ? void 0 : c.call(l, e.txnHash),
                            rel: "noopener noreferrer",
                            target: "_blank",
                            display: "inline-flex",
                            alignItems: "center",
                            gap: "3px",
                            onClick: a,
                            children: [n.jsx(k, {
                                textDecor: "underline",
                                children: ci(e.timestamp, "MMM d hh:mm:ss a")
                            }), n.jsx(L, {
                                as: yt,
                                boxSize: "10px"
                            })]
                        })]
                    })
                }), n.jsxs(I, {
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    gap: "1",
                    children: [n.jsxs(k, {
                        maxW: "40vw",
                        isTruncated: !0,
                        children: [It(e.logType === "buy" ? e.amount1 : e.amount0), " ", e.logType === "buy" ? e.quoteTokenSymbol : e.baseTokenSymbol]
                    }), n.jsx(L, {
                        as: e.logType === "buy" || e.logType === "sell" ? q1 : Kh,
                        color: "gray.500"
                    }), n.jsxs(k, {
                        maxW: "40vw",
                        isTruncated: !0,
                        children: [It(e.logType === "buy" ? e.amount0 : e.amount1), " ", e.logType === "buy" ? e.baseTokenSymbol : e.quoteTokenSymbol]
                    })]
                })]
            })]
        })
    },
    J1 = e => "txnType" in e ? e.txnType : e.logType,
    eb = e => {
        let t = "inherit";
        return e.logType === "buy" ? t = T("green.500", "green.400", e.colorMode) : e.logType === "sell" ? t = T("red.500", "red.400", e.colorMode) : e.logType === "add" ? t = T("green.600", "green.300", e.colorMode) : e.logType === "remove" && (t = T("red.600", "red.300", e.colorMode)), t
    },
    tb = e => {
        if (!e.volumeUsd || !e.pairVolumeUsdH24) return 0;
        const t = Math.max(1e3, Math.floor(e.pairVolumeUsdH24 * .005)),
            o = hi(e.volumeUsd, t);
        return Math.ceil(o.toNumber())
    },
    nb = e => e.volumeThreshold < 1 || e.logType !== "buy" && e.logType !== "sell" ? void 0 : `linear-gradient(to right, ${e.logType=="buy"?"rgba(72, 187, 120, 0.10)":"rgba(244, 91, 91, 0.06)"} ${e.volumeThreshold}%, rgba(0,0,0,0) ${e.volumeThreshold}%)`,
    Nn = {
        minW: "800px",
        gridTemplateColumns: {
            base: "140px 80px 1fr 1.25fr 1.25fr 1.25fr 130px 50px",
            "2xl": "165px 100px 1fr 1.25fr 1.25fr 1.25fr 150px 60px"
        },
        rowHeight: "36px"
    },
    ob = e => {
        var i, a;
        const {
            colorMode: t
        } = pe(), o = e.volumeUsd ? xn(e.volumeUsd, {
            min001: !0,
            min1: !1,
            prefix: void 0,
            significantDigits: l => l.lt(1e5) ? 2 : 0,
            maxDecimalPrecision: 2,
            largeNumberSuffix: {
                threshold: "million",
                significantDigits: 2
            }
        }) : void 0, r = e.priceUsd ? mo(e.priceUsd, {
            significantDigits: l => l.lt(1e3) ? 4 : 2,
            maxDecimalPrecision: l => {
                if (!l.lt(1)) return l.lt(1e3) ? 4 : 2
            }
        }) : void 0;
        let s;
        return r || (s = void 0), n.jsxs(I, {
            as: "td",
            display: "grid",
            alignItems: "stretch",
            minH: Nn.rowHeight,
            padding: "0",
            gridTemplateColumns: Nn.gridTemplateColumns,
            minW: Nn.minW,
            color: e.baseColor,
            fontSize: {
                base: "xs",
                "2xl": "md"
            },
            fontWeight: "semibold",
            wordBreak: "break-word",
            sx: {
                "> div": {
                    display: "flex",
                    alignItems: "center",
                    boxSizing: "border-box",
                    px: {
                        base: 2,
                        "2xl": 4
                    },
                    borderWidth: 1,
                    borderLeftWidth: 0,
                    borderTopWidth: 0,
                    borderColor: T("gray.50", "blue.875", t)
                },
                "> div:last-of-type": {
                    borderRightWidth: 0
                }
            },
            children: [n.jsxs(I, {
                fontWeight: "normal",
                color: T("gray.600", "blue.500", t),
                fontSize: {
                    base: "xs",
                    "2xl": "sm"
                },
                children: [!e.useTimeAgo && ci(e.timestamp, "MMM d hh:mm:ss a"), e.useTimeAgo && n.jsx(Ic, {
                    timestamp: e.timestamp,
                    fontFamily: "mono",
                    enableTooltip: !0
                })]
            }), n.jsx(I, {
                justifyContent: "center",
                fontWeight: "normal",
                fontStyle: e.logType === "add" || e.logType === "remove" ? "italic" : void 0,
                children: yc(e.logType)
            }), o ? n.jsx(I, {
                justifyContent: "right",
                bg: e.gradient,
                children: o
            }) : n.jsx(I, {
                justifyContent: "right",
                fontWeight: "normal",
                color: "gray.500",
                children: "-"
            }), n.jsx(I, {
                justifyContent: "right",
                children: It(e.amount0)
            }), n.jsx(I, {
                justifyContent: "right",
                children: It(e.amount1)
            }), (r || s) && n.jsx(I, {
                justifyContent: "right",
                children: r ? ? s
            }), !r && !s && n.jsx(I, {
                justifyContent: "right",
                fontWeight: "normal",
                color: "gray.500",
                children: "-"
            }), n.jsx(I, {
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontWeight: "normal",
                sx: {
                    padding: "0 !important"
                },
                children: n.jsx(Wd, {
                    chainId: e.chainId,
                    maker: e.maker,
                    makerScreener: e.makerScreener,
                    isMakerFiltered: e.isMakerFiltered,
                    onMakerFilterChange: e.onMakerFilterChange,
                    highlightAddresses: e.highlightAddresses
                })
            }), e.blockExplorer && n.jsx(I, {
                fontWeight: "normal",
                display: "flex",
                sx: {
                    padding: "0 !important"
                },
                children: n.jsx(we, {
                    title: "Open in block explorer",
                    href: (a = (i = e.blockExplorer).txnsURL) == null ? void 0 : a.call(i, e.txnHash),
                    rel: "noopener noreferrer",
                    target: "_blank",
                    textAlign: "center",
                    flex: 1,
                    h: "100%",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    color: T("gray.300", "gray.400", t),
                    _hover: {
                        "@media (hover: hover)": {
                            bg: T("gray.75", "blue.850", t)
                        }
                    },
                    _active: {
                        bg: T("gray.75", "blue.850", t)
                    },
                    children: n.jsx(L, {
                        as: yt
                    })
                })
            })]
        })
    },
    rb = M.memo(({
        layout: e,
        chainId: t,
        baseTokenSymbol: o,
        quoteTokenSymbol: r,
        log: s,
        pairVolumeUsdH24: i,
        useTimeAgo: a,
        isMakerFiltered: l,
        onMakerFilterChange: c,
        highlightAddresses: d
    }) => {
        const {
            colorMode: u
        } = pe(), h = J1(s), m = In(t), g = eb({
            logType: h,
            colorMode: u
        }), p = "priceUsd" in s ? s.priceUsd : void 0, b = "volumeUsd" in s ? s.volumeUsd : void 0, j = nb({
            logType: h,
            volumeThreshold: tb({
                volumeUsd: b,
                pairVolumeUsdH24: i
            }),
            colorMode: u
        });
        return e === "wide" ? n.jsx(ob, {
            chainId: t,
            logType: h,
            txnHash: s.txnHash,
            maker: s.maker,
            makerScreener: s.makerScreener,
            timestamp: s.blockTimestamp,
            volumeUsd: b,
            priceUsd: p,
            priceNative: void 0,
            amount0: s.amount0,
            amount1: s.amount1,
            baseColor: g,
            gradient: j,
            useTimeAgo: a,
            isMakerFiltered: l,
            onMakerFilterChange: c,
            blockExplorer: m,
            highlightAddresses: d
        }) : n.jsx(Z1, {
            chainId: t,
            baseTokenSymbol: o,
            quoteTokenSymbol: r,
            logType: h,
            txnHash: s.txnHash,
            maker: s.maker,
            makerScreener: s.makerScreener,
            timestamp: s.blockTimestamp,
            volumeUsd: b,
            priceUsd: p,
            priceNative: void 0,
            amount0: s.amount0,
            amount1: s.amount1,
            baseColor: g,
            gradient: j,
            useTimeAgo: a,
            isMakerFiltered: l,
            onMakerFilterChange: c,
            blockExplorer: m,
            highlightAddresses: d
        })
    }, (e, t) => !(e.layout !== t.layout || e.log.txnHash !== t.log.txnHash || e.log.logIndex !== t.log.logIndex || e.useTimeAgo !== t.useTimeAgo || e.highlightAddresses !== t.highlightAddresses)),
    sb = Us(qe.div),
    ib = e => {
        var h, m, g;
        const {
            colorMode: t
        } = pe(), {
            layout: o,
            tradingHistory: r,
            animationTimestamp: s
        } = M.useContext(qi);
        s && !s.current && (s.current = (h = r[0]) == null ? void 0 : h.blockTimestamp);
        const i = 10,
            a = Math.min(r.length, i) - e["data-item-index"],
            l = r[e["data-item-index"]],
            c = s !== void 0 && s.current !== void 0 && e["data-item-index"] < i && l && s.current < l.blockTimestamp;
        c && r[0] && (s.current = r[0].blockTimestamp - 1);
        const d = c ? `${(m=r[e["data-item-index"]])==null?void 0:m.txnHash}:${(g=r[e["data-item-index"]])==null?void 0:g.logIndex}` : void 0,
            u = o === "wide" ? Nn.rowHeight : co.rowHeight;
        return n.jsx(sb, {
            as: "tr",
            variants: {
                x: {
                    x: 0,
                    transition: {
                        duration: .3,
                        delay: a * .015
                    }
                },
                opacity: {
                    opacity: 1,
                    transition: {
                        duration: .6,
                        delay: a * .015
                    }
                }
            },
            animate: c ? ["x", "opacity"] : void 0,
            initial: c ? {
                x: -50,
                opacity: 0
            } : void 0,
            bg: T("white", "blue.950", t),
            "data-index": e["data-index"],
            "data-item-index": e["data-item-index"],
            "data-known-size": e["data-known-size"],
            height: u,
            _hover: o === "wide" ? {
                "@media (hover: hover)": {
                    bg: T("gray.25", "blue.900", t)
                }
            } : void 0,
            style: e.style,
            children: e.children
        }, d)
    },
    ab = M.forwardRef(({ ...e
    }, t) => {
        const {
            colorMode: o
        } = pe(), r = ui({
            colorMode: o
        });
        return n.jsx(I, {
            ref: t,
            ...e,
            bg: T("white", "blue.950", o),
            sx: r
        })
    }),
    tn = e => ({
        variant: "unstyled",
        bg: "transparent",
        borderRadius: "none",
        borderWidth: "none",
        justifyContent: "flex-end",
        textAlign: "right",
        paddingInlineEnd: 0,
        paddingInlineStart: 0,
        flex: 1,
        pr: 4,
        rightIcon: n.jsx(L, {
            as: e.isActive ? K1 : Zr,
            ml: 1,
            pos: "relative",
            top: "-0.5px",
            color: e.isActive ? T("accent.500", "accent.400", e.colorMode) : void 0,
            opacity: e.isActive ? 1 : .5,
            boxSize: "16px"
        }),
        iconSpacing: 0,
        _hover: {},
        _focus: {
            boxShadow: "none"
        },
        _disabled: {
            opacity: 1,
            cursor: "wait"
        },
        sx: { ...e.isActive ? void 0 : {
                "@media (hover: hover) ": {
                    "&:enabled:hover": {
                        svg: {
                            opacity: 1,
                            color: T("accent.500", "accent.400", e.colorMode)
                        }
                    }
                },
                "&:active": {
                    svg: {
                        opacity: 1,
                        color: T("accent.500", "accent.400", e.colorMode)
                    }
                }
            },
            "> span": {
                minW: "auto"
            }
        }
    }),
    Dd = [{
        label: ">$100",
        min: 100,
        max: null
    }, {
        label: ">$500",
        min: 500,
        max: null
    }, {
        label: ">$1,000",
        min: 1e3,
        max: null
    }, {
        label: ">$2,500",
        min: 2500,
        max: null
    }, {
        label: ">$5,000",
        min: 5e3,
        max: null
    }, {
        label: ">$10,000",
        min: 1e4,
        max: null
    }],
    Qi = "35px",
    lb = ({
        filters: e,
        baseTokenSymbol: t,
        quoteTokenSymbol: o,
        useTimeAgo: r,
        onToggleUseTimeAgo: s,
        onTypeFilterChange: i,
        onSetActiveFilterModal: a,
        isFilteringDisabled: l
    }) => {
        const {
            colorMode: c
        } = pe();
        return n.jsxs(I, {
            as: "tr",
            minW: Nn.minW,
            w: "100%",
            h: Qi,
            display: "grid",
            gridTemplateColumns: Nn.gridTemplateColumns,
            sx: {
                "> th": {
                    display: "flex",
                    alignItems: "center",
                    bg: T("gray.75", "blue.875", c),
                    borderWidth: 1,
                    borderLeftWidth: 0,
                    borderTopWidth: 0,
                    borderColor: T("gray.125", "blue.825", c),
                    fontSize: "xs",
                    fontWeight: "semibold",
                    wordBreak: "break-word"
                },
                "> th:last-of-type": {
                    borderRightWidth: 0
                },
                "> th > span": {
                    flex: 1,
                    px: {
                        base: 2,
                        "2xl": 4
                    },
                    textTransform: "uppercase"
                },
                "> th > button": {
                    h: "100%",
                    display: "flex",
                    fontSize: "xs",
                    textTransform: "uppercase"
                }
            },
            children: [n.jsxs(I, {
                as: "th",
                display: "flex",
                alignItems: "center",
                justifyContent: "flex-start",
                textAlign: "left",
                children: [n.jsx(k, {
                    flex: "0 !important",
                    pr: "0 !important",
                    wordBreak: "normal",
                    children: "Date"
                }), n.jsx(Je, {
                    onClick: s,
                    variant: "unstyled",
                    icon: n.jsx(L, {
                        as: r ? Qh : $h,
                        boxSize: "14px",
                        pos: "relative",
                        top: "-1px"
                    }),
                    title: "Toggle relative time",
                    "aria-label": "Toggle relative time",
                    minW: "24px",
                    color: T("gray.300", "gray.600", c),
                    _hover: {
                        "@media (hover: hover)": {
                            color: T("gray.400", "gray.400", c)
                        }
                    },
                    _active: {
                        color: T("gray.400", "gray.400", c)
                    }
                })]
            }), n.jsx(I, {
                as: "th",
                display: "flex",
                justifyContent: "center",
                children: n.jsxs(Xn, {
                    strategy: "fixed",
                    children: [n.jsx(qn, {
                        as: ue,
                        ...tn({
                            colorMode: c,
                            isActive: e.type !== null
                        }),
                        flex: "initial",
                        pr: 0,
                        isDisabled: l,
                        children: "Type"
                    }), n.jsx(Io, {
                        children: n.jsxs(Gn, {
                            minW: 0,
                            w: "150px",
                            zIndex: "modal",
                            children: [n.jsx(tt, {
                                isChecked: e.type === null,
                                onClick: () => i(null),
                                children: "All"
                            }), n.jsx(tt, {
                                isChecked: e.type === "buyOrSell",
                                onClick: () => i("buyOrSell"),
                                children: "Buy / Sell"
                            }), n.jsx(tt, {
                                isChecked: e.type === "buy",
                                onClick: () => i("buy"),
                                children: "Buy"
                            }), n.jsx(tt, {
                                isChecked: e.type === "sell",
                                onClick: () => i("sell"),
                                children: "Sell"
                            }), n.jsx(tt, {
                                isChecked: e.type === "addOrRemove",
                                onClick: () => i("addOrRemove"),
                                children: "Add / Remove"
                            }), n.jsx(tt, {
                                isChecked: e.type === "add",
                                onClick: () => i("add"),
                                children: "Add"
                            }), n.jsx(tt, {
                                isChecked: e.type === "remove",
                                onClick: () => i("remove"),
                                children: "Remove"
                            })]
                        })
                    })]
                })
            }), n.jsx(I, {
                as: "th",
                children: n.jsx(ue, {
                    onClick: () => a({
                        type: "minMax",
                        filterKey: "amountUsd",
                        label: "Amount USD",
                        leftInputAddon: "$",
                        value: e.amountUsd,
                        presets: Dd
                    }),
                    ...tn({
                        colorMode: c,
                        isActive: e.amountUsd.min !== null || e.amountUsd.max !== null
                    }),
                    isDisabled: l,
                    children: "USD"
                })
            }), n.jsx(I, {
                as: "th",
                overflow: "hidden",
                children: n.jsx(ue, {
                    onClick: () => a({
                        type: "minMax",
                        filterKey: "amount0",
                        label: `Amount ${t}`,
                        rightInputAddon: t,
                        value: e.amount0
                    }),
                    ...tn({
                        colorMode: c,
                        isActive: e.amount0.min !== null || e.amount0.max !== null
                    }),
                    isDisabled: l,
                    children: n.jsx(k, {
                        as: "span",
                        noOfLines: 1,
                        children: t
                    })
                })
            }), n.jsx(I, {
                as: "th",
                overflow: "hidden",
                children: n.jsx(ue, {
                    onClick: () => a({
                        type: "minMax",
                        filterKey: "amount1",
                        label: `Amount ${o}`,
                        rightInputAddon: o,
                        value: e.amount1
                    }),
                    ...tn({
                        colorMode: c,
                        isActive: e.amount1.min !== null || e.amount1.max !== null
                    }),
                    isDisabled: l,
                    children: n.jsx(k, {
                        children: o
                    })
                })
            }), n.jsx(I, {
                as: "th",
                textAlign: "right",
                children: n.jsx(k, {
                    children: "Price"
                })
            }), n.jsx(I, {
                as: "th",
                textAlign: "right",
                children: n.jsx(ue, {
                    onClick: () => a({
                        type: "text",
                        filterKey: "maker",
                        label: "by Maker",
                        placeholder: "0x123...",
                        value: e.maker
                    }),
                    ...tn({
                        colorMode: c,
                        isActive: e.maker !== null
                    }),
                    isDisabled: l,
                    children: "Maker"
                })
            }), n.jsx(I, {
                as: "th",
                textAlign: "right",
                children: n.jsx(k, {
                    children: "Txn"
                })
            })]
        })
    },
    cb = ({
        filters: e,
        onTypeFilterChange: t,
        onSetActiveFilterModal: o,
        isFilteringDisabled: r
    }) => {
        const {
            colorMode: s
        } = pe();
        return n.jsxs(I, {
            as: "tr",
            minW: co.minW,
            w: "100%",
            h: "30px",
            position: "relative",
            top: "-1px",
            display: "grid",
            gridTemplateColumns: "80fr 80fr 100fr 84fr",
            sx: {
                "> th": {
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    textAlign: "center",
                    bg: T("gray.75", "blue.875", s),
                    borderWidth: 1,
                    borderLeftWidth: 0,
                    borderTopWidth: 0,
                    borderColor: T("gray.125", "blue.825", s),
                    fontSize: "xs",
                    fontWeight: "semibold",
                    wordBreak: "break-word"
                },
                "> th:last-of-type": {
                    borderRightWidth: 0
                },
                "> th > span": {
                    flex: 1,
                    textTransform: "uppercase"
                },
                "> th > button": {
                    h: "100%",
                    display: "flex",
                    fontSize: "xs",
                    textTransform: "uppercase",
                    pr: 0,
                    justifyContent: "center"
                }
            },
            children: [n.jsx(I, {
                as: "th",
                display: "flex",
                children: n.jsxs(Xn, {
                    strategy: "fixed",
                    children: [n.jsx(qn, {
                        as: ue,
                        ...tn({
                            colorMode: s,
                            isActive: e.type !== null
                        }),
                        flex: "initial",
                        pr: 0,
                        isDisabled: r,
                        children: "Txn"
                    }), n.jsx(Io, {
                        children: n.jsxs(Gn, {
                            minW: 0,
                            w: "150px",
                            zIndex: "modal",
                            children: [n.jsx(tt, {
                                isChecked: e.type === null,
                                onClick: () => t(null),
                                children: "All"
                            }), n.jsx(tt, {
                                isChecked: e.type === "buyOrSell",
                                onClick: () => t("buyOrSell"),
                                children: "Buy / Sell"
                            }), n.jsx(tt, {
                                isChecked: e.type === "buy",
                                onClick: () => t("buy"),
                                children: "Buy"
                            }), n.jsx(tt, {
                                isChecked: e.type === "sell",
                                onClick: () => t("sell"),
                                children: "Sell"
                            }), n.jsx(tt, {
                                isChecked: e.type === "addOrRemove",
                                onClick: () => t("addOrRemove"),
                                children: "Add / Remove"
                            }), n.jsx(tt, {
                                isChecked: e.type === "add",
                                onClick: () => t("add"),
                                children: "Add"
                            }), n.jsx(tt, {
                                isChecked: e.type === "remove",
                                onClick: () => t("remove"),
                                children: "Remove"
                            })]
                        })
                    })]
                })
            }), n.jsx(I, {
                as: "th",
                children: n.jsx(ue, {
                    onClick: () => o({
                        type: "minMax",
                        filterKey: "amountUsd",
                        label: "Amount USD",
                        leftInputAddon: "$",
                        value: e.amountUsd,
                        presets: Dd
                    }),
                    ...tn({
                        colorMode: s,
                        isActive: e.amountUsd.min !== null || e.amountUsd.max !== null
                    }),
                    isDisabled: r,
                    children: "USD"
                })
            }), n.jsx(I, {
                as: "th",
                children: n.jsx(k, {
                    children: "Price"
                })
            }), n.jsx(I, {
                as: "th",
                children: n.jsx(ue, {
                    onClick: () => o({
                        type: "text",
                        filterKey: "maker",
                        label: "by Maker",
                        placeholder: "0x123...",
                        value: e.maker
                    }),
                    ...tn({
                        colorMode: s,
                        isActive: e.maker !== null
                    }),
                    isDisabled: r,
                    children: "Maker"
                })
            })]
        })
    };

function Ld(e, t) {
    var o = {};
    for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && t.indexOf(r) < 0 && (o[r] = e[r]);
    if (e != null && typeof Object.getOwnPropertySymbols == "function")
        for (var s = 0, r = Object.getOwnPropertySymbols(e); s < r.length; s++) t.indexOf(r[s]) < 0 && Object.prototype.propertyIsEnumerable.call(e, r[s]) && (o[r[s]] = e[r[s]]);
    return o
}
var wo;
(function(e) {
    e.event = "event", e.props = "prop"
})(wo || (wo = {}));

function nn() {}

function kr(e) {
    return !!(e || "").match(/\d/)
}

function uo(e) {
    return e == null
}

function Nd(e) {
    return typeof e == "number" && isNaN(e)
}

function Hd(e) {
    return e.replace(/[-[\]/{}()*+?.\\^$|]/g, "\\$&")
}

function db(e) {
    switch (e) {
        case "lakh":
            return /(\d+?)(?=(\d\d)+(\d)(?!\d))(\.\d+)?/g;
        case "wan":
            return /(\d)(?=(\d{4})+(?!\d))/g;
        case "thousand":
        default:
            return /(\d)(?=(\d{3})+(?!\d))/g
    }
}

function ub(e, t, o) {
    var r = db(o),
        s = e.search(/[1-9]/);
    return s = s === -1 ? e.length : s, e.substring(0, s) + e.substring(s, e.length).replace(r, "$1" + t)
}

function hb(e) {
    var t = f.useRef(e);
    t.current = e;
    var o = f.useRef(function() {
        for (var r = [], s = arguments.length; s--;) r[s] = arguments[s];
        return t.current.apply(t, r)
    });
    return o.current
}

function $i(e, t) {
    t === void 0 && (t = !0);
    var o = e[0] === "-",
        r = o && t;
    e = e.replace("-", "");
    var s = e.split("."),
        i = s[0],
        a = s[1] || "";
    return {
        beforeDecimal: i,
        afterDecimal: a,
        hasNegation: o,
        addNegation: r
    }
}

function fb(e) {
    if (!e) return e;
    var t = e[0] === "-";
    t && (e = e.substring(1, e.length));
    var o = e.split("."),
        r = o[0].replace(/^0+/, "") || "0",
        s = o[1] || "";
    return (t ? "-" : "") + r + (s ? "." + s : "")
}

function _d(e, t, o) {
    for (var r = "", s = o ? "0" : "", i = 0; i <= t - 1; i++) r += e[i] || s;
    return r
}

function El(e, t) {
    return Array(t + 1).join(e)
}

function Od(e) {
    var t = e + "",
        o = t[0] === "-" ? "-" : "";
    o && (t = t.substring(1));
    var r = t.split(/[eE]/g),
        s = r[0],
        i = r[1];
    if (i = Number(i), !i) return o + s;
    s = s.replace(".", "");
    var a = 1 + i,
        l = s.length;
    return a < 0 ? s = "0." + El("0", Math.abs(a)) + s : a >= l ? s = s + El("0", a - l) : s = (s.substring(0, a) || "0") + "." + s.substring(a), o + s
}

function Pl(e, t, o) {
    if (["", "-"].indexOf(e) !== -1) return e;
    var r = (e.indexOf(".") !== -1 || o) && t,
        s = $i(e),
        i = s.beforeDecimal,
        a = s.afterDecimal,
        l = s.hasNegation,
        c = parseFloat("0." + (a || "0")),
        d = a.length <= t ? "0." + a : c.toFixed(t),
        u = d.split("."),
        h = i.split("").reverse().reduce(function(b, j, y) {
            return b.length > y ? (Number(b[0]) + Number(j)).toString() + b.substring(1, b.length) : j + b
        }, u[0]),
        m = _d(u[1] || "", t, o),
        g = l ? "-" : "",
        p = r ? "." : "";
    return "" + g + h + p + m
}

function Wn(e, t) {
    if (e.value = e.value, e !== null) {
        if (e.createTextRange) {
            var o = e.createTextRange();
            return o.move("character", t), o.select(), !0
        }
        return e.selectionStart || e.selectionStart === 0 ? (e.focus(), e.setSelectionRange(t, t), !0) : (e.focus(), !1)
    }
}

function gb(e, t) {
    for (var o = 0, r = 0, s = e.length, i = t.length; e[o] === t[o] && o < s;) o++;
    for (; e[s - 1 - r] === t[i - 1 - r] && i - r > o && s - r > o;) r++;
    return {
        from: {
            start: o,
            end: s - r
        },
        to: {
            start: o,
            end: i - r
        }
    }
}

function mb(e, t, o) {
    return Math.min(Math.max(e, t), o)
}

function Rl(e) {
    return Math.max(e.selectionStart, e.selectionEnd)
}

function pb() {
    return typeof navigator < "u" && !(navigator.platform && /iPhone|iPod/.test(navigator.platform))
}

function xb(e) {
    return {
        from: {
            start: 0,
            end: 0
        },
        to: {
            start: 0,
            end: e.length
        },
        lastValue: ""
    }
}

function bb(e, t, o, r, s, i) {
    var a = s.findIndex(function(S) {
            return S
        }),
        l = e.slice(0, a);
    !t && !o.startsWith(l) && (o = l + o, r = r + l.length);
    for (var c = o.length, d = e.length, u = {}, h = new Array(c), m = 0; m < c; m++) {
        h[m] = -1;
        for (var g = 0, p = d; g < p; g++)
            if (o[m] === e[g] && u[g] !== !0) {
                h[m] = g, u[g] = !0;
                break
            }
    }
    for (var b = r; b < c && (h[b] === -1 || !i(o[b]));) b++;
    var j = b === c || h[b] === -1 ? d : h[b];
    for (b = r - 1; b > 0 && h[b] === -1;) b--;
    var y = b === -1 || h[b] === -1 ? 0 : h[b] + 1;
    return y > j ? j : r - y < j - r ? y : j
}

function zl(e, t, o, r) {
    var s = e.length;
    if (t = mb(t, 0, s), r === "left") {
        for (; t >= 0 && !o[t];) t--;
        t === -1 && (t = o.indexOf(!0))
    } else {
        for (; t <= s && !o[t];) t++;
        t > s && (t = o.lastIndexOf(!0))
    }
    return t === -1 && (t = s), t
}

function vb(e) {
    for (var t = Array.from({
            length: e.length + 1
        }).map(function() {
            return !0
        }), o = 0, r = t.length; o < r; o++) t[o] = !!(kr(e[o]) || kr(e[o - 1]));
    return t
}

function Ud(e, t, o, r, s, i) {
    i === void 0 && (i = nn);
    var a = f.useRef(),
        l = hb(function(m) {
            var g, p;
            return uo(m) || Nd(m) ? (p = "", g = "") : typeof m == "number" || o ? (p = typeof m == "number" ? Od(m) : m, g = r(p)) : (p = s(m, void 0), g = m), {
                formattedValue: g,
                numAsString: p
            }
        }),
        c = f.useState(function() {
            return l(t)
        }),
        d = c[0],
        u = c[1],
        h = function(m, g) {
            u({
                formattedValue: m.formattedValue,
                numAsString: m.value
            }), i(m, g)
        };
    return f.useMemo(function() {
        uo(e) ? a.current = void 0 : (a.current = l(e), u(a.current))
    }, [e, l]), [d, h]
}

function yb(e) {
    return e.replace(/[^0-9]/g, "")
}

function jb(e) {
    return e
}

function Sb(e) {
    var t = e.type;
    t === void 0 && (t = "text");
    var o = e.displayType;
    o === void 0 && (o = "input");
    var r = e.customInput,
        s = e.renderText,
        i = e.getInputRef,
        a = e.format;
    a === void 0 && (a = jb);
    var l = e.removeFormatting;
    l === void 0 && (l = yb);
    var c = e.defaultValue,
        d = e.valueIsNumericString,
        u = e.onValueChange,
        h = e.isAllowed,
        m = e.onChange;
    m === void 0 && (m = nn);
    var g = e.onKeyDown;
    g === void 0 && (g = nn);
    var p = e.onMouseUp;
    p === void 0 && (p = nn);
    var b = e.onFocus;
    b === void 0 && (b = nn);
    var j = e.onBlur;
    j === void 0 && (j = nn);
    var y = e.value,
        S = e.getCaretBoundary;
    S === void 0 && (S = vb);
    var w = e.isValidInputCharacter;
    w === void 0 && (w = kr);
    var v = Ld(e, ["type", "displayType", "customInput", "renderText", "getInputRef", "format", "removeFormatting", "defaultValue", "valueIsNumericString", "onValueChange", "isAllowed", "onChange", "onKeyDown", "onMouseUp", "onFocus", "onBlur", "value", "getCaretBoundary", "isValidInputCharacter"]),
        x = Ud(y, c, !!d, a, l, u),
        C = x[0],
        E = C.formattedValue,
        R = C.numAsString,
        B = x[1],
        A = f.useRef(),
        P = function(F, G) {
            A.current = F.formattedValue, B(F, G)
        };
    f.useEffect(function() {
        var F = a(R);
        if (A.current === void 0 || F !== A.current) {
            var G = z.current;
            ze({
                formattedValue: F,
                numAsString: R,
                input: G,
                setCaretPosition: !0,
                source: wo.props,
                event: void 0
            })
        }
    });
    var D = f.useState(!1),
        O = D[0],
        V = D[1],
        z = f.useRef(null),
        H = f.useRef({
            setCaretTimeout: null,
            focusTimeout: null
        });
    f.useEffect(function() {
        return V(!0),
            function() {
                clearTimeout(H.current.setCaretTimeout), clearTimeout(H.current.focusTimeout)
            }
    }, []);
    var oe = a,
        re = function(F, G) {
            var ce = parseFloat(G);
            return {
                formattedValue: F,
                value: G,
                floatValue: isNaN(ce) ? void 0 : ce
            }
        },
        ye = function(F, G, ce) {
            Wn(F, G), H.current.setCaretTimeout = setTimeout(function() {
                F.value === ce && Wn(F, G)
            }, 0)
        },
        fe = function(F, G, ce) {
            return zl(F, G, S(F), ce)
        },
        je = function(F, G, ce) {
            var Q = S(G),
                le = bb(G, E, F, ce, Q, w);
            return le = zl(G, le, Q), le
        },
        ze = function(F) {
            var G = F.formattedValue;
            G === void 0 && (G = "");
            var ce = F.input,
                Q = F.setCaretPosition;
            Q === void 0 && (Q = !0);
            var le = F.source,
                te = F.event,
                N = F.numAsString,
                ne = F.caretPos;
            if (ce) {
                if (ne === void 0 && Q) {
                    var Pe = F.inputValue || ce.value,
                        Ke = Rl(ce);
                    ce.value = G, ne = je(Pe, G, Ke)
                }
                ce.value = G, Q && ne !== void 0 && ye(ce, ne, G)
            }
            G !== E && P(re(G, N), {
                event: te,
                source: le
            })
        },
        Me = function(F, G, ce) {
            var Q = gb(E, F),
                le = Object.assign(Object.assign({}, Q), {
                    lastValue: E
                }),
                te = l(F, le),
                N = oe(te);
            if (h && !h(re(N, te))) {
                var ne = G.target,
                    Pe = Rl(ne),
                    Ke = je(F, E, Pe);
                return ye(ne, Ke, E), !1
            }
            return ze({
                formattedValue: N,
                numAsString: te,
                inputValue: F,
                event: G,
                source: ce,
                setCaretPosition: !0,
                input: G.target
            }), !0
        },
        Fe = function(F) {
            var G = F.target,
                ce = G.value,
                Q = Me(ce, F, wo.event);
            Q && m(F)
        },
        Be = function(F) {
            var G = F.target,
                ce = F.key,
                Q = G.selectionStart,
                le = G.selectionEnd,
                te = G.value;
            te === void 0 && (te = "");
            var N;
            if (ce === "ArrowLeft" || ce === "Backspace" ? N = Math.max(Q - 1, 0) : ce === "ArrowRight" ? N = Math.min(Q + 1, te.length) : ce === "Delete" && (N = Q), N === void 0 || Q !== le) {
                g(F);
                return
            }
            var ne = N;
            if (ce === "ArrowLeft" || ce === "ArrowRight") {
                var Pe = ce === "ArrowLeft" ? "left" : "right";
                ne = fe(te, N, Pe)
            } else ce === "Delete" && !w(te[N]) ? ne = fe(te, N, "right") : ce === "Backspace" && !w(te[N]) && (ne = fe(te, N, "left"));
            ne !== N && ye(G, ne, te), F.isUnitTestRun && ye(G, ne, te), g(F)
        },
        W = function(F) {
            var G = F.target,
                ce = G.selectionStart,
                Q = G.selectionEnd,
                le = G.value;
            if (le === void 0 && (le = ""), ce === Q) {
                var te = fe(le, ce);
                te !== ce && ye(G, te, le)
            }
            p(F)
        },
        se = function(F) {
            F.persist();
            var G = F.target;
            z.current = G, H.current.focusTimeout = setTimeout(function() {
                var ce = G.selectionStart,
                    Q = G.selectionEnd,
                    le = G.value;
                le === void 0 && (le = "");
                var te = fe(le, ce);
                te !== ce && !(ce === 0 && Q === le.length) && ye(G, te, le), b(F)
            }, 0)
        },
        J = function(F) {
            z.current = null, clearTimeout(H.current.focusTimeout), clearTimeout(H.current.setCaretTimeout), j(F)
        },
        de = O && pb() ? "numeric" : void 0,
        ie = Object.assign({
            inputMode: de
        }, v, {
            type: t,
            value: E,
            onChange: Fe,
            onKeyDown: Be,
            onMouseUp: W,
            onFocus: se,
            onBlur: J
        });
    if (o === "text") return s ? M.createElement(M.Fragment, null, s(E, v) || null) : M.createElement("span", Object.assign({}, v, {
        ref: i
    }), E);
    if (r) {
        var U = r;
        return M.createElement(U, Object.assign({}, ie, {
            ref: i
        }))
    }
    return M.createElement("input", Object.assign({}, ie, {
        ref: i
    }))
}

function Ml(e, t) {
    var o = t.decimalScale,
        r = t.fixedDecimalScale,
        s = t.prefix;
    s === void 0 && (s = "");
    var i = t.suffix;
    i === void 0 && (i = "");
    var a = t.allowNegative;
    a === void 0 && (a = !0);
    var l = t.thousandsGroupStyle;
    if (l === void 0 && (l = "thousand"), e === "" || e === "-") return e;
    var c = Jr(t),
        d = c.thousandSeparator,
        u = c.decimalSeparator,
        h = o !== 0 && e.indexOf(".") !== -1 || o && r,
        m = $i(e, a),
        g = m.beforeDecimal,
        p = m.afterDecimal,
        b = m.addNegation;
    return o !== void 0 && (p = _d(p, o, !!r)), d && (g = ub(g, d, l)), s && (g = s + g), i && (p = p + i), b && (g = "-" + g), e = g + (h && u || "") + p, e
}

function Jr(e) {
    var t = e.decimalSeparator;
    t === void 0 && (t = ".");
    var o = e.thousandSeparator,
        r = e.allowedDecimalSeparators;
    return o === !0 && (o = ","), r || (r = [t, "."]), {
        decimalSeparator: t,
        thousandSeparator: o,
        allowedDecimalSeparators: r
    }
}

function wb(e, t) {
    e === void 0 && (e = "");
    var o = new RegExp("(-)"),
        r = new RegExp("(-)(.)*(-)"),
        s = o.test(e),
        i = r.test(e);
    return e = e.replace(/-/g, ""), s && !i && t && (e = "-" + e), e
}

function Cb(e, t) {
    return new RegExp("(^-)|[0-9]|" + Hd(e), t ? "g" : void 0)
}

function kb(e, t, o) {
    t === void 0 && (t = xb(e));
    var r = o.allowNegative;
    r === void 0 && (r = !0);
    var s = o.prefix;
    s === void 0 && (s = "");
    var i = o.suffix;
    i === void 0 && (i = "");
    var a = o.decimalScale,
        l = t.from,
        c = t.to,
        d = c.start,
        u = c.end,
        h = Jr(o),
        m = h.allowedDecimalSeparators,
        g = h.decimalSeparator,
        p = e[u] === g;
    if (u - d === 1 && m.indexOf(e[d]) !== -1) {
        var b = a === 0 ? "" : g;
        e = e.substring(0, d) + b + e.substring(d + 1, e.length)
    }
    var j = !1;
    s.startsWith("-") ? j = e.startsWith("--") : i.startsWith("-") && e.length === i.length ? j = !1 : e[0] === "-" && (j = !0), j && (e = e.substring(1), d -= 1, u -= 1);
    var y = 0;
    e.startsWith(s) ? y += s.length : d < s.length && (y = d), e = e.substring(y), u -= y;
    var S = e.length,
        w = e.length - i.length;
    e.endsWith(i) ? S = w : u > e.length - i.length && (S = u), e = e.substring(0, S), e = wb(j ? "-" + e : e, r), e = (e.match(Cb(g, !0)) || []).join("");
    var v = e.indexOf(g);
    e = e.replace(new RegExp(Hd(g), "g"), function(B, A) {
        return A === v ? "." : ""
    });
    var x = $i(e, r),
        C = x.beforeDecimal,
        E = x.afterDecimal,
        R = x.addNegation;
    return c.end - c.start < l.end - l.start && C === "" && p && !parseFloat(E) && (e = R ? "-" : ""), e
}

function Tb(e, t) {
    var o = t.prefix;
    o === void 0 && (o = "");
    var r = t.suffix;
    r === void 0 && (r = "");
    var s = Array.from({
            length: e.length + 1
        }).map(function() {
            return !0
        }),
        i = e[0] === "-";
    s.fill(!1, 0, o.length + (i ? 1 : 0));
    var a = e.length;
    return s.fill(!1, a - r.length + 1, a + 1), s
}

function Ib(e) {
    var t = Jr(e),
        o = t.thousandSeparator,
        r = t.decimalSeparator;
    if (o === r) throw new Error(`
        Decimal separator can't be same as thousand separator.
        thousandSeparator: ` + o + ` (thousandSeparator = {true} is same as thousandSeparator = ",")
        decimalSeparator: ` + r + ` (default value for decimalSeparator is .)
     `)
}

function Ab(e) {
    var t = e.decimalSeparator;
    t === void 0 && (t = ".");
    var o = e.allowLeadingZeros,
        r = e.onKeyDown;
    r === void 0 && (r = nn);
    var s = e.onBlur;
    s === void 0 && (s = nn);
    var i = e.thousandSeparator,
        a = e.decimalScale,
        l = e.fixedDecimalScale,
        c = e.prefix;
    c === void 0 && (c = "");
    var d = e.defaultValue,
        u = e.value,
        h = e.valueIsNumericString,
        m = e.onValueChange,
        g = Ld(e, ["decimalSeparator", "allowedDecimalSeparators", "thousandsGroupStyle", "suffix", "allowNegative", "allowLeadingZeros", "onKeyDown", "onBlur", "thousandSeparator", "decimalScale", "fixedDecimalScale", "prefix", "defaultValue", "value", "valueIsNumericString", "onValueChange"]);
    Ib(e);
    var p = function(A) {
            return Ml(A, e)
        },
        b = function(A, P) {
            return kb(A, P, e)
        },
        j = h;
    uo(u) ? uo(d) || (j = h ? ? typeof d == "number") : j = h ? ? typeof u == "number";
    var y = function(A) {
            return uo(A) || Nd(A) ? A : (typeof A == "number" && (A = Od(A)), j && typeof a == "number" ? Pl(A, a, !!l) : A)
        },
        S = Ud(y(u), y(d), !!j, p, b, m),
        w = S[0],
        v = w.numAsString,
        x = w.formattedValue,
        C = S[1],
        E = function(A) {
            var P = A.target,
                D = A.key,
                O = P.selectionStart,
                V = P.selectionEnd,
                z = P.value;
            if (z === void 0 && (z = ""), O !== V) {
                r(A);
                return
            }
            D === "Backspace" && z[0] === "-" && O === c.length + 1 && Wn(P, 1);
            var H = Jr(e),
                oe = H.decimalSeparator;
            D === "Backspace" && z[O - 1] === oe && a && l && (Wn(P, O - 1), A.preventDefault());
            var re = i === !0 ? "," : i;
            D === "Backspace" && z[O - 1] === re && Wn(P, O - 1), D === "Delete" && z[O] === re && Wn(P, O + 1), r(A)
        },
        R = function(A) {
            var P = v;
            if (P.match(/\d/g) || (P = ""), o || (P = fb(P)), l && a && (P = Pl(P, a, l)), P !== v) {
                var D = Ml(P, e);
                C({
                    formattedValue: D,
                    value: P,
                    floatValue: parseFloat(P)
                }, {
                    event: A,
                    source: wo.event
                })
            }
            s(A)
        },
        B = function(A) {
            return A === t ? !0 : kr(A)
        };
    return Object.assign(Object.assign({}, g), {
        value: x,
        valueIsNumericString: !1,
        isValidInputCharacter: B,
        onValueChange: C,
        format: p,
        removeFormatting: b,
        getCaretBoundary: function(A) {
            return Tb(A, e)
        },
        onKeyDown: E,
        onBlur: R
    })
}

function Bl(e) {
    var t = Ab(e);
    return M.createElement(Sb, Object.assign({}, t))
}
const Fl = e => n.jsx(Hn, {
        borderLeftRadius: 0,
        inputMode: "numeric",
        fontSize: {
            base: "16px",
            lg: "md"
        },
        ...e
    }),
    Wl = e => n.jsx(Hn, {
        borderRightRadius: 0,
        inputMode: "numeric",
        fontSize: {
            base: "16px",
            lg: "md"
        },
        ...e
    }),
    Vd = ({
        children: e,
        label: t,
        disableApply: o,
        disableReset: r,
        onApply: s,
        onReset: i,
        onClose: a
    }) => n.jsxs(Qs, {
        size: "lg",
        onClose: a,
        motionPreset: "none",
        blockScrollOnMount: !1,
        isCentered: !0,
        isOpen: !0,
        children: [n.jsx($s, {}), n.jsxs(Ys, {
            children: [n.jsx(Zs, {}), n.jsx(Yl, {
                children: n.jsx(Lt, {
                    size: "md",
                    noOfLines: 1,
                    wordBreak: "break-all",
                    mr: 8,
                    children: t
                })
            }), n.jsx(ei, {
                p: 5,
                children: n.jsx(I, {
                    children: e
                })
            }), n.jsxs(Jl, {
                children: [n.jsx(ue, {
                    onClick: s,
                    colorScheme: "accent",
                    leftIcon: n.jsx(L, {
                        as: ai
                    }),
                    mr: 3,
                    isDisabled: o,
                    children: "Apply"
                }), n.jsx(ue, {
                    onClick: i,
                    variant: "outline",
                    isDisabled: r,
                    children: "Clear"
                })]
            })]
        })]
    }),
    Eb = ({
        label: e,
        leftInputAddon: t,
        rightInputAddon: o,
        value: r,
        presets: s,
        onChange: i,
        onClose: a
    }) => {
        const [l, c] = f.useState(r.min), [d, u] = f.useState(r.max), h = f.useRef({
            min: r.min,
            max: r.max
        }), m = l !== h.current.min || d !== h.current.max, g = () => {
            m && i({
                min: l,
                max: d
            }), a()
        }, p = j => {
            i({
                min: j.min,
                max: j.max
            }), a()
        }, b = () => {
            i({
                min: null,
                max: null
            }), a()
        };
        return n.jsxs(Vd, {
            label: `Filter ${e}`,
            disableApply: !m,
            disableReset: r.min === null && r.max === null,
            onApply: g,
            onReset: b,
            onClose: a,
            children: [s && n.jsxs(n.Fragment, {
                children: [n.jsx(I, {
                    display: "grid",
                    gridTemplateColumns: "1fr 1fr 1fr",
                    gap: "2",
                    children: s.map(({
                        label: j,
                        min: y,
                        max: S
                    }) => n.jsx(ue, {
                        variant: r.min === y && r.max === S ? "solid" : "outline",
                        onClick: () => p({
                            min: y,
                            max: S
                        }),
                        children: j
                    }, j))
                }), n.jsx(Mr, {
                    my: "5"
                })]
            }), n.jsxs(he, {
                as: "form",
                onSubmit: g,
                spacing: 4,
                children: [n.jsxs(On, {
                    children: [t && n.jsx(ja, {
                        children: Uo(t, 16)
                    }), n.jsx(Bl, {
                        customInput: t ? Fl : Wl,
                        value: l,
                        onValueChange: ({
                            floatValue: j
                        }) => c(j ? ? null),
                        allowNegative: !1,
                        placeholder: "Min",
                        thousandSeparator: !0,
                        autoFocus: !0
                    }), o && n.jsx(vr, {
                        children: Uo(o, 16)
                    })]
                }), n.jsxs(On, {
                    children: [t && n.jsx(ja, {
                        children: Uo(t, 16)
                    }), n.jsx(Bl, {
                        customInput: t ? Fl : Wl,
                        value: d,
                        onValueChange: ({
                            floatValue: j
                        }) => u(j ? ? null),
                        allowNegative: !1,
                        placeholder: "Max",
                        thousandSeparator: !0
                    }), o && n.jsx(vr, {
                        children: Uo(o, 16)
                    })]
                }), n.jsx("input", {
                    type: "submit",
                    hidden: !0
                })]
            })]
        })
    },
    Pb = ({
        label: e,
        placeholder: t,
        value: o,
        onChange: r,
        onClose: s
    }) => {
        const [i, a] = f.useState(o), l = f.useRef(o), c = i !== l.current, d = () => {
            c && r(i || null), s()
        }, u = () => {
            r(null), s()
        };
        return n.jsx(Vd, {
            label: `Filter ${e}`,
            disableApply: !c,
            disableReset: !o,
            onApply: d,
            onReset: u,
            onClose: s,
            children: n.jsxs(he, {
                as: "form",
                onSubmit: d,
                spacing: 4,
                children: [n.jsx(Hn, {
                    fontSize: {
                        base: "16px",
                        lg: "md"
                    },
                    placeholder: t,
                    value: i ? ? "",
                    onChange: h => a(h.target.value),
                    autoFocus: !0
                }), n.jsx("input", {
                    type: "submit",
                    hidden: !0
                })]
            })
        })
    },
    Rb = V1,
    zb = ({
        chainId: e,
        baseTokenSymbol: t,
        quoteTokenSymbol: o,
        pairVolumeUsdH24: r,
        layout: s,
        logs: i,
        filters: a,
        isUpdatingFilter: l,
        isLoading: c,
        onFilterChange: d,
        onRangeChange: u,
        onEndReached: h,
        highlightAddresses: m
    }) => {
        const [, g] = f.useState(), [p, b] = f.useState(null), j = A => {
            a.type !== A && d(P => ({ ...P,
                updatedAtTimestamp: new Date().getTime(),
                type: A
            }))
        }, y = A => {
            d(P => ({ ...P,
                [A.filterKey]: A.value,
                updatedAtTimestamp: new Date().getTime()
            }))
        }, S = A => {
            d(P => ({ ...P,
                [A.filterKey]: A.value,
                updatedAtTimestamp: new Date().getTime()
            }))
        }, w = A => {
            g(A), u(A)
        }, v = () => {
            c || h()
        }, x = f.useRef();
        Is(() => {
            i.length > 0 && (x.current = void 0)
        }, [a.updatedAtTimestamp]);
        const {
            settings: {
                txnsDateFormat: C
            },
            setSettings: E
        } = $t(Tn), R = C === "timeAgo", B = f.useCallback(() => E({
            txnsDateFormat: C === "full" ? "timeAgo" : "full"
        }), [E, C]);
        return n.jsxs(n.Fragment, {
            children: [n.jsx(qi.Provider, {
                value: {
                    filters: a,
                    isUpdatingFilter: l,
                    layout: s,
                    tradingHistory: i,
                    animationTimestamp: x
                },
                children: n.jsx(Rb, {
                    style: {
                        overflowY: "scroll",
                        width: "100%",
                        height: "100%"
                    },
                    components: {
                        Scroller: ab,
                        TableRow: ib,
                        EmptyPlaceholder: X1
                    },
                    increaseViewportBy: {
                        top: 100,
                        bottom: 10
                    },
                    endReached: v,
                    rangeChanged: w,
                    data: l ? [] : i,
                    fixedHeaderContent: () => n.jsxs(n.Fragment, {
                        children: [s === "wide" && n.jsx(lb, {
                            filters: a,
                            baseTokenSymbol: t,
                            quoteTokenSymbol: o,
                            useTimeAgo: R,
                            onToggleUseTimeAgo: B,
                            onTypeFilterChange: j,
                            onSetActiveFilterModal: b,
                            isFilteringDisabled: c || l
                        }), s === "compact" && n.jsx(cb, {
                            filters: a,
                            onTypeFilterChange: j,
                            onSetActiveFilterModal: b,
                            isFilteringDisabled: c || l
                        })]
                    }),
                    itemContent: A => {
                        const P = i[A];
                        return P ? n.jsx(rb, {
                            layout: s,
                            chainId: e,
                            baseTokenSymbol: t,
                            quoteTokenSymbol: o,
                            log: P,
                            pairVolumeUsdH24: r,
                            useTimeAgo: R,
                            isMakerFiltered: a.maker !== null,
                            onMakerFilterChange: D => S({
                                filterKey: "maker",
                                value: D
                            }),
                            highlightAddresses: m
                        }) : null
                    }
                })
            }), p && n.jsxs(n.Fragment, {
                children: [p.type === "minMax" && n.jsx(Eb, {
                    label: p.label,
                    leftInputAddon: p.leftInputAddon,
                    rightInputAddon: p.rightInputAddon,
                    value: p.value,
                    presets: p.presets,
                    onChange: A => y({
                        filterKey: p.filterKey,
                        value: A
                    }),
                    onClose: () => b(null)
                }), p.type === "text" && n.jsx(Pb, {
                    label: p.label,
                    placeholder: p.placeholder,
                    value: p.value,
                    onChange: A => S({
                        filterKey: p.filterKey,
                        value: A
                    }),
                    onClose: () => b(null)
                })]
            })]
        })
    },
    Mb = Z.object({
        progress: Z.coerce.number(),
        curvePosition: Z.string()
    }),
    Bb = ({
        platformId: e,
        pair: t,
        isInverted: o,
        filteredMaker: r,
        onMakerChange: s,
        mobileLayout: i,
        highlightAddresses: a
    }) => {
        var A, P;
        const {
            colorMode: l
        } = pe(), c = Qn(), d = Zt(D => D.updatePairValues), {
            chartAndTxnsPollingRate: u,
            debugPolling: h
        } = kf({
            source: "txns",
            pair: t
        }), m = xe(If), [g, p] = f.useState();
        mr(() => m.tradingHistoryResponse.pipe(an(D => p(D))), [m.tradingHistoryResponse]);
        const [b, j] = f.useState(!1), [y, S] = f.useState({
            updatedAtTimestamp: new Date().getTime(),
            type: null,
            amountUsd: {
                min: null,
                max: null
            },
            amount0: {
                min: null,
                max: null
            },
            amount1: {
                min: null,
                max: null
            },
            maker: r ? ? null
        }), w = De(y), v = f.useCallback(D => {
            const O = typeof D == "function" ? D(w.current) : D;
            s(O.maker ? ? void 0), S(O)
        }, [w, s]);
        f.useEffect(() => {
            w.current.maker !== (r ? ? null) && S({ ...w.current,
                maker: r ? ? null
            })
        }, [r, w]);
        const x = f.useRef({});
        x.current.isUpdatingFilter = (g == null ? void 0 : g.success) === !0 && g.value.fetchedAtTimestamp < y.updatedAtTimestamp;
        const C = async () => {
                var D, O;
                if (j(!0), !(!(g != null && g.success) || !g.value.tradingHistory)) try {
                    await m.fetchHistory({
                        pair: t,
                        isInverted: o,
                        beforeBlockNumber: (O = (D = g.value.tradingHistory) == null ? void 0 : D.slice(-1)[0]) == null ? void 0 : O.blockNumber,
                        isUpdatingFilter: x.current.isUpdatingFilter,
                        currentListRange: x.current.currentListRange,
                        filtersUpdatedAtTimestamp: x.current.filtersUpdatedAtTimestamp,
                        filters: y,
                        isFetchingPastTradingHistory: !0
                    }), j(!1)
                } catch {
                    j(!1), c({
                        status: "error",
                        description: "Error fetching trades"
                    })
                }
            },
            E = async () => {
                if (x.current.isFetchingRecentWithNewFilter || !x.current.isUpdatingFilter && x.current.isFetchingRecent || !x.current.isUpdatingFilter && x.current.currentListRange && x.current.currentListRange.startIndex > 50 || g != null && g.success && !g.value.tradingHistory && !x.current.isUpdatingFilter) return;
                x.current.isUpdatingFilter ? x.current.isFetchingRecentWithNewFilter = !0 : x.current.isFetchingRecent = !0;
                let D;
                !x.current.isUpdatingFilter && (g != null && g.success) && g.value.latestBlockNumber && (D = g.value.latestBlockNumber);
                try {
                    await m.fetchHistory({
                        pair: t,
                        afterBlockNumber: D,
                        isInverted: o,
                        isUpdatingFilter: x.current.isUpdatingFilter,
                        currentListRange: x.current.currentListRange,
                        filtersUpdatedAtTimestamp: x.current.filtersUpdatedAtTimestamp,
                        filters: y
                    })
                } catch {
                    g != null && g.success && x.current.isUpdatingFilter && c({
                        status: "error",
                        description: "Error fetching trades"
                    })
                }
                x.current.isFetchingRecent = !1, x.current.isFetchingRecentWithNewFilter && (x.current.isFetchingRecentWithNewFilter = !1)
            };
        f.useEffect(() => {
            Zh({
                callback: () => E(),
                retrySettings: {
                    tries: 4,
                    delayInMs: 500,
                    timeoutInMs: 15e3
                }
            })
        }, []), Tf(() => {
            g && E()
        }, u.rate), Is(() => {
            u.type !== "invisible" && g && (h && console.log(new Date, `txns.polling.type=${u.type} trigger fetch recent txns`), E())
        }, [u.type]), Is(() => {
            E()
        }, [x.current.isUpdatingFilter]);
        const R = g != null && g.success ? g.value.fetchedAtTimestamp : null;
        f.useEffect(() => {
            var V;
            if (f0(w.current)) return;
            let D, O;
            if (g != null && g.success) {
                const z = (V = g.value.tradingHistory) == null ? void 0 : V.at(0);
                if (z && ("priceUsd" in z && (D = z.priceUsd), "metadata" in z)) {
                    const H = Mb.safeParse(z.metadata);
                    H.success && (O = {
                        progress: H.data.progress,
                        curvePos: H.data.curvePosition
                    })
                }
            }!D && !O || d({
                priceUsd: D,
                moonshot: O
            })
        }, [R, w, d]), f.useEffect(() => () => m.clearHistory(), [m]);
        const B = Qc({
            base: i,
            md: "wide"
        }, void 0, void 0);
        return B ? n.jsx(I, {
            pos: "relative",
            flex: 1,
            bg: T("gray.25", "blue.950", l),
            w: "100%",
            h: "100%",
            sx: {
                table: {
                    w: "100%"
                }
            },
            children: n.jsxs(n.Fragment, {
                children: [(g === void 0 || (g == null ? void 0 : g.success) === !1) && n.jsxs(Ae, {
                    h: "100%",
                    children: [g === void 0 && n.jsx(Cn, {
                        size: "sm"
                    }), (g == null ? void 0 : g.error) === "failed" && n.jsx(Cc, {
                        size: "sm"
                    }), (g == null ? void 0 : g.error) === "schemaVersion" && n.jsx(Kc, {
                        size: "sm"
                    })]
                }), (g == null ? void 0 : g.success) && n.jsx(zb, {
                    chainId: e,
                    baseTokenSymbol: o ? ((A = t.quoteToken) == null ? void 0 : A.symbol) ? ? "QUOTE" : t.baseToken.symbol,
                    quoteTokenSymbol: o ? t.baseToken.symbol : ((P = t.quoteToken) == null ? void 0 : P.symbol) ? ? "QUOTE",
                    pairVolumeUsdH24: t.volume.h24,
                    layout: B,
                    logs: g.value.tradingHistory ? ? [],
                    filters: y,
                    isUpdatingFilter: x.current.isUpdatingFilter,
                    isLoading: b,
                    onFilterChange: v,
                    onRangeChange: D => {
                        x.current.currentListRange = D
                    },
                    onEndReached: C,
                    highlightAddresses: a
                }), b && n.jsx(I, {
                    pos: "absolute",
                    bottom: 0,
                    w: "100%",
                    display: "flex",
                    justifyContent: "center",
                    pb: 3,
                    pointerEvents: "none",
                    children: n.jsx(Cn, {
                        size: "sm",
                        bg: T("gray.100", "blue.1000", l),
                        px: 3,
                        py: 2,
                        borderRadius: "md"
                    })
                })]
            })
        }) : null
    },
    Fb = Yh(Bb, {
        id: "trading-history",
        FallbackComponent: ({
            resetErrorBoundary: e
        }) => n.jsx(Ae, {
            h: "100%",
            children: n.jsxs(q, {
                p: 6,
                textAlign: "center",
                color: ee("gray.500", "blue.600"),
                children: ["Error rendering trades. Please", " ", n.jsx(ue, {
                    onClick: e,
                    variant: "link",
                    fontWeight: "semibold",
                    children: "click here to retry"
                }), " ", "or refresh this page."]
            })
        })
    });

function Wb(e) {
    return Kn({
        tag: "svg",
        attr: {
            fill: "none",
            viewBox: "0 0 24 24",
            strokeWidth: "2",
            stroke: "currentColor",
            "aria-hidden": "true"
        },
        child: [{
            tag: "path",
            attr: {
                strokeLinecap: "round",
                strokeLinejoin: "round",
                d: "M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
            }
        }]
    })(e)
}
const Db = ({
        children: e,
        containerProps: t
    }) => n.jsx(I, {
        fontSize: {
            base: "sm",
            "2xl": "md"
        },
        ...t,
        children: e
    }),
    Lb = ({
        children: e,
        containerProps: t
    }) => n.jsx(I, {
        display: "grid",
        h: Qi,
        fontWeight: "semibold",
        textTransform: "uppercase",
        fontSize: "xs",
        pos: "sticky",
        top: "0",
        zIndex: "sticky",
        bg: ee("gray.75", "blue.875"),
        sx: {
            span: {
                display: "flex",
                alignItems: "center",
                minWidth: "0px",
                borderRightWidth: 1,
                borderBottomWidth: 1,
                borderColor: ee("gray.125", "blue.825"),
                px: {
                    base: 2,
                    "2xl": 4
                }
            },
            "span:last-of-type": {
                borderRightWidth: 0
            }
        },
        ...t,
        children: e
    }),
    Nb = ({
        children: e,
        px: t,
        py: o,
        containerProps: r
    }) => n.jsx(I, {
        display: "grid",
        w: "100%",
        _hover: {
            bg: ee("gray.25", "blue.900")
        },
        sx: {
            "> div": {
                minWidth: "0px",
                px: t ? ? {
                    base: 2,
                    "2xl": 4
                },
                py: o ? ? "4px",
                borderRightWidth: 1,
                borderBottomWidth: 1,
                borderColor: ee("gray.125", "blue.825")
            },
            "> div:last-of-type": {
                borderRightWidth: 0
            }
        },
        ...r,
        children: e
    }),
    vs = ({
        children: e,
        ...t
    }) => n.jsx(k, {
        color: ee("gray.400", "gray.600"),
        pointerEvents: "none",
        ...t,
        children: e ? ? "-"
    }),
    Zo = {
        holders: {
            grid: "50fr 170fr 100fr 250fr 100fr 60fr 60fr",
            minW: "700px"
        },
        lpHolders: {
            grid: "50fr 170fr 100fr 350fr 60fr 60fr",
            minW: "600px"
        }
    },
    Xd = (e, t) => {
        var o, r;
        switch (e) {
            case "holders":
                return t.holders ? et(t.holders.totalSupply).toNumber() : (o = t.su) == null ? void 0 : o.totalSupply;
            case "liquidityProviders":
                return t.lpHolders ? et(t.lpHolders.totalSupply).toNumber() : (r = t.gp) != null && r.lpTotalSupply ? et(t.gp.lpTotalSupply).toNumber() : void 0
        }
    },
    Dl = (e, t) => {
        const o = t ? hi(e.balance, t).toNumber() : void 0;
        return {
            isContract: e.isContract,
            address: e.address,
            tag: e.tag,
            balancePercentage: o,
            balance: et(e.balance).toNumber()
        }
    },
    Hb = (e, t) => {
        const o = t ? hi(e.balance, t).toNumber() : void 0;
        return {
            isContract: e.isContract,
            address: e.address,
            tag: void 0,
            balancePercentage: o,
            balance: e.balance
        }
    },
    Ll = e => ({
        isContract: !1,
        address: e.id,
        label: e.label,
        balancePercentage: e.percentage,
        balance: cr(e.balance)
    }),
    _b = (e, t) => {
        var a, l, c, d, u, h;
        const o = Xd(e, t),
            r = [];
        switch (e) {
            case "holders":
                {
                    if ((a = t.gp) != null && a.holders) {
                        (l = t.gp) == null || l.holders.forEach(m => {
                            r.push(Dl(m, o))
                        });
                        break
                    }
                    if (((c = t.ts) == null ? void 0 : c.status) === "ready" && ((d = t.ts.balances) != null && d.topHolders)) {
                        (u = t.ts.balances) == null || u.topHolders.forEach(m => {
                            r.push(Hb(m, o))
                        });
                        break
                    }
                    t.holders && t.holders.holders.forEach(m => {
                        r.push(Ll(m))
                    });
                    break
                }
            case "liquidityProviders":
                {
                    if ((h = t.gp) != null && h.lpHolders) {
                        t.gp.lpHolders.forEach(m => {
                            r.push(Dl(m, o))
                        });
                        break
                    }
                    t.lpHolders && t.lpHolders.holders.forEach(m => {
                        r.push(Ll(m))
                    });
                    break
                }
        }
        const {
            totalBalance: s,
            totalPercentage: i
        } = r.reduce(({
            totalBalance: m,
            totalPercentage: g
        }, p) => ({
            totalBalance: m + p.balance,
            totalPercentage: p.balancePercentage ? g + p.balancePercentage : g
        }), {
            totalBalance: 0,
            totalPercentage: 0
        });
        return r.length >= 10 && o !== void 0 && r.push({
            address: null,
            balancePercentage: 100 - i,
            balance: o - s
        }), r
    },
    Ob = (e, t) => {
        var o, r;
        switch (e) {
            case "holders":
                return (o = t.gp) == null ? void 0 : o.holderCount;
            case "liquidityProviders":
                return (r = t.gp) == null ? void 0 : r.lpHolderCount
        }
    },
    Nl = ({
        chainId: e,
        type: t,
        onFilterMaker: o,
        highlightAddresses: r
    }) => {
        const {
            colorMode: s
        } = pe(), {
            pair: i,
            pairDetails: a
        } = Zt(c => ({
            pair: c.pair,
            pairDetails: c.pairDetails
        })), l = In(e);
        return be({
            value: Nt(i, a, (c, d) => ({
                pair: c,
                pairDetails: d
            })),
            onPending: () => n.jsx(Ae, {
                h: "100%",
                children: n.jsx(Cn, {
                    size: "sm"
                })
            }),
            onFailure: () => n.jsx(Ae, {
                h: "100%",
                children: n.jsx(k, {
                    children: "Failed loading data"
                })
            }),
            onSuccess: ({
                pair: c,
                pairDetails: d
            }) => {
                var w;
                const u = t === "holders" ? Zo.holders.grid : Zo.lpHolders.grid,
                    h = t === "holders" ? Zo.holders.minW : Zo.lpHolders.minW,
                    m = (w = c == null ? void 0 : c.data) != null && w.priceUsd ? et(c.data.priceUsd) : void 0,
                    g = c.data && d ? Xd(t, d) : void 0,
                    p = c.data && d ? _b(t, d) : void 0,
                    b = d ? Ob(t, d) : void 0,
                    j = p && p.length >= 10 && b !== void 0 ? b - p.length : void 0,
                    y = T("gray.475", "gray.100", s),
                    S = T("gray.150", "gray.600", s);
                return p ? p.length === 0 ? n.jsx(Ae, {
                    h: "100%",
                    children: n.jsxs(he, {
                        maxWidth: "80%",
                        alignItems: "center",
                        textAlign: "center",
                        children: [n.jsxs(k, {
                            fontWeight: "semibold",
                            children: [t === "holders" ? "Holders" : "Liquidity Providers", " not available!"]
                        }), n.jsx(k, {
                            color: T("gray.500", "blue.600", s),
                            children: "This list hasn't been updated yet. Please check back in a few minutes!"
                        })]
                    })
                }) : n.jsxs(Db, {
                    containerProps: {
                        minW: h
                    },
                    children: [n.jsxs(Lb, {
                        containerProps: {
                            gridTemplateColumns: u
                        },
                        children: [n.jsx(k, {
                            justifyContent: "center",
                            children: "Rank"
                        }), n.jsx(k, {
                            justifyContent: "center",
                            children: "Address"
                        }), n.jsx(k, {
                            justifyContent: "right",
                            children: "%"
                        }), n.jsx(k, {
                            justifyContent: "center",
                            children: "Amount"
                        }), t === "holders" && n.jsx(k, {
                            justifyContent: "right",
                            children: "Value"
                        }), n.jsx(k, {
                            justifyContent: "center",
                            px: "0 !important",
                            children: "Txns"
                        }), n.jsx(k, {
                            justifyContent: "center",
                            px: "0 !important",
                            children: "EXP"
                        })]
                    }), p.map((v, x) => {
                        const C = v.address !== null && (r == null ? void 0 : r.find(({
                                type: A,
                                address: P
                            }) => {
                                var D;
                                return A === "liquidityPool" && P.toLowerCase() === ((D = v.address) == null ? void 0 : D.toLowerCase())
                            })) !== void 0,
                            E = v.address !== null && (r == null ? void 0 : r.find(({
                                type: A,
                                address: P
                            }) => {
                                var D;
                                return A === "bondingCurve" && P.toLowerCase() === ((D = v.address) == null ? void 0 : D.toLowerCase())
                            })) !== void 0,
                            R = v.address !== null && (r == null ? void 0 : r.find(({
                                type: A,
                                address: P
                            }) => {
                                var D;
                                return A === "creator" && P.toLowerCase() === ((D = v.address) == null ? void 0 : D.toLowerCase())
                            })) !== void 0,
                            B = v.address !== null && (r == null ? void 0 : r.find(({
                                type: A,
                                address: P
                            }) => {
                                var D;
                                return A === "user" && P.toLowerCase() === ((D = v.address) == null ? void 0 : D.toLowerCase())
                            })) !== void 0;
                        return n.jsxs(Nb, {
                            containerProps: {
                                gridTemplateColumns: u
                            },
                            py: "12px",
                            children: [n.jsx(Ae, {
                                flexDir: "column",
                                fontWeight: "semibold",
                                fontSize: "sm",
                                py: "0 !important",
                                children: n.jsxs(k, {
                                    color: "gray.500",
                                    children: ["#", x + 1]
                                })
                            }), n.jsxs(Ae, {
                                flexDir: "column",
                                fontWeight: "semibold",
                                fontSize: "sm",
                                children: [n.jsxs(Ae, {
                                    gap: 1,
                                    children: [v.isContract && n.jsx(L, {
                                        as: Wb,
                                        fontSize: "xs",
                                        opacity: .5
                                    }), v.label && n.jsx(k, {
                                        fontFamily: "mono",
                                        children: v.label
                                    }), v.address && !v.label && n.jsx(k, {
                                        fontFamily: "mono",
                                        children: Eo(v.address)
                                    }), !v.address && !v.label && n.jsx(k, {
                                        children: j ? `Others (${Gt(j)})` : "Others"
                                    }), C || E || R || B ? n.jsxs(K, {
                                        spacing: "0.5",
                                        children: [C && n.jsx(St, {
                                            label: "Liquidity pool",
                                            children: "🏦"
                                        }), E && n.jsx(St, {
                                            label: "Bonding curve",
                                            children: "🏦"
                                        }), R && n.jsx(St, {
                                            label: "Token creator",
                                            children: "👨‍💻"
                                        }), B && n.jsx(St, {
                                            label: "You",
                                            children: "👤"
                                        })]
                                    }) : null]
                                }), v.tag && n.jsx(k, {
                                    fontSize: "xs",
                                    color: "gray.500",
                                    fontWeight: "normal",
                                    noOfLines: 1,
                                    children: v.tag
                                })]
                            }), n.jsx(Ae, {
                                justifyContent: "flex-end",
                                fontSize: {
                                    base: "md",
                                    "2xl": "lg"
                                },
                                fontWeight: "semibold",
                                children: v.balancePercentage !== void 0 && n.jsxs(k, {
                                    children: [Ts(v.balancePercentage), "%"]
                                })
                            }), n.jsxs(I, {
                                display: "grid",
                                gridTemplateColumns: "50px 1fr 50px",
                                alignItems: "center",
                                gap: 2,
                                children: [n.jsx(k, {
                                    textAlign: "right",
                                    color: T("gray.475", "gray.100", s),
                                    flexShrink: 0,
                                    whiteSpace: "nowrap",
                                    children: Ht(v.balance)
                                }), g && n.jsx(wn, {
                                    containerProps: {
                                        h: "10px"
                                    },
                                    left: {
                                        label: "Position",
                                        value: v.balance,
                                        bg: v.balance <= 0 ? S : y
                                    },
                                    right: {
                                        label: "Total",
                                        value: g - v.balance,
                                        bg: S
                                    },
                                    isJoined: !0,
                                    disableTooltip: !0
                                }), n.jsx(k, {
                                    opacity: T("gray.150", "gray.600", s),
                                    flexShrink: 0,
                                    whiteSpace: "nowrap",
                                    children: g ? Ht(g) : "N/A"
                                })]
                            }), t === "holders" && n.jsx(I, {
                                textAlign: "right",
                                fontWeight: "semibold",
                                fontSize: {
                                    base: "md",
                                    "2xl": "lg"
                                },
                                children: m ? Dt(m.multipliedBy(v.balance)) : n.jsx(vs, {})
                            }), n.jsxs(Ae, {
                                fontSize: "md",
                                p: "0 !important",
                                children: [v.address && !v.label && n.jsx(Je, {
                                    onClick: () => o(v.address ? ? "0x"),
                                    variant: "unstyled",
                                    display: "flex",
                                    alignItems: "center",
                                    justifyContent: "center",
                                    w: "100%",
                                    h: "100%",
                                    borderRadius: "none",
                                    icon: n.jsx(L, {
                                        as: Zr,
                                        boxSize: {
                                            base: "14px",
                                            "2xl": "16px"
                                        }
                                    }),
                                    color: T("gray.300", "gray.400", s),
                                    _hover: {
                                        "@media (hover: hover)": {
                                            bg: T("gray.75", "blue.850", s)
                                        }
                                    },
                                    _active: {
                                        bg: T("gray.75", "blue.850", s)
                                    },
                                    "aria-label": "Show transactions",
                                    title: "Show transactions"
                                }), (!v.address || v.label) && n.jsx(vs, {
                                    opacity: .4
                                })]
                            }), n.jsxs(Ae, {
                                p: "0 !important",
                                children: [v.address && !v.label && n.jsx(Je, {
                                    as: we,
                                    href: l == null ? void 0 : l.accountURL(v.address),
                                    rel: "noopener noreferrer",
                                    target: "_blank",
                                    variant: "unstyled",
                                    display: "flex",
                                    alignItems: "center",
                                    justifyContent: "center",
                                    w: "100%",
                                    h: "100%",
                                    borderRadius: "none",
                                    icon: n.jsx(L, {
                                        as: yt,
                                        boxSize: {
                                            base: "12px",
                                            "2xl": "14px"
                                        }
                                    }),
                                    color: T("gray.300", "gray.400", s),
                                    _hover: {
                                        "@media (hover: hover)": {
                                            bg: T("gray.75", "blue.850", s)
                                        }
                                    },
                                    _active: {
                                        bg: T("gray.75", "blue.850", s)
                                    },
                                    "aria-label": "Open in block explorer",
                                    title: "Open in block explorer"
                                }), (!v.address || v.label) && n.jsx(vs, {
                                    opacity: .4
                                })]
                            })]
                        }, v.address)
                    })]
                }) : n.jsx(Ae, {
                    h: "100%",
                    children: n.jsx(k, {
                        color: T("gray.500", "blue.600", s),
                        children: "Not available for this pair"
                    })
                })
            }
        })
    },
    ro = M.forwardRef(({
        display: e,
        leftIcon: t,
        rightIcon: o,
        label: r,
        onClick: s,
        isActive: i,
        disabled: a
    }, l) => {
        const {
            colorMode: c
        } = pe();
        return n.jsx(ue, {
            ref: l,
            display: e ? ? "flex",
            onClick: s,
            leftIcon: n.jsx(L, {
                as: t
            }),
            rightIcon: o ? n.jsx(L, {
                as: o
            }) : void 0,
            iconSpacing: 1.5,
            variant: "unstyled",
            alignItems: "center",
            borderRadius: "none",
            borderColor: "transparent",
            h: "100%",
            fontWeight: "semibold",
            borderBottomWidth: 2,
            fontSize: "sm",
            px: 3,
            flexShrink: 0,
            color: T("gray.600", "gray.350", c),
            _hover: a ? void 0 : {
                "@media (hover: hover)": {
                    color: T("gray.800", "gray.50", c)
                }
            },
            _active: a ? void 0 : {
                color: T("gray.800", "gray.50", c)
            },
            ...i ? {
                color: T("gray.900", "gray.25", c),
                borderColor: T("gray.650", "gray.300", c)
            } : void 0,
            isDisabled: a,
            children: r
        })
    }),
    Hl = ({
        icon: e,
        ariaLabel: t,
        onClick: o,
        disabled: r
    }) => n.jsx(Je, {
        icon: e,
        "aria-label": t,
        onClick: o,
        variant: "unstyled",
        display: "flex",
        alignItems: "center",
        minW: "30px",
        h: "100%",
        color: ee("gray.600", "gray.400"),
        _hover: {
            "@media (hover: hover)": {
                color: ee("gray.900", "gray.50")
            }
        },
        _active: {
            color: ee("gray.900", "gray.50")
        },
        borderRadius: 0,
        borderLeftWidth: {
            base: 1,
            xl: 0
        },
        borderColor: ee("gray.50", "blue.925"),
        _disabled: {
            pointerEvents: "none",
            opacity: .5
        },
        isDisabled: r
    }),
    Ub = {
        minimized: n.jsx(cc, {}),
        default: n.jsx(uc, {}),
        maximized: n.jsx(hc, {})
    },
    Vb = ({
        value: e,
        onChange: t
    }) => n.jsxs(I, {
        ml: "auto",
        display: {
            base: "none",
            lg: "flex"
        },
        flexShrink: 0,
        children: [n.jsx(Hl, {
            icon: n.jsx(dc, {}),
            ariaLabel: "Minimize",
            onClick: () => t("minimized"),
            disabled: e === "minimized"
        }), n.jsx(Hl, {
            icon: Ub[e],
            ariaLabel: "Maximize",
            onClick: () => t(e !== "default" ? "default" : "maximized")
        })]
    }),
    Xb = 10 * 1e3,
    qb = e => {
        const t = xe(Af),
            o = sr(e.pair),
            r = De(e.pair);
        return fo(() => o.pipe(dt(i => i.c !== "a" ? {
            state: "unsupported"
        } : {
            state: "ok",
            a: i.a,
            chainId: i.chainId,
            pairAddress: i.pairAddress,
            quoteTokenAddress: i.quoteToken.address
        }), Jh(), ws, Qe(i => i.state === "unsupported" ? To(i) : lr(0, Xb).pipe(Qe(() => ef(() => t.getTopMakers({
            pair: r.current
        })).pipe(dt(a => ({
            state: "supported",
            topMakers: a.map(l => {
                var c, d;
                return { ...l,
                    makerType: Fd({
                        volumeUsdBuy: l.volumeUsdBuy,
                        volumeUsdSell: l.volumeUsdSell
                    }),
                    pnl: l.volumeUsdSell - l.volumeUsdBuy,
                    isCreator: ((c = e.highlightAddresses) == null ? void 0 : c.find(({
                        type: u,
                        address: h
                    }) => u === "creator" && h.toLowerCase() === l.maker.toLowerCase())) !== void 0,
                    isUser: ((d = e.highlightAddresses) == null ? void 0 : d.find(({
                        type: u,
                        address: h
                    }) => u === "user" && h.toLowerCase() === l.maker.toLowerCase())) !== void 0
                }
            })
        }))))))), [t, o, r, e.highlightAddresses])
    },
    _l = "50fr 180fr 130fr 130fr 100fr 100fr 130fr 50fr 50fr",
    Gb = ({
        dexScreenerPair: e,
        onFilterMaker: t,
        highlightAddresses: o
    }) => {
        const r = qb({
                pair: e,
                highlightAddresses: o
            }),
            {
                colorMode: s
            } = pe(),
            i = In(e.chainId);
        return be({
            value: r,
            onPending: () => n.jsx(Ae, {
                h: "100%",
                children: n.jsx(Cn, {
                    size: "sm"
                })
            }),
            onFailure: () => n.jsx(Ae, {
                h: "100%",
                children: n.jsx(k, {
                    color: T("gray.500", "blue.600", s),
                    children: "Sorry, can't load top traders for this pair!"
                })
            }),
            onSuccess: a => {
                switch (a.state) {
                    case "unsupported":
                        return n.jsx(Ae, {
                            h: "100%",
                            children: n.jsx(k, {
                                color: T("gray.500", "blue.600", s),
                                children: "Sorry, top traders are not supported for this pair!"
                            })
                        });
                    case "supported":
                        {
                            const {
                                topMakers: l
                            } = a;
                            return n.jsxs(I, {
                                minW: "900px",
                                fontSize: {
                                    base: "sm",
                                    "2xl": "md"
                                },
                                width: "100%",
                                children: [n.jsxs(I, {
                                    display: "grid",
                                    h: Qi,
                                    gridTemplateColumns: _l,
                                    fontWeight: "semibold",
                                    textTransform: "uppercase",
                                    fontSize: "xs",
                                    pos: "sticky",
                                    top: "0",
                                    zIndex: "sticky",
                                    bg: T("gray.75", "blue.875", s),
                                    sx: {
                                        span: {
                                            display: "flex",
                                            alignItems: "center",
                                            minWidth: "0px",
                                            borderRightWidth: 1,
                                            borderBottomWidth: 1,
                                            borderColor: T("gray.125", "blue.825", s),
                                            px: {
                                                base: 2,
                                                "2xl": 4
                                            },
                                            py: 2
                                        },
                                        "span:last-of-type": {
                                            borderRightWidth: 0
                                        }
                                    },
                                    children: [n.jsx(k, {
                                        justifyContent: "center",
                                        px: "0 !important",
                                        children: "Rank"
                                    }), n.jsx(k, {
                                        justifyContent: "center",
                                        children: "Maker"
                                    }), n.jsx(k, {
                                        justifyContent: "right",
                                        children: "Bought"
                                    }), n.jsx(k, {
                                        justifyContent: "right",
                                        children: "Sold"
                                    }), n.jsx(k, {
                                        justifyContent: "right",
                                        children: "PnL"
                                    }), n.jsx(k, {
                                        justifyContent: "right",
                                        children: "Unrealized"
                                    }), n.jsx(k, {
                                        justifyContent: "center",
                                        children: "Balance"
                                    }), n.jsx(k, {
                                        justifyContent: "center",
                                        px: "0 !important",
                                        children: "Txns"
                                    }), n.jsx(k, {
                                        justifyContent: "center",
                                        px: "0 !important",
                                        children: "EXP"
                                    })]
                                }), l.map(({
                                    maker: c,
                                    makerType: d,
                                    volumeUsdBuy: u,
                                    amountBuy: h,
                                    buys: m,
                                    volumeUsdSell: g,
                                    amountSell: p,
                                    sells: b,
                                    pnl: j,
                                    balanceAmount: y,
                                    balancePercentage: S,
                                    isUser: w,
                                    isCreator: v
                                }, x) => n.jsxs(I, {
                                    display: "grid",
                                    gridTemplateColumns: _l,
                                    w: "100%",
                                    _hover: {
                                        "@media (hover: hover)": {
                                            bg: T("gray.25", "blue.900", s)
                                        }
                                    },
                                    sx: {
                                        "> div": {
                                            minWidth: "0px",
                                            px: {
                                                base: 2,
                                                "2xl": 4
                                            },
                                            py: "4px",
                                            borderRightWidth: 1,
                                            borderBottomWidth: 1,
                                            borderColor: T("gray.125", "blue.825", s)
                                        },
                                        "> div:last-of-type": {
                                            borderRightWidth: 0
                                        }
                                    },
                                    children: [n.jsx(Ae, {
                                        fontSize: "sm",
                                        px: 3,
                                        children: n.jsxs(k, {
                                            color: "gray.500",
                                            children: ["#", x + 1]
                                        })
                                    }), n.jsxs(Ae, {
                                        gap: 2,
                                        children: [n.jsx(I, {
                                            children: n.jsx(Ki, {
                                                makerType: d,
                                                iconProps: {
                                                    boxSize: "16px"
                                                }
                                            })
                                        }), n.jsx(k, {
                                            fontWeight: "semibold",
                                            fontFamily: "mono",
                                            color: j >= 0 ? T("accent.darkGreen", "accent.lightGreen", s) : "accent.red",
                                            fontSize: "sm",
                                            children: Eo(c)
                                        }), v || w ? n.jsxs(K, {
                                            spacing: "0.5",
                                            children: [v && n.jsx(St, {
                                                label: "Token creator",
                                                children: "👨‍💻"
                                            }), w && n.jsx(St, {
                                                label: "You",
                                                children: "👤"
                                            })]
                                        }) : null]
                                    }), n.jsxs(I, {
                                        display: "flex",
                                        flexDir: "column",
                                        alignItems: "flex-end",
                                        justifyContent: "center",
                                        textAlign: "right",
                                        children: [u > 0 && n.jsxs(n.Fragment, {
                                            children: [n.jsx(k, {
                                                fontWeight: "semibold",
                                                color: "accent.red",
                                                children: Dt(u)
                                            }), n.jsxs(k, {
                                                fontSize: "xs",
                                                color: "gray.500",
                                                noOfLines: 1,
                                                children: [n.jsx(k, {
                                                    fontWeight: "semibold",
                                                    children: Ht(h)
                                                }), n.jsx(k, {
                                                    color: T("gray.400", "gray.700", s),
                                                    px: "2px",
                                                    children: "/"
                                                }), n.jsx(k, {
                                                    fontWeight: "semibold",
                                                    children: xa(m)
                                                }), " txns"]
                                            })]
                                        }), u === 0 && n.jsx(k, {
                                            fontSize: "xs",
                                            color: T("gray.400", "gray.700", s),
                                            children: "-"
                                        })]
                                    }), n.jsxs(I, {
                                        display: "flex",
                                        flexDir: "column",
                                        alignItems: "flex-end",
                                        justifyContent: "center",
                                        textAlign: "right",
                                        children: [g > 0 && n.jsxs(n.Fragment, {
                                            children: [n.jsx(k, {
                                                fontWeight: "semibold",
                                                color: T("accent.darkGreen", "accent.lightGreen", s),
                                                children: Dt(g)
                                            }), n.jsxs(k, {
                                                fontSize: "xs",
                                                color: "gray.500",
                                                noOfLines: 1,
                                                children: [n.jsx(k, {
                                                    fontWeight: "semibold",
                                                    children: Ht(p)
                                                }), n.jsx(k, {
                                                    color: T("gray.400", "gray.700", s),
                                                    px: "2px",
                                                    children: "/"
                                                }), n.jsx(k, {
                                                    fontWeight: "semibold",
                                                    children: xa(b)
                                                }), " txns"]
                                            })]
                                        }), g === 0 && n.jsx(k, {
                                            fontSize: "xs",
                                            color: T("gray.400", "gray.700", s),
                                            children: "-"
                                        })]
                                    }), n.jsx(I, {
                                        display: "flex",
                                        alignItems: "center",
                                        justifyContent: "flex-end",
                                        fontWeight: "semibold",
                                        color: j > 0 ? T("accent.darkGreen", "accent.lightGreen", s) : "accent.red",
                                        fontSize: {
                                            base: "md",
                                            "2xl": "lg"
                                        },
                                        children: Dt(Math.abs(j))
                                    }), n.jsxs(I, {
                                        display: "flex",
                                        alignItems: "center",
                                        justifyContent: "flex-end",
                                        fontWeight: "semibold",
                                        fontSize: {
                                            base: "md",
                                            "2xl": "lg"
                                        },
                                        children: [e.priceUsd && y && n.jsx(n.Fragment, {
                                            children: Dt(new mt(e.priceUsd).multipliedBy(y))
                                        }), !y && n.jsx(k, {
                                            fontSize: "xs",
                                            color: T("gray.400", "gray.700", s),
                                            children: "-"
                                        })]
                                    }), n.jsxs(Ae, {
                                        flexDir: "column",
                                        gap: 1,
                                        fontSize: {
                                            base: "xs",
                                            "2xl": "sm"
                                        },
                                        children: [n.jsxs(k, {
                                            display: "flex",
                                            justifyContent: "center",
                                            gap: 1,
                                            children: [y !== null && n.jsxs(n.Fragment, {
                                                children: [n.jsx(k, {
                                                    fontWeight: "semibold",
                                                    children: y === "0" ? "0" : Ht(y)
                                                }), n.jsx(k, {
                                                    color: "gray.500",
                                                    children: "of"
                                                }), n.jsx(k, {
                                                    fontWeight: "semibold",
                                                    children: Ht(h)
                                                })]
                                            }), y === null && n.jsx(k, {
                                                color: T("gray.350", "gray.700", s),
                                                fontSize: "xs",
                                                children: "Unknown"
                                            })]
                                        }), y !== null && n.jsx(I, {
                                            w: "100%",
                                            maxW: "130px",
                                            children: n.jsx(Gi, {
                                                balancePercentage: S
                                            })
                                        })]
                                    }), n.jsx(Ae, {
                                        fontSize: "md",
                                        p: "0 !important",
                                        children: n.jsx(Je, {
                                            onClick: () => t(c),
                                            variant: "unstyled",
                                            display: "flex",
                                            alignItems: "center",
                                            justifyContent: "center",
                                            w: "100%",
                                            h: "100%",
                                            borderRadius: "none",
                                            icon: n.jsx(L, {
                                                as: Zr,
                                                boxSize: {
                                                    base: "14px",
                                                    "2xl": "16px"
                                                }
                                            }),
                                            color: T("gray.300", "gray.400", s),
                                            _hover: {
                                                "@media (hover: hover)": {
                                                    bg: T("gray.75", "blue.850", s)
                                                }
                                            },
                                            _active: {
                                                bg: T("gray.75", "blue.850", s)
                                            },
                                            "aria-label": "Show transactions",
                                            title: "Show transactions"
                                        })
                                    }), n.jsx(Ae, {
                                        p: "0 !important",
                                        children: n.jsx(Je, {
                                            as: we,
                                            href: i == null ? void 0 : i.accountURL(c),
                                            rel: "noopener noreferrer",
                                            target: "_blank",
                                            variant: "unstyled",
                                            display: "flex",
                                            alignItems: "center",
                                            justifyContent: "center",
                                            w: "100%",
                                            h: "100%",
                                            borderRadius: "none",
                                            icon: n.jsx(L, {
                                                as: yt,
                                                boxSize: {
                                                    base: "12px",
                                                    "2xl": "14px"
                                                }
                                            }),
                                            color: T("gray.300", "gray.400", s),
                                            _hover: {
                                                "@media (hover: hover)": {
                                                    bg: T("gray.75", "blue.850", s)
                                                }
                                            },
                                            _active: {
                                                bg: T("gray.75", "blue.850", s)
                                            },
                                            "aria-label": "Open in block explorer",
                                            title: "Open in block explorer"
                                        })
                                    })]
                                }, c))]
                            })
                        }
                }
            }
        })
    },
    Kb = e => {
        var Be, W, se, J, de, ie;
        const {
            settings: t,
            setSettings: o
        } = $t(Tn), {
            pair: r,
            pairDetails: s,
            isInverted: i
        } = Zt(({
            pair: U,
            pairDetails: F,
            isInverted: G
        }) => ({
            pair: U,
            pairDetails: F,
            isInverted: G
        })), a = be({
            value: r,
            onPending: ln,
            onFailure: ln,
            onSuccess: U => {
                var F, G;
                return {
                    chainId: (F = U.data) == null ? void 0 : F.chainId,
                    dexId: (G = U.data) == null ? void 0 : G.dexId
                }
            }
        }), l = Er(a == null ? void 0 : a.chainId), [c, d] = f.useState(e.isResizable ? "default" : "maximized"), u = U => {
            e.isResizable && (U === "default" ? o({
                chart: !0,
                trades: !0
            }) : U === "maximized" ? o({
                chart: !1,
                trades: !0
            }) : U === "minimized" && o({
                chart: !0,
                trades: !1
            }))
        };
        f.useEffect(() => {
            t.chart === !1 && t.trades === !0 ? d("maximized") : t.chart === !0 && t.trades === !1 ? d("minimized") : d("default")
        }, [e.isResizable, t.chart, t.trades]);
        const [h, m] = f.useState(Date.now()), g = bc(), p = tf(), b = De(p), j = f.useMemo(() => new URLSearchParams(p.search).get("maker") ? ? void 0, [p.search]), [y, S] = f.useState(j), w = De(y);
        f.useEffect(() => {
            w.current !== j && (S(j), m(Date.now()))
        }, [w, j]);
        const v = f.useCallback(U => {
                const F = new URLSearchParams(b.current.search);
                U ? F.set("maker", U) : F.delete("maker"), g({
                    search: F.toString()
                }, {
                    state: b.current.state
                })
            }, [g, b]),
            [x, C] = f.useState("all"),
            E = f.useCallback(U => {
                e.isResizable && c === "minimized" && (d("default"), o({
                    chart: !0,
                    trades: !0
                })), C(U)
            }, [e.isResizable, o, c]),
            R = f.useCallback(U => {
                S(U), E("all"), v(U)
            }, [E, v]),
            B = kc(),
            A = Sn(B.height, 900),
            P = Hr(),
            D = P ? 110 : 105,
            O = c !== "maximized" ? A - (P ? 200 : 150) : A,
            V = rs(D, A * .35, O),
            z = Sn(t.transactionsHeight, void 0),
            H = rs(D, z ? ? V, O),
            oe = f.useCallback(U => {
                e.isResizable && o({
                    transactionsHeight: rs(D, U, O)
                })
            }, [O, D, e.isResizable, o]);
        f.useEffect(() => {
            var U, F, G;
            if (e.isResizable) switch (c) {
                case "maximized":
                    {
                        (U = e.resizableRef.current) == null || U.updateSize({
                            width: "100%",
                            height: "100%"
                        });
                        return
                    }
                default:
                    {
                        if (((F = e.resizableRef.current) == null ? void 0 : F.size.height) === H) return;
                        (G = e.resizableRef.current) == null || G.updateSize({
                            width: "100%",
                            height: H
                        })
                    }
            }
        }, [H, e.isResizable, e.resizableRef, c]);
        const re = f.useCallback(U => {
                e.isResizable && c !== "maximized" && oe(U)
            }, [e.isResizable, c, oe]),
            ye = f.useCallback(U => {
                o({
                    mobileTxnsLayout: U
                })
            }, [o]),
            fe = f.useCallback(U => {
                m(Date.now()), R(U)
            }, [R]),
            je = (((W = (Be = l == null ? void 0 : l.integrations) == null ? void 0 : Be.goPlus) == null ? void 0 : W.isEnabled) || ((J = (se = l == null ? void 0 : l.integrations) == null ? void 0 : se.tokenSniffer) == null ? void 0 : J.isEnabled) || (l == null ? void 0 : l.slug) === "solana") ? ? !1,
            ze = (((ie = (de = l == null ? void 0 : l.integrations) == null ? void 0 : de.goPlus) == null ? void 0 : ie.isEnabled) || (l == null ? void 0 : l.slug) === "solana" && (a == null ? void 0 : a.dexId) === "raydium") ? ? !1,
            Me = li(U => {
                var F;
                return (F = U.wallet) == null ? void 0 : F.publicKey
            }),
            Fe = lg(be({
                value: r,
                onSuccess: ({
                    data: U
                }) => {
                    if (!U) return [];
                    const F = [];
                    return U.dexId === "raydium" ? F.push({
                        type: "liquidityPool",
                        address: "5Q544fKrFoe6tsEbD7S8EmxGTJYAKtTVhAW5Q5pge4j1"
                    }) : Ye(U) && F.push({
                        type: "bondingCurve",
                        address: U.pairAddress
                    }), oi(U) && F.push({
                        type: "creator",
                        address: U.moonshot.creator
                    }), Me && F.push({
                        type: "user",
                        address: Me
                    }), F
                },
                onPending: () => [],
                onFailure: () => []
            }));
        return {
            resetTableKey: h,
            handleSetTabBarDisclosure: u,
            handleSetActiveTab: E,
            handleSetFilteredMaker: R,
            handleSetFilteredMakerWithReset: fe,
            saveHeight: re,
            mobileTxnsLayout: t.mobileTxnsLayout,
            handleSetMobileTxnsLayout: ye,
            tabBarDisclosure: c,
            activeTab: x,
            filteredMaker: y,
            height: H,
            minContainerHeight: D,
            maxContainerHeight: O,
            isInverted: i,
            isHoldersAvailable: je,
            isLpsAvailable: ze,
            pair: Nt(r, U => U.data),
            isTopTradersAvailable: Nt(r, U => {
                var F;
                return ((F = U.data) == null ? void 0 : F.c) === "a"
            }),
            holdersCount: Nt(s, U => {
                var F, G;
                return ((F = U == null ? void 0 : U.gp) == null ? void 0 : F.holderCount) ? ? ((G = U == null ? void 0 : U.holders) == null ? void 0 : G.count)
            }),
            lpHoldersCount: Nt(s, U => {
                var F, G;
                return ((F = U == null ? void 0 : U.gp) == null ? void 0 : F.lpHolderCount) ? ? ((G = U == null ? void 0 : U.lpHolders) == null ? void 0 : G.count)
            }),
            highlightAddresses: Fe
        }
    },
    Jo = 40,
    Qb = f.memo(e => {
        const {
            isResizable: t
        } = e, {
            colorMode: o
        } = pe(), r = f.useRef(null), s = f.useRef(null), i = Kb({
            resizableRef: r,
            isResizable: t
        });
        f.useEffect(() => {
            var l;
            (l = s.current) == null || l.scrollTo({
                top: 0,
                left: 0,
                behavior: "instant"
            })
        }, [i.activeTab]);
        const a = ui({
            colorMode: o
        });
        return n.jsx(gi, {
            if: t,
            with: l => n.jsx(Jc, {
                ref: r,
                defaultSize: {
                    width: "100%",
                    height: i.height
                },
                enable: {
                    top: i.tabBarDisclosure === "default"
                },
                minHeight: i.tabBarDisclosure !== "minimized" ? i.minContainerHeight : Jo,
                maxHeight: i.tabBarDisclosure !== "minimized" ? i.maxContainerHeight : Jo,
                handleStyles: {
                    top: {
                        top: "-7px",
                        height: "14px",
                        width: "calc(100% - 60px)"
                    }
                },
                handleComponent: {
                    top: n.jsx(ed, {})
                },
                onResizeStop: (c, d, u) => {
                    i.saveHeight(Number.parseInt(u.style.height.replace("px", ""), 10))
                },
                style: {
                    display: "flex",
                    flex: 1
                },
                children: l
            }),
            children: n.jsxs(I, {
                pos: "relative",
                flex: 1,
                bg: T("white", "blue.950", o),
                w: "100%",
                h: "100%",
                overflow: "hidden",
                maxHeight: "100vh",
                children: [n.jsxs(I, {
                    display: {
                        base: i.tabBarDisclosure !== "minimized" ? "flex" : "none",
                        lg: "flex"
                    },
                    pos: "relative",
                    w: "100%",
                    h: `${Jo}px`,
                    bg: T("white", "blue.975", o),
                    borderTopWidth: i.tabBarDisclosure === "minimized" ? 1 : void 0,
                    borderBottomWidth: i.tabBarDisclosure !== "minimized" ? 1 : void 0,
                    borderColor: T("gray.100", "blue.875", o),
                    gap: 2,
                    _after: {
                        pointerEvents: "none",
                        display: {
                            base: "block",
                            xl: "none"
                        },
                        pos: "absolute",
                        content: '""',
                        width: "50px",
                        height: "100%",
                        top: 0,
                        right: t ? {
                            base: "0px",
                            lg: "60px"
                        } : "0px",
                        bgGradient: T("linear(to-r, transparent, white)", "linear(to-r, transparent, blue.975)", o)
                    },
                    children: [n.jsxs(I, {
                        display: "flex",
                        w: "100%",
                        overflowX: "auto",
                        flex: 1,
                        flexShrink: 0,
                        gap: {
                            base: 0,
                            lg: 2
                        },
                        pos: "relative",
                        sx: {
                            "@media (hover: none)": {
                                "::-webkit-scrollbar": {
                                    display: "none"
                                }
                            }
                        },
                        children: [n.jsx(I, {
                            pos: "relative",
                            display: {
                                base: i.activeTab === "all" ? "flex" : "none",
                                md: "none"
                            },
                            children: n.jsxs(Xn, {
                                strategy: "fixed",
                                gutter: 0,
                                children: [n.jsx(qn, {
                                    as: ro,
                                    leftIcon: ba,
                                    rightIcon: Rr,
                                    label: "Txns",
                                    isActive: i.tabBarDisclosure !== "minimized" && i.activeTab === "all"
                                }), n.jsxs(Gn, {
                                    zIndex: "modal",
                                    ml: "3",
                                    children: [n.jsx(tt, {
                                        onClick: () => i.handleSetMobileTxnsLayout("compact"),
                                        isChecked: i.mobileTxnsLayout === "compact",
                                        children: "Compact"
                                    }), n.jsx(tt, {
                                        onClick: () => i.handleSetMobileTxnsLayout("wide"),
                                        isChecked: i.mobileTxnsLayout === "wide",
                                        children: "Table"
                                    })]
                                })]
                            })
                        }), n.jsx(ro, {
                            display: {
                                base: i.activeTab === "all" ? "none" : "flex",
                                md: "flex"
                            },
                            leftIcon: ba,
                            label: n.jsxs(n.Fragment, {
                                children: [n.jsx(k, {
                                    display: {
                                        xl: "none"
                                    },
                                    children: "Txns"
                                }), n.jsx(k, {
                                    display: {
                                        base: "none",
                                        xl: "initial"
                                    },
                                    children: "Transactions"
                                })]
                            }),
                            onClick: () => i.handleSetActiveTab("all"),
                            isActive: i.tabBarDisclosure !== "minimized" && i.activeTab === "all"
                        }), be({
                            value: i.isTopTradersAvailable,
                            onPending: yn,
                            onFailure: yn,
                            onSuccess: l => l ? n.jsx(ro, {
                                leftIcon: rf,
                                label: "Top Traders",
                                onClick: () => i.handleSetActiveTab("traders"),
                                isActive: i.tabBarDisclosure !== "minimized" && i.activeTab === "traders"
                            }) : null
                        }), i.isHoldersAvailable && n.jsx(ro, {
                            leftIcon: nf,
                            label: be({
                                value: i.holdersCount,
                                onPending: () => "Holders",
                                onFailure: () => "Holders",
                                onSuccess: l => l ? `Holders (${Gt(l)})` : "Holders"
                            }),
                            onClick: () => i.handleSetActiveTab("holders"),
                            isActive: i.tabBarDisclosure !== "minimized" && i.activeTab === "holders"
                        }), i.isLpsAvailable && n.jsx(ro, {
                            leftIcon: of ,
                            label: be({
                                value: i.lpHoldersCount,
                                onPending: () => "Liquidity Providers",
                                onFailure: () => "Liquidity Providers",
                                onSuccess: l => l ? `Liquidity Providers (${Gt(l)})` : "Liquidity Providers"
                            }),
                            onClick: () => i.handleSetActiveTab("lps"),
                            isActive: i.tabBarDisclosure !== "minimized" && i.activeTab === "lps"
                        }), n.jsx(I, {
                            display: {
                                base: "none",
                                lg: "initial",
                                xl: "none"
                            },
                            w: "20px",
                            flexShrink: 0,
                            children: " "
                        })]
                    }), t && n.jsx(Vb, {
                        value: i.tabBarDisclosure,
                        onChange: i.handleSetTabBarDisclosure
                    })]
                }), n.jsx(I, {
                    ref: s,
                    display: i.tabBarDisclosure !== "minimized" ? "block" : "none",
                    w: "100%",
                    h: `calc(100% - ${Jo}px)`,
                    overflow: "auto",
                    sx: a,
                    children: be({
                        value: i.pair,
                        onPending: yn,
                        onFailure: yn,
                        onSuccess: l => l ? n.jsxs(n.Fragment, {
                            children: [n.jsx(I, {
                                display: i.activeTab !== "all" ? "none" : void 0,
                                w: "100%",
                                h: "100%",
                                id: "thismf",
                                children: n.jsx(Fb, {
                                    platformId: l.chainId,
                                    pair: l,
                                    isInverted: i.isInverted,
                                    filteredMaker: i.filteredMaker,
                                    mobileLayout: i.mobileTxnsLayout,
                                    onMakerChange: i.handleSetFilteredMaker,
                                    highlightAddresses: i.highlightAddresses
                                }, i.resetTableKey)
                            }), i.activeTab === "traders" && n.jsx(Gb, {
                                dexScreenerPair: l,
                                onFilterMaker: i.handleSetFilteredMakerWithReset,
                                highlightAddresses: i.highlightAddresses
                            }), i.activeTab === "holders" && n.jsx(Nl, {
                                chainId: l.chainId,
                                onFilterMaker: i.handleSetFilteredMakerWithReset,
                                type: "holders",
                                highlightAddresses: i.highlightAddresses
                            }), i.activeTab === "lps" && n.jsx(Nl, {
                                chainId: l.chainId,
                                onFilterMaker: i.handleSetFilteredMakerWithReset,
                                type: "liquidityProviders"
                            })]
                        }) : null
                    })
                })]
            })
        })
    }),
    $b = ({
        isLargeScreen: e,
        pair: t
    }) => {
        const o = xe(kn),
            r = _n(v => v.embedSettings),
            {
                settings: s,
                setSettings: i
            } = $t(Tn),
            {
                toggle: a,
                value: l
            } = Yt(!1),
            {
                isInverted: c,
                tokenSupplies: d
            } = Zt(({
                isInverted: v,
                tokenSupplies: x
            }) => ({
                isInverted: v,
                tokenSupplies: x
            })),
            u = be({
                value: d,
                onPending: ln,
                onFailure: yn,
                onSuccess: v => (v == null ? void 0 : v.circulatingSupply) ? ? null
            }),
            [h, m] = f.useState(t.priceUsd ? "usd" : "quote"),
            [g, p] = f.useState("price"),
            b = v => {
                p(v), o.track({
                    event: "chart:toggleType"
                })
            },
            j = f.useMemo(() => {
                if (r.isEmbed) {
                    const v = r.info !== !1,
                        x = r.chart !== !1,
                        C = r.trades !== !1,
                        E = v && s.sidebar;
                    let R = !0;
                    return (r.dsApp || r.tabs === !1) && (R = !1), [v, x, C].filter(B => B).length <= 1 && (R = !1), {
                        isEmbed: !0,
                        isChartEnabled: x,
                        isChartVisible: e ? x : x && s.chart,
                        chartInterval: r.interval,
                        chartStyle: r.chartStyle,
                        isTxnsVisible: e ? C : C && s.trades === !0,
                        isTxnsResizable: x,
                        isTxnsEnabled: r.trades ? ? !0,
                        isSidebarVisible: E,
                        info: r.info,
                        isSidebarToggleVisible: v && !E,
                        isMobileTabBarVisible: R,
                        isTrendingBarVisible: !1
                    }
                } else return {
                    isEmbed: !1,
                    isChartEnabled: !0,
                    isChartVisible: s.chart,
                    chartStyle: r.chartStyle,
                    chartInterval: r.interval,
                    isTxnsVisible: e ? !0 : s.trades !== !1,
                    isTxnsResizable: !0,
                    isTxnsEnabled: !0,
                    info: r.info,
                    isSidebarVisible: s.sidebar,
                    isSidebarToggleVisible: e && !s.sidebar,
                    isMobileTabBarVisible: !0,
                    isTrendingBarVisible: s.trendingBar
                }
            }, [r.isEmbed, r.info, r.chart, r.trades, r.dsApp, r.tabs, r.interval, r.chartStyle, s.sidebar, s.chart, s.trades, s.trendingBar, e]),
            y = f.useMemo(() => {
                const v = [];
                r.chartStudyTemplates === !1 && v.push("study_templates"), r.chartComparePairs === !1 && v.push("header_compare"), r.chartTimeframesToolbar === !1 && v.push("timeframes_toolbar");
                const x = [];
                return r.chartLeftTollbar === !1 && x.push("hide_left_toolbar_by_default"), {
                    disabledFeatures: v,
                    enabledFeatures: x
                }
            }, [r.chartComparePairs, r.chartLeftTollbar, r.chartStudyTemplates, r.chartTimeframesToolbar]),
            S = f.useCallback(() => {
                a(), o.track({
                    event: "chart:expandOrCollapse"
                })
            }, [o, a]),
            w = f.useCallback(() => i({
                sidebar: !0
            }), [i]);
        return {
            chartQuotePricingMode: h,
            setChartQuotePricingMode: m,
            chartType: g,
            setChartType: b,
            settings: j,
            isPairInverted: c,
            circulatingSupply: u,
            isChartExpanded: l,
            toggleChartExpanded: S,
            tvWidgetOverrides: y,
            sidebarPosition: s.sidebarPosition,
            showSidebar: w
        }
    },
    Yb = e => {
        const {
            onClose: t,
            pair: o
        } = e, r = Hr(), {
            colorMode: s
        } = pe(), i = di("space", "3"), {
            chartQuotePricingMode: a,
            setChartQuotePricingMode: l,
            chartType: c,
            setChartType: d,
            settings: u,
            isPairInverted: h,
            circulatingSupply: m,
            isChartExpanded: g,
            toggleChartExpanded: p,
            tvWidgetOverrides: b,
            sidebarPosition: j,
            showSidebar: y
        } = $b({
            isLargeScreen: r,
            pair: o
        }), {
            isMobileChartOrTxnsVisible: S,
            setSettings: w
        } = $t(Tn), v = De($t(({
            settings: P
        }) => P));
        f.useEffect(() => () => w({ ...v.current,
            chart: !0,
            trades: !0,
            menu: !0
        }), [w, v]);
        const x = [c, a, h, o.pairAddress, o.baseToken.address, o.c, o.txns.h24.buys + o.txns.h24.sells === 0].join(":"),
            C = [h, o.pairAddress, o.baseToken.address, o.c].join(":"),
            [E, R] = f.useState(() => {
                let P;
                return u.info === !1 ? u.isChartEnabled ? u.isTxnsEnabled ? P = "chartTxns" : P = "chart" : P = "txns" : P = "info", P
            }),
            B = E === "chat",
            A = r ? u.isTrendingBarVisible : u.isTrendingBarVisible && !B;
        return n.jsx(O0, {
            value: o,
            children: n.jsxs(I, {
                display: "flex",
                flex: "1",
                height: "100%",
                overflow: "hidden",
                flexDir: {
                    base: "column",
                    lg: "row"
                },
                bg: T("gray.25", "blue.975", s),
                children: [n.jsx(I, {
                    display: {
                        base: !S && u.isSidebarVisible ? "flex" : "none",
                        lg: u.isSidebarVisible ? "flex" : "none"
                    },
                    flex: {
                        base: 1,
                        lg: "initial"
                    },
                    flexShrink: 0,
                    h: "100%",
                    overflow: "auto",
                    w: {
                        base: "100vw",
                        lg: `calc(${["300px",i,i,Ws.scrollbarWidth,Ws.thumbBorderWidth].join(" + ")})`
                    },
                    order: {
                        lg: j === "left" ? -1 : 1
                    },
                    borderLeftWidth: {
                        base: 0,
                        lg: j === "right" ? 1 : 0
                    },
                    borderRightWidth: {
                        base: 0,
                        lg: j === "left" ? 1 : 0
                    },
                    borderColor: T("gray.100", "blue.850", s),
                    children: n.jsx(cx, {
                        chainId: o.chainId,
                        dexId: o.dexId,
                        pair: o,
                        onClose: t,
                        isMobileTabBarVisible: u.isMobileTabBarVisible,
                        isTrendingBarVisible: A,
                        isMobileChatVisible: B
                    })
                }), n.jsxs(I, {
                    display: "flex",
                    flex: {
                        base: S ? 1 : "initial",
                        lg: 1
                    },
                    flexDir: "column",
                    w: "100%",
                    overflow: "hidden",
                    children: [n.jsxs(I, {
                        display: {
                            base: S ? "flex" : "none",
                            lg: "flex"
                        },
                        flex: 1,
                        h: "100%",
                        flexDir: "column",
                        children: [u.isChartEnabled && n.jsx(I, {
                            display: {
                                base: u.isChartVisible ? "flex" : "none",
                                lg: u.isChartVisible ? "flex" : "none"
                            },
                            flex: "1",
                            h: "100%",
                            bg: "trading-view.background",
                            ...r && g ? {
                                pos: "fixed",
                                top: 0,
                                left: 0,
                                w: "100vw",
                                h: "100vh",
                                zIndex: "2147483647"
                            } : void 0,
                            children: n.jsx(Ef, {
                                chartType: c,
                                onChartTypeChange: d,
                                chainId: o.chainId,
                                dexId: o.dexId,
                                pair: o,
                                intervalOverride: u.chartInterval,
                                chartStyle: u.chartStyle,
                                isInverted: h,
                                circulatingSupply: m,
                                isExpanded: r && g,
                                quotePricingMode: a,
                                onQuotePricingModeChange: l,
                                onToggleExpandCollapse: p,
                                widgetConfigOverrides: b
                            }, x)
                        }), u.isTxnsEnabled && n.jsx(I, {
                            display: {
                                base: u.isTxnsVisible ? "flex" : "none",
                                lg: "flex"
                            },
                            flex: u.isChartVisible ? 0 : 1,
                            bg: T("gray.25", "blue.950", s),
                            children: n.jsx(Qb, {
                                contentHeightOffset: 0,
                                isResizable: u.isTxnsResizable
                            }, C)
                        })]
                    }), A && n.jsx(I, {
                        display: {
                            base: S ? "none" : "block",
                            lg: "flex"
                        },
                        order: {
                            lg: -1
                        },
                        children: n.jsx(M0, {
                            activeChainId: o.chainId,
                            activePairAddress: o.pairAddress,
                            activeTokenAddress: o.baseToken.address,
                            isActivePairMoonshot: Ye(o)
                        })
                    })]
                }), u.isMobileTabBarVisible && n.jsx(Q0, {
                    includesInfo: u.info !== !1,
                    includesChart: u.isChartEnabled,
                    includesTxns: u.isTxnsEnabled,
                    includesChat: !u.isEmbed,
                    tabId: E,
                    onTabIdChange: R
                }), u.isSidebarToggleVisible && n.jsx(St, {
                    label: "Show sidebar",
                    placement: j === "left" ? "right" : "left",
                    gutter: 3,
                    children: n.jsx(Je, {
                        variant: "outline",
                        size: "xs",
                        display: "flex",
                        position: "absolute",
                        onClick: y,
                        top: "80px",
                        left: j === "left" ? 0 : void 0,
                        right: j === "right" ? 0 : void 0,
                        icon: n.jsx(L, {
                            as: j === "left" ? sf : af,
                            boxSize: "16px"
                        }),
                        "aria-label": "Show sidebar",
                        bg: "blue.1000",
                        borderColor: "blue.900",
                        color: "blue.600",
                        minWidth: "20px",
                        width: "25px",
                        borderLeftRadius: j === "left" ? 0 : void 0,
                        borderLeftWidth: j === "left" ? 0 : void 0,
                        borderRightRadius: j === "right" ? 0 : void 0,
                        borderRightWidth: j === "right" ? 0 : void 0,
                        _hover: {
                            "@media (hover: hover)": {
                                color: "white"
                            }
                        },
                        _active: {
                            color: "white"
                        },
                        _focus: {
                            boxShadow: "none"
                        },
                        zIndex: 1
                    })
                })]
            })
        })
    },
    Sv = ({
        onClose: e
    }) => {
        const t = Zt(a => a.pair),
            o = f.useCallback(() => n.jsx(vc, {
                loaderProps: {
                    label: "Loading pair..."
                }
            }), []),
            r = f.useCallback(a => a instanceof Ii ? n.jsx(Cc, {
                children: e && n.jsx(Fn, {
                    onClick: e,
                    pos: "absolute",
                    top: 2,
                    right: 2,
                    autoFocus: !0
                })
            }) : a instanceof Nr ? n.jsx(Kc, {
                children: e && n.jsx(Fn, {
                    onClick: e,
                    pos: "absolute",
                    top: 2,
                    right: 2,
                    autoFocus: !0
                })
            }) : n.jsxs(Cs, {
                title: "Woops!",
                children: [n.jsx(q, {
                    children: "We had problems receiveing pair you're looking for."
                }), n.jsxs(q, {
                    mt: 2,
                    children: ["If you think this is an error,", " ", n.jsx(we, {
                        href: va,
                        target: "_blank",
                        rel: "noopener noreferrer",
                        textDecor: "underline",
                        children: "please get in touch with us!"
                    })]
                }), e && n.jsx(Fn, {
                    onClick: e,
                    pos: "absolute",
                    top: 2,
                    right: 2,
                    autoFocus: !0
                })]
            }), [e]),
            s = f.useCallback(() => n.jsxs(Cs, {
                title: "Token or Pair Not Found",
                children: [n.jsx(q, {
                    children: "We can't seem to find the token or pair you're looking for."
                }), n.jsxs(q, {
                    mt: 2,
                    children: ["If you think this is an error,", " ", n.jsx(we, {
                        href: va,
                        target: "_blank",
                        rel: "noopener noreferrer",
                        textDecor: "underline",
                        children: "please get in touch with us!"
                    })]
                }), e && n.jsx(Fn, {
                    onClick: e,
                    pos: "absolute",
                    top: 2,
                    right: 2,
                    autoFocus: !0
                })]
            }), [e]),
            i = f.useCallback(a => {
                if (!a.data) switch (a.status) {
                    case "closed":
                    case "reconnecting":
                        return r();
                    case "connected":
                        return s();
                    default:
                        return o()
                }
                return n.jsxs(n.Fragment, {
                    children: [!e && (a.status === "reconnecting" || a.status === "closed") && n.jsx(lf, {
                        delay: 1e4,
                        children: n.jsx(m0, {})
                    }), n.jsx(Yb, {
                        onClose: e,
                        pair: a.data
                    })]
                })
            }, [e, r, s, o]);
        return be({
            value: t,
            onPending: o,
            onFailure: r,
            onSuccess: i
        })
    };
export {
    rt as A, lg as B, io as C, bv as D, Kc as E, gv as H, vi as I, np as M, Bl as N, Si as P, Ci as T, yv as V, Sv as a, ag as b, I0 as c, pv as d, mv as e, xv as f, Kt as g, C0 as h, Wr as i, zo as j, ji as k, wi as l, Bc as m, Mc as n, t0 as o, R0 as p, m0 as q, ki as r, Ti as s, Oc as t, hv as u, _c as v, rg as w, ep as x, Zm as y, $m as z
};

function __vite__mapDeps(indexes) {
    if (!__vite__mapDeps.viteFileDeps) {
        __vite__mapDeps.viteFileDeps = ["assets/chunks/chat-loader-5JT5oj45.js", "assets/entries/pages_catch-all.K13KjGu-.js", "assets/chunks/preload-helper-Jimfoxkq.js", "assets/static/catch-all.Yj8n6pm8.css", "assets/chunks/index.esm-bR_dkx3R.js", "assets/chunks/chunk-QINAG4RG-e7ISOrBC.js", "assets/chunks/delayed-P4PgrpHN.js", "assets/chunks/span-2n6MBXt2.js", "assets/chunks/dex-search.service-VOfr-JK0.js", "assets/chunks/display-a-ads-ad-1eoQH_VD.js", "assets/chunks/catchError-zPFqauN4.js", "assets/chunks/ads-provider-KuUDbfp5.js", "assets/chunks/embed-feature-disabled-modal-4NIwn0pw.js", "assets/chunks/price-alerts-button-oX0St9rY.js", "assets/chunks/use-observable-memo-O2SfP1qF.js", "assets/chunks/conditional-wrap-CdExTxC-.js", "assets/chunks/util-nd4DUSPU.js", "assets/chunks/index.esm-DX-SEys8.js", "assets/chunks/time-ago-gWdbdBsa.js", "assets/chunks/live-time-ago-bACH5JyH.js", "assets/chunks/AMMPairTrading-Q6o0IJBD.js", "assets/chunks/embed-modal-MOuOuiws.js", "assets/chunks/chunk-CWVAJCXJ-8-IJWDa-.js", "assets/chunks/AMMPairIframe-Tn9A6u-V.js"]
    }
    return indexes.map((i) => __vite__mapDeps.viteFileDeps[i])
}