import {
    _ as l
} from "./preload-helper-Jimfoxkq.js";
import {
    x as a,
    I as p,
    y as t,
    J as m,
    K as n,
    M as d
} from "../entries/pages_catch-all.K13KjGu-.js";
import {
    D as x,
    a as e
} from "./dex-pair-details-Yo3b0SCB.js";
import "./delayed-P4PgrpHN.js";
import "./span-2n6MBXt2.js";
import "./dex-search.service-VOfr-JK0.js";
import "./display-a-ads-ad-1eoQH_VD.js";
import "./catchError-zPFqauN4.js";
import "./ads-provider-KuUDbfp5.js";
import "./embed-feature-disabled-modal-4NIwn0pw.js";
import "./price-alerts-button-oX0St9rY.js";
import "./use-observable-memo-O2SfP1qF.js";
import "./conditional-wrap-CdExTxC-.js";
import "./util-nd4DUSPU.js";
import "./index.esm-DX-SEys8.js";
import "./time-ago-gWdbdBsa.js";
import "./live-time-ago-bACH5JyH.js";
const c = d(async () => {
        const {
            MoonshotWalletAdapter: o
        } = await l(() =>
            import ("./moonshot-wallet-adapter-Qlm_6qyw.js"), __vite__mapDeps([0, 1, 2, 3]));
        return {
            default: o
        }
    }),
    R = a.memo(({
        initialData: o,
        pairAddress: r,
        platformId: i
    }) => {
        const {
            navWidth: s
        } = p();
        return t.jsx(m, {
            display: "flex",
            flex: "1",
            height: "100%",
            overflow: "hidden",
            w: {
                lg: `calc(100vw - ${s}px)`
            },
            children: t.jsx(x, {
                initialData: o,
                chainId: i,
                pairAddress: r,
                children: t.jsx(a.Suspense, {
                    fallback: t.jsx(n, {
                        children: t.jsx(e, {})
                    }),
                    children: t.jsx(c, {
                        children: t.jsx(e, {})
                    })
                })
            }, `${i}/${r}`)
        })
    });
export {
    R as PairDetailPage
};

function __vite__mapDeps(indexes) {
    if (!__vite__mapDeps.viteFileDeps) {
        __vite__mapDeps.viteFileDeps = ["assets/chunks/moonshot-wallet-adapter-Qlm_6qyw.js", "assets/entries/pages_catch-all.K13KjGu-.js", "assets/chunks/preload-helper-Jimfoxkq.js", "assets/static/catch-all.Yj8n6pm8.css"]
    }
    return indexes.map((i) => __vite__mapDeps.viteFileDeps[i])
}