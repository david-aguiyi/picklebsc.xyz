import {
    a1 as A,
    y as G,
    a3 as R,
    by as C,
    bz as f
} from "../entries/pages_catch-all.K13KjGu-.js";
var v = A(function(r, e) {
    const {
        templateAreas: o,
        gap: a,
        rowGap: t,
        columnGap: d,
        column: i,
        row: n,
        autoFlow: u,
        autoRows: l,
        templateRows: m,
        autoColumns: p,
        templateColumns: g,
        ...w
    } = r, c = {
        display: "grid",
        gridTemplateAreas: o,
        gridGap: a,
        gridRowGap: t,
        gridColumnGap: d,
        gridAutoColumns: p,
        gridColumn: i,
        gridRow: n,
        gridAutoFlow: u,
        gridAutoRows: l,
        gridTemplateRows: m,
        gridTemplateColumns: g
    };
    return G.jsx(R.div, {
        ref: e,
        __css: c,
        ...w
    })
});
v.displayName = "Grid";
const y = s => {
        const [r, e] = f();
        return { ...s,
            refreshRequest: e,
            refresh: r
        }
    },
    [h, P] = C("AdsProvider");
export {
    P as A, v as G, y as n, h as u
};