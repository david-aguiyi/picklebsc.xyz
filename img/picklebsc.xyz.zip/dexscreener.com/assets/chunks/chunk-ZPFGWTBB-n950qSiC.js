import {
    a1 as g,
    a2 as w,
    y as l,
    a3 as R,
    a4 as S
} from "../entries/pages_catch-all.K13KjGu-.js";

function t(a) {
    return S(a, r => r === "auto" ? "auto" : `span ${r}/span ${r}`)
}
var f = g(function(r, o) {
    const {
        area: n,
        colSpan: s,
        colStart: d,
        colEnd: i,
        rowEnd: e,
        rowSpan: m,
        rowStart: p,
        ...c
    } = r, u = w({
        gridArea: n,
        gridColumn: t(s),
        gridRow: t(m),
        gridColumnStart: d,
        gridColumnEnd: i,
        gridRowStart: p,
        gridRowEnd: e
    });
    return l.jsx(R.div, {
        ref: o,
        __css: u,
        ...c
    })
});
f.displayName = "GridItem";
export {
    f as G
};