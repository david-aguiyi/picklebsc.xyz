import {
    y as a,
    aj as s,
    ak as t
} from "../entries/pages_catch-all.K13KjGu-.js";
const r = i => {
    var e;
    return a.jsx(s, { ...i,
        initialNow: (e = t().current) == null ? void 0 : e.time
    })
};
export {
    r as L
};