import {
    y as a,
    T as t
} from "../entries/pages_catch-all.K13KjGu-.js";
const p = s => a.jsx(t, {
    as: "span",
    ...s
});
export {
    p as S
};