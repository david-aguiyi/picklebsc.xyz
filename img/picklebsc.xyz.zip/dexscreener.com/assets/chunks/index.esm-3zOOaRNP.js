import {
    L as re,
    _ as R,
    n as ne,
    b as oe,
    E as ie,
    p as B,
    q as se,
    t as p,
    u as ae,
    g as ce,
    c as M,
    C as x,
    r as le,
    v as ue,
    w as de
} from "../entries/pages_catch-all.K13KjGu-.js";
import "./preload-helper-Jimfoxkq.js";
const A = new Map,
    K = {
        activated: !1,
        tokenObservers: []
    },
    he = {
        initialized: !1,
        enabled: !1
    };

function l(t) {
    return A.get(t) || Object.assign({}, K)
}

function fe(t, e) {
    return A.set(t, e), A.get(t)
}

function b() {
    return he
}
const C = "https://content-firebaseappcheck.googleapis.com/v1",
    pe = "exchangeRecaptchaV3Token",
    ge = "exchangeRecaptchaEnterpriseToken",
    ke = "exchangeDebugToken",
    N = {
        OFFSET_DURATION: 5 * 60 * 1e3,
        RETRIAL_MIN_WAIT: 30 * 1e3,
        RETRIAL_MAX_WAIT: 16 * 60 * 1e3
    },
    Ee = 24 * 60 * 60 * 1e3;
class Te {
    constructor(e, r, n, o, i) {
        if (this.operation = e, this.retryPolicy = r, this.getWaitDuration = n, this.lowerBound = o, this.upperBound = i, this.pending = null, this.nextErrorWaitInterval = o, o > i) throw new Error("Proactive refresh lower bound greater than upper bound!")
    }
    start() {
        this.nextErrorWaitInterval = this.lowerBound, this.process(!0).catch(() => {})
    }
    stop() {
        this.pending && (this.pending.reject("cancelled"), this.pending = null)
    }
    isRunning() {
        return !!this.pending
    }
    async process(e) {
        this.stop();
        try {
            this.pending = new p, await me(this.getNextRun(e)), this.pending.resolve(), await this.pending.promise, this.pending = new p, await this.operation(), this.pending.resolve(), await this.pending.promise, this.process(!0).catch(() => {})
        } catch (r) {
            this.retryPolicy(r) ? this.process(!1).catch(() => {}) : this.stop()
        }
    }
    getNextRun(e) {
        if (e) return this.nextErrorWaitInterval = this.lowerBound, this.getWaitDuration(); {
            const r = this.nextErrorWaitInterval;
            return this.nextErrorWaitInterval *= 2, this.nextErrorWaitInterval > this.upperBound && (this.nextErrorWaitInterval = this.upperBound), r
        }
    }
}

function me(t) {
    return new Promise(e => {
        setTimeout(e, t)
    })
}
const we = {
        "already-initialized": "You have already called initializeAppCheck() for FirebaseApp {$appName} with different options. To avoid this error, call initializeAppCheck() with the same options as when it was originally called. This will return the already initialized instance.",
        "use-before-activation": "App Check is being used before initializeAppCheck() is called for FirebaseApp {$appName}. Call initializeAppCheck() before instantiating other Firebase services.",
        "fetch-network-error": "Fetch failed to connect to a network. Check Internet connection. Original error: {$originalErrorMessage}.",
        "fetch-parse-error": "Fetch client could not parse response. Original error: {$originalErrorMessage}.",
        "fetch-status-error": "Fetch server returned an HTTP error status. HTTP status: {$httpStatus}.",
        "storage-open": "Error thrown when opening storage. Original error: {$originalErrorMessage}.",
        "storage-get": "Error thrown when reading from storage. Original error: {$originalErrorMessage}.",
        "storage-set": "Error thrown when writing to storage. Original error: {$originalErrorMessage}.",
        "recaptcha-error": "ReCAPTCHA error.",
        throttled: "Requests throttled due to {$httpStatus} error. Attempts allowed again after {$time}"
    },
    u = new ie("appCheck", "AppCheck", we);

function m(t = !1) {
    var e;
    return t ? (e = self.grecaptcha) === null || e === void 0 ? void 0 : e.enterprise : self.grecaptcha
}

function F(t) {
    if (!l(t).activated) throw u.create("use-before-activation", {
        appName: t.name
    })
}

function P(t) {
    const e = Math.round(t / 1e3),
        r = Math.floor(e / (3600 * 24)),
        n = Math.floor((e - r * 3600 * 24) / 3600),
        o = Math.floor((e - r * 3600 * 24 - n * 3600) / 60),
        i = e - r * 3600 * 24 - n * 3600 - o * 60;
    let a = "";
    return r && (a += E(r) + "d:"), n && (a += E(n) + "h:"), a += E(o) + "m:" + E(i) + "s", a
}

function E(t) {
    return t === 0 ? "00" : t >= 10 ? t.toString() : "0" + t
}
async function y({
    url: t,
    body: e
}, r) {
    const n = {
            "Content-Type": "application/json"
        },
        o = r.getImmediate({
            optional: !0
        });
    if (o) {
        const d = await o.getHeartbeatsHeader();
        d && (n["X-Firebase-Client"] = d)
    }
    const i = {
        method: "POST",
        body: JSON.stringify(e),
        headers: n
    };
    let a;
    try {
        a = await fetch(t, i)
    } catch (d) {
        throw u.create("fetch-network-error", {
            originalErrorMessage: d == null ? void 0 : d.message
        })
    }
    if (a.status !== 200) throw u.create("fetch-status-error", {
        httpStatus: a.status
    });
    let c;
    try {
        c = await a.json()
    } catch (d) {
        throw u.create("fetch-parse-error", {
            originalErrorMessage: d == null ? void 0 : d.message
        })
    }
    const s = c.ttl.match(/^([\d.]+)(s)$/);
    if (!s || !s[2] || isNaN(Number(s[1]))) throw u.create("fetch-parse-error", {
        originalErrorMessage: `ttl field (timeToLive) is not in standard Protobuf Duration format: ${c.ttl}`
    });
    const f = Number(s[1]) * 1e3,
        S = Date.now();
    return {
        token: c.token,
        expireTimeMillis: S + f,
        issuedAtTimeMillis: S
    }
}

function _e(t, e) {
    const {
        projectId: r,
        appId: n,
        apiKey: o
    } = t.options;
    return {
        url: `${C}/projects/${r}/apps/${n}:${pe}?key=${o}`,
        body: {
            recaptcha_v3_token: e
        }
    }
}

function be(t, e) {
    const {
        projectId: r,
        appId: n,
        apiKey: o
    } = t.options;
    return {
        url: `${C}/projects/${r}/apps/${n}:${ge}?key=${o}`,
        body: {
            recaptcha_enterprise_token: e
        }
    }
}

function ve(t, e) {
    const {
        projectId: r,
        appId: n,
        apiKey: o
    } = t.options;
    return {
        url: `${C}/projects/${r}/apps/${n}:${ke}?key=${o}`,
        body: {
            debug_token: e
        }
    }
}
const Ae = "firebase-app-check-database",
    Re = 1,
    g = "firebase-app-check-store",
    L = "debug-token";
let T = null;

function z() {
    return T || (T = new Promise((t, e) => {
        try {
            const r = indexedDB.open(Ae, Re);
            r.onsuccess = n => {
                t(n.target.result)
            }, r.onerror = n => {
                var o;
                e(u.create("storage-open", {
                    originalErrorMessage: (o = n.target.error) === null || o === void 0 ? void 0 : o.message
                }))
            }, r.onupgradeneeded = n => {
                const o = n.target.result;
                switch (n.oldVersion) {
                    case 0:
                        o.createObjectStore(g, {
                            keyPath: "compositeKey"
                        })
                }
            }
        } catch (r) {
            e(u.create("storage-open", {
                originalErrorMessage: r == null ? void 0 : r.message
            }))
        }
    }), T)
}

function Ce(t) {
    return q(W(t))
}

function Pe(t, e) {
    return j(W(t), e)
}

function ye(t) {
    return j(L, t)
}

function De() {
    return q(L)
}
async function j(t, e) {
    const n = (await z()).transaction(g, "readwrite"),
        i = n.objectStore(g).put({
            compositeKey: t,
            value: e
        });
    return new Promise((a, c) => {
        i.onsuccess = s => {
            a()
        }, n.onerror = s => {
            var f;
            c(u.create("storage-set", {
                originalErrorMessage: (f = s.target.error) === null || f === void 0 ? void 0 : f.message
            }))
        }
    })
}
async function q(t) {
    const r = (await z()).transaction(g, "readonly"),
        o = r.objectStore(g).get(t);
    return new Promise((i, a) => {
        o.onsuccess = c => {
            const s = c.target.result;
            i(s ? s.value : void 0)
        }, r.onerror = c => {
            var s;
            a(u.create("storage-get", {
                originalErrorMessage: (s = c.target.error) === null || s === void 0 ? void 0 : s.message
            }))
        }
    })
}

function W(t) {
    return `${t.options.appId}-${t.name}`
}
const k = new re("@firebase/app-check");
async function Ie(t) {
    if (B()) {
        let e;
        try {
            e = await Ce(t)
        } catch (r) {
            k.warn(`Failed to read token from IndexedDB. Error: ${r}`)
        }
        return e
    }
}

function v(t, e) {
    return B() ? Pe(t, e).catch(r => {
        k.warn(`Failed to write token to IndexedDB. Error: ${r}`)
    }) : Promise.resolve()
}
async function Se() {
    let t;
    try {
        t = await De()
    } catch {}
    if (t) return t; {
        const e = ue();
        return ye(e).catch(r => k.warn(`Failed to persist debug token to IndexedDB. Error: ${r}`)), e
    }
}

function U() {
    return b().enabled
}
async function G() {
    const t = b();
    if (t.enabled && t.token) return t.token.promise;
    throw Error(`
            Can't get debug token in production mode.
        `)
}

function Me() {
    const t = se(),
        e = b();
    if (e.initialized = !0, typeof t.FIREBASE_APPCHECK_DEBUG_TOKEN != "string" && t.FIREBASE_APPCHECK_DEBUG_TOKEN !== !0) return;
    e.enabled = !0;
    const r = new p;
    e.token = r, typeof t.FIREBASE_APPCHECK_DEBUG_TOKEN == "string" ? r.resolve(t.FIREBASE_APPCHECK_DEBUG_TOKEN) : r.resolve(Se())
}
const xe = {
    error: "UNKNOWN_ERROR"
};

function Ne(t) {
    return de.encodeString(JSON.stringify(t), !1)
}
async function w(t, e = !1) {
    const r = t.app;
    F(r);
    const n = l(r);
    let o = n.token,
        i;
    if (o && !h(o) && (n.token = void 0, o = void 0), !o) {
        const s = await n.cachedTokenPromise;
        s && (h(s) ? o = s : await v(r, void 0))
    }
    if (!e && o && h(o)) return {
        token: o.token
    };
    let a = !1;
    if (U()) {
        n.exchangeTokenPromise || (n.exchangeTokenPromise = y(ve(r, await G()), t.heartbeatServiceProvider).finally(() => {
            n.exchangeTokenPromise = void 0
        }), a = !0);
        const s = await n.exchangeTokenPromise;
        return await v(r, s), n.token = s, {
            token: s.token
        }
    }
    try {
        n.exchangeTokenPromise || (n.exchangeTokenPromise = n.provider.getToken().finally(() => {
            n.exchangeTokenPromise = void 0
        }), a = !0), o = await l(r).exchangeTokenPromise
    } catch (s) {
        s.code === "appCheck/throttled" ? k.warn(s.message) : k.error(s), i = s
    }
    let c;
    return o ? i ? h(o) ? c = {
        token: o.token,
        internalError: i
    } : c = $(i) : (c = {
        token: o.token
    }, n.token = o, await v(r, o)) : c = $(i), a && X(r, c), c
}

function D(t, e, r, n) {
    const {
        app: o
    } = t, i = l(o), a = {
        next: r,
        error: n,
        type: e
    };
    if (i.tokenObservers = [...i.tokenObservers, a], i.token && h(i.token)) {
        const c = i.token;
        Promise.resolve().then(() => {
            r({
                token: c.token
            }), O(t)
        }).catch(() => {})
    }
    i.cachedTokenPromise.then(() => O(t))
}

function I(t, e) {
    const r = l(t),
        n = r.tokenObservers.filter(o => o.next !== e);
    n.length === 0 && r.tokenRefresher && r.tokenRefresher.isRunning() && r.tokenRefresher.stop(), r.tokenObservers = n
}

function O(t) {
    const {
        app: e
    } = t, r = l(e);
    let n = r.tokenRefresher;
    n || (n = Oe(t), r.tokenRefresher = n), !n.isRunning() && r.isTokenAutoRefreshEnabled && n.start()
}

function Oe(t) {
    const {
        app: e
    } = t;
    return new Te(async () => {
        const r = l(e);
        let n;
        if (r.token ? n = await w(t, !0) : n = await w(t), n.error) throw n.error;
        if (n.internalError) throw n.internalError
    }, () => !0, () => {
        const r = l(e);
        if (r.token) {
            let n = r.token.issuedAtTimeMillis + (r.token.expireTimeMillis - r.token.issuedAtTimeMillis) * .5 + 3e5;
            const o = r.token.expireTimeMillis - 5 * 60 * 1e3;
            return n = Math.min(n, o), Math.max(0, n - Date.now())
        } else return 0
    }, N.RETRIAL_MIN_WAIT, N.RETRIAL_MAX_WAIT)
}

function X(t, e) {
    const r = l(t).tokenObservers;
    for (const n of r) try {
        n.type === "EXTERNAL" && e.error != null ? n.error(e.error) : n.next(e)
    } catch {}
}

function h(t) {
    return t.expireTimeMillis - Date.now() > 0
}

function $(t) {
    return {
        token: Ne(xe),
        error: t
    }
}
class $e {
    constructor(e, r) {
        this.app = e, this.heartbeatServiceProvider = r
    }
    _delete() {
        const {
            tokenObservers: e
        } = l(this.app);
        for (const r of e) I(this.app, r.next);
        return Promise.resolve()
    }
}

function He(t, e) {
    return new $e(t, e)
}

function Be(t) {
    return {
        getToken: e => w(t, e),
        addTokenListener: e => D(t, "INTERNAL", e),
        removeTokenListener: e => I(t.app, e)
    }
}
const Ke = "@firebase/app-check",
    Fe = "0.6.3";
const Le = "https://www.google.com/recaptcha/api.js",
    ze = "https://www.google.com/recaptcha/enterprise.js";

function je(t, e) {
    const r = new p,
        n = l(t);
    n.reCAPTCHAState = {
        initialized: r
    };
    const o = V(t),
        i = m(!1);
    return i ? _(t, e, i, o, r) : Ue(() => {
        const a = m(!1);
        if (!a) throw new Error("no recaptcha");
        _(t, e, a, o, r)
    }), r.promise
}

function qe(t, e) {
    const r = new p,
        n = l(t);
    n.reCAPTCHAState = {
        initialized: r
    };
    const o = V(t),
        i = m(!0);
    return i ? _(t, e, i, o, r) : Ge(() => {
        const a = m(!0);
        if (!a) throw new Error("no recaptcha");
        _(t, e, a, o, r)
    }), r.promise
}

function _(t, e, r, n, o) {
    r.ready(() => {
        We(t, e, r, n), o.resolve(r)
    })
}

function V(t) {
    const e = `fire_app_check_${t.name}`,
        r = document.createElement("div");
    return r.id = e, r.style.display = "none", document.body.appendChild(r), e
}
async function Y(t) {
    F(t);
    const r = await l(t).reCAPTCHAState.initialized.promise;
    return new Promise((n, o) => {
        const i = l(t).reCAPTCHAState;
        r.ready(() => {
            n(r.execute(i.widgetId, {
                action: "fire_app_check"
            }))
        })
    })
}

function We(t, e, r, n) {
    const o = r.render(n, {
            sitekey: e,
            size: "invisible"
        }),
        i = l(t);
    i.reCAPTCHAState = Object.assign(Object.assign({}, i.reCAPTCHAState), {
        widgetId: o
    })
}

function Ue(t) {
    const e = document.createElement("script");
    e.src = Le, e.onload = t, document.head.appendChild(e)
}

function Ge(t) {
    const e = document.createElement("script");
    e.src = ze, e.onload = t, document.head.appendChild(e)
}
class J {
    constructor(e) {
        this._siteKey = e, this._throttleData = null
    }
    async getToken() {
        var e, r;
        te(this._throttleData);
        const n = await Y(this._app).catch(i => {
            throw u.create("recaptcha-error")
        });
        let o;
        try {
            o = await y(_e(this._app, n), this._heartbeatServiceProvider)
        } catch (i) {
            throw !((e = i.code) === null || e === void 0) && e.includes("fetch-status-error") ? (this._throttleData = ee(Number((r = i.customData) === null || r === void 0 ? void 0 : r.httpStatus), this._throttleData), u.create("throttled", {
                time: P(this._throttleData.allowRequestsAfter - Date.now()),
                httpStatus: this._throttleData.httpStatus
            })) : i
        }
        return this._throttleData = null, o
    }
    initialize(e) {
        this._app = e, this._heartbeatServiceProvider = R(e, "heartbeat"), je(e, this._siteKey).catch(() => {})
    }
    isEqual(e) {
        return e instanceof J ? this._siteKey === e._siteKey : !1
    }
}
class Q {
    constructor(e) {
        this._siteKey = e, this._throttleData = null
    }
    async getToken() {
        var e, r;
        te(this._throttleData);
        const n = await Y(this._app).catch(i => {
            throw u.create("recaptcha-error")
        });
        let o;
        try {
            o = await y(be(this._app, n), this._heartbeatServiceProvider)
        } catch (i) {
            throw !((e = i.code) === null || e === void 0) && e.includes("fetch-status-error") ? (this._throttleData = ee(Number((r = i.customData) === null || r === void 0 ? void 0 : r.httpStatus), this._throttleData), u.create("throttled", {
                time: P(this._throttleData.allowRequestsAfter - Date.now()),
                httpStatus: this._throttleData.httpStatus
            })) : i
        }
        return this._throttleData = null, o
    }
    initialize(e) {
        this._app = e, this._heartbeatServiceProvider = R(e, "heartbeat"), qe(e, this._siteKey).catch(() => {})
    }
    isEqual(e) {
        return e instanceof Q ? this._siteKey === e._siteKey : !1
    }
}
class Z {
    constructor(e) {
        this._customProviderOptions = e
    }
    async getToken() {
        const e = await this._customProviderOptions.getToken(),
            r = ne(e.token),
            n = r !== null && r < Date.now() && r > 0 ? r * 1e3 : Date.now();
        return Object.assign(Object.assign({}, e), {
            issuedAtTimeMillis: n
        })
    }
    initialize(e) {
        this._app = e
    }
    isEqual(e) {
        return e instanceof Z ? this._customProviderOptions.getToken.toString() === e._customProviderOptions.getToken.toString() : !1
    }
}

function ee(t, e) {
    if (t === 404 || t === 403) return {
        backoffCount: 1,
        allowRequestsAfter: Date.now() + Ee,
        httpStatus: t
    }; {
        const r = e ? e.backoffCount : 0,
            n = ae(r, 1e3, 2);
        return {
            backoffCount: r + 1,
            allowRequestsAfter: Date.now() + n,
            httpStatus: t
        }
    }
}

function te(t) {
    if (t && Date.now() - t.allowRequestsAfter <= 0) throw u.create("throttled", {
        time: P(t.allowRequestsAfter - Date.now()),
        httpStatus: t.httpStatus
    })
}

function Ze(t = oe(), e) {
    t = ce(t);
    const r = R(t, "app-check");
    if (b().initialized || Me(), U() && G().then(o => console.log(`App Check debug token: ${o}. You will need to add it to your app's App Check settings in the Firebase console for it to work.`)), r.isInitialized()) {
        const o = r.getImmediate(),
            i = r.getOptions();
        if (i.isTokenAutoRefreshEnabled === e.isTokenAutoRefreshEnabled && i.provider.isEqual(e.provider)) return o;
        throw u.create("already-initialized", {
            appName: t.name
        })
    }
    const n = r.initialize({
        options: e
    });
    return Xe(t, e.provider, e.isTokenAutoRefreshEnabled), l(t).isTokenAutoRefreshEnabled && D(n, "INTERNAL", () => {}), n
}

function Xe(t, e, r) {
    const n = fe(t, Object.assign({}, K));
    n.activated = !0, n.provider = e, n.cachedTokenPromise = Ie(t).then(o => (o && h(o) && (n.token = o, X(t, {
        token: o.token
    })), o)), n.isTokenAutoRefreshEnabled = r === void 0 ? t.automaticDataCollectionEnabled : r, n.provider.initialize(t)
}

function et(t, e) {
    const r = t.app,
        n = l(r);
    n.tokenRefresher && (e === !0 ? n.tokenRefresher.start() : n.tokenRefresher.stop()), n.isTokenAutoRefreshEnabled = e
}
async function tt(t, e) {
    const r = await w(t, e);
    if (r.error) throw r.error;
    return {
        token: r.token
    }
}

function rt(t, e, r, n) {
    let o = () => {},
        i = () => {};
    return e.next != null ? o = e.next.bind(e) : o = e, e.error != null ? i = e.error.bind(e) : r && (i = r), D(t, "EXTERNAL", o, i), () => I(t.app, o)
}
const Ve = "app-check",
    H = "app-check-internal";

function Ye() {
    M(new x(Ve, t => {
        const e = t.getProvider("app").getImmediate(),
            r = t.getProvider("heartbeat");
        return He(e, r)
    }, "PUBLIC").setInstantiationMode("EXPLICIT").setInstanceCreatedCallback((t, e, r) => {
        t.getProvider(H).initialize()
    })), M(new x(H, t => {
        const e = t.getProvider("app-check").getImmediate();
        return Be(e)
    }, "PUBLIC").setInstantiationMode("EXPLICIT")), le(Ke, Fe)
}
Ye();
export {
    Z as CustomProvider, Q as ReCaptchaEnterpriseProvider, J as ReCaptchaV3Provider, tt as getToken, Ze as initializeAppCheck, rt as onTokenChanged, et as setTokenAutoRefreshEnabled
};