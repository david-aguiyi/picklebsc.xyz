import {
    bg as rs,
    a1 as de,
    bh as is,
    bi as ls,
    y as e,
    a3 as je,
    a9 as C,
    cO as Ve,
    b6 as Q,
    cP as ae,
    b7 as W,
    J as T,
    ao as me,
    x as d,
    cQ as ye,
    cR as xe,
    bU as oe,
    az as O,
    cS as cs,
    V as ce,
    U as F,
    cT as Le,
    cU as Se,
    bE as Oe,
    A as q,
    aT as ds,
    ak as hs,
    cl as Fe,
    cm as us,
    ch as ms,
    cV as ge,
    T as L,
    cW as xs,
    cX as ps,
    cY as gs,
    cZ as bs,
    c_ as fs,
    c$ as js,
    d0 as ke,
    bX as Ue,
    cp as ys,
    d1 as Ss,
    d2 as vs,
    d3 as Is,
    af as be,
    d4 as Cs,
    d5 as he,
    d6 as ws,
    aG as Y,
    c8 as ks,
    c7 as Te,
    c4 as Be,
    b5 as Ts,
    d7 as qe,
    d8 as Ge,
    bn as Ms,
    d9 as Es,
    aY as Ps,
    bV as Ws,
    c3 as As,
    bx as zs,
    a$ as Me,
    da as Rs,
    db as Ds,
    dc as Ns,
    aV as _s,
    dd as Hs,
    aN as Vs,
    ar as Ls,
    as as Os,
    at as Fs,
    av as Us,
    de as Bs,
    df as qs,
    dg as Gs,
    Z as U,
    dh as Ks,
    ag as Xs,
    ax as $s,
    cu as Ys,
    O as Qs,
    cf as Zs,
    H as Ee,
    a6 as Js,
    di as en,
    bR as sn,
    dj as nn,
    dk as tn,
    dl as Ke,
    dm as an,
    dn as on,
    aR as rn
} from "../entries/pages_catch-all.K13KjGu-.js";
import {
    b as ln,
    g as cn,
    B as dn,
    W as hn,
    a as un,
    c as mn,
    T as Pe,
    s as xn,
    d as Xe,
    A as pn,
    E as gn,
    S as bn
} from "./dex-search.service-VOfr-JK0.js";
import {
    r as fn,
    S as jn
} from "./logo-RhqyaPCw.js";
import {
    n as yn,
    A as Sn,
    G as $e
} from "./ads-provider-KuUDbfp5.js";
import {
    S as p
} from "./span-2n6MBXt2.js";
import {
    W as We,
    a as $
} from "./embed-feature-disabled-modal-4NIwn0pw.js";
import {
    c as Ye
} from "./catchError-zPFqauN4.js";
import {
    G as Qe
} from "./chunk-ZPFGWTBB-n950qSiC.js";
var [vn, Ze] = rs({
    name: "TagStylesContext",
    errorMessage: `useTagStyles returned is 'undefined'. Seems you forgot to wrap the components in "<Tag />" `
}), Je = de((s, n) => {
    const a = is("Tag", s),
        r = ls(s),
        o = {
            display: "inline-flex",
            verticalAlign: "top",
            alignItems: "center",
            maxWidth: "100%",
            ...a.container
        };
    return e.jsx(vn, {
        value: a,
        children: e.jsx(je.span, {
            ref: n,
            ...r,
            __css: o
        })
    })
});
Je.displayName = "Tag";
var es = de((s, n) => {
    const a = Ze();
    return e.jsx(je.span, {
        ref: n,
        noOfLines: 1,
        ...s,
        __css: a.label
    })
});
es.displayName = "TagLabel";
var In = de((s, n) => e.jsx(C, {
    ref: n,
    verticalAlign: "top",
    marginEnd: "0.5rem",
    ...s
}));
In.displayName = "TagLeftIcon";
var Cn = de((s, n) => e.jsx(C, {
    ref: n,
    verticalAlign: "top",
    marginStart: "0.5rem",
    ...s
}));
Cn.displayName = "TagRightIcon";
var ss = s => e.jsx(C, {
    verticalAlign: "inherit",
    viewBox: "0 0 512 512",
    ...s,
    children: e.jsx("path", {
        fill: "currentColor",
        d: "M289.94 256l95-95A24 24 0 00351 127l-95 95-95-95a24 24 0 00-34 34l95 95-95 95a24 24 0 1034 34l95-95 95 95a24 24 0 0034-34z"
    })
});
ss.displayName = "TagCloseIcon";
var ns = de((s, n) => {
    const {
        isDisabled: a,
        children: r,
        ...o
    } = s, i = {
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        outline: "0",
        ...Ze().closeButton
    };
    return e.jsx(je.button, {
        ref: n,
        "aria-label": "close",
        ...o,
        type: "button",
        disabled: a,
        __css: i,
        children: r || e.jsx(ss, {})
    })
});
ns.displayName = "TagCloseButton";
let Ae = s => typeof s == "object" && s != null && s.nodeType === 1,
    ze = (s, n) => (!n || s !== "hidden") && s !== "visible" && s !== "clip",
    pe = (s, n) => {
        if (s.clientHeight < s.scrollHeight || s.clientWidth < s.scrollWidth) {
            let a = getComputedStyle(s, null);
            return ze(a.overflowY, n) || ze(a.overflowX, n) || (r => {
                let o = (t => {
                    if (!t.ownerDocument || !t.ownerDocument.defaultView) return null;
                    try {
                        return t.ownerDocument.defaultView.frameElement
                    } catch {
                        return null
                    }
                })(r);
                return !!o && (o.clientHeight < r.scrollHeight || o.clientWidth < r.scrollWidth)
            })(s)
        }
        return !1
    },
    ue = (s, n, a, r, o, t, i, l) => t < s && i > n || t > s && i < n ? 0 : t <= s && l <= a || i >= n && l >= a ? t - s - r : i > n && l < a || t < s && l > a ? i - n + o : 0,
    wn = s => {
        let n = s.parentElement;
        return n ? ? (s.getRootNode().host || null)
    },
    Re = (s, n) => {
        var a, r, o, t;
        if (typeof document > "u") return [];
        let {
            scrollMode: i,
            block: l,
            inline: g,
            boundary: E,
            skipOverflowHiddenElements: y
        } = n, P = typeof E == "function" ? E : _ => _ !== E;
        if (!Ae(s)) throw new TypeError("Invalid target");
        let m = document.scrollingElement || document.documentElement,
            h = [],
            S = s;
        for (; Ae(S) && P(S);) {
            if (S = wn(S), S === m) {
                h.push(S);
                break
            }
            S != null && S === document.body && pe(S) && !pe(document.documentElement) || S != null && pe(S, y) && h.push(S)
        }
        let v = (r = (a = window.visualViewport) == null ? void 0 : a.width) != null ? r : innerWidth,
            A = (t = (o = window.visualViewport) == null ? void 0 : o.height) != null ? t : innerHeight,
            {
                scrollX: w,
                scrollY: b
            } = window,
            {
                height: z,
                width: f,
                top: x,
                right: k,
                bottom: V,
                left: B
            } = s.getBoundingClientRect(),
            N = l === "start" || l === "nearest" ? x : l === "end" ? V : x + z / 2,
            R = g === "center" ? B + f / 2 : g === "end" ? k : B,
            D = [];
        for (let _ = 0; _ < h.length; _++) {
            let I = h[_],
                {
                    height: M,
                    width: K,
                    top: G,
                    right: re,
                    bottom: ie,
                    left: X
                } = I.getBoundingClientRect();
            if (i === "if-needed" && x >= 0 && B >= 0 && V <= A && k <= v && x >= G && V <= ie && B >= X && k <= re) return D;
            let Z = getComputedStyle(I),
                J = parseInt(Z.borderLeftWidth, 10),
                ee = parseInt(Z.borderTopWidth, 10),
                se = parseInt(Z.borderRightWidth, 10),
                c = parseInt(Z.borderBottomWidth, 10),
                u = 0,
                j = 0,
                H = "offsetWidth" in I ? I.offsetWidth - I.clientWidth - J - se : 0,
                ne = "offsetHeight" in I ? I.offsetHeight - I.clientHeight - ee - c : 0,
                ve = "offsetWidth" in I ? I.offsetWidth === 0 ? 0 : K / I.offsetWidth : 0,
                Ie = "offsetHeight" in I ? I.offsetHeight === 0 ? 0 : M / I.offsetHeight : 0;
            if (m === I) u = l === "start" ? N : l === "end" ? N - A : l === "nearest" ? ue(b, b + A, A, ee, c, b + N, b + N + z, z) : N - A / 2, j = g === "start" ? R : g === "center" ? R - v / 2 : g === "end" ? R - v : ue(w, w + v, v, J, se, w + R, w + R + f, f), u = Math.max(0, u + b), j = Math.max(0, j + w);
            else {
                u = l === "start" ? N - G - ee : l === "end" ? N - ie + c + ne : l === "nearest" ? ue(G, ie, M, ee, c + ne, N, N + z, z) : N - (G + M / 2) + ne / 2, j = g === "start" ? R - X - J : g === "center" ? R - (X + K / 2) + H / 2 : g === "end" ? R - re + se + H : ue(X, re, K, J, se + H, R, R + f, f);
                let {
                    scrollLeft: Ce,
                    scrollTop: we
                } = I;
                u = Math.max(0, Math.min(we + u / Ie, I.scrollHeight - M / Ie + ne)), j = Math.max(0, Math.min(Ce + j / ve, I.scrollWidth - K / ve + H)), N += we - u, R += Ce - j
            }
            D.push({
                el: I,
                top: u,
                left: j
            })
        }
        return D
    };
const kn = s => s === !1 ? {
    block: "end",
    inline: "nearest"
} : (n => n === Object(n) && Object.keys(n).length !== 0)(s) ? s : {
    block: "start",
    inline: "nearest"
};

function Tn(s, n) {
    if (!s.isConnected || !(o => {
            let t = o;
            for (; t && t.parentNode;) {
                if (t.parentNode === document) return !0;
                t = t.parentNode instanceof ShadowRoot ? t.parentNode.host : t.parentNode
            }
            return !1
        })(s)) return;
    const a = (o => {
        const t = window.getComputedStyle(o);
        return {
            top: parseFloat(t.scrollMarginTop) || 0,
            right: parseFloat(t.scrollMarginRight) || 0,
            bottom: parseFloat(t.scrollMarginBottom) || 0,
            left: parseFloat(t.scrollMarginLeft) || 0
        }
    })(s);
    if ((o => typeof o == "object" && typeof o.behavior == "function")(n)) return n.behavior(Re(s, n));
    const r = typeof n == "boolean" || n == null ? void 0 : n.behavior;
    for (const {
            el: o,
            top: t,
            left: i
        } of Re(s, kn(n))) {
        const l = t - a.top + a.bottom,
            g = i - a.left + a.right;
        o.scroll({
            top: l,
            left: g,
            behavior: r
        })
    }
}
const ts = {
        base: "83px",
        lg: "58px"
    },
    te = "40px",
    Mn = () => e.jsx(Ve, {
        userSelect: "none",
        borderRadius: "md",
        py: "0",
        alignItems: {
            lg: "center"
        },
        justifyContent: {
            base: "center",
            lg: "flex-start"
        },
        h: ts,
        children: e.jsxs(Q, {
            align: "center",
            pos: "relative",
            direction: {
                base: "column",
                lg: "row"
            },
            spacing: {
                base: 3,
                lg: 2
            },
            paddingX: {
                base: 1,
                lg: 2
            },
            pt: {
                base: "35px",
                lg: 3
            },
            pb: {
                base: "10px",
                lg: 3
            },
            children: [e.jsx(ae, {
                pos: {
                    base: "absolute",
                    lg: "initial"
                },
                top: "-10px",
                size: te,
                bg: W("rgba(0, 0, 0, 0.05)", "rgba(255, 255, 255, 0.025)")
            }), e.jsxs(T, {
                display: "flex",
                flexDir: "column",
                alignItems: {
                    base: "center",
                    lg: "flex-start"
                },
                w: "100%",
                gap: 2,
                children: [e.jsx(T, {
                    bg: W("rgba(0, 0, 0, 0.05)", "rgba(255, 255, 255, 0.025)"),
                    w: "70%",
                    h: "14px"
                }), e.jsx(T, {
                    bg: W("rgba(0, 0, 0, 0.05)", "rgba(255, 255, 255, 0.025)"),
                    w: "40%",
                    h: "10px"
                })]
            })]
        })
    }),
    En = ({
        onClose: s,
        pair: n
    }) => {
        var t, i;
        const a = q(ln),
            {
                colorMode: r
            } = me(),
            o = d.useCallback(l => {
                l.metaKey || l.ctrlKey || l.button === 1 || s()
            }, [s]);
        return e.jsx(ye, {
            to: xe({
                platformId: n.chainId,
                pairAddress: n.pairAddress
            }),
            onClick: o,
            display: "flex",
            alignItems: {
                lg: "center"
            },
            justifyContent: {
                base: "center",
                lg: "flex-start"
            },
            userSelect: "none",
            borderRadius: "md",
            bg: W("white", "blue.950"),
            py: "0",
            isHoverable: !0,
            minW: "0",
            h: ts,
            children: e.jsxs(Q, {
                align: "center",
                pos: "relative",
                direction: {
                    base: "column",
                    lg: "row"
                },
                spacing: {
                    base: 3,
                    lg: 2
                },
                paddingX: {
                    base: 1,
                    lg: 2
                },
                pt: {
                    base: "35px",
                    lg: 3
                },
                pb: {
                    base: "10px",
                    lg: 3
                },
                children: [e.jsx(T, {
                    pos: {
                        base: "absolute",
                        lg: "initial"
                    },
                    top: "-10px",
                    children: (t = n.cmsProfile) != null && t.iconId ? e.jsx(oe, {
                        src: a({
                            assetId: (i = n.cmsProfile) == null ? void 0 : i.iconId,
                            fit: "crop",
                            size: "lg"
                        }),
                        minW: te,
                        width: te,
                        height: te,
                        minWidth: te,
                        loading: "lazy"
                    }) : e.jsx(ae, {
                        size: te,
                        bg: O("blackAlpha.200", "blackAlpha.300", r),
                        children: e.jsx(C, {
                            as: cs,
                            boxSize: "20px",
                            color: O("white", "whiteAlpha.150", r)
                        })
                    })
                }), e.jsx(T, {
                    display: "flex",
                    flexDir: "column",
                    alignItems: {
                        base: "center",
                        lg: "flex-start"
                    },
                    overflow: "hidden",
                    children: e.jsxs(ce, {
                        align: {
                            base: "center",
                            lg: "flex-start"
                        },
                        w: "100%",
                        spacing: "0.5",
                        textAlign: {
                            base: "center",
                            lg: "left"
                        },
                        children: [e.jsx(p, {
                            px: {
                                base: 2,
                                lg: 0
                            },
                            pr: {
                                lg: 2
                            },
                            display: "block",
                            fontWeight: "semibold",
                            fontSize: "md",
                            noOfLines: 1,
                            wordBreak: "break-all",
                            overflow: "hidden",
                            textOverflow: "ellipsis",
                            children: n.baseToken.name
                        }), e.jsxs(F, {
                            spacing: 1.5,
                            children: [e.jsx(p, {
                                fontSize: "xs",
                                fontWeight: "semibold",
                                color: W("blue.400", "blue.600"),
                                children: n.moonshot.progress < 100 ? `${Math.floor(n.moonshot.progress)}%` : Le(n.fdv ? ? 0)
                            }), n.pairCreatedAt && e.jsxs(F, {
                                spacing: "2px",
                                fontSize: "2xs",
                                color: O("blue.300", "blue.700", r),
                                children: [e.jsx(C, {
                                    as: Se
                                }), e.jsx(p, {
                                    children: Oe(n.pairCreatedAt, {
                                        now: new Date,
                                        singleUnit: !0
                                    })
                                })]
                            })]
                        })]
                    })
                })]
            })
        })
    },
    Pn = ds.memo(({
        pair: s,
        onClick: n,
        selected: a,
        isHoverable: r,
        ...o
    }) => {
        var z, f;
        const {
            colorMode: t
        } = me(), i = d.useCallback(x => {
            n == null || n(x)
        }, [n]), l = W("gray.800", "white"), g = (z = hs().current) == null ? void 0 : z.time, E = q(un), y = q(Ue), P = q(ys), m = Fe(s.chainId), h = us(s.dexId), S = ms(s.chainId), v = Ss(s), A = vs(s), w = s.marketCap ? ? s.fdv, b = d.useMemo(() => E({
            dsDataParams: cn({
                pair: s
            }),
            cmsParams: s.cmsProfile ? {
                assetId: s.cmsProfile.iconId,
                fit: "crop"
            } : void 0
        }), [s, E]);
        return e.jsxs(T, {
            pos: "relative",
            children: [e.jsxs(ye, {
                pr: {
                    base: 0,
                    md: "55px"
                },
                onClick: i,
                to: xe({
                    platformId: s.chainId,
                    pairAddress: s.pairAddress
                }),
                display: "flex",
                p: 3,
                py: 2.5,
                transition: "none",
                borderWidth: "3px",
                borderColor: a ? "accent.300" : "transparent",
                borderRadius: "md",
                isHoverable: r,
                textDecoration: "none",
                _focus: {
                    boxShadow: "none"
                },
                _hover: {
                    borderColor: "accent.300",
                    textDecoration: "none"
                },
                ...o,
                children: [e.jsxs(Q, {
                    flexShrink: 0,
                    spacing: 3.5,
                    direction: "column",
                    alignItems: "center",
                    justifyContent: "center",
                    children: [e.jsx(oe, {
                        src: y(s.chainId),
                        w: "24px",
                        h: "24px",
                        title: m,
                        loading: "lazy"
                    }), S != null && S.isChainAndDEX ? null : v ? e.jsx(p, {
                        color: "moonshot.accent.text",
                        title: "Moonshot",
                        children: e.jsx(C, {
                            as: ge,
                            boxSize: "24px"
                        })
                    }) : e.jsx(oe, {
                        pos: "relative",
                        src: P(s.dexId),
                        w: "24px",
                        h: "24px",
                        title: h,
                        loading: "lazy"
                    })]
                }), e.jsxs(T, {
                    ml: {
                        base: 4,
                        md: 5
                    },
                    overflow: "hidden",
                    children: [e.jsxs(Q, {
                        spacing: 2,
                        lineHeight: "1",
                        direction: {
                            base: "column",
                            md: "row"
                        },
                        children: [e.jsxs(F, {
                            children: [s.labels && s.labels.length > 0 && e.jsx(F, {
                                display: "inline-flex",
                                spacing: 1,
                                children: s.labels && s.labels.length > 0 && ((f = s.labels) == null ? void 0 : f.map(x => e.jsx(dn, {
                                    fontSize: "10px",
                                    px: "1",
                                    py: "3px",
                                    borderColor: O("gray.75", "blue.875", t),
                                    children: x
                                }, x)))
                            }), e.jsxs(L, {
                                as: "span",
                                fontSize: {
                                    base: "sm",
                                    md: "md"
                                },
                                py: "0.5",
                                noOfLines: 1,
                                children: [e.jsx(L, {
                                    as: "span",
                                    fontWeight: "semibold",
                                    children: s.baseToken.symbol
                                }), e.jsx(L, {
                                    as: "span",
                                    mx: "2px",
                                    color: O("gray.400", "gray.600", t),
                                    children: "/"
                                }), e.jsx(L, {
                                    as: "span",
                                    color: O("gray.400", "gray.600", t),
                                    children: s.quoteTokenSymbol
                                })]
                            })]
                        }), e.jsxs(F, {
                            spacing: "1",
                            minWidth: "100px",
                            children: [b && e.jsx(oe, {
                                src: b,
                                width: "16px",
                                height: "16px",
                                alt: s.baseToken.name,
                                loading: "lazy"
                            }), e.jsx(L, {
                                as: "span",
                                whiteSpace: "nowrap",
                                textOverflow: "ellipsis",
                                overflow: "hidden",
                                py: "0.5",
                                children: s.baseToken.name
                            }), A && e.jsx(p, {
                                color: "moonshot.accent.text",
                                title: "Moonshot",
                                marginTop: -.5,
                                children: e.jsx(C, {
                                    as: ge,
                                    boxSize: "12px"
                                })
                            })]
                        })]
                    }), e.jsxs(We, {
                        mt: {
                            base: 2,
                            md: 2
                        },
                        spacing: {
                            base: 1,
                            md: 3
                        },
                        align: "stretch",
                        fontSize: "sm",
                        color: W("gray.550", "gray.250"),
                        children: [s.price && e.jsxs($, {
                            fontWeight: "semibold",
                            fontSize: {
                                base: "sm",
                                md: "md"
                            },
                            w: {
                                base: "100%",
                                md: "auto"
                            },
                            pb: {
                                base: 1,
                                md: 0
                            },
                            color: l,
                            children: [s.priceUsd && xs(s.priceUsd), !s.priceUsd && ps(s.price, s.quoteTokenSymbol), s.priceChange.h24 !== void 0 && e.jsx(L, {
                                as: "span",
                                fontSize: "sm",
                                ml: "1.5",
                                children: e.jsx(gs, {
                                    value: s.priceChange.h24
                                })
                            })]
                        }), !v && s.liquidity && e.jsxs($, {
                            fontSize: "sm",
                            pr: {
                                base: 2,
                                lg: 0
                            },
                            children: [e.jsx(p, {
                                display: {
                                    md: "none"
                                },
                                children: "LIQ:"
                            }), e.jsx(p, {
                                display: {
                                    base: "none",
                                    md: "initial"
                                },
                                children: "Liquidity:"
                            }), e.jsx(L, {
                                as: "span",
                                fontWeight: "semibold",
                                ml: 1,
                                children: s.liquidity.usd > 0 ? bs(s.liquidity.usd) : "N/A"
                            })]
                        }), v && !!s.moonshot.progress && e.jsxs($, {
                            fontSize: "sm",
                            pr: {
                                base: 2,
                                lg: 0
                            },
                            children: [e.jsx(p, {
                                display: {
                                    md: "none"
                                },
                                children: "PROG:"
                            }), e.jsx(p, {
                                display: {
                                    base: "none",
                                    md: "initial"
                                },
                                children: "Progress:"
                            }), e.jsx(L, {
                                as: "span",
                                fontWeight: "semibold",
                                ml: 1,
                                children: e.jsx(fs, {
                                    min1: !0,
                                    number: s.moonshot.progress,
                                    significantDigits: 0,
                                    maxDecimalPrecision: 5,
                                    suffix: "%"
                                })
                            })]
                        }), s.volume.h24 && s.volume.h24 > 0 && e.jsxs($, {
                            fontSize: "sm",
                            pr: {
                                base: 2,
                                lg: 0
                            },
                            children: [e.jsx(p, {
                                display: {
                                    md: "none"
                                },
                                children: "VOL:"
                            }), e.jsx(p, {
                                display: {
                                    base: "none",
                                    md: "initial"
                                },
                                children: "24H Volume:"
                            }), e.jsx(L, {
                                as: "span",
                                fontWeight: "semibold",
                                ml: 1,
                                children: js(s.volume.h24)
                            })]
                        }), e.jsx($, {
                            children: e.jsxs(We, {
                                children: [w && e.jsxs($, {
                                    fontSize: "sm",
                                    pr: {
                                        base: 2,
                                        lg: 0
                                    },
                                    children: [e.jsx(p, {
                                        display: {
                                            md: "none"
                                        },
                                        children: "MCAP:"
                                    }), e.jsx(p, {
                                        display: {
                                            base: "none",
                                            md: "initial"
                                        },
                                        children: "Market Cap:"
                                    }), e.jsx(L, {
                                        as: "span",
                                        fontWeight: "semibold",
                                        ml: 1,
                                        children: Le(w)
                                    })]
                                }), s.pairCreatedAt && e.jsxs($, {
                                    display: "flex",
                                    alignItems: "center",
                                    gap: "1",
                                    fontSize: "sm",
                                    children: [e.jsx(C, {
                                        as: Se,
                                        boxSize: "10px"
                                    }), e.jsx(L, {
                                        as: "span",
                                        children: Oe(s.pairCreatedAt, {
                                            now: g
                                        })
                                    })]
                                })]
                            })
                        })]
                    }), e.jsxs(Q, {
                        mt: {
                            base: 2,
                            md: 1
                        },
                        direction: {
                            base: "column",
                            md: "row"
                        },
                        spacing: {
                            base: 0,
                            md: 3
                        },
                        fontSize: {
                            base: "xs",
                            md: "sm"
                        },
                        color: W("gray.300", "gray.600"),
                        children: [e.jsxs(T, {
                            children: ["Pair:", " ", e.jsx(p, {
                                ml: "0.5",
                                fontFamily: "mono",
                                children: ke(s.pairAddress)
                            })]
                        }), e.jsxs(T, {
                            children: ["Token:", " ", e.jsx(p, {
                                ml: "0.5",
                                fontFamily: "mono",
                                children: ke(s.baseToken.address)
                            })]
                        })]
                    })]
                })]
            }), v ? null : e.jsx(T, {
                pos: "absolute",
                top: {
                    md: 3
                },
                right: 3,
                bottom: {
                    base: 3,
                    md: "initial"
                },
                children: e.jsx(hn, {
                    watchlistPair: {
                        type: "dexPair",
                        chainId: s.chainId,
                        dexId: s.dexId,
                        pairId: s.pairAddress,
                        baseTokenName: s.baseToken.name,
                        baseTokenSymbol: s.baseToken.symbol,
                        quoteTokenSymbol: s.quoteTokenSymbol
                    },
                    buttonProps: {
                        size: "sm",
                        minW: "auto",
                        px: 2,
                        iconSpacing: 0,
                        sx: {
                            "> span:last-of-type": {
                                display: "none"
                            }
                        }
                    },
                    menuContainerProps: {
                        ml: "auto",
                        display: "flex",
                        minH: "100%"
                    },
                    menuProps: {
                        strategy: "fixed",
                        placement: "bottom-end",
                        matchWidth: !1
                    }
                })
            })]
        })
    }),
    Wn = ({
        token: s
    }) => {
        const n = Fe(s.chain.id),
            a = mn(s.socials ? ? [], "type").sort((t, i) => Pe.indexOf(t.type) - Pe.indexOf(i.type)),
            r = s.websites ? ? [],
            o = r.find(Is) ? ? r[0];
        return {
            socials: a ? ? [],
            website: o,
            chainName: n
        }
    },
    as = {
        base: "114px",
        lg: "92px"
    },
    le = {
        base: "40px",
        lg: "60px"
    },
    An = ({ ...s
    }) => e.jsx(Ve, {
        userSelect: "none",
        borderRadius: "md",
        h: as,
        py: "0",
        ...s,
        children: e.jsxs(Q, {
            align: "center",
            pos: "relative",
            direction: {
                base: "column",
                lg: "row"
            },
            spacing: {
                base: 3,
                lg: 4
            },
            padding: {
                base: 1,
                lg: 3
            },
            pt: {
                base: "35px",
                lg: 3
            },
            pb: {
                base: "10px",
                lg: 3
            },
            children: [e.jsx(ae, {
                pos: {
                    base: "absolute",
                    lg: "initial"
                },
                top: "-10px",
                size: le,
                bg: W("rgba(0, 0, 0, 0.05)", "rgba(255, 255, 255, 0.025)")
            }), e.jsxs(T, {
                display: "flex",
                flexDir: "column",
                alignItems: {
                    base: "center",
                    lg: "flex-start"
                },
                overflow: "hidden",
                w: "100%",
                maxW: "100%",
                gap: "2",
                py: "1",
                children: [e.jsx(T, {
                    bg: W("rgba(0, 0, 0, 0.05)", "rgba(255, 255, 255, 0.025)"),
                    w: "70%",
                    h: "16px"
                }), e.jsx(T, {
                    bg: W("rgba(0, 0, 0, 0.05)", "rgba(255, 255, 255, 0.025)"),
                    w: "50%",
                    h: "16px"
                }), e.jsxs(F, {
                    spacing: "1",
                    children: [e.jsx(ae, {
                        bg: W("rgba(0, 0, 0, 0.05)", "rgba(255, 255, 255, 0.025)"),
                        size: "16px"
                    }), e.jsx(ae, {
                        bg: W("rgba(0, 0, 0, 0.05)", "rgba(255, 255, 255, 0.025)"),
                        size: "16px"
                    }), e.jsx(ae, {
                        bg: W("rgba(0, 0, 0, 0.05)", "rgba(255, 255, 255, 0.025)"),
                        size: "16px"
                    })]
                })]
            })]
        })
    }),
    De = {
        padding: "0.5",
        minWidth: "0",
        minHeight: "0",
        height: "auto",
        variant: "ghost",
        size: "sm"
    },
    zn = ({
        onClose: s,
        token: n,
        ...a
    }) => {
        var P;
        const r = q(ws),
            o = q(Ue),
            {
                chainName: t,
                website: i,
                socials: l
            } = Wn({
                token: n
            }),
            {
                colorMode: g
            } = me(),
            E = d.useCallback(m => {
                m.metaKey || m.ctrlKey || m.button === 1 || s()
            }, [s]),
            y = d.useCallback(m => h => {
                h.preventDefault(), h.stopPropagation(), window.open(m, void 0, "noopener,noreferrer")
            }, []);
        return e.jsx(ye, {
            to: xe({
                platformId: n.chain.id,
                pairAddress: n.address
            }),
            isHoverable: !0,
            onClick: E,
            userSelect: "none",
            borderRadius: "md",
            h: as,
            py: "0",
            ...a,
            children: e.jsxs(Q, {
                align: "center",
                pos: "relative",
                direction: {
                    base: "column",
                    lg: "row"
                },
                spacing: {
                    base: 3,
                    lg: 4
                },
                padding: {
                    base: 1,
                    lg: 3
                },
                pt: {
                    base: "35px",
                    lg: 3
                },
                pb: {
                    base: "10px",
                    lg: 3
                },
                children: [e.jsx(oe, {
                    pos: {
                        base: "absolute",
                        lg: "initial"
                    },
                    top: "-10px",
                    src: r({
                        chainId: n.chain.id,
                        tokenAddress: n.address,
                        cacheKey: (P = n.profile) == null ? void 0 : P.imgKey,
                        size: "lg"
                    }),
                    minW: le,
                    width: le,
                    height: le,
                    minWidth: le,
                    loading: "lazy"
                }), e.jsxs(T, {
                    display: "flex",
                    flexDir: "column",
                    alignItems: {
                        base: "center",
                        lg: "flex-start"
                    },
                    overflow: "hidden",
                    w: "100%",
                    maxW: "100%",
                    children: [e.jsx(p, {
                        fontWeight: "semibold",
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        whiteSpace: "nowrap",
                        maxW: {
                            base: "90%",
                            lg: "100%"
                        },
                        children: n.name
                    }), e.jsxs(F, {
                        pt: {
                            base: .5,
                            lg: 1
                        },
                        pb: {
                            base: 1,
                            lg: 1.5
                        },
                        spacing: "1",
                        color: O("gray.500", "blue.600", g),
                        children: [e.jsx(oe, {
                            src: o(n.chain.id),
                            w: "16px",
                            h: "16px",
                            loading: "lazy"
                        }), e.jsx(p, {
                            children: t
                        })]
                    }), e.jsxs(F, {
                        spacing: "1",
                        children: [i && e.jsx(be, { ...De,
                            icon: e.jsx(C, {
                                as: Cs
                            }),
                            "aria-label": he(i.label),
                            title: he(i.label),
                            onClick: y(i.url)
                        }), l == null ? void 0 : l.map(m => e.jsx(be, { ...De,
                            icon: e.jsx(C, {
                                as: xn[m.type]
                            }),
                            "aria-label": he(m.type),
                            title: he(m.type),
                            onClick: y(m.url)
                        }, m.type))]
                    })]
                })]
            })
        })
    },
    Rn = 2,
    Dn = s => {
        const n = q(Ms),
            a = q(Xe),
            {
                debounceTime: r,
                onError: o,
                clearError: t,
                onSearch: i
            } = s,
            [l, g] = d.useState({
                query: s.initialQuery ? ? "",
                filters: s.initialFilters
            }),
            [E, y] = d.useState(),
            [P, m] = d.useState(!1),
            h = Y(l),
            S = l.query !== "",
            v = ks(f => f.pipe(Te(({
                query: x,
                filters: k
            }) => {
                n.track({
                    event: "search",
                    data: {
                        query: x,
                        moonshot: k == null ? void 0 : k.moonshot
                    }
                }), i == null || i({
                    query: x,
                    filters: k
                })
            }), Be(({
                query: x,
                filters: k
            }) => a.searchPairs({
                query: x,
                filters: k
            }).pipe(Ye(V => (m(!1), o == null || o(Ts(V)), qe)))), Te(x => {
                t == null || t(), m(!1), y(x)
            })), [n, i, a, o, t]),
            A = d.useCallback(f => {
                m(!0), v(f)
            }, [v]),
            w = d.useMemo(() => Ge(A, r ? ? 500), [A, r]);
        d.useEffect(() => () => w.cancel(), [w]);
        const b = d.useCallback(f => {
                m(!1), g(f), f.query.trim().length >= Rn ? w(f) : (w.cancel(), y(void 0), t == null || t())
            }, [t, w]),
            z = d.useCallback(() => {
                w.cancel(), m(!1), v(h.current)
            }, [v, w, h]);
        return {
            query: l.query,
            filters: l.filters,
            searchValue: l,
            setSearchValue: b,
            showClearButton: S,
            isLoading: P,
            refresh: z,
            pairs: E
        }
    },
    Nn = {
        adLocation: {
            preferredAdKind: "native",
            screen: "search",
            provider: "direct"
        },
        enabled: !0
    },
    Ne = 500,
    _n = 6e4,
    Hn = 5e3,
    Vn = ({
        isExtraLargeScreen: s,
        searchValueOverride: n,
        onSearchValueChange: a
    }) => {
        const r = q(Xe),
            [o, t] = d.useState(),
            [i, l] = d.useState(),
            [g, E] = d.useState(Es),
            y = d.useCallback(() => l(void 0), []),
            P = s ? void 0 : Ne,
            {
                setSearchValue: m,
                searchValue: h,
                isLoading: S,
                pairs: v,
                showClearButton: A
            } = Dn({
                debounceTime: P,
                onError: l,
                clearError: y
            }),
            w = Ps(),
            b = Y(w),
            z = Y(h),
            f = d.useMemo(() => Ge(a, Ne), [a]);
        d.useEffect(() => () => f.cancel(), [f]), d.useEffect(() => {
            b.current && f(h)
        }, [b, f, h]), d.useEffect(() => {
            Ws(n, z.current) === !1 && m(n)
        }, [n, z, m]);
        const x = d.useMemo(() => yn(Nn), []);
        return As(() => zs(0, _n).pipe(Me(() => E(k => {
            switch (k.kind) {
                case "AsyncPending":
                case "AsyncFailure":
                    return k;
                case "AsyncFailureWithData":
                case "AsyncSuccess":
                case "AsyncPendingWithData":
                    return Rs(k.value)
            }
        })), Be(() => r.spotlight().pipe(fn({
            delay: Hn,
            count: 2
        }), Ye(k => (E(V => Ns(V, k)), qe)))), Me(k => E(Ds(k)))), [r]), d.useEffect(() => {
            v && v.length > 0 && t(0)
        }, [v, t]), {
            selectedPairIndex: o,
            setSelectedPairIndex: t,
            error: i,
            setSearchValue: m,
            isLoading: S,
            pairs: v,
            showClearButton: A,
            adsProviderValue: x,
            clearError: y,
            searchValue: h,
            spotlight: g
        }
    },
    fe = 18,
    os = [...Array(fe)],
    _e = ({
        data: s,
        onClose: n
    }) => {
        const [a, r] = d.useState("trending"), o = Zs();
        let t;
        if (s) switch (a) {
            case "trending":
                t = s.trending;
                break;
            case "top":
                t = s.top;
                break;
            case "new":
                t = s.new;
                break;
            case "rising":
                t = s.rising;
                break;
            case "finalized":
                t = s.finalized
        }
        const i = {
            variant: "outline",
            flex: 1,
            flexShrink: 0,
            iconSpacing: {
                base: .5,
                md: 1
            },
            width: {
                md: "100px"
            },
            borderColor: W("blue.125", "blue.900"),
            _focus: {},
            _hover: {},
            sx: {
                "@media (hover:hover)": {
                    _hover: {
                        bg: W("blue.125", "blue.900")
                    }
                }
            }
        };
        return e.jsxs(e.Fragment, {
            children: [e.jsxs(ce, {
                alignItems: "stretch",
                pt: {
                    base: 1,
                    lg: 3
                },
                children: [e.jsxs(F, {
                    overflowX: "auto",
                    children: [e.jsxs(Ee, {
                        to: "/moonshot",
                        flexShrink: 0,
                        pos: "relative",
                        top: {
                            base: "1px",
                            md: "-1px"
                        },
                        mr: {
                            base: .5,
                            md: 1
                        },
                        _hover: {
                            color: "moonshot.accent.text"
                        },
                        children: [e.jsx(p, {
                            display: {
                                base: "none",
                                md: "initial"
                            },
                            children: e.jsx(jn, {
                                height: "20px"
                            })
                        }), e.jsx(p, {
                            display: {
                                md: "none"
                            },
                            children: e.jsx(ge, {
                                height: "16px"
                            })
                        })]
                    }), e.jsxs(Js, {
                        flex: {
                            base: 1,
                            md: 0
                        },
                        size: "xs",
                        sx: {
                            button: {
                                "&:not(:first-of-type)": {
                                    borderLeftWidth: 0
                                }
                            }
                        },
                        pointerEvents: t ? void 0 : "none",
                        isAttached: !0,
                        children: [e.jsx(U, { ...i,
                            flex: 1.1,
                            leftIcon: e.jsx(C, {
                                as: en
                            }),
                            onClick: () => r("trending"),
                            ...a === "trending" ? {
                                variant: "solid",
                                colorScheme: "moonshot",
                                pointerEvents: "none"
                            } : void 0,
                            children: "Trending"
                        }), e.jsx(U, { ...i,
                            flex: .8,
                            leftIcon: e.jsx(C, {
                                as: sn
                            }),
                            onClick: () => r("top"),
                            ...a === "top" ? {
                                variant: "solid",
                                colorScheme: "moonshot",
                                pointerEvents: "none"
                            } : void 0,
                            children: "Top"
                        }), e.jsx(U, { ...i,
                            flex: .9,
                            leftIcon: e.jsx(C, {
                                as: nn
                            }),
                            onClick: () => r("rising"),
                            ...a === "rising" ? {
                                variant: "solid",
                                colorScheme: "moonshot",
                                pointerEvents: "none"
                            } : void 0,
                            children: "Rising"
                        }), e.jsx(U, { ...i,
                            flex: .9,
                            leftIcon: e.jsx(C, {
                                as: Se
                            }),
                            onClick: () => r("new"),
                            ...a === "new" ? {
                                variant: "solid",
                                colorScheme: "moonshot",
                                pointerEvents: "none"
                            } : void 0,
                            children: "New"
                        }), e.jsx(U, { ...i,
                            flex: 1.2,
                            width: {
                                md: "110px"
                            },
                            leftIcon: e.jsx(C, {
                                as: tn
                            }),
                            onClick: () => r("finalized"),
                            ...a === "finalized" ? {
                                variant: "solid",
                                colorScheme: "moonshot",
                                pointerEvents: "none"
                            } : void 0,
                            children: "Finalized"
                        })]
                    }), e.jsxs(F, {
                        display: {
                            base: "none",
                            md: "flex"
                        },
                        spacing: "1",
                        ml: "auto",
                        children: [e.jsx(Ee, {
                            to: "/moonshot",
                            fontSize: "sm",
                            flexShrink: 0,
                            pos: "relative",
                            children: "Wen Moon?"
                        }), e.jsx(C, {
                            as: Ke,
                            boxSize: "10px"
                        })]
                    })]
                }), e.jsxs($e, {
                    templateColumns: {
                        base: "repeat(2, 1fr)",
                        md: "repeat(4, 1fr)"
                    },
                    columnGap: "2",
                    rowGap: {
                        base: 4,
                        lg: 2
                    },
                    maxH: o.isOpen ? void 0 : {
                        base: "94px",
                        lg: "132px"
                    },
                    overflow: "hidden",
                    pt: {
                        base: "8px",
                        lg: 0
                    },
                    pb: 2,
                    children: [!t && os.map((l, g) => e.jsx(Mn, {}, g)), t && t.map(l => e.jsx(Qe, {
                        as: En,
                        pair: l,
                        minWidth: "0",
                        onClose: n
                    }, l.pairAddress))]
                })]
            }), e.jsxs(U, {
                size: "xs",
                variant: "link",
                rightIcon: e.jsx(C, {
                    as: o.isOpen ? on : an
                }),
                alignSelf: "center",
                fontWeight: "normal",
                onClick: o.onToggle,
                mb: {
                    base: 2.5,
                    lg: 0
                },
                pointerEvents: t ? void 0 : "none",
                opacity: t ? void 0 : .3,
                transition: "opacity 0.5s",
                _hover: {},
                sx: {
                    "@media (hover: hover)": {
                        _hover: {
                            textDecor: "underline"
                        }
                    }
                },
                children: ["show ", o.isOpen ? "less" : "more"]
            })]
        })
    },
    He = ({
        children: s
    }) => e.jsxs(ce, {
        alignItems: "stretch",
        children: [e.jsxs(F, {
            justifyContent: "space-between",
            children: [e.jsxs(p, {
                fontWeight: "semibold",
                fontSize: {
                    md: "xl"
                },
                fontFamily: "heading",
                children: ["Recently Updated ", e.jsx(p, {
                    display: {
                        base: "none",
                        md: "initial"
                    },
                    children: "Token Info"
                })]
            }), e.jsxs(rn, {
                href: "https://marketplace.dexscreener.com/product/token-info",
                target: "_blank",
                display: "flex",
                alignItems: "center",
                gap: "1",
                fontSize: "sm",
                children: [e.jsx(C, {
                    as: bn
                }), e.jsxs(p, {
                    children: ["Claim your spot ", e.jsx(p, {
                        display: {
                            base: "none",
                            md: "initial"
                        },
                        children: "here"
                    })]
                }), e.jsx(C, {
                    as: Ke,
                    boxSize: "10px"
                })]
            })]
        }), e.jsx($e, {
            templateColumns: {
                base: "repeat(2, 1fr)",
                md: "repeat(3, 1fr)"
            },
            columnGap: "3",
            rowGap: {
                base: 5,
                lg: 3
            },
            mt: {
                base: 2.5,
                lg: 0
            },
            children: s
        })]
    }),
    Xn = s => {
        const {
            children: n,
            onSelect: a,
            onClose: r
        } = s, o = _s({
            lg: !0
        }, {
            ssr: !1
        }), t = o, {
            colorMode: i
        } = me(), l = Hs(), g = Vs(), {
            selectedPairIndex: E,
            setSelectedPairIndex: y,
            error: P,
            isLoading: m,
            pairs: h,
            showClearButton: S,
            adsProviderValue: v,
            clearError: A,
            searchValue: w,
            setSearchValue: b,
            spotlight: z
        } = Vn({
            isExtraLargeScreen: o ? ? !1,
            searchValueOverride: s.searchValue,
            onSearchValueChange: s.onSearchValueChange
        }), {
            query: f,
            filters: x
        } = w, [k, V] = d.useState(), B = d.useRef(null), N = d.useRef(null), R = d.useRef(null), D = Y(E), _ = Y(h), I = Y(t), M = Y(w), K = d.useCallback(c => {
            a ? a(c) : g(xe({
                platformId: c.chainId,
                pairAddress: c.pairAddress
            }))
        }, [g, a]), G = d.useCallback(c => {
            b({
                query: c,
                filters: M.current.filters
            })
        }, [M, b]), re = d.useCallback(c => {
            var H;
            const u = c.currentTarget.dataset.index ? parseInt(c.currentTarget.dataset.index) : void 0;
            if (u === void 0) return;
            const j = (H = _.current) == null ? void 0 : H[u];
            if (j && a) {
                c.preventDefault(), a(j);
                return
            }
        }, [a, _]), ie = d.useCallback(c => {
            if (!I.current) return;
            const u = c.currentTarget.dataset.index ? parseInt(c.currentTarget.dataset.index) : void 0;
            u !== void 0 && (V("mouse"), y(u))
        }, [I, y]), X = d.useCallback(() => {
            var u;
            if (!t || !R.current || D.current === void 0) return;
            const c = R.current.querySelector(`div:nth-of-type(${D.current+1}) a`);
            c && (D.current === 0 ? (u = B.current) == null || u.scroll({
                top: 0,
                behavior: "smooth"
            }) : Tn(c, {
                scrollMode: "if-needed",
                block: "center"
            }))
        }, [D, t]), Z = d.useCallback(c => {
            var j;
            const u = t && !P && D.current !== void 0;
            switch (c.key) {
                case "ArrowDown":
                    {
                        if (!u) return;V("keyboard"),
                        _.current && D.current < _.current.length - 1 && (c.preventDefault(), y(D.current + 1));
                        break
                    }
                case "ArrowUp":
                    {
                        if (!u) return;V("keyboard"),
                        D.current > 0 && (c.preventDefault(), y(D.current - 1));
                        break
                    }
                case "Enter":
                    {
                        if (!u) return;
                        if (V("keyboard"), _.current) {
                            const H = _.current[D.current];
                            H && (c.preventDefault(), K(H))
                        }
                        break
                    }
                case "Backspace":
                    M.current.query === "" && ((j = M.current.filters) != null && j.moonshot) && b({
                        query: "",
                        filters: { ...M.current.filters,
                            moonshot: !1
                        }
                    })
            }
            X()
        }, [t, P, D, X, _, y, K, M, b]), J = d.useCallback(() => {
            var c;
            b({
                query: "",
                filters: M.current.filters
            }), A(), (c = N.current) == null || c.focus(), y(void 0)
        }, [A, M, b, y]), ee = d.useCallback(c => {
            var u, j;
            b({
                query: c.target.value,
                filters: M.current.filters
            }), ((u = B.current) == null ? void 0 : u.scrollTop) !== 0 && ((j = B.current) == null || j.scroll({
                top: 0,
                behavior: "smooth"
            }))
        }, [M, b]), se = d.useCallback(() => {
            b({
                query: M.current.query,
                filters: { ...M.current.filters,
                    moonshot: !1
                }
            })
        }, [M, b]);
        return d.useEffect(() => {
            h && h.length > 0 && y(0)
        }, [h, y]), e.jsx(Ls, {
            onClose: r,
            scrollBehavior: "inside",
            closeOnEsc: !l,
            motionPreset: "none",
            blockScrollOnMount: !1,
            isOpen: !0,
            children: e.jsx(Os, {
                children: e.jsx(Sn, {
                    value: v,
                    children: e.jsxs(Fs, {
                        mt: {
                            base: 0,
                            lg: "16"
                        },
                        maxW: {
                            base: "100vw",
                            lg: "4xl"
                        },
                        h: {
                            base: "100vh",
                            lg: "auto"
                        },
                        maxH: {
                            base: "100dvh",
                            lg: "calc(100% - 7.5rem)"
                        },
                        children: [e.jsx(Us, {
                            bg: O("white", "blue.875", i),
                            p: 0,
                            children: e.jsxs(T, {
                                display: "flex",
                                alignItems: "center",
                                h: "50px",
                                gap: {
                                    base: 2,
                                    lg: 4
                                },
                                px: {
                                    base: 2.5,
                                    lg: 4
                                },
                                children: [e.jsxs(T, {
                                    display: "flex",
                                    alignItems: "center",
                                    color: O("gray.600", "white", i),
                                    children: [!m && e.jsx(C, {
                                        as: Bs,
                                        boxSize: "18px"
                                    }), m && e.jsx(qs, {
                                        boxSize: "18px",
                                        thickness: "3px"
                                    })]
                                }), x != null && x.moonshot ? e.jsx(T, {
                                    display: "flex",
                                    children: e.jsxs(Je, {
                                        size: {
                                            base: "sm",
                                            md: "lg"
                                        },
                                        children: [e.jsx(es, {
                                            children: "Moonshot"
                                        }), e.jsx(ns, {
                                            onClick: se
                                        })]
                                    })
                                }) : null, e.jsx(Gs, {
                                    ref: N,
                                    value: f,
                                    onChange: ee,
                                    onKeyDown: Z,
                                    variant: "unstyled",
                                    flex: 1,
                                    fontSize: "xl",
                                    placeholder: x != null && x.moonshot ? "Search Moonshot" : "Search"
                                }), S && e.jsx(U, {
                                    onClick: J,
                                    variant: "outline",
                                    fontWeight: "normal",
                                    size: "xs",
                                    leftIcon: e.jsx(C, {
                                        as: Ks
                                    }),
                                    iconSpacing: "1",
                                    children: "Clear"
                                }), e.jsx(be, {
                                    onClick: r,
                                    display: {
                                        base: "flex",
                                        lg: "none"
                                    },
                                    variant: "ghost",
                                    fontWeight: "normal",
                                    size: "sm",
                                    icon: e.jsx(C, {
                                        as: Xs
                                    }),
                                    "aria-label": "Close",
                                    mr: "-2"
                                })]
                            })
                        }), e.jsx($s, {
                            ref: B,
                            p: 0,
                            bg: O("gray.25", "blue.975", i),
                            children: (!f || !h) && n || e.jsxs(ce, {
                                p: 3,
                                alignItems: "stretch",
                                width: "100%",
                                spacing: "0",
                                children: [e.jsx(T, {
                                    mb: 2,
                                    children: e.jsx(pn, {
                                        variant: "search"
                                    })
                                }), h === void 0 && !P && Ys({
                                    value: z,
                                    onPending: () => {
                                        var c;
                                        return e.jsxs(e.Fragment, {
                                            children: [!((c = s.searchValue.filters) != null && c.moonshot) && e.jsx(_e, {
                                                data: null,
                                                onClose: r
                                            }), e.jsx(He, {
                                                children: os.map((u, j) => e.jsx(An, {
                                                    display: {
                                                        base: j < fe ? void 0 : "none",
                                                        md: "block"
                                                    }
                                                }, j))
                                            })]
                                        })
                                    },
                                    onFailure: () => e.jsx(T, {
                                        width: "100%",
                                        maxWidth: "500px",
                                        padding: "3",
                                        textAlign: "center",
                                        alignSelf: "center",
                                        children: e.jsxs(L, {
                                            color: O("gray.400", "gray.200", i),
                                            children: ["Try:", " ", e.jsx(U, {
                                                onClick: () => G("Wrapped BTC"),
                                                variant: "link",
                                                colorScheme: "accent",
                                                children: "Wrapped BTC"
                                            }), ", ", e.jsx(U, {
                                                onClick: () => G("WETH"),
                                                variant: "link",
                                                colorScheme: "accent",
                                                minW: "auto",
                                                children: "WETH"
                                            }), " or ", e.jsx(U, {
                                                onClick: () => G("ETH USD"),
                                                variant: "link",
                                                colorScheme: "accent",
                                                children: "ETH USD"
                                            })]
                                        })
                                    }),
                                    onSuccess: ({
                                        latestProfiles: c,
                                        moonshot: u
                                    }) => {
                                        var j;
                                        return e.jsxs(e.Fragment, {
                                            children: [!((j = s.searchValue.filters) != null && j.moonshot) && e.jsx(_e, {
                                                data: u,
                                                onClose: r
                                            }), e.jsx(He, {
                                                children: c.map((H, ne) => e.jsx(Qe, {
                                                    as: zn,
                                                    token: H,
                                                    onClose: r,
                                                    minWidth: "0",
                                                    display: {
                                                        base: ne < fe ? void 0 : "none",
                                                        md: "block"
                                                    }
                                                }, H.id))
                                            })]
                                        })
                                    }
                                }), P && e.jsx(gn, {
                                    size: "sm"
                                }), !P && (h == null ? void 0 : h.length) === 0 && e.jsx(T, {
                                    p: 3,
                                    children: e.jsxs(Qs, {
                                        as: "p",
                                        flexDir: "column",
                                        gap: "3",
                                        opacity: .5,
                                        children: [e.jsx(p, {
                                            fontWeight: "semibold",
                                            fontFamily: "mono",
                                            fontSize: "32px",
                                            children: "¯\\_(ツ)_/¯"
                                        }), e.jsx(p, {
                                            children: "No results found"
                                        })]
                                    })
                                }), !P && h && h.length > 0 && e.jsx(ce, {
                                    ref: R,
                                    spacing: 2.5,
                                    alignItems: "stretch",
                                    children: h.map((c, u) => e.jsx(Pn, {
                                        "data-index": u,
                                        pair: c,
                                        onClick: re,
                                        onMouseMove: ie,
                                        selected: t && u === E,
                                        isHoverable: k === "mouse"
                                    }, `${c.chainId}:${c.pairAddress}`))
                                })]
                            })
                        })]
                    })
                })
            })
        })
    };
export {
    Xn as C
};