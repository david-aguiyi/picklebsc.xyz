function k(e) {
    return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e
}
var E = {
        exports: {}
    },
    t = E.exports = {},
    i, s;

function T() {
    throw new Error("setTimeout has not been defined")
}

function w() {
    throw new Error("clearTimeout has not been defined")
}(function() {
    try {
        typeof setTimeout == "function" ? i = setTimeout : i = T
    } catch {
        i = T
    }
    try {
        typeof clearTimeout == "function" ? s = clearTimeout : s = w
    } catch {
        s = w
    }
})();

function b(e) {
    if (i === setTimeout) return setTimeout(e, 0);
    if ((i === T || !i) && setTimeout) return i = setTimeout, setTimeout(e, 0);
    try {
        return i(e, 0)
    } catch {
        try {
            return i.call(null, e, 0)
        } catch {
            return i.call(this, e, 0)
        }
    }
}

function x(e) {
    if (s === clearTimeout) return clearTimeout(e);
    if ((s === w || !s) && clearTimeout) return s = clearTimeout, clearTimeout(e);
    try {
        return s(e)
    } catch {
        try {
            return s.call(null, e)
        } catch {
            return s.call(this, e)
        }
    }
}
var u = [],
    f = !1,
    c, v = -1;

function _() {
    !f || !c || (f = !1, c.length ? u = c.concat(u) : v = -1, u.length && L())
}

function L() {
    if (!f) {
        var e = b(_);
        f = !0;
        for (var n = u.length; n;) {
            for (c = u, u = []; ++v < n;) c && c[v].run();
            v = -1, n = u.length
        }
        c = null, f = !1, x(e)
    }
}
t.nextTick = function(e) {
    var n = new Array(arguments.length - 1);
    if (arguments.length > 1)
        for (var o = 1; o < arguments.length; o++) n[o - 1] = arguments[o];
    u.push(new C(e, n)), u.length === 1 && !f && b(L)
};

function C(e, n) {
    this.fun = e, this.array = n
}
C.prototype.run = function() {
    this.fun.apply(null, this.array)
};
t.title = "browser";
t.browser = !0;
t.env = {};
t.argv = [];
t.version = "";
t.versions = {};

function l() {}
t.on = l;
t.addListener = l;
t.once = l;
t.off = l;
t.removeListener = l;
t.removeAllListeners = l;
t.emit = l;
t.prependListener = l;
t.prependOnceListener = l;
t.listeners = function(e) {
    return []
};
t.binding = function(e) {
    throw new Error("process.binding is not supported")
};
t.cwd = function() {
    return "/"
};
t.chdir = function(e) {
    throw new Error("process.chdir is not supported")
};
t.umask = function() {
    return 0
};
var O = E.exports;
const B = k(O),
    R = "modulepreload",
    $ = function(e) {
        return "/" + e
    },
    y = {},
    U = function(n, o, P) {
        let g = Promise.resolve();
        if (o && o.length > 0) {
            const h = document.getElementsByTagName("link");
            g = Promise.all(o.map(r => {
                if (r = $(r), r in y) return;
                y[r] = !0;
                const m = r.endsWith(".css"),
                    S = m ? '[rel="stylesheet"]' : "";
                if (!!P)
                    for (let d = h.length - 1; d >= 0; d--) {
                        const p = h[d];
                        if (p.href === r && (!m || p.rel === "stylesheet")) return
                    } else if (document.querySelector(`link[href="${r}"]${S}`)) return;
                const a = document.createElement("link");
                if (a.rel = m ? "stylesheet" : R, m || (a.as = "script", a.crossOrigin = ""), a.href = r, document.head.appendChild(a), m) return new Promise((d, p) => {
                    a.addEventListener("load", d), a.addEventListener("error", () => p(new Error(`Unable to preload CSS for ${r}`)))
                })
            }))
        }
        return g.then(() => n()).catch(h => {
            const r = new Event("vite:preloadError", {
                cancelable: !0
            });
            if (r.payload = h, window.dispatchEvent(r), !r.defaultPrevented) throw h
        })
    };
export {
    U as _, B as p
};