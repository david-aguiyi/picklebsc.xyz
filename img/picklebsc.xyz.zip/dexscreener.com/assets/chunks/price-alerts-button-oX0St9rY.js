import {
    a5 as w,
    bg as De,
    a1 as R,
    bh as he,
    bi as be,
    bD as Y,
    bj as Me,
    a2 as Fe,
    x as y,
    y as e,
    a3 as V,
    ew as _e,
    cJ as Be,
    ex as Re,
    dg as A,
    dw as Ve,
    ey as ve,
    dE as ye,
    Q as te,
    d1 as xe,
    b5 as K,
    V as H,
    T as x,
    a9 as I,
    ez as se,
    Z as $,
    cv as Ge,
    ag as ze,
    A as E,
    bn as ne,
    aB as J,
    ao as ie,
    J as W,
    az as l,
    H as Oe,
    cR as We,
    ay as ae,
    eA as de,
    U as le,
    af as ee,
    eB as qe,
    e9 as $e,
    e3 as Le,
    dN as Ke,
    dt as _,
    dK as He,
    d5 as ge,
    ar as Qe,
    as as Ye,
    at as Je,
    au as Xe,
    av as Ze,
    aw as er,
    ax as rr,
    O as pe,
    aR as ue,
    eC as tr,
    eD as sr,
    cf as me,
    ap as nr,
    cy as ir,
    eE as ar
} from "../entries/pages_catch-all.K13KjGu-.js";
import {
    a as k,
    W as q,
    B as or,
    E as cr
} from "./embed-feature-disabled-modal-4NIwn0pw.js";
import {
    S as dr
} from "./span-2n6MBXt2.js";
import {
    u as lr
} from "./use-observable-memo-O2SfP1qF.js";
const gr = ({
        priceUsd: r,
        price: t
    }) => r && new w(r.replace(/,/g, "")).dividedBy(t.replace(/,/g, "")).toFixed(),
    pr = ({
        price: r
    }) => new w(1).dividedBy(r.replace(/,/g, "")).toFixed();
var [ur, mr] = De({
    name: "InputGroupStylesContext",
    errorMessage: `useInputGroupStyles returned is 'undefined'. Seems you forgot to wrap the components in "<InputGroup />" `
}), N = R(function(t, n) {
    const s = he("Input", t),
        {
            children: o,
            className: c,
            ...p
        } = be(t),
        g = Y("chakra-input__group", c),
        u = {},
        b = Me(o),
        a = s.field;
    b.forEach(d => {
        var f, j;
        s && (a && d.type.id === "InputLeftElement" && (u.paddingStart = (f = a.height) != null ? f : a.h), a && d.type.id === "InputRightElement" && (u.paddingEnd = (j = a.height) != null ? j : a.h), d.type.id === "InputRightAddon" && (u.borderEndRadius = 0), d.type.id === "InputLeftAddon" && (u.borderStartRadius = 0))
    });
    const C = b.map(d => {
        var f, j;
        const m = Fe({
            size: ((f = d.props) == null ? void 0 : f.size) || t.size,
            variant: ((j = d.props) == null ? void 0 : j.variant) || t.variant
        });
        return d.type.id !== "Input" ? y.cloneElement(d, m) : y.cloneElement(d, Object.assign(m, u, d.props))
    });
    return e.jsx(V.div, {
        className: g,
        ref: n,
        __css: {
            width: "100%",
            display: "flex",
            position: "relative",
            isolation: "isolate",
            ...s.group
        },
        "data-group": !0,
        ...p,
        children: e.jsx(ur, {
            value: s,
            children: C
        })
    })
});
N.displayName = "InputGroup";
var hr = {
        left: {
            marginEnd: "-1px",
            borderEndRadius: 0,
            borderEndColor: "transparent"
        },
        right: {
            marginStart: "-1px",
            borderStartRadius: 0,
            borderStartColor: "transparent"
        }
    },
    br = V("div", {
        baseStyle: {
            flex: "0 0 auto",
            width: "auto",
            display: "flex",
            alignItems: "center",
            whiteSpace: "nowrap"
        }
    }),
    oe = R(function(t, n) {
        var s;
        const {
            placement: o = "left",
            ...c
        } = t, p = (s = hr[o]) != null ? s : {}, g = mr();
        return e.jsx(br, {
            ref: n,
            ...c,
            __css: { ...g.addon,
                ...p
            }
        })
    });
oe.displayName = "InputAddon";
var T = R(function(t, n) {
    return e.jsx(oe, {
        ref: n,
        placement: "left",
        ...t,
        className: Y("chakra-input__left-addon", t.className)
    })
});
T.displayName = "InputLeftAddon";
T.id = "InputLeftAddon";
var Q = R(function(t, n) {
    return e.jsx(oe, {
        ref: n,
        placement: "right",
        ...t,
        className: Y("chakra-input__right-addon", t.className)
    })
});
Q.displayName = "InputRightAddon";
Q.id = "InputRightAddon";
var fe = r => e.jsx(V.div, {
    className: "chakra-stack__divider",
    ...r,
    __css: { ...r.__css,
        borderWidth: 0,
        alignSelf: "stretch",
        borderColor: "inherit",
        width: "auto",
        height: "auto"
    }
});
fe.displayName = "StackDivider";
var je = R(function(t, n) {
    const {
        children: s,
        placeholder: o,
        className: c,
        ...p
    } = t;
    return e.jsxs(V.select, { ...p,
        ref: n,
        className: Y("chakra-select", c),
        children: [o && e.jsx("option", {
            value: "",
            children: o
        }), s]
    })
});
je.displayName = "SelectField";

function vr(r, t) {
    const n = {},
        s = {};
    for (const [o, c] of Object.entries(r)) t.includes(o) ? n[o] = c : s[o] = c;
    return [n, s]
}
var X = R((r, t) => {
    var n;
    const s = he("Select", r),
        {
            rootProps: o,
            placeholder: c,
            icon: p,
            color: g,
            height: u,
            h: b,
            minH: a,
            minHeight: C,
            iconColor: d,
            iconSize: f,
            ...j
        } = be(r),
        [m, h] = vr(j, Re),
        i = _e(h),
        v = {
            width: "100%",
            height: "fit-content",
            position: "relative",
            color: g
        },
        P = {
            paddingEnd: "2rem",
            ...s.field,
            _focus: {
                zIndex: "unset",
                ...(n = s.field) == null ? void 0 : n._focus
            }
        };
    return e.jsxs(V.div, {
        className: "chakra-select__wrapper",
        __css: v,
        ...m,
        ...o,
        children: [e.jsx(je, {
            ref: t,
            height: b ? ? u,
            minH: a ? ? C,
            placeholder: c,
            ...i,
            __css: P,
            children: r.children
        }), e.jsx(ke, {
            "data-disabled": Be(i.disabled),
            ...(d || g) && {
                color: d || g
            },
            __css: s.icon,
            ...f && {
                fontSize: f
            },
            children: p
        })]
    })
});
X.displayName = "Select";
var yr = r => e.jsx("svg", {
        viewBox: "0 0 24 24",
        ...r,
        children: e.jsx("path", {
            fill: "currentColor",
            d: "M16.59 8.59L12 13.17 7.41 8.59 6 10l6 6 6-6z"
        })
    }),
    xr = V("div", {
        baseStyle: {
            position: "absolute",
            display: "inline-flex",
            alignItems: "center",
            justifyContent: "center",
            pointerEvents: "none",
            top: "50%",
            transform: "translateY(-50%)"
        }
    }),
    ke = r => {
        const {
            children: t = e.jsx(yr, {}),
            ...n
        } = r, s = y.cloneElement(t, {
            role: "presentation",
            className: "chakra-select__icon",
            focusable: !1,
            "aria-hidden": !0,
            style: {
                width: "1em",
                height: "1em",
                color: "currentColor"
            }
        });
        return e.jsx(xr, { ...n,
            className: "chakra-select__icon-wrapper",
            children: y.isValidElement(t) ? s : null
        })
    };
ke.displayName = "SelectIcon";
const Ie = [{
        type: "priceUsd",
        types: ["priceUsd", "priceUsdPercentage", "priceUsdCross"]
    }, {
        type: "priceNative",
        types: ["priceNative"]
    }, {
        type: "marketCap",
        types: ["marketCap"]
    }],
    Se = [{
        type: "priceUsdInverted",
        types: ["priceUsdInverted", "priceUsdInvertedCross"]
    }, {
        type: "priceNativeInverted",
        types: ["priceNativeInverted"]
    }],
    Ce = [{
        type: "moonshotProgress",
        types: ["moonshotProgress"]
    }],
    we = [{
        base: "priceUsd",
        type: "priceUsd",
        direction: "over",
        message: "Goes over",
        channels: ["web", "mobile"]
    }, {
        base: "priceUsd",
        type: "priceUsd",
        direction: "under",
        message: "Goes under",
        channels: ["web", "mobile"]
    }, {
        base: "priceUsd",
        type: "priceUsdCross",
        message: "Crosses",
        channels: ["mobile"]
    }, {
        base: "priceUsd",
        type: "priceUsdPercentage",
        message: "Goes up or down",
        channels: ["mobile"]
    }, {
        base: "priceUsd",
        type: "priceUsdPercentage",
        direction: "over",
        channels: ["web"]
    }, {
        base: "priceUsd",
        type: "priceUsdPercentage",
        direction: "under",
        channels: ["web"]
    }, {
        base: "priceNative",
        type: "priceNative",
        direction: "over",
        message: "Goes over",
        channels: ["web", "mobile"]
    }, {
        base: "priceNative",
        type: "priceNative",
        direction: "under",
        message: "Goes under",
        channels: ["web", "mobile"]
    }, {
        base: "marketCap",
        type: "marketCap",
        direction: "over",
        message: "Goes over",
        channels: ["web", "mobile"]
    }, {
        base: "marketCap",
        type: "marketCap",
        direction: "under",
        message: "Goes under",
        channels: ["web", "mobile"]
    }],
    Ne = [{
        base: "priceUsdInverted",
        type: "priceUsdInverted",
        direction: "over",
        message: "Goes over",
        channels: ["web", "mobile"]
    }, {
        base: "priceUsdInverted",
        type: "priceUsdInverted",
        direction: "under",
        message: "Goes under",
        channels: ["web", "mobile"]
    }, {
        base: "priceUsdInverted",
        type: "priceUsdInvertedCross",
        message: "Crosses",
        channels: ["mobile"]
    }, {
        base: "priceNativeInverted",
        type: "priceNativeInverted",
        direction: "over",
        message: "Goes over",
        channels: ["web", "mobile"]
    }, {
        base: "priceNativeInverted",
        type: "priceNativeInverted",
        direction: "under",
        message: "Goes under",
        channels: ["web", "mobile"]
    }],
    Pe = [{
        base: "moonshotProgress",
        type: "moonshotProgress",
        direction: "over",
        message: "Reaches",
        channels: ["web", "mobile"]
    }],
    re = r => {
        const {
            pair: t,
            token: n,
            formValues: s,
            isInverted: o,
            currentMoonshotProgress: c
        } = r;
        if (!t && !n) throw new Error("Neither pair nor token provided.");
        if (t) switch (s.triggerAndDirection) {
            case "priceUsdValueOver":
                if (s.priceUsd) return {
                    type: o ? "priceUsdInverted" : "priceUsd",
                    subject: t,
                    direction: "over",
                    priceUsd: s.priceUsd.replace(/,/g, "")
                };
                break;
            case "priceUsdValueUnder":
                if (s.priceUsd) return {
                    type: o ? "priceUsdInverted" : "priceUsd",
                    subject: t,
                    direction: "under",
                    priceUsd: s.priceUsd.replace(/,/g, "")
                };
                break;
            case "priceNativeValueOver":
                if (s.priceNative) return {
                    type: o ? "priceNativeInverted" : "priceNative",
                    subject: t,
                    direction: "over",
                    price: s.priceNative.replace(/,/g, "")
                };
                break;
            case "priceNativeValueUnder":
                if (s.priceNative) return {
                    type: o ? "priceNativeInverted" : "priceNative",
                    subject: t,
                    direction: "under",
                    price: s.priceNative.replace(/,/g, "")
                };
                break;
            case "priceUsdPercentageOver":
                if (s.percentage && s.timeframeKey) return {
                    type: "priceUsdPercentage",
                    subject: t,
                    direction: "over",
                    percentage: new w(s.percentage).decimalPlaces(2).toNumber(),
                    timeframeKey: s.timeframeKey
                };
                break;
            case "priceUsdPercentageUnder":
                if (s.percentage && s.timeframeKey) return {
                    type: "priceUsdPercentage",
                    subject: t,
                    direction: "under",
                    percentage: new w(s.percentage).decimalPlaces(2).toNumber(),
                    timeframeKey: s.timeframeKey
                };
                break;
            case "marketCapValueUnder":
                if (s.marketCap) return {
                    type: "marketCap",
                    subject: t,
                    direction: "under",
                    marketCap: new w(s.marketCap).decimalPlaces(2).toNumber()
                };
                break;
            case "marketCapValueOver":
                if (s.marketCap) return {
                    type: "marketCap",
                    subject: t,
                    direction: "over",
                    marketCap: new w(s.marketCap).decimalPlaces(2).toNumber()
                };
                break
        }
        if (n) switch (s.triggerAndDirection) {
            case "moonshotProgressValueOver":
            case "moonshotProgressValueUnder":
                if (s.percentage) return {
                    type: "moonshotProgress",
                    subject: n,
                    direction: c && c < s.percentage ? "over" : "under",
                    percentage: new w(s.percentage).decimalPlaces(2).toNumber()
                };
                break
        }
    },
    Ue = ({
        form: r,
        currentAlertBases: t,
        baseTokenSymbol: n
    }) => {
        const s = (o, c) => {
            switch (o.type) {
                case "priceUsd":
                case "priceUsdInverted":
                    return "Price in USD";
                case "priceNative":
                case "priceNativeInverted":
                    return `Price in ${c}`;
                case "moonshotProgress":
                    return "Progress";
                case "marketCap":
                    return "Market Cap"
            }
            return ""
        };
        return e.jsx(k, {
            as: "span",
            children: e.jsx(X, { ...r.register("triggerBase"),
                children: t.map(o => e.jsx("option", {
                    value: o.type,
                    children: s(o, n)
                }, o.type))
            })
        })
    },
    fr = r => {
        var j;
        const {
            alert: t,
            dexScreenerPair: n
        } = r, s = t.trigger.type === "priceUsdInverted" || t.trigger.type === "priceNativeInverted", o = t.trigger.subject.type === "dexToken", c = ((m, h) => m ? Ne : h ? Pe : we)(s, o), p = ((m, h) => m ? Se : h ? Ce : Ie)(s, o), g = t.trigger.type === "priceUsdInverted" || t.trigger.type === "priceUsd" ? t.trigger.priceUsd : n == null ? void 0 : n.priceUsd, u = t.trigger.type === "priceNative" || t.trigger.type === "priceNativeInverted" ? t.trigger.price : n == null ? void 0 : n.price, b = ((j = c.find(m => m.type === t.trigger.type)) == null ? void 0 : j.base) ? ? "priceUsd", a = t.trigger.type === "marketCap" ? t.trigger.marketCap : (n == null ? void 0 : n.marketCap) ? ? (n == null ? void 0 : n.fdv), C = t.trigger.type === "priceUsdPercentage" || t.trigger.type === "moonshotProgress" ? t.trigger.percentage : void 0, d = t.trigger.type === "priceUsdPercentage" ? t.trigger.timeframeKey : void 0;
        let f = "over";
        return (t.trigger.type === "priceUsd" || t.trigger.type === "priceUsdInverted" || t.trigger.type === "priceNative" || t.trigger.type === "priceNativeInverted" || t.trigger.type === "priceUsdPercentage" || t.trigger.type === "marketCap") && (f = t.trigger.direction), {
            isInverted: s,
            isMoonshot: o,
            priceUsd: g,
            priceNative: u,
            triggerAndDirection: B(t.trigger.type, f),
            triggerBase: b,
            percentage: C,
            timeframeKey: d,
            marketCap: a,
            currentAlertTypes: c,
            currentAlertBases: p
        }
    },
    Ae = ({
        form: r,
        quoteTokenSymbol: t = "$"
    }) => {
        switch (r.watch("triggerBase")) {
            case "priceNative":
                return e.jsx(k, {
                    as: "div",
                    flex: 1,
                    children: e.jsxs(N, {
                        children: [e.jsx(T, {
                            children: t
                        }), e.jsx(A, {
                            isInvalid: !!r.formState.errors.priceNative,
                            ...r.register("priceNative", {
                                validate: n => n ? new w(n.replace(/,/g, "")).gt(0) : !1
                            })
                        }, "TriggerAndDirectionFormPriceNative")]
                    })
                });
            case "marketCap":
                return e.jsx(k, {
                    as: "div",
                    flex: 1,
                    children: e.jsxs(N, {
                        children: [e.jsx(T, {
                            children: "$"
                        }), e.jsx(A, {
                            isInvalid: !!r.formState.errors.marketCap,
                            ...r.register("marketCap", {
                                validate: n => n ? new w(n).gt(0) : !1
                            })
                        }, "TriggerAndDirectionFormMarketCap")]
                    })
                });
            default:
                switch (r.watch("triggerAndDirection")) {
                    case "priceUsdPercentageOver":
                    case "priceUsdPercentageUnder":
                        return e.jsxs(e.Fragment, {
                            children: [e.jsx(k, {
                                as: "div",
                                flex: 1,
                                children: e.jsxs(N, {
                                    children: [e.jsx(A, {
                                        placeholder: "0",
                                        type: "number",
                                        step: ".01",
                                        isInvalid: !!r.formState.errors.percentage,
                                        ...r.register("percentage", {
                                            valueAsNumber: !0,
                                            validate: n => !(!n || n < 0 || r.getValues("triggerAndDirection") === "priceUsdPercentageUnder" && n > 99.99)
                                        })
                                    }), e.jsx(Q, {
                                        children: "%"
                                    })]
                                })
                            }), e.jsx(k, {
                                as: "div",
                                children: "within the"
                            }), e.jsx(k, {
                                as: "div",
                                children: e.jsx(X, { ...r.register("timeframeKey"),
                                    children: Ve.map(n => e.jsx("option", {
                                        value: n,
                                        children: ve[n].label
                                    }, n))
                                })
                            })]
                        });
                    case "moonshotProgressValueUnder":
                    case "moonshotProgressValueOver":
                        return e.jsx(e.Fragment, {
                            children: e.jsx(k, {
                                as: "div",
                                flex: 1,
                                children: e.jsxs(N, {
                                    children: [e.jsx(A, {
                                        placeholder: "0",
                                        type: "number",
                                        step: ".01",
                                        isInvalid: !!r.formState.errors.percentage,
                                        ...r.register("percentage", {
                                            valueAsNumber: !0,
                                            validate: n => !(!n || n < 0 || r.getValues("triggerAndDirection").startsWith("moonshotProgressValue") && n > 99.99)
                                        })
                                    }), e.jsx(Q, {
                                        children: "%"
                                    })]
                                })
                            })
                        });
                    default:
                        return e.jsx(k, {
                            as: "div",
                            flex: 1,
                            children: e.jsxs(N, {
                                children: [e.jsx(T, {
                                    children: "$"
                                }), e.jsx(A, {
                                    isInvalid: !!r.formState.errors.priceUsd,
                                    ...r.register("priceUsd", {
                                        validate: n => n ? new w(n.replace(/,/g, "")).gt(0) : !1
                                    })
                                }, "TriggerAndDirectionFormPriceUsd")]
                            })
                        })
                }
        }
    },
    Te = ({
        form: r,
        alertTypes: t
    }) => {
        const n = s => {
            switch (s.type) {
                case "priceUsd":
                case "priceUsdInverted":
                case "priceNative":
                case "priceNativeInverted":
                case "marketCap":
                    return s.direction === "over" ? "Goes over" : "Goes under";
                case "priceUsdCross":
                case "priceUsdInvertedCross":
                    return "Crosses";
                case "priceUsdPercentage":
                    return s.direction === "over" ? "Goes up more than" : "Goes down more than";
                case "moonshotProgress":
                    return "Reaches"
            }
        };
        return y.useEffect(() => {
            t && t[0] && r.setValue("triggerAndDirection", B(t[0].type, t[0].direction))
        }, []), e.jsx(X, { ...r.register("triggerAndDirection"),
            children: t.map(s => e.jsx("option", {
                value: B(s.type, s.direction),
                children: n(s)
            }, B(s.type, s.direction)))
        })
    },
    jr = ({
        alert: r,
        onSubmit: t,
        onCancel: n,
        dexScreenerPair: s
    }) => {
        const o = y.useRef(!1),
            c = fr({
                alert: r,
                dexScreenerPair: s
            }),
            {
                isInverted: p,
                isMoonshot: g,
                priceUsd: u,
                priceNative: b,
                triggerBase: a,
                percentage: C,
                timeframeKey: d,
                marketCap: f,
                triggerAndDirection: j,
                currentAlertTypes: m,
                currentAlertBases: h
            } = c,
            i = ye({
                defaultValues: {
                    triggerBase: a,
                    triggerAndDirection: j,
                    priceUsd: u,
                    priceNative: b,
                    marketCap: f,
                    percentage: C,
                    note: r.note,
                    timeframeKey: d
                }
            }),
            v = te(),
            P = E(ne),
            [G, z] = y.useState(!1),
            D = E(J),
            M = i.watch("triggerBase"),
            L = y.useCallback(() => m.filter(S => S.base === i.watch("triggerBase") && S.channels.includes("web")), [m, i])();
        y.useEffect(() => {
            if (o.current) return i.setValue("triggerAndDirection", `${M}ValueOver`);
            o.current = !0
        }, [i, M]);
        const Z = i.handleSubmit(async S => {
                if (G) return;
                let F;
                if (r.trigger.subject.type === "dexToken") {
                    const U = {
                        type: "dexToken",
                        chainId: r.trigger.subject.chainId,
                        dexId: r.trigger.subject.dexId,
                        tokenId: r.trigger.subject.tokenId,
                        baseTokenName: r.trigger.subject.baseTokenName,
                        baseTokenSymbol: r.trigger.subject.baseTokenSymbol,
                        quoteTokenSymbol: r.trigger.subject.quoteTokenSymbol
                    };
                    F = re({
                        token: U,
                        formValues: S,
                        isInverted: p,
                        currentMoonshotProgress: s && xe(s) ? s.moonshot.progress : void 0
                    })
                } else if (r.trigger.subject.type === "dexPair") {
                    const U = {
                        type: "dexPair",
                        chainId: r.trigger.subject.chainId,
                        dexId: r.trigger.subject.dexId,
                        pairId: r.trigger.subject.pairId,
                        baseTokenName: r.trigger.subject.baseTokenName,
                        baseTokenSymbol: r.trigger.subject.baseTokenSymbol,
                        quoteTokenSymbol: r.trigger.subject.quoteTokenSymbol
                    };
                    F = re({
                        pair: U,
                        formValues: S,
                        isInverted: p
                    })
                }
                if (!F) {
                    v({
                        status: "error",
                        description: "Invalid price alert"
                    });
                    return
                }
                z(!0);
                try {
                    await D.actions.updateAlert(r.id, {
                        schemaVersion: "1.0.0",
                        trigger: F,
                        channels: [{
                            type: "browser"
                        }],
                        enabled: !0,
                        note: S.note
                    }), P.track({
                        event: "updatePriceAlert",
                        data: {
                            id: r.id
                        }
                    }), v({
                        status: "success",
                        description: "Price alert updated!"
                    }), t()
                } catch (U) {
                    v({
                        status: "error",
                        description: `Failed updating price alert: ${K(U).message}`
                    })
                }
                z(!1)
            }),
            O = r.trigger.subject.type === "dexPair" ? p ? r.trigger.subject.baseTokenSymbol : r.trigger.subject.quoteTokenSymbol : void 0;
        return e.jsx(e.Fragment, {
            children: e.jsxs(H, {
                spacing: 4,
                alignItems: "flex-start",
                as: "form",
                onSubmit: Z,
                children: [e.jsxs(q, {
                    style: {
                        height: "inherit"
                    },
                    children: [e.jsx(k, {
                        as: "span",
                        alignItems: "center",
                        children: e.jsx(x, {
                            children: "Alert me when "
                        })
                    }), e.jsx(Ue, {
                        form: i,
                        currentAlertBases: h,
                        baseTokenSymbol: O ? ? ""
                    })]
                }), e.jsxs(q, {
                    align: "center",
                    width: "100%",
                    children: [e.jsx(k, {
                        as: "span",
                        w: "210px",
                        children: e.jsx(Te, {
                            form: i,
                            alertTypes: L
                        })
                    }), (O || g) && e.jsx(Ae, {
                        form: i,
                        quoteTokenSymbol: O
                    })]
                }), e.jsxs(N, {
                    children: [e.jsx(T, {
                        children: e.jsx(I, {
                            as: se
                        })
                    }), e.jsx(A, {
                        isInvalid: !!i.formState.errors.note,
                        ...i.register("note"),
                        placeholder: "Add a note to your alert (optional)"
                    })]
                }), e.jsx(q, {
                    width: "100%",
                    display: "flex",
                    justifyContent: "end",
                    children: e.jsxs(k, {
                        as: "div",
                        children: [e.jsx($, {
                            isLoading: G,
                            type: "submit",
                            mr: 2,
                            leftIcon: e.jsx(I, {
                                as: Ge
                            }),
                            colorScheme: "green",
                            children: "Save"
                        }), e.jsx($, {
                            onClick: n,
                            leftIcon: e.jsx(I, {
                                as: ze
                            }),
                            colorScheme: "red",
                            variant: "ghost",
                            children: "Cancel"
                        })]
                    })
                })]
            })
        })
    },
    kr = ({
        priceAlert: r
    }) => {
        var n;
        const {
            colorMode: t
        } = ie();
        switch (r.trigger.type) {
            case "priceUsd":
                return e.jsxs(e.Fragment, {
                    children: ["Alert me when price", " ", e.jsxs(x, {
                        as: "span",
                        fontWeight: "semibold",
                        color: r.trigger.direction === "over" ? l("green.500", "green.400", t) : l("red.500", "red.400", t),
                        children: [r.trigger.direction === "over" ? "goes over" : "goes under", " $", _(r.trigger.priceUsd)]
                    })]
                });
            case "priceUsdInverted":
                return e.jsxs(e.Fragment, {
                    children: ["Alert me when ", r.trigger.subject.quoteTokenSymbol, " price", " ", e.jsxs(x, {
                        as: "span",
                        fontWeight: "semibold",
                        color: r.trigger.direction === "over" ? l("green.500", "green.400", t) : l("red.500", "red.400", t),
                        children: [r.trigger.direction === "over" ? "goes over" : "goes under", " $", _(r.trigger.priceUsd)]
                    })]
                });
            case "priceNative":
            case "priceNativeInverted":
                return e.jsxs(e.Fragment, {
                    children: ["Alert me when ", r.trigger.subject.baseTokenSymbol, " price", " ", e.jsxs(x, {
                        as: "span",
                        fontWeight: "semibold",
                        color: r.trigger.direction === "over" ? l("green.500", "green.400", t) : l("red.500", "red.400", t),
                        children: [r.trigger.direction === "over" ? "goes over" : "goes under", " ", _(r.trigger.price), " ", r.trigger.subject.quoteTokenSymbol]
                    })]
                });
            case "priceUsdPercentage":
                return e.jsxs(x, {
                    as: "span",
                    children: ["Alert me when price is", " ", e.jsxs(x, {
                        as: "span",
                        fontWeight: "semibold",
                        color: r.trigger.direction === "over" ? l("green.500", "green.400", t) : l("red.500", "red.400", t),
                        children: [r.trigger.direction === "over" ? "goes up more than" : "goes down more than", " ", _(r.trigger.percentage), "%"]
                    }), " ", "within the", " ", e.jsx(W, {
                        as: "span",
                        fontWeight: "semibold",
                        children: (n = ve[r.trigger.timeframeKey]) == null ? void 0 : n.label.toLowerCase()
                    })]
                });
            case "marketCap":
                return e.jsxs(e.Fragment, {
                    children: ["Alert me when market cap", " ", e.jsxs(x, {
                        as: "span",
                        fontWeight: "semibold",
                        color: r.trigger.direction === "over" ? l("green.500", "green.400", t) : l("red.500", "red.400", t),
                        children: [r.trigger.direction === "over" ? "goes over" : "goes under", " $", _(r.trigger.marketCap)]
                    })]
                });
            case "moonshotProgress":
                return e.jsxs(x, {
                    as: "span",
                    children: ["Alert me when moonshot progress", " ", e.jsxs(x, {
                        as: "span",
                        fontWeight: "semibold",
                        children: ["Reaches ", _(r.trigger.percentage), "%"]
                    }), " "]
                });
            default:
                return null
        }
    },
    Ir = ({
        priceAlerts: r,
        containerProps: t,
        showPair: n,
        dexScreenerPair: s,
        onPairClick: o
    }) => {
        const c = E(J),
            {
                actions: p
            } = c,
            [g, u] = y.useState(void 0),
            b = te(),
            {
                colorMode: a
            } = ie(),
            C = i => {
                try {
                    p.resetAlert(i), b({
                        status: "success",
                        description: "Price alert reset"
                    })
                } catch (v) {
                    b({
                        status: "error",
                        description: `Failed resetting price alert: ${K(v).message}`
                    })
                }
            },
            d = i => {
                try {
                    p.deleteAlert(i)
                } catch (v) {
                    b({
                        status: "error",
                        description: `Failed deleting price alert: ${K(v).message}`
                    })
                }
            },
            f = i => {
                u({
                    type: "edit",
                    id: i.id
                })
            },
            j = () => {
                u(void 0)
            },
            m = () => {
                u(void 0)
            },
            h = () => {
                u(void 0)
            };
        return e.jsx(H, {
            spacing: 3,
            alignItems: "stretch",
            ...t,
            children: r.map(i => {
                if (i.trigger.subject.type !== "dexPair" && i.trigger.subject.type !== "dexToken") return;
                const v = g && g.type === "edit" && g.id === i.id,
                    P = g && g.type === "delete" && g.id === i.id;
                return e.jsxs(W, {
                    borderWidth: 1,
                    borderColor: v ? l("gray.100", "gray.800", a) : l("gray.50", "gray.925", a),
                    p: 3,
                    bg: v ? l("gray.0", "blue.950", a) : l("gray.50", "gray.925", a),
                    borderRadius: "md",
                    children: [n && e.jsx(Oe, {
                        display: "block",
                        w: "100%",
                        to: We({
                            platformId: i.trigger.subject.chainId,
                            pairAddress: i.trigger.subject.type === "dexPair" ? i.trigger.subject.pairId : i.trigger.subject.type === "dexToken" ? i.trigger.subject.tokenId : ""
                        }),
                        onClick: o ? () => o() : void 0,
                        mb: 3,
                        pb: 2,
                        borderBottomWidth: 1,
                        borderBottomColor: l("gray.100", "gray.800", a),
                        _hover: {
                            textDecoration: "none",
                            borderBottomColor: l("gray.150", "gray.750", a)
                        },
                        children: e.jsxs(x, {
                            as: "span",
                            fontSize: {
                                base: "sm",
                                md: "md"
                            },
                            children: [e.jsx(x, {
                                as: "span",
                                fontWeight: "semibold",
                                children: i.trigger.subject.baseTokenSymbol
                            }), e.jsx(x, {
                                as: "span",
                                mx: "2px",
                                color: l("gray.400", "gray.500", a),
                                children: "/"
                            }), e.jsx(x, {
                                as: "span",
                                color: l("gray.400", "gray.500", a),
                                children: i.trigger.subject.quoteTokenSymbol
                            }), e.jsx(x, {
                                as: "span",
                                display: {
                                    base: "none",
                                    md: "initial"
                                },
                                ml: 3,
                                children: i.trigger.subject.baseTokenName
                            })]
                        })
                    }), e.jsxs(W, {
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-between",
                        ...i.note && {
                            pb: 2
                        },
                        children: [e.jsxs(W, {
                            width: "100%",
                            children: [e.jsxs(W, {
                                wordBreak: "break-all",
                                children: [e.jsxs(x, {
                                    as: "span",
                                    display: "flex",
                                    alignItems: "center",
                                    mb: 1,
                                    fontWeight: "semibold",
                                    textTransform: "uppercase",
                                    fontSize: "xs",
                                    color: i.enabled ? l("green.500", "green.400", a) : l("red.500", "red.400", a),
                                    children: [e.jsx(I, {
                                        as: ae,
                                        mr: "3px"
                                    }), i.enabled ? "Active" : "Disabled"]
                                }), v && e.jsx(jr, {
                                    alert: i,
                                    dexScreenerPair: s,
                                    onSubmit: j,
                                    onCancel: m
                                }), !v && e.jsx(kr, {
                                    priceAlert: i
                                })]
                            }), !v && e.jsxs(x, {
                                as: "span",
                                fontSize: "sm",
                                color: l("gray.400", "gray.600", a),
                                children: ["Created ", de(i.createdAt), " ago", i.triggeredAt && `, last triggered ${de(i.triggeredAt)} ago`]
                            })]
                        }), !v && e.jsxs(le, {
                            children: [!i.enabled && e.jsx(ee, {
                                onClick: () => C(i.id),
                                "aria-label": "Reset alert",
                                title: "Reset alert",
                                icon: e.jsx(I, {
                                    as: qe
                                }),
                                flexShrink: 0,
                                variant: "unstyled",
                                colorScheme: "red",
                                size: "sm",
                                ml: 3,
                                color: l("gray.500", "gray.600", a),
                                _hover: {
                                    color: l("green.600", "green.300", a)
                                }
                            }), e.jsx(ee, {
                                onClick: () => f(i),
                                variant: "unstyled",
                                flexShrink: 0,
                                size: "sm",
                                ml: 3,
                                title: "Edit alert",
                                "aria-label": "Edit alert",
                                icon: e.jsx(I, {
                                    as: $e
                                }),
                                color: l("gray.500", "gray.600", a),
                                _hover: {
                                    color: l("accent.500", "accent.400", a)
                                }
                            }), e.jsx(ee, {
                                onClick: () => u({
                                    type: "delete",
                                    id: i.id
                                }),
                                "aria-label": "Delete alert",
                                title: "Delete alert",
                                icon: e.jsx(I, {
                                    as: Le
                                }),
                                flexShrink: 0,
                                variant: "unstyled",
                                colorScheme: "red",
                                size: "sm",
                                ml: 3,
                                color: l("gray.500", "gray.600", a),
                                _hover: {
                                    color: l("red.500", "red.400", a)
                                }
                            })]
                        })]
                    }), !v && i.note && e.jsx(e.Fragment, {
                        children: e.jsxs(H, {
                            alignItems: "flex-start",
                            children: [e.jsx(fe, {
                                borderTopWidth: 1,
                                borderColor: l("gray.100", "blue.900", a)
                            }), e.jsxs(le, {
                                spacing: 2,
                                justifyContent: "flex-start",
                                alignItems: "center",
                                children: [e.jsx(I, {
                                    as: se,
                                    color: l("gray.400", "gray.600", a)
                                }), e.jsx(x, {
                                    as: "span",
                                    fontSize: "sm",
                                    color: l("gray.500", "gray.300", a),
                                    children: i.note
                                })]
                            })]
                        })
                    }), P && e.jsx(Ke, {
                        modalProps: {
                            onClose: () => h()
                        },
                        message: "Are you sure you want to delete this alert?",
                        onConfirm: () => d(i.id),
                        onCancel: () => h()
                    })]
                }, i.id)
            })
        })
    },
    B = (r, t) => r === "priceUsdCross" || r === "priceNativeInverted" || r === "priceUsdInvertedCross" || r === "newScreenerPair" || r === "watchlistPriceUsdPercentage" ? r : r === "priceUsd" || r === "priceNative" || r === "marketCap" ? `${r}Value${t?ge(t):""}` : `${r}${t?ge(t):""}`,
    Sr = ({
        pair: r,
        isInverted: t
    }) => {
        const n = y.useRef(!0),
            {
                price: s,
                priceUsd: o,
                chainId: c,
                pairAddress: p,
                dexId: g,
                quoteToken: u,
                baseToken: b,
                marketCap: a,
                fdv: C
            } = r,
            d = xe(r),
            f = y.useMemo(() => d ? r.moonshot.progress : 0, [d, r]),
            j = y.useCallback(() => t ? Se : d ? Ce : Ie, [t, d])(),
            m = y.useCallback(() => t ? Ne : d ? Pe : we, [t, d])(),
            h = ye({
                defaultValues: {
                    triggerBase: j[0].type,
                    triggerAndDirection: B(m[0].type, m[0].direction ? m[0].direction : void 0),
                    priceUsd: t ? gr({
                        price: s,
                        priceUsd: o
                    }) : o,
                    priceNative: t ? pr({
                        price: s
                    }) : s,
                    percentage: d ? f : 0,
                    marketCap: a ? ? C ? ? 0,
                    note: void 0
                }
            }),
            i = y.useCallback(() => m.filter(S => S.base === h.watch("triggerBase") && S.channels.includes("web")), [m, h])(),
            v = te(),
            P = E(ne),
            [G, z] = y.useState(!1),
            D = E(J),
            M = lr(() => d ? D.listAlertsByToken(c, g, r.baseToken.address) : D.listAlertsByPair(c, g, r.pairAddress), [D, c, g, r.pairAddress, r.baseToken.address, d], []),
            {
                setValue: L
            } = h;
        y.useEffect(() => () => {
            n.current = !1
        }, [n]), y.useEffect(() => {
            L("triggerAndDirection", B(m[0].type, m[0].direction ? m[0].direction : void 0))
        }, [L, m]);
        const Z = h.handleSubmit(async S => {
                if (G) return;
                const F = {
                        type: "dexPair",
                        chainId: c,
                        dexId: g,
                        pairId: p,
                        baseTokenName: b.name,
                        baseTokenSymbol: b.symbol,
                        quoteTokenSymbol: u.symbol
                    },
                    U = {
                        type: "dexToken",
                        chainId: c,
                        dexId: g,
                        tokenId: b.address,
                        baseTokenName: b.name,
                        baseTokenSymbol: b.symbol,
                        quoteTokenSymbol: u.symbol
                    },
                    ce = re({
                        pair: d ? void 0 : F,
                        token: d ? U : void 0,
                        formValues: S,
                        isInverted: t,
                        currentMoonshotProgress: d ? r.moonshot.progress : void 0
                    });
                if (!ce) {
                    v({
                        status: "error",
                        description: "Invalid price alert"
                    });
                    return
                }
                z(!0);
                try {
                    await D.actions.createAlert({
                        schemaVersion: "1.0.0",
                        trigger: ce,
                        channels: [{
                            type: "browser"
                        }],
                        enabled: !0,
                        note: S.note
                    }), P.track({
                        event: "addPriceAlert"
                    }), v({
                        status: "success",
                        description: "Price alert created!"
                    }), n.current && (h.setValue("priceUsd", void 0), h.setValue("priceNative", void 0), h.setValue("marketCap", void 0), h.setValue("percentage", void 0), h.setValue("note", null))
                } catch (Ee) {
                    v({
                        status: "error",
                        description: `Failed creating price alert: ${K(Ee).message}`
                    })
                }
                z(!1)
            }),
            O = t ? b.symbol : u.symbol;
        return e.jsxs(e.Fragment, {
            children: [e.jsxs(H, {
                spacing: 4,
                alignItems: "flex-start",
                as: "form",
                onSubmit: Z,
                children: [e.jsxs(q, {
                    style: {
                        height: "inherit"
                    },
                    children: [e.jsx(k, {
                        as: "span",
                        alignItems: "center",
                        children: e.jsx(x, {
                            children: "Alert me when "
                        })
                    }), e.jsx(Ue, {
                        form: h,
                        currentAlertBases: j,
                        baseTokenSymbol: r.baseToken.symbol
                    })]
                }), e.jsxs(q, {
                    align: "center",
                    width: "100%",
                    children: [e.jsx(k, {
                        as: "span",
                        w: "210px",
                        children: e.jsx(Te, {
                            form: h,
                            alertTypes: i
                        })
                    }), e.jsx(Ae, {
                        form: h,
                        quoteTokenSymbol: O
                    }), e.jsx(k, {
                        as: "div",
                        children: e.jsx($, {
                            isLoading: G,
                            type: "submit",
                            leftIcon: e.jsx(I, {
                                as: He
                            }),
                            colorScheme: "green",
                            children: "Create Alert"
                        })
                    })]
                }), e.jsxs(N, {
                    children: [e.jsx(T, {
                        children: e.jsx(I, {
                            as: se
                        })
                    }), e.jsx(A, {
                        isInvalid: !!h.formState.errors.note,
                        ...h.register("note"),
                        placeholder: "Add a note to your alert (optional)"
                    })]
                })]
            }), M && M.length > 0 && e.jsx(Ir, {
                dexScreenerPair: r,
                containerProps: {
                    mt: 5
                },
                priceAlerts: M
            })]
        })
    },
    Cr = ({
        pair: r,
        onClose: t,
        isInverted: n
    }) => {
        const [s, o] = y.useState();
        y.useEffect(() => {
            "Notification" in window && o(window.Notification.permission)
        }, []);
        const c = () => {
                "Notification" in window && window.Notification.requestPermission(g => {
                    o(g)
                })
            },
            {
                colorMode: p
            } = ie();
        return e.jsxs(Qe, {
            size: "3xl",
            onClose: t,
            motionPreset: "none",
            scrollBehavior: "inside",
            blockScrollOnMount: !1,
            isOpen: !0,
            children: [e.jsx(Ye, {}), e.jsxs(Je, {
                children: [e.jsx(Xe, {}), e.jsx(Ze, {
                    children: e.jsx(er, {
                        size: "md",
                        children: "Manage Price Alerts"
                    })
                }), e.jsxs(rr, {
                    p: 5,
                    children: [s === "default" && e.jsxs(pe, {
                        display: "flex",
                        flexDir: "column",
                        py: 6,
                        textAlign: "center",
                        children: [e.jsxs(x, {
                            fontSize: "lg",
                            children: ["To set price alerts please enable", " ", e.jsx(ue, {
                                href: "https://support.google.com/chrome/answer/3220216?hl=en&co=GENIE.Platform%3DDesktop",
                                target: "_blank",
                                rel: "noreferrer",
                                color: l("accent.600", "accent.200", p),
                                textDecor: "underline",
                                children: "browser notifications"
                            }), " ", "for DEX Screener first:"]
                        }), e.jsx($, {
                            mt: 4,
                            onClick: c,
                            colorScheme: "green",
                            leftIcon: e.jsx(I, {
                                as: ae
                            }),
                            size: "lg",
                            children: "Enable Notifications"
                        })]
                    }), s === "denied" && e.jsxs(pe, {
                        display: "flex",
                        flexDir: "column",
                        py: 6,
                        textAlign: "center",
                        children: [e.jsx(I, {
                            as: tr,
                            color: l("red.500", "red.400", p),
                            boxSize: "80px"
                        }), e.jsxs(x, {
                            mt: 4,
                            fontSize: "lg",
                            children: ["You have blocked notifications for DEX Screener. Please", " ", e.jsx(ue, {
                                href: "https://support.google.com/chrome/answer/3220216?hl=en&co=GENIE.Platform%3DDesktop",
                                target: "_blank",
                                rel: "noreferrer",
                                color: l("accent.600", "accent.200", p),
                                textDecor: "underline",
                                children: "change your browser settings"
                            }), ", reload this page and try again."]
                        })]
                    }), s === "granted" && e.jsx(Sr, {
                        pair: r,
                        isInverted: n
                    })]
                })]
            })]
        })
    },
    Ar = ({
        pair: r,
        buttonProps: t,
        isInverted: n
    }) => {
        const s = E(ne),
            {
                isEmbed: o
            } = sr(a => a.embedSettings),
            c = me(),
            p = me(),
            g = E(J),
            u = nr(g.active, []).filter(({
                trigger: a
            }) => a.subject.type === "dexPair" && a.subject.chainId === (r == null ? void 0 : r.chainId) && a.subject.pairId === r.pairAddress || a.subject.type === "dexToken" && a.subject.chainId === (r == null ? void 0 : r.chainId) && a.subject.tokenId === r.baseToken.address).length,
            b = () => {
                if (o) {
                    c.onOpen();
                    return
                }
                p.onOpen(), s.track({
                    event: "priceAlertsButtonClick"
                })
            };
        return e.jsxs(e.Fragment, {
            children: [e.jsx(ir, {
                isDisabled: t && !t.isDisabled,
                label: "Your device does not support notifications",
                children: e.jsxs($, {
                    onClick: b,
                    leftIcon: e.jsx(I, {
                        as: u === 0 ? ar : ae,
                        boxSize: "16px"
                    }),
                    fontWeight: "normal",
                    pointerEvents: r ? void 0 : "none",
                    _focus: {
                        boxShadow: "none"
                    },
                    ...t,
                    children: [e.jsx(dr, {
                        children: "Alerts"
                    }), u > 0 && e.jsx(or, {
                        label: u
                    })]
                })
            }), r && p.isOpen && e.jsx(Cr, {
                pair: r,
                onClose: p.onClose,
                isInverted: n
            }), c.isOpen && e.jsx(cr, {
                onClose: c.onClose
            })]
        })
    };
export {
    N as I, Ar as P, fe as S, Ir as a, T as b, Q as c, pr as d, gr as i, mr as u
};