import {
    y as e,
    aC as o,
    A as n,
    $ as s,
    aD as r
} from "../entries/pages_catch-all.K13KjGu-.js";
import "./preload-helper-Jimfoxkq.js";
const A = s({
        env: r()
    }, ({
        env: a
    }) => ({
        type: "solana",
        rpcUrl: a.DS_WEB_SOLANA_WALLET_ADAPTER_RPC_URL ? ? void 0,
        adapters: [],
        network: a.DS_WEB_SOLANA_WALLET_ADAPTER_NETWORK
    })),
    p = ({
        children: a
    }) => {
        const t = n(A);
        return e.jsx(o, {
            config: t,
            children: a
        })
    };
export {
    p as MoonshotWalletAdapter
};