import {
    a1 as I,
    bC as S,
    bi as A,
    y as m,
    a3 as M,
    bD as N,
    ak as T,
    x as d,
    bE as l
} from "../entries/pages_catch-all.K13KjGu-.js";
var W = I(function(e, r) {
    const {
        borderLeftWidth: s,
        borderBottomWidth: i,
        borderTopWidth: n,
        borderRightWidth: o,
        borderWidth: a,
        borderStyle: h,
        borderColor: f,
        ...v
    } = S("Divider", e), {
        className: b,
        orientation: c = "horizontal",
        __css: D,
        ...x
    } = A(e), _ = {
        vertical: {
            borderLeftWidth: s || o || a || "1px",
            height: "100%"
        },
        horizontal: {
            borderBottomWidth: i || n || a || "1px",
            width: "100%"
        }
    };
    return m.jsx(M.hr, {
        ref: r,
        "aria-orientation": c,
        ...x,
        __css: { ...v,
            border: "0",
            borderColor: f,
            borderStyle: h,
            ..._[c],
            ...D
        },
        className: N("chakra-divider", b)
    })
});
W.displayName = "Divider";
const u = 6e4,
    g = 60 * u,
    w = 24 * g,
    y = (t, e) => {
        if (t > e) return;
        const r = e - t;
        if (!(r > w)) return r > g ? 6e4 : r > u ? 5e3 : 200
    },
    U = t => t instanceof Date ? t.getTime() : t,
    E = t => {
        var n;
        const e = (n = T().current) == null ? void 0 : n.time,
            [r, s] = d.useState(l(t.timestamp, {
                now: e,
                singleUnit: t.singleUnit
            })),
            i = y(U(t.timestamp), Date.now());
        return d.useEffect(() => {
            const o = i ? setInterval(() => {
                s(l(t.timestamp, {
                    now: Date.now(),
                    singleUnit: t.singleUnit
                }))
            }, i) : -1;
            return () => clearInterval(o)
        }, [t.timestamp, t.singleUnit, i]), {
            timeAgo: r ? ? "0s"
        }
    },
    k = ({
        timestamp: t,
        singleUnit: e
    }) => {
        const {
            timeAgo: r
        } = E({
            timestamp: t,
            singleUnit: e
        });
        return m.jsx("span", {
            children: r ? ? "0s"
        })
    };
export {
    W as D, k as T
};