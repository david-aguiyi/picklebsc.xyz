import {
    $ as j,
    bu as Dt,
    gv as jr,
    gw as Fr,
    gx as Et,
    dO as Hr,
    gy as Mr,
    gz as _r,
    gA as Wr,
    gB as Br,
    d6 as Nr,
    gC as Kr,
    gD as ar,
    bo as _,
    gE as qr,
    a$ as it,
    gF as Or,
    cd as Ve,
    b1 as or,
    gG as Vr,
    gH as Lt,
    gI as nt,
    b4 as J,
    c4 as ae,
    gJ as It,
    fx as $r,
    gK as Gr,
    gL as Zr,
    gM as Yr,
    bn as dr,
    bt as ct,
    gN as Xr,
    x as f,
    a1 as Jr,
    bC as Qr,
    bi as ei,
    y as l,
    a3 as ti,
    bD as ri,
    gO as ii,
    aG as Q,
    A as de,
    aD as lt,
    aR as Re,
    bU as Je,
    J as H,
    eF as ni,
    U as ut,
    a9 as oe,
    aS as si,
    T as O,
    af as ai,
    ag as oi,
    b7 as cr,
    ao as pt,
    az as G,
    V as st,
    b6 as di,
    aY as ht,
    bz as ci,
    eg as li,
    c3 as Tt,
    c8 as ui,
    ca as Ut,
    gP as pi,
    c7 as hi,
    G as fi,
    eD as mi,
    cf as lr,
    Z as at,
    eq as $e,
    Q as vi,
    cu as Rt,
    e7 as gi,
    gQ as xi,
    a7 as bi,
    a8 as yi,
    gR as zt,
    ac as wi,
    gS as ki,
    e5 as Ci,
    gT as Ai,
    cv as Si,
    f6 as Di,
    gU as Ei,
    ej as Li,
    b5 as Pt,
    ek as Ii,
    f_ as Ti,
    fZ as Ui,
    f$ as Ri,
    gV as zi,
    gW as Pi,
    gX as ce,
    gY as ze,
    gZ as V,
    g_ as Pe,
    g$ as je,
    h0 as Fe,
    h1 as He,
    h2 as Me,
    h3 as _e,
    h4 as q,
    h5 as Qe,
    h6 as ur,
    h7 as ji
} from "../entries/pages_catch-all.K13KjGu-.js";
import {
    b as Fi,
    c as et,
    d as ft,
    A as mt,
    e as jt,
    D as Ft
} from "./display-a-ads-ad-1eoQH_VD.js";
import {
    S as Te
} from "./span-2n6MBXt2.js";
import {
    c as ye
} from "./catchError-zPFqauN4.js";
import {
    u as Hi
} from "./ads-provider-KuUDbfp5.js";
import {
    E as Mi,
    B as _i
} from "./embed-feature-disabled-modal-4NIwn0pw.js";
const pr = j(jr, e => ({
    buildTokenMetadataURL: t => {
        const r = new URL(e);
        return r.pathname = `/cms/tokens/metadata/${t}`, r.toString()
    },
    buildTokenImageURL: (t, r, i) => {
        const s = new URL(e);
        return s.pathname = `/cms/images/tokens/${t}/${r}`, s.search = Dt.stringify(i), s.toString()
    },
    buildImageURL: (t, r) => {
        const i = new URL(e);
        return i.pathname = `/cms/images/${encodeURIComponent(t)}`, i.search = Dt.stringify(r), i.toString()
    }
}));

function Ht(e, t) {
    Fr(2, arguments);
    var r = Et(e),
        i = Et(t);
    return r.getTime() < i.getTime()
}

function Mt(e) {
    return new Hr(t => {
        try {
            t.next(e())
        } catch (r) {
            t.error(r)
        }
    })
}
class Wi extends Mr {
    constructor(t, r) {
        super(r(t.getValue())), this.property = t, this.f = r
    }
    subscribe(t) {
        return t ? typeof t == "function" ? this.property.subscribe(r => t(this.f(r))) : this.property.subscribe({
            next: r => {
                var i;
                return (i = t.next) == null ? void 0 : i.call(t, this.f(r))
            },
            error: r => {
                var i;
                return (i = t.error) == null ? void 0 : i.call(t, r)
            },
            complete: () => {
                var r;
                return (r = t.complete) == null ? void 0 : r.call(t)
            }
        }) : _r.EMPTY
    }
    get value() {
        return this.getValue()
    }
    getValue() {
        return this.f(this.property.getValue())
    }
}

function Bi(e, t) {
    return new Wi(e, t)
}

function Ni(e, t) {
    return e && e.length ? Wr(e, Br(t)) : []
}
const Ge = {
        sm: 64,
        md: 128,
        lg: 256,
        xl: 800
    },
    Ze = {
        sm: {
            width: 300,
            height: 100
        },
        md: {
            width: 600,
            height: 200
        },
        lg: {
            width: 900,
            height: 300
        },
        xl: {
            width: 1500,
            height: 500
        }
    },
    _t = e => typeof e == "string" ? {
        width: Ge[e],
        height: Ge[e]
    } : e,
    Wt = e => typeof e == "string" ? {
        width: Ze[e].width,
        height: Ze[e].height
    } : e,
    Ki = j(pr, e => t => {
        const r = {
            width: t.size ? _t(t.size).width : Ge.sm,
            height: t.size ? _t(t.size).height : Ge.sm,
            fit: t.fit,
            quality: 95,
            format: "auto"
        };
        return e.buildImageURL(t.assetId, r)
    }),
    qi = j(pr, e => t => {
        const r = {
            width: t.size ? Wt(t.size).width : Ze.md.width,
            height: t.size ? Wt(t.size).height : Ze.md.height,
            fit: t.fit,
            quality: 95,
            format: "auto"
        };
        return e.buildImageURL(t.assetId, r)
    }),
    ks = e => {
        if (e.pair.profile) return {
            chainId: e.pair.chainId,
            tokenAddress: e.pair.baseToken.address,
            size: e.size,
            cacheKey: e.pair.profile.imgKey
        }
    },
    Cs = j(Nr, Ki, (e, t) => r => {
        if (r.dsDataParams) return e(r.dsDataParams);
        if (r.cmsParams) return t(r.cmsParams)
    }),
    As = j(Kr, qi, (e, t) => r => {
        if (r.dsDataParams) return e(r.dsDataParams);
        if (r.cmsParams) return t(r.cmsParams)
    }),
    Ye = ["twitter", "telegram", "discord", "facebook", "tiktok"],
    Oi = "Website",
    hr = e => e.label === Oi,
    fr = e => e.filter(t => t.type !== void 0).sort((t, r) => Ye.indexOf(t.type) - Ye.indexOf(r.type)),
    mr = e => e.filter(t => t.type === void 0),
    Vi = (e, t) => {
        if (!t) return;
        const r = ar(t.claims ? ? []),
            i = (e && r ? r.socials : t.socials) ? ? [],
            s = Ni(i, "type").sort((o, h) => Ye.indexOf(o.type) - Ye.indexOf(h.type)),
            d = (e && r ? r.websites : t.websites) ? ? [],
            p = d.find(hr) ? ? d[0];
        return {
            socials: s,
            websites: d,
            website: p
        }
    },
    $i = e => {
        if (!e.cmsToken) return;
        const t = ar(e.cmsToken.claims ? ? []),
            r = (e.includeClaims && t ? t.links : e.cmsToken.links) ? ? [],
            i = fr(r),
            s = mr(r),
            d = s.find(hr) ? ? s[0];
        return {
            socials: i,
            websites: s,
            website: d
        }
    },
    Ss = e => {
        const t = Vi(e.includeClaims, e.dsDataToken);
        if (t) return t;
        const r = $i({
            includeClaims: e.includeClaims,
            cmsToken: e.cmsToken
        });
        return r || {
            socials: [],
            websites: [],
            website: void 0
        }
    },
    Ds = e => {
        const t = e.links ? ? [],
            r = fr(t),
            i = mr(t);
        return {
            socials: r,
            websites: i
        }
    },
    Gi = _.union([_.object({
        kind: _.literal("ready")
    }), _.object({
        kind: _.literal("error"),
        error: _.string()
    })]),
    vr = "https://request-global.czilladx.com",
    Zi = j("@dexscreener/feature-ads//CoinzillaAdsDataSource", Vr, or, (e, t) => ({
        findNativeAdUnit: r => e.nativeUnits.find(i => i.screen === r.screen),
        getDefaultNativeAdUnit: r => ({ ...e.defaultNativeUnit,
            screen: r.screen
        }),
        getNativeAd: r => {
            const i = Xi(r);
            return t.get(i, qr).pipe(it(Or))
        },
        findDisplayAdUnit: r => {
            const i = e.displayUnits.filter(s => s.screen === r.screen && Ve(s.size, r.size));
            return r.chainId === void 0 ? i.find(s => s.chainId === void 0) : i.find(s => s.chainId === r.chainId) ? ? i.find(s => s.chainId === void 0)
        },
        getDefaultDisplayAdUnit: r => ({ ...e.defaultDisplayUnit,
            screen: r.screen
        }),
        getDisplayAd: r => {
            const i = Ji(r);
            return t.text(i).pipe(it(s => {
                const d = new URL(s);
                if (d.searchParams.get("c") === "DEFAULT") throw new Error("Non-monetizable ad");
                return {
                    kind: "display",
                    provider: "coinzilla",
                    iframeURL: d.toString(),
                    adUnit: r
                }
            }))
        }
    }));

function Yi() {
    return `${Math.floor(Math.random()*1e12)+new Date().getTime()}`
}

function Xi(e) {
    const t = new URL(vr);
    return t.pathname = "/serve/native.php", t.searchParams.append("z", e.id), t.toString()
}

function Ji(e) {
    const t = new URL(vr);
    return e.size === "responsive" ? t.pathname = "/serve/header.php" : (t.pathname = "/serve/get.php", t.searchParams.append("w", Bt(e.size.width)), t.searchParams.append("h", Bt(e.size.height))), t.searchParams.append("withoutAdCode", "1"), t.searchParams.append("z", e.id), t.searchParams.append("n", Yi()), t.toString()
}

function Bt(e) {
    return e.toString()
}
const tt = j("@dexscreener/feature-ads//DirectAdUnitsDataSource", () => {
        const e = {
            native: {
                home: {
                    adKind: "native",
                    provider: "direct",
                    screen: "home",
                    id: "native-ad-home"
                },
                search: {
                    adKind: "native",
                    provider: "direct",
                    screen: "search",
                    id: "native-ad-search"
                },
                multicharts: {
                    adKind: "native",
                    provider: "direct",
                    screen: "multicharts",
                    id: "native-ad-multicharts"
                },
                gainersLosers: {
                    adKind: "native",
                    provider: "direct",
                    screen: "gainers-losers",
                    id: "native-ad-gainers-losers"
                },
                newPairs: {
                    adKind: "native",
                    provider: "direct",
                    screen: "new-pairs",
                    id: "native-ad-new-pairs"
                },
                watchlist: {
                    adKind: "native",
                    provider: "direct",
                    screen: "watchlist",
                    id: "native-ad-watchlist"
                },
                screener: {
                    adKind: "native",
                    provider: "direct",
                    screen: "screener",
                    id: "native-ad-screener"
                }
            },
            display: {
                pair: {
                    all: {
                        "300x250": {
                            adKind: "display",
                            provider: "direct",
                            screen: "pair",
                            id: "direct-ad-300x250",
                            size: {
                                width: 300,
                                height: 250
                            }
                        },
                        "320x100": {
                            adKind: "display",
                            provider: "direct",
                            screen: "pair",
                            id: "direct-ad-320x100",
                            size: {
                                width: 320,
                                height: 100
                            }
                        }
                    },
                    consensys: {
                        "300x250": {
                            adKind: "display",
                            provider: "direct",
                            screen: "pair",
                            id: "metamask-direct-ad-300x250",
                            size: {
                                width: 300,
                                height: 250
                            },
                            chainIds: ["ethereum", "optimism", "bsc", "polygon", "arbitrum", "avalanche", "linea"]
                        }
                    }
                }
            }
        };
        return {
            map: e,
            nativeAdUnits: [e.native.home, e.native.search, e.native.multicharts, e.native.gainersLosers, e.native.newPairs, e.native.watchlist, e.native.screener],
            displayAdUnits: [e.display.pair.all["300x250"], e.display.pair.consensys["300x250"], e.display.pair.all["320x100"]]
        }
    }),
    Qi = j(tt, e => [{
        kind: "display",
        provider: "direct",
        adUnits: [e.map.display.pair.all["300x250"], e.map.display.pair.consensys["300x250"]],
        source: "iframe",
        id: "coin-poker-300x250-FI-UK-0147",
        src: "https://static.dexscreen.com/finixio/coin-poker-300x250-v3/index.html",
        url: "https://a1.adform.net/C/?bn=73094922",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=73094922;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/pair/display/coin-poker-300x250"],
        startDate: new Date("2023-03-28"),
        endDate: new Date("2024-08-31"),
        weight: 15
    }, {
        kind: "display",
        provider: "direct",
        adUnits: [e.map.display.pair.all["320x100"]],
        source: "iframe",
        id: "coin-poker-320x100-FI-UK-0147",
        src: "https://static.dexscreen.com/finixio/coin-poker-320x100-v3/index.html",
        url: "https://a1.adform.net/C/?bn=73094923",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=73094923;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/pair/display/coin-poker-320x100"],
        startDate: new Date("2023-03-28"),
        endDate: new Date("2024-08-31"),
        weight: 15
    }, {
        kind: "display",
        provider: "direct",
        adUnits: [e.map.display.pair.all["300x250"], e.map.display.pair.consensys["300x250"]],
        source: "iframe",
        id: "wiener-ai-300x250-FI-UK-0142",
        src: "https://static.dexscreen.com/finixio/wiener-ai-300x250/300x250.html",
        url: "https://a1.adform.net/C/?bn=73269528",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=73269528;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/pair/display/wiener-ai-300x250"],
        startDate: new Date("2023-04-30"),
        endDate: new Date("2024-08-31"),
        weight: 10
    }, {
        kind: "display",
        provider: "direct",
        adUnits: [e.map.display.pair.all["320x100"]],
        source: "iframe",
        id: "wiener-ai-320x100-FI-UK-0142",
        src: "https://static.dexscreen.com/finixio/wiener-ai-320x100/320x100.html",
        url: "https://a1.adform.net/C/?bn=73269527",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=73269527;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/pair/display/wiener-ai-320x100"],
        startDate: new Date("2023-04-30"),
        endDate: new Date("2024-08-31"),
        weight: 10
    }, {
        kind: "display",
        provider: "direct",
        adUnits: [e.map.display.pair.all["300x250"], e.map.display.pair.consensys["300x250"]],
        source: "iframe",
        id: "play-doge-300x250-FI-UK-0142",
        src: "https://static.dexscreen.com/finixio/play-doge-300x250-v3/300x250.html",
        url: "https://a1.adform.net/C/?bn=73856674",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=73856674;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/pair/display/play-doge-300x250"],
        startDate: new Date("2023-04-30"),
        endDate: new Date("2024-08-31"),
        weight: 10
    }, {
        kind: "display",
        provider: "direct",
        adUnits: [e.map.display.pair.all["320x100"]],
        source: "iframe",
        id: "play-doge-320x100-FI-UK-0142",
        src: "https://static.dexscreen.com/finixio/play-doge-320x100-v3/320x100.html",
        url: "https://a1.adform.net/C/?bn=73856676",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=73856676;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/pair/display/play-doge-320x100"],
        startDate: new Date("2023-04-30"),
        endDate: new Date("2024-08-31"),
        weight: 10
    }, {
        kind: "display",
        provider: "direct",
        adUnits: [e.map.display.pair.all["300x250"], e.map.display.pair.consensys["300x250"]],
        source: "iframe",
        id: "base-dawgz-300x250-FI-UK-0174",
        src: "https://static.dexscreen.com/finixio/base-dawgz-300x250/300x250.html",
        url: "https://a1.adform.net/C/?bn=73856674",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=73856674;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/pair/display/base-dawgz-300x250"],
        startDate: new Date("2023-04-30"),
        endDate: new Date("2024-08-31"),
        weight: 10
    }, {
        kind: "display",
        provider: "direct",
        adUnits: [e.map.display.pair.all["320x100"]],
        source: "iframe",
        id: "base-dawgz-320x100-FI-UK-0174",
        src: "https://static.dexscreen.com/finixio/base-dawgz-320x100/320x100.html",
        url: "https://a1.adform.net/C/?bn=74064971",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=74064971;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/pair/display/base-dawgz-320x100"],
        startDate: new Date("2023-04-30"),
        endDate: new Date("2024-08-31"),
        weight: 10
    }, {
        kind: "display",
        provider: "direct",
        adUnits: [e.map.display.pair.all["300x250"], e.map.display.pair.consensys["300x250"]],
        source: "iframe",
        id: "pepe-unchained-300x250-FI-UK-0177",
        src: "https://static.dexscreen.com/finixio/pepe-unchained-300x250/300x250.html",
        url: "https://a1.adform.net/C/?bn=74610137",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=74610137;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/pair/display/pepe-unchained-300x250"],
        startDate: new Date("2023-04-30"),
        endDate: new Date("2024-08-31"),
        weight: 20
    }, {
        kind: "display",
        provider: "direct",
        adUnits: [e.map.display.pair.all["320x100"]],
        source: "iframe",
        id: "pepe-unchained-320x100-FI-UK-0177",
        src: "https://static.dexscreen.com/finixio/pepe-unchained-320x100/320x100.html",
        url: "https://a1.adform.net/C/?bn=74610135",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=74610135;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/pair/display/pepe-unchained-320x100"],
        startDate: new Date("2023-04-30"),
        endDate: new Date("2024-08-31"),
        weight: 20
    }, {
        kind: "display",
        provider: "direct",
        adUnits: [e.map.display.pair.all["300x250"], e.map.display.pair.consensys["300x250"]],
        source: "iframe",
        id: "shiba-shootout-300x250-FI-UK-0157",
        src: "https://static.dexscreen.com/finixio/shiba-shootout-300x250/index.html",
        url: "https://a1.adform.net/C/?bn=74758575",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=74758575;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/pair/display/shiba-shootout-300x250"],
        startDate: new Date("2023-04-30"),
        endDate: new Date("2024-08-31"),
        weight: 10
    }, {
        kind: "display",
        provider: "direct",
        adUnits: [e.map.display.pair.all["320x100"]],
        source: "iframe",
        id: "shiba-shootout-320x100-FI-UK-0157",
        src: "https://static.dexscreen.com/finixio/shiba-shootout-320x100/index.html",
        url: "https://a1.adform.net/C/?bn=74758579",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=74758579;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/pair/display/shiba-shootout-320x100"],
        startDate: new Date("2023-04-30"),
        endDate: new Date("2024-08-31"),
        weight: 10
    }, {
        kind: "display",
        provider: "direct",
        adUnits: [e.map.display.pair.all["300x250"], e.map.display.pair.consensys["300x250"]],
        source: "iframe",
        id: "meme-games-300x250-FI-UK-0157",
        src: "https://static.dexscreen.com/finixio/meme-games-300x250/300x250.html",
        url: "https://a1.adform.net/C/?bn=75033567",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=75033567;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/pair/display/meme-games-300x250"],
        startDate: new Date("2023-04-30"),
        endDate: new Date("2024-08-31"),
        weight: 10
    }, {
        kind: "display",
        provider: "direct",
        adUnits: [e.map.display.pair.all["320x100"]],
        source: "iframe",
        id: "meme-games-320x100-FI-UK-0157",
        src: "https://static.dexscreen.com/finixio/meme-games-320x100/320x100.html",
        url: "https://a1.adform.net/C/?bn=75033568",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=75033568;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/pair/display/meme-games-320x100"],
        startDate: new Date("2023-04-30"),
        endDate: new Date("2024-08-31"),
        weight: 10
    }, {
        kind: "display",
        provider: "direct",
        adUnits: [e.map.display.pair.all["300x250"], e.map.display.pair.consensys["300x250"]],
        source: "iframe",
        id: "tg-casino-300x250-FI-UK-0095",
        src: "https://static.dexscreen.com/finixio/tg-casino-300x250-v4/300x250.html",
        url: "https://a1.adform.net/C/?bn=69415140",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=69415140;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/pair/display/tg-casino-300x250"],
        startDate: new Date("2023-04-30"),
        endDate: new Date("2024-08-31"),
        weight: 15
    }, {
        kind: "display",
        provider: "direct",
        adUnits: [e.map.display.pair.all["320x100"]],
        source: "iframe",
        id: "tg-casino-320x100-FI-UK-0095",
        src: "https://static.dexscreen.com/finixio/tg-casino-320x100-v4/320x100.html",
        url: "https://a1.adform.net/C/?bn=69415139",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=69415139;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/pair/display/tg-casino-320x100"],
        startDate: new Date("2023-04-30"),
        endDate: new Date("2024-08-31"),
        weight: 15
    }]),
    fe = {
        kind: "native",
        provider: "direct",
        title: "CoinPoker",
        description: "No KYC Crypto Poker, Instant Withdrawals - Get a 150% Welcome Bonus Up To $2000!",
        callToAction: "PLAY NOW",
        thumbnail: "https://static.dexscreen.com/finixio/coinpoker-logo.svg",
        advertiseLink: "https://docs.dexscreener.com/contact-us/advertise",
        startDate: new Date("2024-04-16T00:00:00.00Z"),
        endDate: new Date("2024-08-17T00:00:00.00Z"),
        weight: 15
    },
    me = {
        kind: "native",
        provider: "direct",
        title: "Wiener AI",
        description: "Better than Shiba? New Meme coin raises $350k instantly",
        callToAction: "Buy $WAI",
        thumbnail: "https://static.dexscreen.com/finixio/wiener-ai-logo.png",
        advertiseLink: "https://docs.dexscreener.com/contact-us/advertise",
        startDate: new Date("2024-04-16T00:00:00.00Z"),
        endDate: new Date("2024-08-17T00:00:00.00Z"),
        weight: 10
    },
    ve = {
        kind: "native",
        provider: "direct",
        title: "PlayDoge",
        description: "Traders Invest $250,000+ Into PlayDoge, Get in EARLY on this Play to Earn Meme Coin!",
        callToAction: "BUY $PLAY",
        thumbnail: "https://static.dexscreen.com/finixio/play-doge-logo-v2.svg",
        advertiseLink: "https://docs.dexscreener.com/contact-us/advertise",
        startDate: new Date("2024-04-16T00:00:00.00Z"),
        endDate: new Date("2024-08-17T00:00:00.00Z"),
        weight: 10
    },
    ge = {
        kind: "native",
        provider: "direct",
        title: "Base Dawgz",
        description: "New BASE Meme Coin Base Dawgz Selling Out Fast! Is $DAWGZ The Next BRETT?",
        callToAction: "BUY $DAWGZ",
        thumbnail: "https://static.dexscreen.com/finixio/base-dawgz-logo.png",
        advertiseLink: "https://docs.dexscreener.com/contact-us/advertise",
        startDate: new Date("2024-04-16T00:00:00.00Z"),
        endDate: new Date("2024-08-17T00:00:00.00Z"),
        weight: 10
    },
    xe = {
        kind: "native",
        provider: "direct",
        title: "Pepe Unchained",
        description: "Pepe Unchained Raises $200,000 in Minutes, Whales Discover This New Layer 2 Meme Coin!",
        callToAction: "BUY $PEPU",
        thumbnail: "https://static.dexscreen.com/finixio/pepe-unchained.svg",
        advertiseLink: "https://docs.dexscreener.com/contact-us/advertise",
        startDate: new Date("2024-04-16T00:00:00.00Z"),
        endDate: new Date("2024-08-18T00:00:00.00Z"),
        weight: 20
    },
    be = {
        kind: "native",
        provider: "direct",
        title: "TG.Casino",
        description: "TG.Casino, world’s first licensed telegram casino. Fully anonymous - 10 ETH Bonus + 25% Cashback",
        callToAction: "Play Now!",
        thumbnail: "https://dexscreener.com/a/direct/tg-casino-logo.svg",
        advertiseLink: "https://docs.dexscreener.com/contact-us/advertise",
        startDate: new Date("2024-04-16T00:00:00.00Z"),
        endDate: new Date("2024-08-17T00:00:00.00Z"),
        weight: 15
    },
    en = j(tt, e => [{ ...fe,
        adUnit: e.map.native.home,
        url: "https://a1.adform.net/C/?bn=73094925",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=73094925;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/home/native/coinpoker"]
    }, { ...me,
        adUnit: e.map.native.home,
        url: "https://a1.adform.net/C/?bn=73269530",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=73269530;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/home/native/wiener-ai"]
    }, { ...ve,
        adUnit: e.map.native.home,
        url: "https://a1.adform.net/C/?bn=73856673",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=73856673;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/home/native/play-doge"]
    }, { ...xe,
        adUnit: e.map.native.home,
        url: "https://a1.adform.net/C/?bn=74610138",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=74610138;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/home/native/pepe-unchained"]
    }, { ...ge,
        adUnit: e.map.native.home,
        url: "https://a1.adform.net/C/?bn=74064975",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=74064975;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/home/native/base-dawgz"]
    }, { ...be,
        adUnit: e.map.native.home,
        url: "https://a1.adform.net/C/?bn=69415138",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=69415138;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/home/native/tg-casino"]
    }, { ...fe,
        adUnit: e.map.native.multicharts,
        url: "https://a1.adform.net/C/?bn=73094924",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=73094924;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/multicharts/native/coinpoker"]
    }, { ...me,
        adUnit: e.map.native.multicharts,
        url: "https://a1.adform.net/C/?bn=73269531",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=73269531;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/multicharts/native/wiener-ai"]
    }, { ...ve,
        adUnit: e.map.native.multicharts,
        url: "https://a1.adform.net/C/?bn=73856672",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=73856672;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/multicharts/native/play-doge"]
    }, { ...xe,
        adUnit: e.map.native.multicharts,
        url: "https://a1.adform.net/C/?bn=74610134",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=74610134;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/multicharts/native/pepe-unchained"]
    }, { ...ge,
        adUnit: e.map.native.multicharts,
        url: "https://a1.adform.net/C/?bn=73856672",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=73856672;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/multicharts/native/base-dawgz"]
    }, { ...be,
        adUnit: e.map.native.multicharts,
        url: "https://a1.adform.net/C/?bn=69415136",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=69415136;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/multicharts/native/tg-casino"]
    }, { ...fe,
        adUnit: e.map.native.gainersLosers,
        url: "https://a1.adform.net/C/?bn=73094924",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=73094924;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/gainers-losers/native/coinpoker"]
    }, { ...me,
        adUnit: e.map.native.gainersLosers,
        url: "https://a1.adform.net/C/?bn=73269531",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=73269531;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/multicharts/native/wiener-ai"]
    }, { ...ve,
        adUnit: e.map.native.gainersLosers,
        url: "https://a1.adform.net/C/?bn=73856672",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=73856672;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/multicharts/native/play-doge"]
    }, { ...xe,
        adUnit: e.map.native.gainersLosers,
        url: "https://a1.adform.net/C/?bn=74610134",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=74610134;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/multicharts/native/pepe-unchained"]
    }, { ...ge,
        adUnit: e.map.native.gainersLosers,
        url: "https://a1.adform.net/C/?bn=74064973",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=74064973;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/multicharts/native/base-dawgz"]
    }, { ...be,
        adUnit: e.map.native.gainersLosers,
        url: "https://a1.adform.net/C/?bn=69415136",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=69415136;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/multicharts/native/tg-casino"]
    }, { ...fe,
        adUnit: e.map.native.newPairs,
        url: "https://a1.adform.net/C/?bn=73094924",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=73094924;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/new-pairs/native/coinpoker"]
    }, { ...me,
        adUnit: e.map.native.newPairs,
        url: "https://a1.adform.net/C/?bn=73269531",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=73269531;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/multicharts/native/wiener-ai"]
    }, { ...ve,
        adUnit: e.map.native.newPairs,
        url: "https://a1.adform.net/C/?bn=73856672",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=73856672;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/multicharts/native/play-doge"]
    }, { ...xe,
        adUnit: e.map.native.newPairs,
        url: "https://a1.adform.net/C/?bn=74610134",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=74610134;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/multicharts/native/pepe-unchained"]
    }, { ...ge,
        adUnit: e.map.native.newPairs,
        url: "https://a1.adform.net/C/?bn=74064973",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=74064973;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/multicharts/native/base-dawgz"]
    }, { ...be,
        adUnit: e.map.native.newPairs,
        url: "https://a1.adform.net/C/?bn=69415136",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=69415136;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/multicharts/native/tg-casino"]
    }, { ...fe,
        adUnit: e.map.native.watchlist,
        url: "https://a1.adform.net/C/?bn=73094924",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=73094924;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/watchlist/native/coinpoker"]
    }, { ...me,
        adUnit: e.map.native.watchlist,
        url: "https://a1.adform.net/C/?bn=73269531",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=73269531;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/multicharts/native/wiener-ai"]
    }, { ...ve,
        adUnit: e.map.native.watchlist,
        url: "https://a1.adform.net/C/?bn=73856672",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=73856672;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/multicharts/native/play-doge"]
    }, { ...xe,
        adUnit: e.map.native.watchlist,
        url: "https://a1.adform.net/C/?bn=74610134",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=74610134;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/multicharts/native/pepe-unchained"]
    }, { ...ge,
        adUnit: e.map.native.watchlist,
        url: "https://a1.adform.net/C/?bn=74064973",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=74064973;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/multicharts/native/base-dawgz"]
    }, { ...be,
        adUnit: e.map.native.watchlist,
        url: "https://a1.adform.net/C/?bn=69415136",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=69415136;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/multicharts/native/tg-casino"]
    }, { ...fe,
        adUnit: e.map.native.search,
        url: "https://a1.adform.net/C/?bn=73094921",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=73094921;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/search/native/coinpoker"]
    }, { ...me,
        adUnit: e.map.native.search,
        url: "https://a1.adform.net/C/?bn=73269529",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=73269529;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/search/native/wiener-ai"]
    }, { ...ve,
        adUnit: e.map.native.search,
        url: "https://a1.adform.net/C/?bn=73856675",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=73856675;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/search/native/play-doge"]
    }, { ...xe,
        adUnit: e.map.native.search,
        url: "https://a1.adform.net/C/?bn=74610136",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=74610136;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/search/native/pepe-unchained"]
    }, { ...ge,
        adUnit: e.map.native.search,
        url: "https://a1.adform.net/C/?bn=74064976",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=74064976;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/search/native/base-dawgz"]
    }, { ...be,
        adUnit: e.map.native.search,
        url: "https://a1.adform.net/C/?bn=69415137",
        impressionURLs: ["https://a1.adform.net/adfserve/?CC=1&bn=69415137;1x1inv=1;srctype=3", "https://cfw.dexscreener.com/a/direct/search/native/tg-casino"]
    }]),
    tn = j(tt, e => [{
        kind: "native",
        provider: "direct",
        title: "MetaWin",
        description: "5% Cashback, Instant Withdrawals & Max Payout Guarantee!",
        callToAction: "Play Now",
        thumbnail: "https://dexscreener.com/a/direct/meta-win-logo.svg",
        url: "http://metawin.com/t/dexscreener-1?utm_source=dexscreener&utm_medium=display&utm_campaign=Native-Direct",
        advertiseLink: "https://docs.dexscreener.com/contact-us/advertise",
        startDate: new Date("2023-10-30T13:00:00.00Z"),
        endDate: new Date("2024-08-31T13:00:00.00Z"),
        weight: 1,
        adUnit: e.map.native.screener,
        impressionURLs: ["https://cfw.dexscreener.com/a/direct/screener/native/metawin"]
    }]),
    rn = j("@dexscreener/feature-ads//DirectAdsDataSource", $r, tt, en, Qi, tn, (e, t, r, i, s) => {
        const d = [...r, ...s],
            p = [...i];
        return {
            findNativeAdUnit: o => t.nativeAdUnits.find(h => h.screen === o.screen),
            findDisplayAdUnit: o => {
                const h = o.chainId;
                if (h) {
                    const c = t.displayAdUnits.find(u => o.screen === u.screen && Ve(o.size, u.size) && u.chainIds !== void 0 && u.chainIds.includes(h));
                    if (c) return c
                }
                return t.displayAdUnits.find(c => o.screen === c.screen && Ve(o.size, c.size) && c.chainIds === void 0)
            },
            getNativeAd: o => {
                const h = new Date,
                    u = d.filter(v => Lt(h, v.startDate) && Ht(h, v.endDate) && v.adUnit.id === o.id).flatMap(v => Array(v.weight).fill(v)),
                    m = u.at(nt(u.length - 1, !1));
                return J(m)
            },
            getDisplayAd: o => {
                const h = new Date,
                    u = p.filter(v => Lt(h, v.startDate) && Ht(h, v.endDate) && v.adUnits.includes(o)).flatMap(v => Array(v.weight).fill({ ...v,
                        adUnit: o
                    })),
                    m = u[nt(u.length - 1, !1)];
                return m ? J(m).pipe(ae(v => It(async ({
                    signal: y
                }) => {
                    for (const g of v.impressionURLs) await e.head(g, {
                        mode: "no-cors",
                        signal: y
                    });
                    return v
                }))) : J(void 0)
            },
            notifyViewed: o => It(async ({
                signal: h
            }) => {
                for (const c of o.impressionURLs) await e.text(c, {
                    mode: "no-cors",
                    signal: h
                })
            })
        }
    }),
    nn = [{
        adKind: "display",
        provider: "cointraffic",
        screen: "pair",
        size: {
            width: 300,
            height: 250
        },
        id: "ct_ct5dIzkNSN8"
    }, {
        adKind: "display",
        provider: "cointraffic",
        screen: "pair",
        size: {
            width: 320,
            height: 100
        },
        id: "ct_cy5LKkF4i9i"
    }],
    sn = j(() => ({
        findDisplayAdUnit: e => nn.find(t => t.screen !== e.screen ? !1 : Gr(t.size, e.size)),
        getDisplayAd: e => J({
            kind: "display",
            provider: "cointraffic",
            adUnit: e
        })
    })),
    an = j("@dexscreener/feature-ads//fallbackAds", () => [{
        kind: "native",
        provider: "fallback",
        description: "Advertise on DEX Screener and reach millions of crypto enthusiasts!",
        callToAction: "More info",
        url: "https://docs.dexscreener.com/contact-us/advertise"
    }, {
        kind: "native",
        provider: "fallback",
        description: "Have you tried the DEX Screener app for iOS/Android yet?",
        callToAction: "Download now!",
        url: "https://docs.dexscreener.com/mobile-app"
    }, {
        kind: "native",
        provider: "fallback",
        description: "Did you know DEX Screener has a free API?",
        callToAction: "More info",
        url: "https://docs.dexscreener.com/api/reference"
    }]),
    on = {
        adKind: "native",
        provider: "fallback"
    },
    dn = j("@dexcreener/feature-ads//fallbackAdsDataSource", an, e => ({
        getAd: () => J(e[nt(0, e.length - 1, !1)] ? ? e[0]),
        findAdUnit: () => on
    })),
    cn = j("@dexscreener/feature-ads//GoogleAdsAdUnitsDataSource", () => ({
        displayUnits: [{
            adKind: "display",
            provider: "google",
            id: "/22881105882/pair-details-300x250",
            screen: "pair",
            size: {
                width: 300,
                height: 250
            }
        }],
        defaultDisplayUnit: {
            adKind: "display",
            provider: "google",
            id: "/22881105882/pair-details-300x250",
            size: {
                width: 300,
                height: 250
            }
        }
    })),
    ln = j("@dexscreener/feature-ads//GoogleAdsDataSource", cn, e => ({
        findDisplayAdUnit: t => e.displayUnits.find(r => r.screen === t.screen && Ve(r.size, t.size)),
        getDefaultDisplayAdUnit: t => ({ ...e.defaultDisplayUnit,
            ...t
        }),
        getDisplayAd: t => {
            const r = {
                kind: "display",
                provider: "google",
                id: t.id,
                adUnit: t
            };
            return J(r)
        }
    })),
    un = j(Xr, dn, Zi, Fi, ln, ct, dr, rn, Yr, sn, (e, t, r, i, s, d, p, o, h, c) => {
        const u = d.getChildLogger({
                name: d.settings.name + "/AdsService"
            }),
            m = new Zr([]),
            v = n => {
                switch (n.preferredAdKind) {
                    case "native":
                        {
                            switch (n.provider) {
                                case "coinzilla":
                                    return r.findNativeAdUnit(n) ? ? r.getDefaultNativeAdUnit(n);
                                case "direct":
                                    return o.findNativeAdUnit(n) ? ? t.findAdUnit()
                            }
                            break
                        }
                    case "display":
                        switch (n.provider) {
                            case "coinzilla":
                                return r.findDisplayAdUnit(n) ? ? r.getDefaultDisplayAdUnit(n);
                            case "a-ads":
                                return i.findDisplayAdUnit(n) ? ? i.getDefaultDisplayAdUnit(n);
                            case "google":
                                return s.findDisplayAdUnit(n) ? ? s.getDefaultDisplayAdUnit(n);
                            case "direct":
                                {
                                    const a = o.findDisplayAdUnit(n);
                                    if (a) return a;
                                    const A = {
                                        preferredAdKind: "display",
                                        provider: "coinzilla",
                                        screen: n.screen,
                                        size: n.size
                                    };
                                    return r.findDisplayAdUnit(A) ? ? r.getDefaultDisplayAdUnit(A)
                                }
                            case "persona":
                                {
                                    const a = h.findDisplayAdUnit(n);
                                    if (a) return a;
                                    const A = {
                                        preferredAdKind: "display",
                                        provider: "coinzilla",
                                        screen: n.screen,
                                        size: n.size
                                    };
                                    return r.findDisplayAdUnit(A) ? ? r.getDefaultDisplayAdUnit(A)
                                }
                            case "cointraffic":
                                {
                                    const a = c.findDisplayAdUnit(n);
                                    if (a) return a;
                                    const A = {
                                        preferredAdKind: "display",
                                        provider: "coinzilla",
                                        screen: n.screen,
                                        size: n.size
                                    };
                                    return r.findDisplayAdUnit(A) ? ? r.getDefaultDisplayAdUnit(A)
                                }
                        }
                }
            },
            y = n => {
                switch (u.silly("getAdDirectly", n), n.adKind) {
                    case "native":
                        {
                            switch (n.provider) {
                                case "fallback":
                                    return t.getAd();
                                case "coinzilla":
                                    return r.getNativeAd(n);
                                case "direct":
                                    return o.getNativeAd(n)
                            }
                            break
                        }
                    case "display":
                        switch (n.provider) {
                            case "coinzilla":
                                return r.getDisplayAd(n);
                            case "a-ads":
                                return i.getDisplayAd(n);
                            case "google":
                                return s.getDisplayAd(n);
                            case "direct":
                                return o.getDisplayAd(n);
                            case "persona":
                                return h.getDisplayAd(n);
                            case "cointraffic":
                                return c.getDisplayAd(n)
                        }
                }
            },
            g = () => (u.silly("getNativeFallbackAdFromFallbacks"), t.getAd()),
            S = n => (u.silly("getNativeFallbackAdFromAdsWorker", n), e.getAd(n)),
            D = n => (u.silly("getDisplayFallbackAdFromAAds", n), Mt(() => i.findDisplayAdUnit(n) ? ? i.getDefaultDisplayAdUnit(n)).pipe(ae(a => i.getDisplayAd(a)))),
            k = n => (u.silly("getDisplayFallbackAdFromCoinzilla", n), Mt(() => r.findDisplayAdUnit(n) ? ? r.getDefaultDisplayAdUnit(n)).pipe(ae(r.getDisplayAd))),
            w = n => {
                switch (u.silly("getFallbackAd", n), p.track(pn(n)), n.adKind) {
                    case "native":
                        {
                            switch (n.provider) {
                                case "fallback":
                                case "direct":
                                    return g();
                                case "coinzilla":
                                    return S({
                                        preferredAdKind: "native",
                                        screen: n.screen,
                                        provider: "coinzilla"
                                    }).pipe(ye(() => g()))
                            }
                            break
                        }
                    case "display":
                        return n.provider === "coinzilla" ? n.size === "responsive" ? D({
                            preferredAdKind: "display",
                            provider: "a-ads",
                            screen: n.screen,
                            size: {
                                width: 320,
                                height: 100
                            }
                        }).pipe(ye(() => g())) : D({
                            preferredAdKind: "display",
                            provider: "a-ads",
                            screen: n.screen,
                            size: n.size
                        }).pipe(ye(() => g())) : n.provider === "direct" || n.provider === "persona" || n.provider === "cointraffic" ? k({
                            preferredAdKind: "display",
                            provider: "coinzilla",
                            screen: n.screen,
                            size: n.size
                        }).pipe(ye(() => g())) : g()
                }
            },
            C = n => (u.silly("getAdByAdUnit", n), y(n).pipe(ye(() => w(n)), ae(a => a ? J(a) : w(n))));
        return {
            getAd: n => {
                u.silly("getAd", n);
                const a = v(n);
                return C(a)
            },
            getAdByAdUnit: C,
            getFallbackAd: w,
            hideAd: n => {
                const a = m.getValue();
                Nt(a, n) || (m.next([...a, n]), p.track(fn(n)))
            },
            notifyViewed: n => {
                switch (p.track(hn(n)), n.kind) {
                    case "native":
                        {
                            switch (n.provider) {
                                case "direct":
                                    return o.notifyViewed(n);
                                case "fallback":
                                case "coinzilla":
                                    return e.notifyViewed(n)
                            }
                            break
                        }
                    case "display":
                        switch (n.provider) {
                            case "direct":
                                return o.notifyViewed(n);
                            case "coinzilla":
                            case "google":
                            case "a-ads":
                            case "persona":
                            case "cointraffic":
                                return J(void 0)
                        }
                }
            },
            notifyHidden: n => (p.track(mn(n)), J(void 0)),
            findAdUnit: v,
            isAdLocationHidden: n => Bi(m, a => Nt(a, n))
        }
    });

function Nt(e, t) {
    return e.some(r => r.screen === t.screen)
}

function gr(e) {
    return e.size === "responsive" ? e.size : `${e.size.width}x${e.size.height}`
}

function pn(e) {
    switch (e.adKind) {
        case "native":
            {
                switch (e.provider) {
                    case "direct":
                    case "coinzilla":
                        return {
                            event: "adFallback",
                            data: {
                                adUnitKind: e.adKind,
                                adUnitScreen: e.screen,
                                adUnitID: e.id
                            }
                        };
                    case "fallback":
                        return {
                            event: "adFallback",
                            data: {
                                adUnitKind: e.adKind
                            }
                        }
                }
                break
            }
        case "display":
            return {
                event: "adFallback",
                data: {
                    adUnitKind: e.adKind,
                    adUnitScreen: e.screen,
                    adUnitID: e.id.toString(),
                    adUnitProvider: e.provider,
                    adUnitSize: gr(e)
                }
            }
    }
}

function hn(e) {
    switch (e.kind) {
        case "native":
            return {
                event: "adImpression",
                data: {
                    adKind: e.kind
                }
            };
        case "display":
            return {
                event: "adImpression",
                data: {
                    adKind: e.kind,
                    adUnitKind: e.adUnit.adKind,
                    adUnitScreen: e.adUnit.screen,
                    adUnitID: e.adUnit.id.toString(),
                    adUnitProvider: e.adUnit.provider,
                    adUnitSize: gr(e.adUnit)
                }
            }
    }
}

function fn(e) {
    switch (e.preferredAdKind) {
        case "native":
            return {
                event: "hideAd",
                data: {
                    kind: e.preferredAdKind,
                    screen: e.screen
                }
            };
        case "display":
            return {
                event: "hideAd",
                data: {
                    kind: e.preferredAdKind,
                    screen: e.screen,
                    provider: e.provider
                }
            }
    }
}

function mn(e) {
    switch (e.preferredAdKind) {
        case "native":
            return {
                event: "adHidden",
                data: {
                    kind: e.preferredAdKind,
                    screen: e.screen
                }
            };
        case "display":
            return {
                event: "adHidden",
                data: {
                    kind: e.preferredAdKind,
                    screen: e.screen,
                    provider: e.provider
                }
            }
    }
}
const vn = e => {
        const [t, r] = f.useState(() => e.getValue());
        return f.useEffect(() => {
            r(() => e.getValue());
            const i = e.subscribe(s => r(() => s));
            return () => i.unsubscribe()
        }, [e]), t
    },
    gn = _.enum(["idle", "loading", "ready", "error"]),
    xn = e => {
        const [t, r] = f.useState(e ? "loading" : "idle");
        return f.useEffect(() => {
            if (!e) {
                r("idle");
                return
            }
            let i = document.querySelector(`script[src='${e}']`);
            if (i) {
                const d = gn.safeParse(i.getAttribute("data-status"));
                d.success && r(d.data)
            } else {
                i = document.createElement("script"), i.src = e, i.async = !0, i.setAttribute("data-status", "loading"), document.body.appendChild(i);
                const d = p => {
                    i == null || i.setAttribute("data-status", p.type === "load" ? "ready" : "error")
                };
                i.addEventListener("load", d), i.addEventListener("error", d)
            }
            const s = d => {
                r(d.type === "load" ? "ready" : "error")
            };
            return i.addEventListener("load", s), i.addEventListener("error", s), () => {
                i && (i.removeEventListener("load", s), i.removeEventListener("error", s))
            }
        }, [e]), t
    };
var bn = Jr(function(t, r) {
    const i = Qr("Badge", t),
        {
            className: s,
            ...d
        } = ei(t);
    return l.jsx(ti.span, {
        ref: r,
        className: ri("chakra-badge", t.className),
        ...d,
        __css: {
            display: "inline-block",
            whiteSpace: "nowrap",
            verticalAlign: "middle",
            ...i
        }
    })
});
bn.displayName = "Badge";
const Es = e => f.createElement("svg", {
        id: "eyes",
        xmlns: "http://www.w3.org/2000/svg",
        xmlnsXlink: "http://www.w3.org/1999/xlink",
        x: "0px",
        y: "0px",
        viewBox: "0 0 128 128",
        style: {
            enableBackground: "new 0 0 128 128"
        },
        xmlSpace: "preserve",
        ...e
    }, f.createElement("g", null, f.createElement("g", null, f.createElement("g", null, f.createElement("g", null, f.createElement("path", {
        style: {
            fill: "#FAFAFA"
        },
        d: "M34.16,106.51C18.73,106.51,6.19,87.44,6.19,64c0-23.44,12.55-42.51,27.97-42.51 c15.42,0,27.97,19.07,27.97,42.51C62.13,87.44,49.58,106.51,34.16,106.51z"
    }), f.createElement("path", {
        style: {
            fill: "#B0BEC5"
        },
        d: "M34.16,23.49c6.63,0,12.98,4,17.87,11.27c5.22,7.75,8.1,18.14,8.1,29.24s-2.88,21.49-8.1,29.24 c-4.89,7.27-11.24,11.27-17.87,11.27s-12.98-4-17.87-11.27C11.06,85.49,8.19,75.1,8.19,64s2.88-21.49,8.1-29.24 C21.18,27.49,27.52,23.49,34.16,23.49 M34.16,19.49C17.61,19.49,4.19,39.42,4.19,64s13.42,44.51,29.97,44.51 S64.13,88.58,64.13,64S50.71,19.49,34.16,19.49L34.16,19.49z"
    })), f.createElement("linearGradient", {
        id: "emoji-u1f440-g1",
        gradientUnits: "userSpaceOnUse",
        x1: 22.5233,
        y1: 46.6759,
        x2: 22.5233,
        y2: 82.0828
    }, f.createElement("stop", {
        offset: 0,
        style: {
            stopColor: "#424242"
        }
    }), f.createElement("stop", {
        offset: 1,
        style: {
            stopColor: "#212121"
        }
    })), f.createElement("path", {
        style: {
            fill: "url(#emoji-u1f440-g1)"
        },
        d: "M25.63,59.84c-2.7-2.54-2.1-7.58,1.36-11.26c0.18-0.19,0.36-0.37,0.55-0.54 c-1.54-0.87-3.23-1.36-5.01-1.36c-7.19,0-13.02,7.93-13.02,17.7s5.83,17.7,13.02,17.7s13.02-7.93,13.02-17.7 c0-1.75-0.19-3.45-0.54-5.05C31.77,61.66,27.9,61.97,25.63,59.84z"
    }))), f.createElement("g", null, f.createElement("g", null, f.createElement("ellipse", {
        style: {
            fill: "#EEEEEE"
        },
        cx: 93.84,
        cy: 64,
        rx: 29.97,
        ry: 44.51
    }), f.createElement("g", null, f.createElement("path", {
        style: {
            fill: "#FAFAFA"
        },
        d: "M93.84,106.51c-15.42,0-27.97-19.07-27.97-42.51c0-23.44,12.55-42.51,27.97-42.51 c15.42,0,27.97,19.07,27.97,42.51C121.81,87.44,109.27,106.51,93.84,106.51z"
    }), f.createElement("path", {
        style: {
            fill: "#B0BEC5"
        },
        d: "M93.84,23.49c6.63,0,12.98,4,17.87,11.27c5.22,7.75,8.1,18.14,8.1,29.24s-2.88,21.49-8.1,29.24 c-4.89,7.27-11.24,11.27-17.87,11.27s-12.98-4-17.87-11.27c-5.22-7.75-8.1-18.14-8.1-29.24s2.88-21.49,8.1-29.24 C80.86,27.49,87.21,23.49,93.84,23.49 M93.84,19.49c-16.55,0-29.97,19.93-29.97,44.51s13.42,44.51,29.97,44.51 S123.81,88.58,123.81,64S110.39,19.49,93.84,19.49L93.84,19.49z"
    })), f.createElement("linearGradient", {
        id: "emoji-u1f440-g2",
        gradientUnits: "userSpaceOnUse",
        x1: 82.2093,
        y1: 46.6759,
        x2: 82.2093,
        y2: 82.0828
    }, f.createElement("stop", {
        offset: 0,
        style: {
            stopColor: "#424242"
        }
    }), f.createElement("stop", {
        offset: 1,
        style: {
            stopColor: "#212121"
        }
    })), f.createElement("path", {
        style: {
            fill: "url(#emoji-u1f440-g2)"
        },
        d: "M85.31,59.84c-2.7-2.54-2.1-7.58,1.36-11.26c0.18-0.19,0.36-0.37,0.55-0.54 c-1.54-0.87-3.23-1.36-5.01-1.36c-7.19,0-13.02,7.93-13.02,17.7s5.83,17.7,13.02,17.7c7.19,0,13.02-7.93,13.02-17.7 c0-1.75-0.19-3.45-0.54-5.05C91.46,61.66,87.58,61.97,85.31,59.84z"
    }))))),
    ot = "@dexscreener/postmessage-bus/user-message",
    yn = _.object({
        data: _.unknown(),
        origin: _.string(),
        source: _.unknown()
    }),
    Oe = "@dexscreener/postmessage-bus/handshake",
    Kt = "@dexscreener/postmessage-bus/acknowledge",
    wn = _.object({
        [ot]: _.unknown()
    }),
    kn = e => {
        function t(w) {
            return w.receiver.postMessage(w.message, "*")
        }
        const {
            receiver: r,
            incomingSchema: i,
            outgoingSchema: s,
            sender: d
        } = e, p = e.logger.getChildLogger({
            name: e.name ? ? "PostMessageBus"
        }), o = [], h = new ii;
        let c = r,
            u = !1,
            m = !1;

        function v() {
            m = !0, d.removeEventListener("message", k), o.length = 0, c = void 0, h.complete()
        }

        function y() {
            c = void 0, u = !1
        }

        function g(w) {
            return u = !1, m || (c = w, c && t({
                receiver: c,
                message: Oe
            })), {
                dispose: y
            }
        }

        function S(w) {
            const C = {
                [ot]: s.parse(w)
            };
            if (c)
                if (u) {
                    t({
                        receiver: c,
                        message: C
                    });
                    return
                } else {
                    o.push(C), t({
                        receiver: c,
                        message: Oe
                    });
                    return
                }
            else {
                o.push(C);
                return
            }
        }

        function D(w) {
            for (const C of o) t({
                receiver: w,
                message: C
            });
            o.length = 0
        }

        function k(w) {
            if (!c) return;
            const C = yn.safeParse(w);
            if (!C.success || c !== C.data.source) return;
            const {
                data: {
                    data: n
                }
            } = C;
            if (n === Oe) {
                u = !0, t({
                    receiver: c,
                    message: Kt
                }), D(c);
                return
            } else if (n === Kt) {
                u = !0, D(c);
                return
            }
            const a = wn.safeParse(n);
            if (a.success) {
                const {
                    [ot]: A
                } = a.data;
                if (i !== void 0) {
                    const x = i.safeParse(A);
                    x.success ? h.next(x.data) : p.warn("Cannot parse incoming message", x.error, A)
                }
            }
        }
        return d.addEventListener("message", k), c && t({
            receiver: c,
            message: Oe
        }), {
            emit: S,
            message: h,
            setReceiver: g,
            dispose: v
        }
    },
    xr = f.memo(e => {
        const {
            onHide: t,
            width: r,
            contentWidth: i,
            height: s,
            src: d,
            isShown: p
        } = e, o = de(ct), [h, c] = f.useState(!0), u = f.useMemo(() => kn({
            logger: o,
            sender: window,
            incomingSchema: Gi,
            outgoingSchema: _.never()
        }), [o]);
        f.useEffect(() => () => u == null ? void 0 : u.dispose(), [u]);
        const m = f.useRef(null);
        f.useEffect(() => {
            var y;
            !p || !((y = m.current) != null && y.contentWindow) || !u || u.setReceiver(m.current.contentWindow)
        }, [u, p]);
        const v = Q(e);
        return f.useEffect(() => {
            if (!p) return;
            let y;
            const g = u == null ? void 0 : u.message.subscribe({
                next: S => {
                    switch (clearTimeout(y), S.kind) {
                        case "ready":
                            {
                                c(!1);
                                break
                            }
                        case "error":
                            {
                                v.current.onFallbackRequest();
                                break
                            }
                    }
                },
                error: () => {
                    clearTimeout(y), v.current.onFallbackRequest()
                }
            });
            return y = setTimeout(() => {
                g == null || g.unsubscribe(), v.current.onFallbackRequest()
            }, 5e3), () => {
                g == null || g.unsubscribe(), clearTimeout(y)
            }
        }, [u == null ? void 0 : u.message, p, v]), l.jsx(et, {
            contentWidth: i,
            width: r,
            height: s,
            onHide: t,
            isLoaded: !h,
            children: p && l.jsx(ft, {
                ref: m,
                src: d,
                width: "100%",
                height: "100%"
            })
        })
    }),
    Cn = lt(),
    qt = f.memo(function(t) {
        const {
            onHide: r,
            width: i,
            adUnit: s,
            height: d,
            isShown: p
        } = t, o = de(Cn), h = f.useMemo(() => {
            const m = new URL(o.DS_WEB_ADS_PAGES_PUBLIC_ORIGIN);
            return m.pathname = "/cointraffic", m.searchParams.set("id", s.id), m
        }, [s.id, o.DS_WEB_ADS_PAGES_PUBLIC_ORIGIN]), c = Q(t), u = f.useCallback(() => c.current.onFallbackRequest(c.current.adUnit), [c]);
        return l.jsx(xr, {
            isShown: p,
            contentWidth: `${s.size.width}px`,
            width: i,
            height: d,
            onHide: r,
            src: h.toString(),
            onFallbackRequest: u
        })
    }),
    Ot = f.memo(e => {
        const {
            height: t,
            width: r,
            onHide: i,
            ad: s,
            onView: d
        } = e, p = Q(s), o = f.useCallback(() => {
            p.current && d(p.current)
        }, [p, d]);
        return l.jsx(et, {
            contentWidth: s ? s.adUnit.size === "responsive" ? "100%" : `${s.adUnit.size.width}px` : void 0,
            width: r,
            height: t,
            onHide: i,
            isLoaded: !!s,
            advertiseLink: "https://docs.dexscreener.com/contact-us/advertise",
            children: s && l.jsx(ft, {
                onLoad: o,
                id: `zone-${s.adUnit.id}`,
                width: "100%",
                height: "100%",
                src: s.iframeURL
            })
        })
    }),
    Vt = f.memo(e => {
        const {
            height: t,
            onHide: r,
            ad: i,
            width: s,
            onView: d,
            onFallbackRequest: p,
            adUnit: o
        } = e, h = Q(i), [c, u] = f.useState(!1), m = f.useCallback(() => {
            h.current && (u(!0), d(h.current))
        }, [h, d]), v = f.useCallback(() => {
            p(o)
        }, [o, p]);
        return l.jsx(et, {
            contentWidth: i ? An(i.adUnit) : void 0,
            width: s,
            height: t,
            onHide: r,
            isLoaded: c,
            children: i && l.jsxs(Re, {
                href: i.url,
                target: "_blank",
                rel: "noopener noreferrer nofollow",
                children: [i.source === "image" && l.jsx(Je, {
                    src: i.src,
                    onLoad: m,
                    onError: v,
                    loading: "lazy"
                }), i.source === "iframe" && l.jsx(ft, {
                    style: {
                        pointerEvents: "none"
                    },
                    onLoad: m,
                    onError: v,
                    width: "100%",
                    height: "100%",
                    src: i.src
                })]
            })
        })
    });

function An(e) {
    return e.size === "responsive" ? "100%" : `${e.size.width}px`
}
window.googletag = window.googletag || {
    cmd: []
};
const $t = f.memo(e => {
        const {
            height: t,
            width: r,
            adUnit: i,
            onFallbackRequest: s,
            onHide: d,
            isShown: p,
            ad: o,
            onView: h
        } = e, c = de(ct), u = Q(o), m = xn(p ? "https://securepubads.g.doubleclick.net/tag/js/gpt.js" : void 0);
        f.useEffect(() => {
            m === "error" && (c.error({
                event: {
                    id: "failedToLoadGPTScript"
                }
            }), s(i))
        }, [i, c, s, m]);
        const v = f.useId(),
            y = f.useRef(!1),
            [g, S] = f.useState(!1),
            D = f.useRef(),
            k = f.useRef(),
            w = f.useRef(p);
        return f.useEffect(() => {
            if (clearTimeout(k.current), !p) return;
            w.current = !0, k.current = setTimeout(() => {
                googletag.cmd.push(() => {
                    googletag.pubads().removeEventListener("slotRenderEnded", C)
                }), y.current || (y.current = !0, s(i))
            }, 5e3);

            function C(n) {
                if (n.slot === D.current) {
                    if (clearTimeout(k.current), y.current) return;
                    n.isEmpty ? s(i) : (S(!0), u.current && h(u.current))
                }
            }
            return S(!1), googletag.cmd.push(() => {
                var n;
                try {
                    if (y.current) return;
                    D.current && (googletag.destroySlots([D.current]), D.current = void 0);
                    const a = googletag.pubads();
                    a.addEventListener("slotRenderEnded", C), D.current = (n = googletag.defineSlot(i.id, i.size === "responsive" ? "fluid" : [i.size.width, i.size.height], v)) == null ? void 0 : n.addService(a), googletag.enableServices(), googletag.display(v)
                } catch (a) {
                    c.error({
                        event: {
                            id: "failedToRenderGoogleAd",
                            data: {
                                error: a
                            }
                        }
                    }), s(i)
                }
            }), () => {
                clearTimeout(k.current), w.current && googletag.cmd.push(() => {
                    try {
                        googletag.pubads().removeEventListener("slotRenderEnded", C), D.current && (googletag.destroySlots([D.current]), D.current = void 0)
                    } catch (n) {
                        c.error({
                            event: {
                                id: "failedToDestroyGoogleAd",
                                data: {
                                    error: n
                                }
                            }
                        })
                    }
                })
            }
        }, [p, i, v, c, s, D, u, h]), f.useEffect(() => () => {
            y.current = !0
        }, []), l.jsx(et, {
            contentWidth: "100%",
            width: r,
            height: t,
            onHide: d,
            isLoaded: g,
            children: l.jsx(H, {
                width: "100%",
                height: "100%",
                id: v
            })
        })
    }),
    Sn = lt(),
    Gt = f.memo(function(t) {
        const {
            onHide: r,
            width: i,
            adUnit: s,
            height: d,
            isShown: p
        } = t, o = de(Sn), h = f.useMemo(() => {
            const m = new URL(o.DS_WEB_ADS_PAGES_PUBLIC_ORIGIN);
            return m.pathname = "/persona", m.searchParams.set("ad-unit-id", s.id), m
        }, [s.id, o.DS_WEB_ADS_PAGES_PUBLIC_ORIGIN]), c = Q(t), u = f.useCallback(() => c.current.onFallbackRequest(c.current.adUnit), [c]);
        return l.jsx(xr, {
            isShown: p,
            contentWidth: `${s.size.width}px`,
            width: i,
            height: d,
            onHide: r,
            src: h.toString(),
            onFallbackRequest: u
        })
    });
var br = {
        exports: {}
    },
    Dn = br.exports = {};
Dn.forEach = function(e, t) {
    for (var r = 0; r < e.length; r++) {
        var i = t(e[r]);
        if (i) return i
    }
};
var yr = br.exports,
    En = function(e) {
        var t = e.stateHandler.getState;

        function r(p) {
            var o = t(p);
            return o && !!o.isDetectable
        }

        function i(p) {
            t(p).isDetectable = !0
        }

        function s(p) {
            return !!t(p).busy
        }

        function d(p, o) {
            t(p).busy = !!o
        }
        return {
            isDetectable: r,
            markAsDetectable: i,
            isBusy: s,
            markBusy: d
        }
    },
    Ln = function(e) {
        var t = {};

        function r(p) {
            var o = e.get(p);
            return o === void 0 ? [] : t[o] || []
        }

        function i(p, o) {
            var h = e.get(p);
            t[h] || (t[h] = []), t[h].push(o)
        }

        function s(p, o) {
            for (var h = r(p), c = 0, u = h.length; c < u; ++c)
                if (h[c] === o) {
                    h.splice(c, 1);
                    break
                }
        }

        function d(p) {
            var o = r(p);
            o && (o.length = 0)
        }
        return {
            get: r,
            add: i,
            removeListener: s,
            removeAllListeners: d
        }
    },
    In = function() {
        var e = 1;

        function t() {
            return e++
        }
        return {
            generate: t
        }
    },
    Tn = function(e) {
        var t = e.idGenerator,
            r = e.stateHandler.getState;

        function i(d) {
            var p = r(d);
            return p && p.id !== void 0 ? p.id : null
        }

        function s(d) {
            var p = r(d);
            if (!p) throw new Error("setId required the element to have a resize detection state.");
            var o = t.generate();
            return p.id = o, o
        }
        return {
            get: i,
            set: s
        }
    },
    Un = function(e) {
        function t() {}
        var r = {
            log: t,
            warn: t,
            error: t
        };
        if (!e && window.console) {
            var i = function(s, d) {
                s[d] = function() {
                    var o = console[d];
                    if (o.apply) o.apply(console, arguments);
                    else
                        for (var h = 0; h < arguments.length; h++) o(arguments[h])
                }
            };
            i(r, "log"), i(r, "warn"), i(r, "error")
        }
        return r
    },
    wr = {
        exports: {}
    },
    kr = wr.exports = {};
kr.isIE = function(e) {
    function t() {
        var i = navigator.userAgent.toLowerCase();
        return i.indexOf("msie") !== -1 || i.indexOf("trident") !== -1 || i.indexOf(" edge/") !== -1
    }
    if (!t()) return !1;
    if (!e) return !0;
    var r = function() {
        var i, s = 3,
            d = document.createElement("div"),
            p = d.getElementsByTagName("i");
        do d.innerHTML = "<!--[if gt IE " + ++s + "]><i></i><![endif]-->"; while (p[0]);
        return s > 4 ? s : i
    }();
    return e === r
};
kr.isLegacyOpera = function() {
    return !!window.opera
};
var Cr = wr.exports,
    Ar = {
        exports: {}
    },
    Rn = Ar.exports = {};
Rn.getOption = zn;

function zn(e, t, r) {
    var i = e[t];
    return i == null && r !== void 0 ? r : i
}
var Pn = Ar.exports,
    Zt = Pn,
    jn = function(t) {
        t = t || {};
        var r = t.reporter,
            i = Zt.getOption(t, "async", !0),
            s = Zt.getOption(t, "auto", !0);
        s && !i && (r && r.warn("Invalid options combination. auto=true and async=false is invalid. Setting async=true."), i = !0);
        var d = Yt(),
            p, o = !1;

        function h(g, S) {
            !o && s && i && d.size() === 0 && m(), d.add(g, S)
        }

        function c() {
            for (o = !0; d.size();) {
                var g = d;
                d = Yt(), g.process()
            }
            o = !1
        }

        function u(g) {
            o || (g === void 0 && (g = i), p && (v(p), p = null), g ? m() : c())
        }

        function m() {
            p = y(c)
        }

        function v(g) {
            var S = clearTimeout;
            return S(g)
        }

        function y(g) {
            var S = function(D) {
                return setTimeout(D, 0)
            };
            return S(g)
        }
        return {
            add: h,
            force: u
        }
    };

function Yt() {
    var e = {},
        t = 0,
        r = 0,
        i = 0;

    function s(o, h) {
        h || (h = o, o = 0), o > r ? r = o : o < i && (i = o), e[o] || (e[o] = []), e[o].push(h), t++
    }

    function d() {
        for (var o = i; o <= r; o++)
            for (var h = e[o], c = 0; c < h.length; c++) {
                var u = h[c];
                u()
            }
    }

    function p() {
        return t
    }
    return {
        add: s,
        process: d,
        size: p
    }
}
var vt = "_erd";

function Fn(e) {
    return e[vt] = {}, Sr(e)
}

function Sr(e) {
    return e[vt]
}

function Hn(e) {
    delete e[vt]
}
var Mn = {
        initState: Fn,
        getState: Sr,
        cleanState: Hn
    },
    we = Cr,
    _n = function(e) {
        e = e || {};
        var t = e.reporter,
            r = e.batchProcessor,
            i = e.stateHandler.getState;
        if (!t) throw new Error("Missing required dependency: reporter.");

        function s(c, u) {
            function m() {
                u(c)
            }
            if (we.isIE(8)) i(c).object = {
                proxy: m
            }, c.attachEvent("onresize", m);
            else {
                var v = o(c);
                if (!v) throw new Error("Element is not detectable by this strategy.");
                v.contentDocument.defaultView.addEventListener("resize", m)
            }
        }

        function d(c) {
            var u = e.important ? " !important; " : "; ";
            return (c.join(u) + u).trim()
        }

        function p(c, u, m) {
            m || (m = u, u = c, c = null), c = c || {};

            function v(y, g) {
                var S = d(["display: block", "position: absolute", "top: 0", "left: 0", "width: 100%", "height: 100%", "border: none", "padding: 0", "margin: 0", "opacity: 0", "z-index: -1000", "pointer-events: none"]),
                    D = !1,
                    k = window.getComputedStyle(y),
                    w = y.offsetWidth,
                    C = y.offsetHeight;
                i(y).startSize = {
                    width: w,
                    height: C
                };

                function n() {
                    function a() {
                        if (k.position === "static") {
                            y.style.setProperty("position", "relative", c.important ? "important" : "");
                            var z = function(M, U, F, E) {
                                function T(W) {
                                    return W.replace(/[^-\d\.]/g, "")
                                }
                                var N = F[E];
                                N !== "auto" && T(N) !== "0" && (M.warn("An element that is positioned static has style." + E + "=" + N + " which is ignored due to the static positioning. The element will need to be positioned relative, so the style." + E + " will be set to 0. Element: ", U), U.style.setProperty(E, "0", c.important ? "important" : ""))
                            };
                            z(t, y, k, "top"), z(t, y, k, "right"), z(t, y, k, "bottom"), z(t, y, k, "left")
                        }
                    }

                    function A() {
                        D || a();

                        function z(U, F) {
                            if (!U.contentDocument) {
                                var E = i(U);
                                E.checkForObjectDocumentTimeoutId && window.clearTimeout(E.checkForObjectDocumentTimeoutId), E.checkForObjectDocumentTimeoutId = setTimeout(function() {
                                    E.checkForObjectDocumentTimeoutId = 0, z(U, F)
                                }, 100);
                                return
                            }
                            F(U.contentDocument)
                        }
                        var M = this;
                        z(M, function(F) {
                            g(y)
                        })
                    }
                    k.position !== "" && (a(), D = !0);
                    var x = document.createElement("object");
                    x.style.cssText = S, x.tabIndex = -1, x.type = "text/html", x.setAttribute("aria-hidden", "true"), x.onload = A, we.isIE() || (x.data = "about:blank"), i(y) && (y.appendChild(x), i(y).object = x, we.isIE() && (x.data = "about:blank"))
                }
                r ? r.add(n) : n()
            }
            we.isIE(8) ? m(u) : v(u, m)
        }

        function o(c) {
            return i(c).object
        }

        function h(c) {
            if (i(c)) {
                var u = o(c);
                u && (we.isIE(8) ? c.detachEvent("onresize", u.proxy) : c.removeChild(u), i(c).checkForObjectDocumentTimeoutId && window.clearTimeout(i(c).checkForObjectDocumentTimeoutId), delete i(c).object)
            }
        }
        return {
            makeDetectable: p,
            addListener: s,
            uninstall: h
        }
    },
    Wn = yr.forEach,
    Bn = function(e) {
        e = e || {};
        var t = e.reporter,
            r = e.batchProcessor,
            i = e.stateHandler.getState,
            s = e.idHandler;
        if (!r) throw new Error("Missing required dependency: batchProcessor");
        if (!t) throw new Error("Missing required dependency: reporter.");
        var d = u(),
            p = "erd_scroll_detection_scrollbar_style",
            o = "erd_scroll_detection_container";

        function h(n) {
            m(n, p, o)
        }
        h(window.document);

        function c(n) {
            var a = e.important ? " !important; " : "; ";
            return (n.join(a) + a).trim()
        }

        function u() {
            var n = 500,
                a = 500,
                A = document.createElement("div");
            A.style.cssText = c(["position: absolute", "width: " + n * 2 + "px", "height: " + a * 2 + "px", "visibility: hidden", "margin: 0", "padding: 0"]);
            var x = document.createElement("div");
            x.style.cssText = c(["position: absolute", "width: " + n + "px", "height: " + a + "px", "overflow: scroll", "visibility: none", "top: " + -n * 3 + "px", "left: " + -a * 3 + "px", "visibility: hidden", "margin: 0", "padding: 0"]), x.appendChild(A), document.body.insertBefore(x, document.body.firstChild);
            var z = n - x.clientWidth,
                M = a - x.clientHeight;
            return document.body.removeChild(x), {
                width: z,
                height: M
            }
        }

        function m(n, a, A) {
            function x(F, E) {
                E = E || function(N) {
                    n.head.appendChild(N)
                };
                var T = n.createElement("style");
                return T.innerHTML = F, T.id = a, E(T), T
            }
            if (!n.getElementById(a)) {
                var z = A + "_animation",
                    M = A + "_animation_active",
                    U = `/* Created by the element-resize-detector library. */
`;
                U += "." + A + " > div::-webkit-scrollbar { " + c(["display: none"]) + ` }

`, U += "." + M + " { " + c(["-webkit-animation-duration: 0.1s", "animation-duration: 0.1s", "-webkit-animation-name: " + z, "animation-name: " + z]) + ` }
`, U += "@-webkit-keyframes " + z + ` { 0% { opacity: 1; } 50% { opacity: 0; } 100% { opacity: 1; } }
`, U += "@keyframes " + z + " { 0% { opacity: 1; } 50% { opacity: 0; } 100% { opacity: 1; } }", x(U)
            }
        }

        function v(n) {
            n.className += " " + o + "_animation_active"
        }

        function y(n, a, A) {
            if (n.addEventListener) n.addEventListener(a, A);
            else if (n.attachEvent) n.attachEvent("on" + a, A);
            else return t.error("[scroll] Don't know how to add event listeners.")
        }

        function g(n, a, A) {
            if (n.removeEventListener) n.removeEventListener(a, A);
            else if (n.detachEvent) n.detachEvent("on" + a, A);
            else return t.error("[scroll] Don't know how to remove event listeners.")
        }

        function S(n) {
            return i(n).container.childNodes[0].childNodes[0].childNodes[0]
        }

        function D(n) {
            return i(n).container.childNodes[0].childNodes[0].childNodes[1]
        }

        function k(n, a) {
            var A = i(n).listeners;
            if (!A.push) throw new Error("Cannot add listener to an element that is not detectable.");
            i(n).listeners.push(a)
        }

        function w(n, a, A) {
            A || (A = a, a = n, n = null), n = n || {};

            function x() {
                if (n.debug) {
                    var b = Array.prototype.slice.call(arguments);
                    if (b.unshift(s.get(a), "Scroll: "), t.log.apply) t.log.apply(null, b);
                    else
                        for (var L = 0; L < b.length; L++) t.log(b[L])
                }
            }

            function z(b) {
                function L(R) {
                    var $ = R.getRootNode && R.getRootNode().contains(R);
                    return R === R.ownerDocument.body || R.ownerDocument.body.contains(R) || $
                }
                return !L(b) || window.getComputedStyle(b) === null
            }

            function M(b) {
                var L = i(b).container.childNodes[0],
                    R = window.getComputedStyle(L);
                return !R.width || R.width.indexOf("px") === -1
            }

            function U() {
                var b = window.getComputedStyle(a),
                    L = {};
                return L.position = b.position, L.width = a.offsetWidth, L.height = a.offsetHeight, L.top = b.top, L.right = b.right, L.bottom = b.bottom, L.left = b.left, L.widthCSS = b.width, L.heightCSS = b.height, L
            }

            function F() {
                var b = U();
                i(a).startSize = {
                    width: b.width,
                    height: b.height
                }, x("Element start size", i(a).startSize)
            }

            function E() {
                i(a).listeners = []
            }

            function T() {
                if (x("storeStyle invoked."), !i(a)) {
                    x("Aborting because element has been uninstalled");
                    return
                }
                var b = U();
                i(a).style = b
            }

            function N(b, L, R) {
                i(b).lastWidth = L, i(b).lastHeight = R
            }

            function W(b) {
                return S(b).childNodes[0]
            }

            function re() {
                return 2 * d.width + 1
            }

            function We() {
                return 2 * d.height + 1
            }

            function Be(b) {
                return b + 10 + re()
            }

            function Ne(b) {
                return b + 10 + We()
            }

            function Dr(b) {
                return b * 2 + re()
            }

            function Er(b) {
                return b * 2 + We()
            }

            function bt(b, L, R) {
                var $ = S(b),
                    ie = D(b),
                    le = Be(L),
                    ue = Ne(R),
                    B = Dr(L),
                    I = Er(R);
                $.scrollLeft = le, $.scrollTop = ue, ie.scrollLeft = B, ie.scrollTop = I
            }

            function yt() {
                var b = i(a).container;
                if (!b) {
                    b = document.createElement("div"), b.className = o, b.style.cssText = c(["visibility: hidden", "display: inline", "width: 0px", "height: 0px", "z-index: -1", "overflow: hidden", "margin: 0", "padding: 0"]), i(a).container = b, v(b), a.appendChild(b);
                    var L = function() {
                        i(a).onRendered && i(a).onRendered()
                    };
                    y(b, "animationstart", L), i(a).onAnimationStart = L
                }
                return b
            }

            function Lr() {
                function b() {
                    var P = i(a).style;
                    if (P.position === "static") {
                        a.style.setProperty("position", "relative", n.important ? "important" : "");
                        var X = function(he, se, Rr, qe) {
                            function zr(Pr) {
                                return Pr.replace(/[^-\d\.]/g, "")
                            }
                            var rt = Rr[qe];
                            rt !== "auto" && zr(rt) !== "0" && (he.warn("An element that is positioned static has style." + qe + "=" + rt + " which is ignored due to the static positioning. The element will need to be positioned relative, so the style." + qe + " will be set to 0. Element: ", se), se.style[qe] = 0)
                        };
                        X(t, a, P, "top"), X(t, a, P, "right"), X(t, a, P, "bottom"), X(t, a, P, "left")
                    }
                }

                function L(P, X, he, se) {
                    return P = P ? P + "px" : "0", X = X ? X + "px" : "0", he = he ? he + "px" : "0", se = se ? se + "px" : "0", ["left: " + P, "top: " + X, "right: " + se, "bottom: " + he]
                }
                if (x("Injecting elements"), !i(a)) {
                    x("Aborting because element has been uninstalled");
                    return
                }
                b();
                var R = i(a).container;
                R || (R = yt());
                var $ = d.width,
                    ie = d.height,
                    le = c(["position: absolute", "flex: none", "overflow: hidden", "z-index: -1", "visibility: hidden", "width: 100%", "height: 100%", "left: 0px", "top: 0px"]),
                    ue = c(["position: absolute", "flex: none", "overflow: hidden", "z-index: -1", "visibility: hidden"].concat(L(-(1 + $), -(1 + ie), -ie, -$))),
                    B = c(["position: absolute", "flex: none", "overflow: scroll", "z-index: -1", "visibility: hidden", "width: 100%", "height: 100%"]),
                    I = c(["position: absolute", "flex: none", "overflow: scroll", "z-index: -1", "visibility: hidden", "width: 100%", "height: 100%"]),
                    K = c(["position: absolute", "left: 0", "top: 0"]),
                    ne = c(["position: absolute", "width: 200%", "height: 200%"]),
                    Z = document.createElement("div"),
                    Y = document.createElement("div"),
                    pe = document.createElement("div"),
                    kt = document.createElement("div"),
                    Ke = document.createElement("div"),
                    Ct = document.createElement("div");
                Z.dir = "ltr", Z.style.cssText = le, Z.className = o, Y.className = o, Y.style.cssText = ue, pe.style.cssText = B, kt.style.cssText = K, Ke.style.cssText = I, Ct.style.cssText = ne, pe.appendChild(kt), Ke.appendChild(Ct), Y.appendChild(pe), Y.appendChild(Ke), Z.appendChild(Y), R.appendChild(Z);

                function At() {
                    var P = i(a);
                    P && P.onExpand ? P.onExpand() : x("Aborting expand scroll handler: element has been uninstalled")
                }

                function St() {
                    var P = i(a);
                    P && P.onShrink ? P.onShrink() : x("Aborting shrink scroll handler: element has been uninstalled")
                }
                y(pe, "scroll", At), y(Ke, "scroll", St), i(a).onExpandScroll = At, i(a).onShrinkScroll = St
            }

            function Ir() {
                function b(B, I, K) {
                    var ne = W(B),
                        Z = Be(I),
                        Y = Ne(K);
                    ne.style.setProperty("width", Z + "px", n.important ? "important" : ""), ne.style.setProperty("height", Y + "px", n.important ? "important" : "")
                }

                function L(B) {
                    var I = a.offsetWidth,
                        K = a.offsetHeight,
                        ne = I !== i(a).lastWidth || K !== i(a).lastHeight;
                    x("Storing current size", I, K), N(a, I, K), r.add(0, function() {
                        if (ne) {
                            if (!i(a)) {
                                x("Aborting because element has been uninstalled");
                                return
                            }
                            if (!R()) {
                                x("Aborting because element container has not been initialized");
                                return
                            }
                            if (n.debug) {
                                var Y = a.offsetWidth,
                                    pe = a.offsetHeight;
                                (Y !== I || pe !== K) && t.warn(s.get(a), "Scroll: Size changed before updating detector elements.")
                            }
                            b(a, I, K)
                        }
                    }), r.add(1, function() {
                        if (!i(a)) {
                            x("Aborting because element has been uninstalled");
                            return
                        }
                        if (!R()) {
                            x("Aborting because element container has not been initialized");
                            return
                        }
                        bt(a, I, K)
                    }), ne && B && r.add(2, function() {
                        if (!i(a)) {
                            x("Aborting because element has been uninstalled");
                            return
                        }
                        if (!R()) {
                            x("Aborting because element container has not been initialized");
                            return
                        }
                        B()
                    })
                }

                function R() {
                    return !!i(a).container
                }

                function $() {
                    function B() {
                        return i(a).lastNotifiedWidth === void 0
                    }
                    x("notifyListenersIfNeeded invoked");
                    var I = i(a);
                    if (B() && I.lastWidth === I.startSize.width && I.lastHeight === I.startSize.height) return x("Not notifying: Size is the same as the start size, and there has been no notification yet.");
                    if (I.lastWidth === I.lastNotifiedWidth && I.lastHeight === I.lastNotifiedHeight) return x("Not notifying: Size already notified");
                    x("Current size not notified, notifying..."), I.lastNotifiedWidth = I.lastWidth, I.lastNotifiedHeight = I.lastHeight, Wn(i(a).listeners, function(K) {
                        K(a)
                    })
                }

                function ie() {
                    if (x("startanimation triggered."), M(a)) {
                        x("Ignoring since element is still unrendered...");
                        return
                    }
                    x("Element rendered.");
                    var B = S(a),
                        I = D(a);
                    (B.scrollLeft === 0 || B.scrollTop === 0 || I.scrollLeft === 0 || I.scrollTop === 0) && (x("Scrollbars out of sync. Updating detector elements..."), L($))
                }

                function le() {
                    if (x("Scroll detected."), M(a)) {
                        x("Scroll event fired while unrendered. Ignoring...");
                        return
                    }
                    L($)
                }
                if (x("registerListenersAndPositionElements invoked."), !i(a)) {
                    x("Aborting because element has been uninstalled");
                    return
                }
                i(a).onRendered = ie, i(a).onExpand = le, i(a).onShrink = le;
                var ue = i(a).style;
                b(a, ue.width, ue.height)
            }

            function Tr() {
                if (x("finalizeDomMutation invoked."), !i(a)) {
                    x("Aborting because element has been uninstalled");
                    return
                }
                var b = i(a).style;
                N(a, b.width, b.height), bt(a, b.width, b.height)
            }

            function Ur() {
                A(a)
            }

            function wt() {
                x("Installing..."), E(), F(), r.add(0, T), r.add(1, Lr), r.add(2, Ir), r.add(3, Tr), r.add(4, Ur)
            }
            x("Making detectable..."), z(a) ? (x("Element is detached"), yt(), x("Waiting until element is attached..."), i(a).onRendered = function() {
                x("Element is now attached"), wt()
            }) : wt()
        }

        function C(n) {
            var a = i(n);
            a && (a.onExpandScroll && g(S(n), "scroll", a.onExpandScroll), a.onShrinkScroll && g(D(n), "scroll", a.onShrinkScroll), a.onAnimationStart && g(a.container, "animationstart", a.onAnimationStart), a.container && n.removeChild(a.container))
        }
        return {
            makeDetectable: w,
            addListener: k,
            uninstall: C,
            initDocument: h
        }
    },
    Ue = yr.forEach,
    Nn = En,
    Kn = Ln,
    qn = In,
    On = Tn,
    Vn = Un,
    Xt = Cr,
    $n = jn,
    ee = Mn,
    Gn = _n,
    Zn = Bn;

function Jt(e) {
    return Array.isArray(e) || e.length !== void 0
}

function Qt(e) {
    if (Array.isArray(e)) return e;
    var t = [];
    return Ue(e, function(r) {
        t.push(r)
    }), t
}

function er(e) {
    return e && e.nodeType === 1
}
var Yn = function(e) {
    e = e || {};
    var t;
    if (e.idHandler) t = {
        get: function(w) {
            return e.idHandler.get(w, !0)
        },
        set: e.idHandler.set
    };
    else {
        var r = qn(),
            i = On({
                idGenerator: r,
                stateHandler: ee
            });
        t = i
    }
    var s = e.reporter;
    if (!s) {
        var d = s === !1;
        s = Vn(d)
    }
    var p = te(e, "batchProcessor", $n({
            reporter: s
        })),
        o = {};
    o.callOnAdd = !!te(e, "callOnAdd", !0), o.debug = !!te(e, "debug", !1);
    var h = Kn(t),
        c = Nn({
            stateHandler: ee
        }),
        u, m = te(e, "strategy", "object"),
        v = te(e, "important", !1),
        y = {
            reporter: s,
            batchProcessor: p,
            stateHandler: ee,
            idHandler: t,
            important: v
        };
    if (m === "scroll" && (Xt.isLegacyOpera() ? (s.warn("Scroll strategy is not supported on legacy Opera. Changing to object strategy."), m = "object") : Xt.isIE(9) && (s.warn("Scroll strategy is not supported on IE9. Changing to object strategy."), m = "object")), m === "scroll") u = Zn(y);
    else if (m === "object") u = Gn(y);
    else throw new Error("Invalid strategy name: " + m);
    var g = {};

    function S(w, C, n) {
        function a(F) {
            var E = h.get(F);
            Ue(E, function(N) {
                N(F)
            })
        }

        function A(F, E, T) {
            h.add(E, T), F && T(E)
        }
        if (n || (n = C, C = w, w = {}), !C) throw new Error("At least one element required.");
        if (!n) throw new Error("Listener required.");
        if (er(C)) C = [C];
        else if (Jt(C)) C = Qt(C);
        else return s.error("Invalid arguments. Must be a DOM element or a collection of DOM elements.");
        var x = 0,
            z = te(w, "callOnAdd", o.callOnAdd),
            M = te(w, "onReady", function() {}),
            U = te(w, "debug", o.debug);
        Ue(C, function(E) {
            ee.getState(E) || (ee.initState(E), t.set(E));
            var T = t.get(E);
            if (U && s.log("Attaching listener to element", T, E), !c.isDetectable(E)) {
                if (U && s.log(T, "Not detectable."), c.isBusy(E)) {
                    U && s.log(T, "System busy making it detectable"), A(z, E, n), g[T] = g[T] || [], g[T].push(function() {
                        x++, x === C.length && M()
                    });
                    return
                }
                return U && s.log(T, "Making detectable..."), c.markBusy(E, !0), u.makeDetectable({
                    debug: U,
                    important: v
                }, E, function(W) {
                    if (U && s.log(T, "onElementDetectable"), ee.getState(W)) {
                        c.markAsDetectable(W), c.markBusy(W, !1), u.addListener(W, a), A(z, W, n);
                        var re = ee.getState(W);
                        if (re && re.startSize) {
                            var We = W.offsetWidth,
                                Be = W.offsetHeight;
                            (re.startSize.width !== We || re.startSize.height !== Be) && a(W)
                        }
                        g[T] && Ue(g[T], function(Ne) {
                            Ne()
                        })
                    } else U && s.log(T, "Element uninstalled before being detectable.");
                    delete g[T], x++, x === C.length && M()
                })
            }
            U && s.log(T, "Already detecable, adding listener."), A(z, E, n), x++
        }), x === C.length && M()
    }

    function D(w) {
        if (!w) return s.error("At least one element is required.");
        if (er(w)) w = [w];
        else if (Jt(w)) w = Qt(w);
        else return s.error("Invalid arguments. Must be a DOM element or a collection of DOM elements.");
        Ue(w, function(C) {
            h.removeAllListeners(C), u.uninstall(C), ee.cleanState(C)
        })
    }

    function k(w) {
        u.initDocument && u.initDocument(w)
    }
    return {
        listenTo: S,
        removeListener: h.removeListener,
        removeAllListeners: h.removeAllListeners,
        uninstall: D,
        initDocument: k
    }
};

function te(e, t, r) {
    var i = e[t];
    return i == null && r !== void 0 ? r : i
}
const Xn = ni(Yn),
    gt = e => {
        const {
            containerProps: t,
            closeButtonProps: r,
            onClose: i,
            advertiseLink: s
        } = e, d = f.useCallback(p => {
            p.preventDefault(), i == null || i()
        }, [i]);
        return l.jsxs(H, {
            display: "flex",
            alignItems: "center",
            ...t,
            children: [s !== void 0 && l.jsx(Re, {
                pointerEvents: "auto",
                href: s,
                variant: "link",
                size: "sm",
                fontSize: "11px",
                fontWeight: "normal",
                opacity: .5,
                target: "_blank",
                rel: "noreferrer noopener",
                _hover: {
                    opacity: .8
                },
                _focus: {
                    outline: "none"
                },
                children: l.jsxs(ut, {
                    spacing: "3px",
                    children: [l.jsx(oe, {
                        as: si
                    }), l.jsx(O, {
                        children: "Ad"
                    })]
                })
            }), l.jsx(ai, {
                pointerEvents: "auto",
                onClick: d,
                size: "sm",
                icon: l.jsx(oe, {
                    as: oi
                }),
                "aria-label": "Hide",
                variant: "link",
                minW: "23px",
                py: "7px",
                opacity: .5,
                _hover: {
                    opacity: .8
                },
                _focus: {},
                ...r
            })]
        })
    },
    xt = f.memo(e => {
        const {
            title: t
        } = e, r = cr("accent.600", "accent.150");
        return l.jsx(O, {
            as: "span",
            fontWeight: "semibold",
            fontSize: {
                base: "sm",
                lg: "md"
            },
            noOfLines: 1,
            color: r,
            children: t
        })
    }),
    Jn = f.memo(e => {
        const {
            onHide: t,
            ad: r,
            height: i
        } = e, {
            colorMode: s
        } = pt(), d = r && r.url, p = d ? Re : H, o = f.useRef(null), [h, c] = f.useState();
        f.useEffect(() => {
            const v = o.current;
            let y;
            return v && (y = Xn({
                strategy: "scroll"
            }), y.listenTo(v, g => {
                c(g.getBoundingClientRect().height)
            })), () => {
                v && y && y.uninstall(v)
            }
        }, []);
        const u = h !== void 0 && h > 150,
            m = cr("accent.600", "accent.150");
        return l.jsxs(H, {
            position: "relative",
            children: [l.jsxs(p, {
                _focus: {
                    outline: "none"
                },
                display: "flex",
                alignItems: "center",
                position: "relative",
                href: r == null ? void 0 : r.url,
                target: "_blank",
                rel: "sponsored noreferrer noopener",
                width: "100%",
                height: i,
                pt: "7px",
                pb: "8px",
                px: 2,
                pl: "10px",
                borderWidth: 1,
                borderRadius: "md",
                borderColor: G("gray.100", "blue.850", s),
                transition: "background-color 0.25s",
                cursor: d ? "pointer" : "default",
                _hover: {
                    textDecoration: "none",
                    bg: d ? G("gray.50", "blue.875", s) : "initial"
                },
                ref: o,
                children: [!(r && h !== void 0) && l.jsx(mt, {}), r && h !== void 0 && l.jsxs(st, {
                    alignItems: "stretch",
                    flex: 1,
                    spacing: u ? "10px" : "3px",
                    children: [(r.thumbnail || r.title) && l.jsxs(di, {
                        direction: u ? "column" : "row",
                        spacing: u ? 2 : 1,
                        alignItems: "center",
                        children: [r.thumbnail && l.jsx(Je, {
                            src: r.thumbnail,
                            w: "20px",
                            h: "20px",
                            loading: "lazy"
                        }), r.title && l.jsx(xt, {
                            title: r.title
                        })]
                    }), !u && (r.description || r.callToAction) && l.jsxs(O, {
                        fontSize: "sm",
                        lineHeight: "15px",
                        noOfLines: 2,
                        children: [r.description && l.jsx(Te, {
                            children: r.description
                        }), r.callToAction && l.jsx(Te, {
                            paddingLeft: r.description ? 1 : 0,
                            color: m,
                            fontWeight: "semibold",
                            children: r.callToAction
                        })]
                    }), u && (r.description || r.callToAction) && l.jsxs(st, {
                        spacing: 3,
                        lineHeight: "20px",
                        fontSize: "sm",
                        alignItems: "center",
                        children: [r.description && l.jsx(Te, {
                            noOfLines: 4,
                            textAlign: "center",
                            children: r.description
                        }), r.callToAction && l.jsx(Te, {
                            color: m,
                            fontWeight: "semibold",
                            children: r.callToAction
                        })]
                    })]
                })]
            }), r && l.jsx(gt, {
                advertiseLink: r.advertiseLink,
                containerProps: {
                    pos: "absolute",
                    top: 0,
                    right: "3px"
                },
                onClose: t
            })]
        })
    }),
    tr = 66,
    rr = 25,
    Qn = f.memo(e => {
        const {
            ad: t,
            onHide: r,
            height: i
        } = e, {
            colorMode: s
        } = pt(), d = t && t.url, p = d ? Re : H, o = G("white", "blue.950", s);
        return l.jsxs(H, {
            position: "relative",
            children: [l.jsxs(p, {
                _focus: {
                    outline: "none"
                },
                href: t == null ? void 0 : t.url,
                target: "_blank",
                rel: "sponsored noreferrer noopener",
                height: i,
                pos: "relative",
                display: "flex",
                alignItems: "center",
                padding: 2,
                borderColor: G("gray.100", "blue.900", s),
                bg: o,
                px: {
                    base: "10px",
                    md: 3
                },
                pt: {
                    base: "6px",
                    md: 3
                },
                pb: {
                    base: "6px",
                    md: 3
                },
                cursor: d ? "pointer" : "default",
                _hover: {
                    textDecoration: "none",
                    bg: d ? G("gray.50", "blue.900", s) : o
                },
                borderWidth: 1,
                borderRadius: "md",
                children: [!t && l.jsx(mt, {}), t && l.jsxs(H, {
                    display: "flex",
                    flexDir: {
                        base: "column",
                        md: "row"
                    },
                    fontSize: {
                        base: "sm",
                        md: "md"
                    },
                    w: "100%",
                    alignItems: {
                        base: "flex-start",
                        md: "center"
                    },
                    paddingRight: {
                        md: t.advertiseLink === void 0 ? `${rr}px` : `${tr}px`
                    },
                    children: [l.jsxs(ut, {
                        align: {
                            base: "flex-start",
                            md: "center"
                        },
                        spacing: 1,
                        flexShrink: 0,
                        children: [t.thumbnail && l.jsx(Je, {
                            alt: "thumbnail",
                            src: t.thumbnail,
                            width: "20px",
                            height: "20px",
                            display: "flex",
                            alignSelf: "center",
                            loading: "lazy"
                        }), t.title && l.jsx(xt, {
                            title: t.title
                        })]
                    }), l.jsx(H, {
                        lineHeight: "15px",
                        fontSize: "sm",
                        display: "flex",
                        flexDirection: "row",
                        width: {
                            base: "100%",
                            md: "initial"
                        },
                        children: l.jsxs(O, {
                            as: "span",
                            noOfLines: 2,
                            ml: {
                                base: 0,
                                md: t.thumbnail || t.title ? 2 : 0
                            },
                            children: [t.description && l.jsx(O, {
                                as: "span",
                                children: t.description
                            }), t.callToAction && l.jsx(O, {
                                as: "span",
                                ml: {
                                    base: 1,
                                    lg: 2
                                },
                                color: G("accent.600", "accent.150", s),
                                fontWeight: "semibold",
                                children: t.callToAction
                            })]
                        })
                    })]
                })]
            }), t && l.jsx(gt, {
                advertiseLink: t.advertiseLink,
                containerProps: {
                    pointerEvents: "none",
                    justifyContent: "flex-end",
                    width: t.advertiseLink === void 0 ? `${rr}px` : `${tr}px`,
                    pos: "absolute",
                    top: 0,
                    bottom: {
                        md: 0
                    },
                    right: {
                        base: 0,
                        md: 2
                    }
                },
                closeButtonProps: {
                    ml: {
                        md: 2
                    }
                },
                onClose: r
            })]
        })
    }),
    ir = 66,
    nr = 25,
    es = f.memo(e => {
        const {
            ad: t,
            onHide: r,
            height: i
        } = e, {
            colorMode: s
        } = pt(), d = t && t.url, p = d ? Re : H, o = G("white", "gray.925", s);
        return l.jsxs(H, {
            position: "relative",
            children: [l.jsxs(p, {
                _focus: {
                    outline: "none"
                },
                href: t == null ? void 0 : t.url,
                target: "_blank",
                rel: "sponsored noreferrer noopener",
                height: i,
                pos: "relative",
                display: "flex",
                alignItems: "center",
                padding: 2,
                borderColor: G("gray.100", "gray.875", s),
                bg: o,
                px: {
                    base: "10px",
                    md: 3
                },
                pt: {
                    base: "6px",
                    md: 3
                },
                pb: {
                    base: "6px",
                    md: 3
                },
                cursor: d ? "pointer" : "default",
                _hover: {
                    textDecoration: "none",
                    bg: d ? G("gray.50", "gray.875", s) : o
                },
                borderWidth: 1,
                borderRadius: "md",
                children: [!t && l.jsx(mt, {}), t && l.jsx(H, {
                    display: "flex",
                    flexDir: {
                        base: "column",
                        md: "row"
                    },
                    fontSize: {
                        base: "sm",
                        md: "md"
                    },
                    w: "100%",
                    alignItems: {
                        base: "flex-start",
                        md: "center"
                    },
                    paddingRight: {
                        md: t.advertiseLink === void 0 ? `${nr}px` : `${ir}px`
                    },
                    children: l.jsxs(ut, {
                        spacing: "2",
                        flexShrink: 0,
                        children: [t.thumbnail && l.jsx(Je, {
                            src: t.thumbnail,
                            width: "48px",
                            minWidth: "48px",
                            height: "48px",
                            display: "flex",
                            alignSelf: "center",
                            loading: "lazy"
                        }), l.jsxs(st, {
                            alignItems: "stretch",
                            spacing: "0",
                            children: [t.title && l.jsx(xt, {
                                title: t.title
                            }), l.jsx(H, {
                                lineHeight: "15px",
                                fontSize: "sm",
                                display: "flex",
                                flexDirection: "row",
                                width: {
                                    base: "100%",
                                    md: "initial"
                                },
                                children: l.jsxs(O, {
                                    as: "span",
                                    noOfLines: 2,
                                    children: [t.description && l.jsx(O, {
                                        as: "span",
                                        children: t.description
                                    }), t.callToAction && l.jsx(O, {
                                        as: "span",
                                        ml: {
                                            base: 1,
                                            md: 2
                                        },
                                        color: G("accent.600", "accent.150", s),
                                        fontWeight: "semibold",
                                        children: t.callToAction
                                    })]
                                })
                            })]
                        })]
                    })
                })]
            }), t && l.jsx(gt, {
                advertiseLink: t.advertiseLink,
                containerProps: {
                    pointerEvents: "none",
                    justifyContent: "flex-end",
                    width: t.advertiseLink === void 0 ? `${nr}px` : `${ir}px`,
                    pos: "absolute",
                    top: 0,
                    right: 0
                },
                onClose: r
            })]
        })
    }),
    sr = f.memo(e => {
        const {
            location: t,
            ad: r,
            onHide: i,
            height: s
        } = e;
        switch (t) {
            case "screener":
                return l.jsx(Qn, {
                    ad: r,
                    onHide: i,
                    height: s
                });
            case "pair":
                return l.jsx(Jn, {
                    ad: r,
                    onHide: i,
                    height: s
                });
            case "search":
                return l.jsx(es, {
                    ad: r,
                    onHide: i,
                    height: s
                })
        }
    }),
    ts = () => {
        const e = Hi(),
            t = de(un),
            r = ht(),
            i = vn(f.useMemo(() => t.isAdLocationHidden(e.adLocation), [e.adLocation, t])),
            s = f.useMemo(() => e.enabled ? r ? i : !1 : !0, [e.enabled, i, r]),
            [d, p] = f.useState(s ? void 0 : e.ad),
            o = f.useMemo(() => t.findAdUnit(e.adLocation), [e.adLocation, t]),
            [h, c] = f.useMemo(() => ci(), []),
            {
                value: u,
                enable: m
            } = li(!1);
        Tt(() => {
            if (s || !u) return;
            const k = e.ad ? Ut : t.getAdByAdUnit(o),
                w = c.pipe(ae(() => t.getFallbackAd(o))),
                C = e.ad ? Ut : e.refreshRequest.pipe(ae(() => t.getAdByAdUnit(o)));
            return pi(k, C, w).pipe(hi(p))
        }, [o, e.ad, e.refresh, e.refreshRequest, t, c, s, u]);
        const v = f.useCallback(() => {
                t.hideAd(e.adLocation)
            }, [e.adLocation, t]),
            y = ui(k => k.pipe(ae(t.notifyViewed)), [t.notifyViewed]),
            g = Q(e.adLocation),
            S = Q(e.enabled),
            D = Q(i);
        return Tt(() => {
            if (S.current && D.current && r) return t.notifyHidden(g.current)
        }, [g, t, D, S, r]), {
            isHidden: s,
            ad: d,
            hide: v,
            adUnit: o,
            requestFallback: h,
            show: m,
            isShown: u,
            notifyViewed: y
        }
    },
    Ls = f.memo(e => {
        const {
            variant: t,
            containerProps: r
        } = e, {
            show: i,
            hide: s,
            ad: d,
            isHidden: p,
            adUnit: o,
            requestFallback: h,
            isShown: c,
            notifyViewed: u
        } = ts(), m = f.useMemo(() => rs(t, o), [t, o]), v = f.useMemo(() => is(o), [o]), y = f.useRef(null);
        if (f.useEffect(() => {
                let S;
                return y.current && (S = new IntersectionObserver(D => {
                    for (const k of D)
                        if (k.isIntersecting) return i()
                }), S.observe(y.current)), () => {
                    S && S.disconnect()
                }
            }, [i]), f.useEffect(() => {
                d && d.kind === "native" && u(d)
            }, [d, u]), p) return null;
        const g = () => {
            if (d) switch (d.kind) {
                case "native":
                    return l.jsx(H, {
                        width: "100%",
                        children: l.jsx(sr, {
                            height: m,
                            location: t,
                            ad: d,
                            onHide: s
                        })
                    });
                case "display":
                    switch (d.provider) {
                        case "coinzilla":
                            return l.jsx(Ot, {
                                width: v,
                                height: m,
                                ad: d,
                                onHide: s,
                                onView: u
                            });
                        case "a-ads":
                            return l.jsx(Ft, {
                                width: v,
                                height: m,
                                ad: d,
                                onHide: s,
                                onView: u
                            });
                        case "google":
                            return l.jsx($t, {
                                ad: d,
                                width: v,
                                height: m,
                                adUnit: d.adUnit,
                                onFallbackRequest: h,
                                onHide: s,
                                isShown: c,
                                onView: u
                            });
                        case "direct":
                            return l.jsx(Vt, {
                                onView: u,
                                ad: d,
                                width: v,
                                height: m,
                                adUnit: d.adUnit,
                                onFallbackRequest: h,
                                onHide: s
                            });
                        case "persona":
                            return l.jsx(Gt, {
                                isShown: c,
                                width: v,
                                height: m,
                                adUnit: d.adUnit,
                                onHide: s,
                                onFallbackRequest: h
                            });
                        case "cointraffic":
                            return l.jsx(qt, {
                                isShown: c,
                                width: v,
                                height: m,
                                adUnit: d.adUnit,
                                onHide: s,
                                onFallbackRequest: h
                            })
                    }
            } else switch (o.adKind) {
                case "native":
                    return l.jsx(H, {
                        width: "100%",
                        children: l.jsx(sr, {
                            height: m,
                            location: t,
                            ad: d,
                            onHide: s
                        })
                    });
                case "display":
                    switch (o.provider) {
                        case "coinzilla":
                            return l.jsx(Ot, {
                                width: v,
                                height: m,
                                onHide: s,
                                onView: u
                            });
                        case "a-ads":
                            return l.jsx(Ft, {
                                width: v,
                                height: m,
                                onHide: s,
                                onView: u
                            });
                        case "google":
                            return l.jsx($t, {
                                width: v,
                                height: m,
                                adUnit: o,
                                onFallbackRequest: h,
                                onHide: s,
                                isShown: c,
                                onView: u
                            });
                        case "direct":
                            return l.jsx(Vt, {
                                onView: u,
                                width: v,
                                height: m,
                                adUnit: o,
                                onFallbackRequest: h,
                                onHide: s
                            });
                        case "persona":
                            return l.jsx(Gt, {
                                isShown: c,
                                width: v,
                                height: m,
                                adUnit: o,
                                onHide: s,
                                onFallbackRequest: h
                            });
                        case "cointraffic":
                            return l.jsx(qt, {
                                isShown: c,
                                width: v,
                                height: m,
                                adUnit: o,
                                onHide: s,
                                onFallbackRequest: h
                            })
                    }
            }
        };
        return l.jsx(H, {
            width: "100%",
            display: "flex",
            justifyContent: "center",
            overflow: "hidden",
            ...r,
            ref: y,
            children: g()
        })
    });

function rs(e, t) {
    switch (t.adKind) {
        case "native":
            {
                switch (e) {
                    case "search":
                        return {
                            base: "64px",
                            md: "74px"
                        };
                    case "screener":
                        return {
                            base: "64px",
                            md: "47px"
                        };
                    case "pair":
                        return {
                            base: "58px",
                            lg: "71px"
                        }
                }
                break
            }
        case "display":
            return t.size === "responsive" ? `calc(90px + ${jt}px)` : `calc(${t.size.height}px + ${jt}px)`
    }
}

function is(e) {
    switch (e.adKind) {
        case "native":
            return "100%";
        case "display":
            return e.size === "responsive" ? "100%" : `${e.size.width}px`
    }
}
const Is = ({
        children: e,
        ...t
    }) => l.jsxs(fi, { ...t,
        emoji: "😢",
        title: "Failed connecting to server",
        children: [l.jsx(O, {
            children: "Please wait a few seconds or refresh this page to try again."
        }), e]
    }),
    ns = {
        strategy: "fixed",
        isLazy: !0,
        matchWidth: !0
    },
    dt = {
        fontWeight: "normal",
        iconSpacing: "4px",
        _focus: {
            boxShadow: "none"
        }
    },
    Xe = {
        boxSize: "20px"
    },
    ss = ({
        watchlistPair: e,
        containerProps: t,
        buttonProps: r,
        menuProps: i
    }) => {
        const s = de(dr),
            d = vi(),
            p = ht(),
            h = de(Ii).actions,
            [c, u] = f.useState(!1),
            m = Rt({
                value: gi(),
                onPending: () => [],
                onFailure: () => [],
                onSuccess: k => k
            }),
            v = xi(),
            y = Rt({
                value: v,
                onPending: () => [],
                onFailure: () => [],
                onSuccess: k => k
            }),
            g = [];
        m.forEach(k => {
            k.pairs.find(w => w.chainId === e.chainId && w.pairId === e.pairId) && g.push(k.id)
        });
        const S = lr(),
            D = async k => {
                if (!e) return;
                const w = g.length === 0 || !g.includes(k) ? "add" : "remove";
                e.dexId && s.track({
                    event: "toggleWatchlist",
                    data: {
                        action: w,
                        chainId: e.chainId,
                        dexId: e.dexId,
                        pairId: e.pairId,
                        pair: `${e.baseTokenSymbol}/${e.quoteTokenSymbol}`
                    }
                }), u(!0);
                const C = y.find(n => n.id === k);
                if (w === "add") try {
                    if (C) await h.addPairToWatchlist(k, e);
                    else {
                        const n = m.find(a => a.id === k && a.default);
                        if (!n) throw new Error(`The list '${k}' does not exist!`);
                        await h.createWatchlist({
                            visibility: "private",
                            schemaVersion: "1.0.0",
                            name: n.name,
                            default: n.default,
                            pairs: [e]
                        })
                    }
                } catch (n) {
                    d({
                        status: "error",
                        title: `Failed adding pair to watchlist: ${Pt(n).message}`
                    })
                } else try {
                    const n = C == null ? void 0 : C.pairs.find(a => a.pairId === e.pairId && a.chainId === e.chainId);
                    if (!n) {
                        d({
                            status: "error",
                            title: "Failed removing pair from watchlist"
                        });
                        return
                    }
                    await h.removePairFromWatchlist(k, n)
                } catch (n) {
                    d({
                        status: "error",
                        title: `Failed removing pair from watchlist: ${Pt(n).message}`
                    })
                }
                u(!1)
            };
        return l.jsxs(l.Fragment, {
            children: [l.jsx(H, { ...t,
                children: l.jsxs(bi, { ...ns,
                    ...i,
                    children: [l.jsxs(yi, {
                        as: at,
                        isDisabled: !p || c,
                        w: "100%",
                        leftIcon: l.jsx(oe, {
                            as: g.length === 0 ? $e : zt,
                            ...Xe
                        }),
                        sx: {
                            span: {
                                flex: "initial"
                            }
                        },
                        ...dt,
                        ...r,
                        children: [l.jsx(Te, {
                            children: "Watchlist"
                        }), g.length > 0 && l.jsx(_i, {
                            label: g.length
                        })]
                    }), l.jsxs(wi, {
                        overflowX: "hidden",
                        overflowY: "auto",
                        maxH: {
                            base: "max(20vh, 150px)",
                            lg: "250px"
                        },
                        children: [l.jsx(ki, {
                            children: m.map(k => l.jsx(Ci, {
                                onClick: () => D(k.id),
                                closeOnSelect: !0,
                                children: l.jsxs(O, {
                                    as: "span",
                                    display: "flex",
                                    alignItems: "center",
                                    fontWeight: g != null && g.includes(k.id) ? "semibold" : void 0,
                                    w: "100%",
                                    children: [l.jsx(oe, {
                                        as: g.length === 0 || !g.includes(k.id) ? $e : zt,
                                        mr: 2,
                                        ...Xe
                                    }), l.jsx(O, {
                                        as: "span",
                                        children: Ai(k.name, 30)
                                    }), (g == null ? void 0 : g.includes(k.id)) && l.jsx(oe, {
                                        ml: "auto",
                                        as: Si
                                    })]
                                })
                            }, k.id))
                        }), l.jsx(Di, {}), l.jsx(Ei, {
                            onOpenManager: S.onOpen
                        })]
                    })]
                })
            }), S.isOpen && l.jsx(Li, {
                onClose: S.onClose
            })]
        })
    },
    Ts = ({
        watchlistPair: e,
        menuContainerProps: t,
        buttonProps: r,
        menuProps: i
    }) => {
        const {
            isEmbed: s
        } = mi(o => o.embedSettings), d = lr(), p = ht();
        return !p || !e ? l.jsx(at, {
            isDisabled: !p,
            leftIcon: l.jsx(oe, {
                as: $e,
                ...Xe
            }),
            ...dt,
            ...r,
            children: "Watchlist"
        }) : s ? l.jsxs(l.Fragment, {
            children: [l.jsx(at, {
                isDisabled: !p,
                onClick: d.onOpen,
                leftIcon: l.jsx(oe, {
                    as: $e,
                    ...Xe
                }),
                ...dt,
                ...r,
                children: "Watchlist"
            }), d.isOpen && l.jsx(Mi, {
                onClose: d.onClose
            })]
        }) : l.jsx(ss, {
            watchlistPair: e,
            containerProps: t,
            buttonProps: r,
            menuProps: i
        })
    },
    Us = {
        telegram: Ti,
        twitter: Ui,
        discord: Ri,
        tiktok: zi,
        facebook: Pi
    },
    ke = {
        chainId: !0,
        dexId: !0,
        labels: !0,
        pairAddress: !0,
        baseToken: !0,
        quoteToken: !0,
        quoteTokenSymbol: !0,
        price: !0,
        priceUsd: !0,
        txns: !0,
        buyers: !0,
        sellers: !0,
        makers: !0,
        volume: !0,
        volumeBuy: !0,
        volumeSell: !0,
        priceChange: !0,
        liquidity: !0,
        marketCap: !0,
        pairCreatedAt: !0,
        eti: !0,
        boosts: !0,
        c: !0
    };
ce({
    schemaVersion: ze("3.0"),
    pairs: V(Pe([je.pick({ ...ke,
        a: !0,
        cgi: !0
    }), Fe.pick(ke), He.pick(ke), Me.pick({ ...ke,
        pn: !0
    }), _e.pick({ ...ke,
        cgi: !0
    })]))
});
const Ce = {
    chainId: !0,
    dexId: !0,
    labels: !0,
    pairAddress: !0,
    baseToken: !0,
    quoteToken: !0,
    quoteTokenSymbol: !0,
    price: !0,
    priceUsd: !0,
    txns: !0,
    buyers: !0,
    sellers: !0,
    makers: !0,
    volume: !0,
    volumeBuy: !0,
    volumeSell: !0,
    priceChange: !0,
    liquidity: !0,
    marketCap: !0,
    pairCreatedAt: !0,
    eti: !0,
    profile: !0,
    boosts: !0,
    c: !0
};
ce({
    schemaVersion: ze("4.0"),
    pairs: V(Pe([je.pick({ ...Ce,
        a: !0,
        cgi: !0
    }), Fe.pick(Ce), He.pick(Ce), Me.pick({ ...Ce,
        pn: !0
    }), _e.pick({ ...Ce,
        cgi: !0
    })]))
});
const Ae = {
    chainId: !0,
    dexId: !0,
    labels: !0,
    pairAddress: !0,
    baseToken: !0,
    quoteToken: !0,
    quoteTokenSymbol: !0,
    price: !0,
    priceUsd: !0,
    txns: !0,
    buyers: !0,
    sellers: !0,
    makers: !0,
    volume: !0,
    volumeBuy: !0,
    volumeSell: !0,
    priceChange: !0,
    liquidity: !0,
    marketCap: !0,
    fdv: !0,
    pairCreatedAt: !0,
    eti: !0,
    profile: !0,
    boosts: !0,
    c: !0
};
ce({
    schemaVersion: ze("5.0"),
    pairs: V(Pe([je.pick({ ...Ae,
        a: !0,
        cgi: !0
    }), Fe.pick(Ae), He.pick(Ae), Me.pick({ ...Ae,
        pn: !0
    }), _e.pick({ ...Ae,
        cgi: !0
    })]))
});
const Se = {
        chainId: !0,
        dexId: !0,
        labels: !0,
        pairAddress: !0,
        baseToken: !0,
        quoteToken: !0,
        quoteTokenSymbol: !0,
        price: !0,
        priceUsd: !0,
        txns: !0,
        buyers: !0,
        sellers: !0,
        makers: !0,
        volume: !0,
        volumeBuy: !0,
        volumeSell: !0,
        priceChange: !0,
        liquidity: !0,
        marketCap: !0,
        fdv: !0,
        pairCreatedAt: !0,
        eti: !0,
        profile: !0,
        boosts: !0,
        c: !0,
        cmsProfile: !0
    },
    De = {
        website: !0,
        twitter: !0,
        discord: !0,
        linkCount: !0,
        headerId: !0,
        iconId: !0,
        description: !0
    },
    as = {
        progress: !0,
        curvePos: !0,
        mcapThreshold: !0,
        creator: !0
    };
ce({
    schemaVersion: ze("6.0"),
    pairs: V(Pe([je.extend({
        cmsProfile: q.pick(De).optional(),
        moonshot: Qe.pick(as).optional()
    }).pick({ ...Se,
        a: !0,
        cgi: !0,
        moonshot: !0
    }), Fe.extend({
        cmsProfile: q.pick(De).optional()
    }).pick({ ...Se
    }), He.extend({
        cmsProfile: q.pick(De).optional()
    }).pick({ ...Se
    }), Me.extend({
        cmsProfile: q.pick(De).optional()
    }).pick({ ...Se,
        pn: !0
    }), _e.extend({
        cmsProfile: q.pick(De).optional()
    }).pick({ ...Se,
        cgi: !0
    })]))
});
const Ee = {
        chainId: !0,
        dexId: !0,
        labels: !0,
        pairAddress: !0,
        baseToken: !0,
        quoteToken: !0,
        quoteTokenSymbol: !0,
        price: !0,
        priceUsd: !0,
        txns: !0,
        buyers: !0,
        sellers: !0,
        makers: !0,
        volume: !0,
        volumeBuy: !0,
        volumeSell: !0,
        priceChange: !0,
        liquidity: !0,
        marketCap: !0,
        fdv: !0,
        pairCreatedAt: !0,
        eti: !0,
        profile: !0,
        boosts: !0,
        c: !0,
        cmsProfile: !0
    },
    Le = {
        website: !0,
        twitter: !0,
        discord: !0,
        linkCount: !0,
        headerId: !0,
        iconId: !0,
        description: !0
    },
    os = {
        progress: !0,
        curvePos: !0,
        mcapThreshold: !0,
        creator: !0,
        quoteMcap: !0,
        curveType: !0,
        coefB: !0
    },
    ds = ce({
        schemaVersion: ze("7.0"),
        pairs: V(Pe([je.extend({
            cmsProfile: q.pick(Le).optional(),
            moonshot: Qe.pick(os).optional()
        }).pick({ ...Ee,
            a: !0,
            cgi: !0,
            moonshot: !0
        }), Fe.extend({
            cmsProfile: q.pick(Le).optional()
        }).pick({ ...Ee
        }), He.extend({
            cmsProfile: q.pick(Le).optional()
        }).pick({ ...Ee
        }), Me.extend({
            cmsProfile: q.pick(Le).optional()
        }).pick({ ...Ee,
            pn: !0
        }), _e.extend({
            cmsProfile: q.pick(Le).optional()
        }).pick({ ...Ee,
            cgi: !0
        })]))
    }),
    cs = {
        chainId: !0,
        dexId: !0,
        labels: !0,
        pairAddress: !0,
        baseToken: !0,
        quoteToken: !0,
        quoteTokenSymbol: !0,
        price: !0,
        priceUsd: !0,
        txns: !0,
        buyers: !0,
        sellers: !0,
        makers: !0,
        volume: !0,
        volumeBuy: !0,
        volumeSell: !0,
        priceChange: !0,
        liquidity: !0,
        marketCap: !0,
        fdv: !0,
        pairCreatedAt: !0,
        eti: !0,
        profile: !0,
        cmsProfile: !0,
        boosts: !0,
        c: !0,
        a: !0,
        cgi: !0,
        moonshot: !0
    },
    ls = {
        website: !0,
        twitter: !0,
        discord: !0,
        linkCount: !0,
        headerId: !0,
        iconId: !0,
        description: !0
    },
    us = {
        progress: !0,
        curvePos: !0,
        mcapThreshold: !0,
        creator: !0
    };
ur.extend({
    cmsProfile: q.pick(ls).optional(),
    moonshot: Qe.pick(us)
}).pick({ ...cs
});
const ps = {
        chainId: !0,
        dexId: !0,
        labels: !0,
        pairAddress: !0,
        baseToken: !0,
        quoteToken: !0,
        quoteTokenSymbol: !0,
        price: !0,
        priceUsd: !0,
        txns: !0,
        buyers: !0,
        sellers: !0,
        makers: !0,
        volume: !0,
        volumeBuy: !0,
        volumeSell: !0,
        priceChange: !0,
        liquidity: !0,
        marketCap: !0,
        fdv: !0,
        pairCreatedAt: !0,
        eti: !0,
        profile: !0,
        cmsProfile: !0,
        boosts: !0,
        c: !0,
        a: !0,
        cgi: !0,
        moonshot: !0
    },
    hs = {
        website: !0,
        twitter: !0,
        discord: !0,
        linkCount: !0,
        headerId: !0,
        iconId: !0,
        description: !0
    },
    fs = {
        progress: !0,
        curvePos: !0,
        mcapThreshold: !0,
        creator: !0,
        quoteMcap: !0,
        curveType: !0,
        coefB: !0
    },
    Ie = ur.extend({
        cmsProfile: q.pick(hs).optional(),
        moonshot: Qe.pick(fs)
    }).pick({ ...ps
    }),
    ms = ce({
        latestProfiles: V(ji),
        moonshot: ce({
            trending: V(Ie),
            top: V(Ie),
            rising: V(Ie),
            new: V(Ie),
            finalized: V(Ie)
        })
    }),
    Rs = j({
        env: lt(),
        httpClient: or
    }, ({
        env: e,
        httpClient: t
    }) => ({
        searchPairs: ({
            query: r,
            filters: i
        }) => {
            const s = new URL(e.DS_DEX_SCREENER_SEARCH_PUBLIC_ORIGIN);
            return s.pathname = "/dex/search/v7/pairs", s.searchParams.append("q", r), i != null && i.moonshot && s.searchParams.append("ms", "true"), t.avro(s.toString(), ds, {
                credentials: "include"
            }).pipe(it(d => d.pairs))
        },
        spotlight: () => {
            const r = new URL(e.DS_DEX_SCREENER_SEARCH_PUBLIC_ORIGIN);
            return r.pathname = "/dex/search/spotlight/v3", t.avro(r.toString(), ms, {
                credentials: "include"
            })
        }
    }));
export {
    Ls as A, bn as B, Is as E, Es as S, Ye as T, Ts as W, Cs as a, Ki as b, Ni as c, Rs as d, qi as e, Ds as f, ks as g, Ss as h, As as i, Xn as n, Us as s, xn as u
};