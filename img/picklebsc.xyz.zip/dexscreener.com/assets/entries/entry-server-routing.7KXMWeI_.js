import {
    p as R,
    _ as be
} from "../chunks/preload-helper-Jimfoxkq.js";

function $e() {
    return !(typeof R > "u" || !R.cwd || !R.versions || typeof R.versions.node > "u" || !R.release || R.release.name !== "node")
}

function H(e, t) {
    let n; {
        var r = Error.stackTraceLimit;
        Error.stackTraceLimit = 1 / 0, n = new Error(e), Error.stackTraceLimit = r
    }
    return $e() && (n.stack = Te(n.stack, t)), n
}

function Te(e, t) {
    if (!e) return e;
    const n = ke(e);
    let r = 0;
    return n.filter(s => s.includes(" (internal/") || s.includes(" (node:internal") ? !1 : r < t && Pe(s) ? (r++, !1) : !0).join(`
`)
}

function Pe(e) {
    return e.startsWith("    at ")
}

function ke(e) {
    return e.split(/\r?\n/)
}

function k(e, t) {
    const n = globalThis[X] = globalThis[X] || {};
    return n[e] = n[e] || t
}
const X = "_vike";

function S(e) {
    return typeof e == "object" && e !== null
}

function ae(e) {
    return Array.from(new Set(e))
}
const b = k("assertPackageInstances.ts", {
        instances: [],
        alreadyLogged: new Set
    }),
    Re = "The client runtime of Server Routing as well as the client runtime of Client Routing are both being loaded. Make sure they aren't loaded both at the same time for a given page. See https://vike.dev/client-runtimes-conflict",
    le = "Two vike client runtime instances are being loaded. Make sure your client-side bundles don't include vike twice. (In order to reduce the size of your client-side JavaScript bundles.)";

function ce() {
    {
        const e = ae(b.instances);
        je(e.length <= 1, `Both vike@${e[0]} and vike@${e[1]} loaded. Only one version should be loaded.`)
    }
    b.checkSingleInstance && b.instances.length > 1 && A(!1, le, {
        onlyOnce: !0,
        showStackTrace: !0
    })
}

function xe(e) {
    A(b.isClientRouting !== !0, Re, {
        onlyOnce: !0,
        showStackTrace: !0
    }), A(b.isClientRouting === void 0, le, {
        onlyOnce: !0,
        showStackTrace: !0
    }), b.isClientRouting = !1, e && (b.checkSingleInstance = !0), ce()
}

function _e(e) {
    b.instances.push(e), ce()
}

function je(e, t) {
    if (e) return;
    const n = `[vike][Wrong Usage] ${t}`;
    throw new Error(n)
}

function A(e, t, {
    onlyOnce: n,
    showStackTrace: r
}) {
    if (e) return;
    const i = `[vike][Warning] ${t}`;
    if (n) {
        const {
            alreadyLogged: s
        } = b, l = n === !0 ? i : n;
        if (s.has(l)) return;
        s.add(l)
    }
    console.warn(r ? new Error(i) : i)
}
const Ie = "0.4.161",
    ue = {
        projectName: "Vike",
        projectVersion: Ie
    };
_e(ue.projectVersion);
const E = new Proxy(e => e, {
        get: () => E
    }),
    w = k("utils/assert.ts", {
        alreadyLogged: new Set,
        logger(e, t) {
            t === "info" ? console.log(e) : console.warn(e)
        },
        showStackTraceList: new WeakSet
    }),
    Oe = "[vike]",
    Ce = `[vike@${ue.projectVersion}]`,
    U = 2;

function o(e, t) {
    var s;
    if (e) return;
    const n = (() => {
        if (!t) return null;
        const l = typeof t == "string" ? t : JSON.stringify(t);
        return E.dim(`Debug info (for Vike maintainers; you can ignore this): ${l}`)
    })();
    let r = ["You stumbled upon a Vike bug.", `Go to ${E.blue("https://github.com/vikejs/vike/issues/new")} and copy-paste this error. A maintainer will fix the bug (usually under 24 hours).`, n].filter(Boolean).join(" ");
    r = F(r), r = C(r, "Bug"), r = L(r, !0);
    const i = H(r, U);
    throw (s = w.onBeforeLog) == null || s.call(w), i
}

function h(e, t, {
    showStackTrace: n
} = {}) {
    var i;
    if (e) return;
    t = F(t), t = C(t, "Wrong Usage"), t = L(t);
    const r = H(t, U);
    throw n && w.showStackTraceList.add(r), (i = w.onBeforeLog) == null || i.call(w), r
}

function Fe(e) {
    return e = F(e), e = C(e, "Error"), e = L(e), H(e, U)
}

function P(e, t, {
    onlyOnce: n,
    showStackTrace: r
}) {
    var i;
    if (!e) {
        if (t = F(t), t = C(t, "Warning"), t = L(t), n) {
            const {
                alreadyLogged: s
            } = w, l = n === !0 ? t : n;
            if (s.has(l)) return;
            s.add(l)
        }
        if ((i = w.onBeforeLog) == null || i.call(w), r) {
            const s = new Error(t);
            w.showStackTraceList.add(s), w.logger(s, "warn")
        } else w.logger(t, "warn")
    }
}

function C(e, t) {
    let n = `[${t}]`;
    const r = t === "Warning" ? "yellow" : "red";
    return n = E.bold(E[r](n)), `${n}${e}`
}

function F(e) {
    return e.startsWith("[") ? e : ` ${e}`
}

function L(e, t = !1) {
    return `${t?Ce:Oe}${e}`
}

function B() {
    return typeof window < "u" && typeof window.scrollY == "number"
}
const q = k("utils/assertRouterType.ts", {});

function Le() {
    We(q.isClientRouting !== !0), q.isClientRouting = !1
}

function We(e) {
    h(B(), `${E.cyan("import { something } from 'vike/client/router'")} is forbidden on the server-side`, {
        showStackTrace: !0
    }), P(e, "You shouldn't `import { something } from 'vike/client/router'` when using Server Routing. The 'vike/client/router' utilities work only with Client Routing. In particular, don't `import { navigate }` nor `import { prefetch }` as they unnecessarily bloat your client-side bundle sizes.", {
        showStackTrace: !0,
        onlyOnce: !0
    })
}
const Ae = ["js", "ts", "cjs", "cts", "mjs", "mts", "jsx", "tsx", "cjsx", "ctsx", "mjsx", "mtsx"],
    fe = ["vue", "svelte", "marko", "md", "mdx"],
    Ve = [...Ae, ...fe];

function de(e) {
    const t = Ve.some(n => e.endsWith("." + n));
    return o(!ze(e) || t), t
}

function ze(e) {
    return /\.(c|m)?(j|t)sx?$/.test(e)
}

function Ne(e) {
    return fe.some(t => e.endsWith("." + t))
}

function I(e, t, n) {
    return typeof e == "string" ? K(e.split(""), t, n).join("") : K(e, t, n)
}

function K(e, t, n) {
    const r = [];
    let i = t >= 0 ? t : e.length + t;
    o(i >= 0 && i <= e.length);
    let s = n >= 0 ? n : e.length + n;
    for (o(s >= 0 && s <= e.length); !(i === s || (i === e.length && (i = 0), i === s));) {
        const l = e[i];
        o(l !== void 0), r.push(l), i++
    }
    return r
}
const ge = ["http://", "https://", "tauri://"];

function De(e) {
    return ge.some(t => e.startsWith(t)) || e.startsWith("/") || e.startsWith(".") || e.startsWith("?") || e.startsWith("#") || e === ""
}

function He(e, t) {
    o(De(e)), o(t.startsWith("/"));
    const [n, ...r] = e.split("#");
    o(n !== void 0);
    const i = ["", ...r].join("#") || null;
    o(i === null || i.startsWith("#"));
    const s = i === null ? "" : V(i.slice(1)),
        [l, ...a] = n.split("?");
    o(l !== void 0);
    const c = ["", ...a].join("?") || null;
    o(c === null || c.startsWith("?"));
    const u = {},
        f = {};
    Array.from(new URLSearchParams(c || "")).forEach(([v, M]) => {
        u[v] = M, f[v] = [...f.hasOwnProperty(v) ? f[v] : [], M]
    });
    const {
        origin: d,
        pathname: y
    } = Be(l, t);
    o(d === null || d === V(d)), o(y.startsWith("/")), o(d === null || e.startsWith(d));
    const g = l.slice((d || "").length);
    Xe(e, d, g, c, i);
    let {
        pathname: m,
        hasBaseServer: $
    } = Ye(y, t);
    return m = Ue(m), o(m.startsWith("/")), {
        origin: d,
        pathname: m,
        pathnameOriginal: g,
        hasBaseServer: $,
        search: u,
        searchAll: f,
        searchOriginal: c,
        hash: s,
        hashOriginal: i
    }
}

function V(e) {
    try {
        return decodeURIComponent(e)
    } catch {}
    try {
        return decodeURI(e)
    } catch {}
    return e
}

function Ue(e) {
    return e = e.replace(/\s+$/, ""), e = e.split("/").map(t => V(t).split("/").join("%2F")).join("/"), e
}

function Be(e, t) {
    var n;
    o(!e.includes("?") && !e.includes("#")); {
        const {
            origin: r,
            pathname: i
        } = Q(e);
        if (r) return {
            origin: r,
            pathname: i
        };
        o(i === e)
    }
    if (e.startsWith("/")) return {
        origin: null,
        pathname: e
    }; {
        const r = typeof window < "u" ? (n = window == null ? void 0 : window.document) == null ? void 0 : n.baseURI : void 0;
        let i;
        return r ? i = Q(r.split("?")[0]).pathname : i = t, {
            origin: null,
            pathname: Ge(e, i)
        }
    }
}

function Q(e) {
    if (ge.some(t => e.startsWith(t))) {
        const [t, n, r, ...i] = e.split("/"), s = [t, n, r].join("/"), l = ["", ...i].join("/") || "/";
        return {
            origin: s,
            pathname: l
        }
    } else return {
        pathname: e,
        origin: null
    }
}

function Ge(e, t) {
    const n = t.split("/"),
        r = e.split("/");
    let i = t.endsWith("/");
    e.startsWith(".") && n.pop();
    for (const l in r) {
        const a = r[l];
        a == "" && l === "0" || a != "." && (a == ".." ? n.pop() : (i = !1, n.push(a)))
    }
    let s = n.join("/");
    return i && !s.endsWith("/") && (s += "/"), s.startsWith("/") || (s = "/" + s), s
}

function Je(e) {
    o(e.startsWith("/")), o(!e.includes("?")), o(!e.includes("#"))
}

function Ye(e, t) {
    Je(e), o(Me(t));
    let n = e;
    if (o(n.startsWith("/")), o(t.startsWith("/")), t === "/") return {
        pathname: e,
        hasBaseServer: !0
    };
    let r = t;
    return t.endsWith("/") && n === I(t, 0, -1) && (r = I(t, 0, -1), o(n === r)), n.startsWith(r) ? (o(n.startsWith("/") || n.startsWith("http")), o(n.startsWith(r)), n = n.slice(r.length), n.startsWith("/") || (n = "/" + n), o(n.startsWith("/")), {
        pathname: n,
        hasBaseServer: !0
    }) : {
        pathname: e,
        hasBaseServer: !1
    }
}

function Me(e) {
    return e.startsWith("/")
}

function Xe(e, t, n, r, i) {
    const s = qe(t, n, r, i);
    o(e === s)
}

function qe(e, t, n, r) {
    return `${e||""}${t}${n||""}${r||""}`
}

function x(e, t) {
    t && Object.defineProperties(e, Object.getOwnPropertyDescriptors(t))
}

function W(e) {
    return e instanceof Function || typeof e == "function"
}

function Ke(e) {
    return (t, n) => {
        const r = e(t),
            i = e(n);
        if (o([!0, !1, null].includes(r)), o([!0, !1, null].includes(i)), r === i) return 0;
        if (r === !0 || i === !1) return -1;
        if (i === !0 || r === !1) return 1;
        o(!1)
    }
}

function Qe(e) {
    return Ke(t => {
        const n = e(t);
        return n === null ? null : !n
    })
}

function p(e, t, n = "unknown") {
    if (!S(e)) return !1;
    if (!(t in e)) return n === "undefined";
    if (n === "unknown") return !0;
    const r = e[t];
    return n === "array" ? Array.isArray(r) : n === "object" ? S(r) : n === "string[]" ? Array.isArray(r) && r.every(i => typeof i == "string") : n === "function" ? W(r) : Array.isArray(n) ? typeof r == "string" && n.includes(r) : n === "null" ? r === null : n === "undefined" ? r === void 0 : n === "true" ? r === !0 : n === "false" ? r === !1 : typeof r === n
}

function Ze(e, t) {
    return e.toLowerCase() < t.toLowerCase() ? -1 : e.toLowerCase() > t.toLowerCase() ? 1 : 0
}
const et = e => e != null;

function he(e) {
    const t = n => `Not a posix path: ${n}`;
    o(e !== null, t("null")), o(typeof e == "string", t(`typeof path === ${JSON.stringify(typeof e)}`)), o(e !== "", t("(empty string)")), o(e), o(!e.includes("\\"), t(e))
}
const tt = ["clientRouting"];

function nt(e) {
    tt.forEach(t => {
        if (o(e.fileExports), !(t in e.fileExports)) return;
        const n = `The value of \`${t}\` is only allowed to be \`true\`.`;
        h(e.fileExports[t] !== !1, `${e.filePath} has \`export { ${t} }\` with the value \`false\` which is prohibited: remove \`export { ${t} }\` instead. (${n})`), h(e.fileExports[t] === !0, `${e.filePath} has \`export { ${t} }\` with a forbidden value. ${n}`)
    })
}
const pe = ["render", "clientRouting", "prerender", "doNotPrerender"];

function rt(e, t) {
    h(!pe.includes(e), `${t} has \`export default { ${e} }\` which is prohibited, use \`export { ${e} }\` instead.`)
}

function it(e, t) {
    if (!e) return null;
    let [n, ...r] = e;
    if (!n || r.length === 0 && ["*", "default", t].includes(n)) return null;
    o(n !== "*");
    let i = "",
        s = "";
    return n === "default" ? i = "export default" : (i = "export", r = [n, ...r]), r.forEach(a => {
        i = `${i} { ${a}`, s = ` }${s}`
    }), i + s
}

function me(e, t, {
    definedAt: n
}) {
    const r = st(n, t),
        i = r === "internally" ? r : `at ${r}`;
    let s = `${t}`;
    return `${e} ${E.cyan(s)} defined ${i}`
}

function st(e, t) {
    if ("isComputed" in e) return "internally";
    let n;
    return "files" in e ? n = e.files : n = [e], o(n.length >= 1), n.map(i => {
        const {
            filePathToShowToUser: s,
            fileExportPathToShowToUser: l
        } = i;
        let a = s;
        const c = it(l, t);
        return c && (a = `${a} > ${E.cyan(c)}`), a
    }).join(" / ")
}

function ot({
    definedAt: e
}) {
    if ("isComputed" in e || "files" in e) return null;
    const {
        filePathToShowToUser: t
    } = e;
    return o(t), t
}

function at(e, t) {
    const n = {},
        r = {},
        i = {};
    e.forEach(a => {
        lt(a).forEach(({
            exportName: u,
            exportValue: f,
            isFromDefaultExport: d
        }) => {
            o(u !== "default"), i[u] = i[u] ? ? [], i[u].push({
                exportValue: f,
                exportSource: `${a.filePath} > ${d?`\`export default { ${u} }\``:`\`export { ${u} }\``}`,
                filePath: a.filePath,
                _filePath: a.filePath,
                _fileType: a.fileType,
                _isFromDefaultExport: d
            })
        })
    }), t && Object.entries(t.configValues).forEach(([a, c]) => {
        const {
            value: u
        } = c, f = ot(c), d = me("Config", a, c);
        r[a] = r[a] ? ? u, n[a] = n[a] ? ? [], o(n[a].length === 0), n[a].push({
            configValue: u,
            configDefinedAt: d,
            configDefinedByFile: f
        });
        const y = a;
        i[y] = i[y] ? ? [], i[y].push({
            exportValue: u,
            exportSource: d,
            filePath: f,
            _filePath: f,
            _fileType: null,
            _isFromDefaultExport: null
        })
    });
    const s = ct(),
        l = {};
    return Object.entries(i).forEach(([a, c]) => {
        c.forEach(({
            exportValue: u,
            _fileType: f,
            _isFromDefaultExport: d
        }) => {
            l[a] = l[a] ? ? u, f === ".page" && !d && (a in s || (s[a] = u))
        })
    }), o(!("default" in l)), o(!("default" in i)), {
        config: r,
        configEntries: n,
        exports: l,
        exportsAll: i,
        pageExports: s
    }
}

function lt(e) {
    const {
        filePath: t,
        fileExports: n
    } = e;
    o(n), o(de(t));
    const r = [];
    return Object.entries(n).sort(Qe(([i]) => i === "default")).forEach(([i, s]) => {
        let l = i === "default";
        if (l)
            if (Ne(t)) i = "Page";
            else {
                h(S(s), `The ${E.cyan("export default")} of ${t} should be an object.`), Object.entries(s).forEach(([a, c]) => {
                    rt(a, t), r.push({
                        exportName: a,
                        exportValue: c,
                        isFromDefaultExport: l
                    })
                });
                return
            }
        r.push({
            exportName: i,
            exportValue: s,
            isFromDefaultExport: l
        })
    }), r.forEach(({
        exportName: i,
        isFromDefaultExport: s
    }) => {
        o(!(s && pe.includes(i)))
    }), r
}

function ct() {
    return new Proxy({}, {
        get(...e) {
            return B() || P(!1, "`pageContext.pageExports` is outdated. Use `pageContext.exports` instead, see https://vike.dev/exports", {
                onlyOnce: !0,
                showStackTrace: !0
            }), Reflect.get(...e)
        }
    })
}

function ut(e) {
    const t = ".page.",
        n = I(e.split(t), 0, -1).join(t);
    return o(!n.includes("\\")), n
}

function _(e) {
    he(e)
}

function G(e, t) {
    return o(!e.includes("\\")), e.includes("/_error")
}

function ft(e, t) {
    if (t.length > 0) {
        const n = t.find(r => r.pageId === e);
        return o(n), !!n.isErrorPage
    } else return G(e)
}
const dt = [".page", ".page.server", ".page.route", ".page.client", ".css"];

function gt(e) {
    if (he(e), e.endsWith(".css")) return ".css";
    o(de(e), e);
    const n = e.split("/").slice(-1)[0].split("."),
        r = n.slice(-3)[0],
        i = n.slice(-2)[0];
    if (i === "page") return ".page";
    if (o(r === "page", e), i === "server") return ".page.server";
    if (i === "client") return ".page.client";
    if (i === "route") return ".page.route";
    o(!1, e)
}

function ye(e) {
    const t = s => i.pageId === s || i.isDefaultPageFile && (Z(i.filePath) || ht(s, i.filePath)),
        n = gt(e),
        i = {
            filePath: e,
            fileType: n,
            isEnv: s => {
                if (o(n !== ".page.route"), s === "CLIENT_ONLY") return n === ".page.client" || n === ".css";
                if (s === "SERVER_ONLY") return n === ".page.server";
                if (s === "CLIENT_AND_SERVER") return n === ".page";
                o(!1)
            },
            isRelevant: t,
            isDefaultPageFile: z(e),
            isRendererPageFile: n !== ".css" && z(e) && Z(e),
            isErrorPageFile: G(e),
            pageId: ut(e)
        };
    return i
}

function z(e) {
    return _(e), G(e) ? !1 : e.includes("/_default")
}

function Z(e) {
    return _(e), e.includes("/renderer/")
}

function ht(e, t) {
    _(e), _(t), o(!e.endsWith("/")), o(!t.endsWith("/")), o(z(t));
    const n = I(t.split("/"), 0, -1).filter(r => r !== "_default").join("/");
    return e.startsWith(n)
}

function pt(e) {
    o(Array.isArray(e)), e.forEach(t => {
        o(S(t)), o(p(t, "pageId", "string")), o(p(t, "routeFilesystem")), o(p(t, "configValuesSerialized")), o(p(t, "configValuesImported"))
    })
}

function mt(e) {
    o(p(e, "configValuesImported"))
}
const yt = ["$$registrations", "_rerender_only"],
    Et = [".md", ".mdx"];

function wt(e, t, n) {
    const r = Object.keys(e).filter(s => !yt.includes(s)),
        i = r.filter(s => s !== "default" && s !== n);
    if (i.length === 0) {
        if (r.length === 1) return;
        const s = E.cyan("export default"),
            l = E.cyan(`export { ${n} }`);
        r.length === 0 ? h(!1, `${t} doesn't export any value, but it should have a ${l} or ${s}`) : (o(r.length === 2), P(!1, `${t} remove ${l} or ${s}`, {
            onlyOnce: !0
        }))
    } else {
        if (Et.some(s => t.endsWith(s))) return;
        i.forEach(s => {
            P(!1, `${t} should have only one export: move ${E.cyan(`export { ${s} }`)} to its own +${i}.js file`, {
                onlyOnce: !0
            })
        })
    }
}

function N(e) {
    const t = {};
    e.filter(r => r.configName !== "client").forEach(r => {
        if (r.isValueFile) {
            const {
                exportValues: i,
                importPath: s,
                configName: l
            } = r;
            wt(i, s, l), Object.entries(i).forEach(([a, c]) => {
                const u = a !== "default",
                    f = u ? a : r.configName;
                t[f] ? ? (t[f] = []), t[f].push({
                    value: c,
                    importPath: s,
                    exportName: a,
                    isSideExport: u
                })
            })
        } else {
            const {
                configName: i,
                importPath: s,
                exportValue: l,
                exportName: a
            } = r;
            t[i] ? ? (t[i] = []), t[i].push({
                value: l,
                importPath: s,
                exportName: a,
                isSideExport: !1
            })
        }
    });
    const n = {};
    return Object.entries(t).forEach(([r, i]) => {
        const s = i.filter(c => !c.isSideExport),
            l = s.length > 1,
            a = s.length === i.length;
        if (l) o(a), o(!1);
        else {
            const c = s[0] ? ? i[0];
            o(c);
            const {
                value: u,
                importPath: f,
                exportName: d
            } = c;
            n[r] = {
                value: u,
                definedAt: {
                    filePathToShowToUser: f,
                    fileExportPathToShowToUser: [r, "default"].includes(d) ? [] : [d]
                }
            }, St(u, r, f)
        }
    }), n
}

function St(e, t, n) {
    o(!n.includes("+config."))
}
const vt = [{
    is: e => e === void 0,
    match: e => e === "!undefined",
    serialize: () => "!undefined",
    deserialize: () => {}
}, {
    is: e => e === 1 / 0,
    match: e => e === "!Infinity",
    serialize: () => "!Infinity",
    deserialize: () => 1 / 0
}, {
    is: e => e === -1 / 0,
    match: e => e === "!-Infinity",
    serialize: () => "!-Infinity",
    deserialize: () => -1 / 0
}, {
    is: e => typeof e == "number" && isNaN(e),
    match: e => e === "!NaN",
    serialize: () => "!NaN",
    deserialize: () => NaN
}, {
    is: e => e instanceof Date,
    match: e => e.startsWith("!Date:"),
    serialize: e => "!Date:" + e.toISOString(),
    deserialize: e => new Date(e.slice(6))
}, {
    is: e => typeof e == "bigint",
    match: e => e.startsWith("!BigInt:"),
    serialize: e => "!BigInt:" + e.toString(),
    deserialize: e => {
        if (typeof BigInt > "u") throw new Error("Your JavaScript environement does not support BigInt. Consider adding a polyfill.");
        return BigInt(e.slice(8))
    }
}, {
    is: e => e instanceof RegExp,
    match: e => e.startsWith("!RegExp:"),
    serialize: e => "!RegExp:" + e.toString(),
    deserialize: e => {
        e = e.slice(8);
        const t = e.match(/\/(.*)\/(.*)?/),
            n = t[1],
            r = t[2];
        return new RegExp(n, r)
    }
}, {
    is: e => e instanceof Map,
    match: e => e.startsWith("!Map:"),
    serialize: (e, t) => "!Map:" + t(Array.from(e.entries())),
    deserialize: (e, t) => new Map(t(e.slice(5)))
}, {
    is: e => e instanceof Set,
    match: e => e.startsWith("!Set:"),
    serialize: (e, t) => "!Set:" + t(Array.from(e.values())),
    deserialize: (e, t) => new Set(t(e.slice(5)))
}, {
    is: e => typeof e == "string" && e.startsWith("!"),
    match: e => e.startsWith("!"),
    serialize: e => "!" + e,
    deserialize: e => e.slice(1)
}];

function J(e) {
    const t = JSON.parse(e);
    return Ee(t)
}

function Ee(e) {
    return typeof e == "string" ? bt(e) : (typeof e == "object" && e !== null && Object.entries(e).forEach(([t, n]) => {
        e[t] = Ee(n)
    }), e)
}

function bt(e) {
    for (const {
            match: t,
            deserialize: n
        } of vt)
        if (t(e)) return n(e, J);
    return e
}

function we(e) {
    const t = {};
    return Object.entries(e).forEach(([n, r]) => {
        const {
            valueSerialized: i,
            definedAt: s
        } = r;
        o(i), o(!t[n]), t[n] = {
            value: J(i),
            definedAt: s
        }
    }), t
}

function $t(e, t) {
    const n = e.map(i => {
            const s = {}; {
                const {
                    configValuesSerialized: f
                } = i, d = we(f);
                Object.assign(s, d)
            } {
                const {
                    configValuesImported: f
                } = i, d = N(f);
                Object.assign(s, d)
            }
            const {
                pageId: l,
                isErrorPage: a,
                routeFilesystem: c,
                loadConfigValuesAll: u
            } = i;
            return Tt(s), {
                pageId: l,
                isErrorPage: a,
                routeFilesystem: c,
                configValues: s,
                loadConfigValuesAll: u
            }
        }),
        r = {
            configValues: {}
        }; {
        const i = N(t.configValuesImported);
        Object.assign(r.configValues, i)
    }
    return {
        pageConfigs: n,
        pageConfigGlobal: r
    }
}

function Tt(e) {
    const t = "route",
        n = e[t];
    if (!n) return;
    const {
        value: r
    } = n, i = typeof r, s = me("Config", t, n);
    h(i === "string" || W(r), `${s} has an invalid type '${i}': it should be a string or a function instead, see https://vike.dev/route`)
}

function Pt(e) {
    o(p(e, "isGeneratedFile")), o(e.isGeneratedFile !== !1, "vike was re-installed(/re-built). Restart your app."), o(e.isGeneratedFile === !0, `\`isGeneratedFile === ${e.isGeneratedFile}\``), o(p(e, "pageFilesLazy", "object")), o(p(e, "pageFilesEager", "object")), o(p(e, "pageFilesExportNamesLazy", "object")), o(p(e, "pageFilesExportNamesEager", "object")), o(p(e.pageFilesLazy, ".page")), o(p(e.pageFilesLazy, ".page.client") || p(e.pageFilesLazy, ".page.server")), o(p(e, "pageFilesList", "string[]")), o(p(e, "pageConfigsSerialized")), o(p(e, "pageConfigGlobalSerialized"));
    const {
        pageConfigsSerialized: t,
        pageConfigGlobalSerialized: n
    } = e;
    pt(t), mt(n);
    const {
        pageConfigs: r,
        pageConfigGlobal: i
    } = $t(t, n), s = {};
    j(e.pageFilesLazy).forEach(({
        filePath: a,
        pageFile: c,
        globValue: u
    }) => {
        c = s[a] = s[a] ? ? c;
        const f = u;
        ee(f), c.loadFile = async () => {
            "fileExports" in c || (c.fileExports = await f(), nt(c))
        }
    }), j(e.pageFilesExportNamesLazy).forEach(({
        filePath: a,
        pageFile: c,
        globValue: u
    }) => {
        c = s[a] = s[a] ? ? c;
        const f = u;
        ee(f), c.loadExportNames = async () => {
            if (!("exportNames" in c)) {
                const d = await f();
                h("exportNames" in d, "You seem to be using Vite 2 but the latest vike versions only work with Vite 3"), o(p(d, "exportNames", "string[]"), c.filePath), c.exportNames = d.exportNames
            }
        }
    }), j(e.pageFilesEager).forEach(({
        filePath: a,
        pageFile: c,
        globValue: u
    }) => {
        c = s[a] = s[a] ? ? c;
        const f = u;
        o(S(f)), c.fileExports = f
    }), j(e.pageFilesExportNamesEager).forEach(({
        filePath: a,
        pageFile: c,
        globValue: u
    }) => {
        c = s[a] = s[a] ? ? c;
        const f = u;
        o(S(f)), o(p(f, "exportNames", "string[]"), c.filePath), c.exportNames = f.exportNames
    }), e.pageFilesList.forEach(a => {
        s[a] = s[a] ? ? ye(a)
    });
    const l = Object.values(s);
    return l.forEach(({
        filePath: a
    }) => {
        o(!a.includes("\\"))
    }), {
        pageFiles: l,
        pageConfigs: r,
        pageConfigGlobal: i
    }
}

function j(e) {
    const t = [];
    return Object.entries(e).forEach(([n, r]) => {
        o(dt.includes(n)), o(S(r)), Object.entries(r).forEach(([i, s]) => {
            const l = ye(i);
            o(l.fileType === n), t.push({
                filePath: i,
                pageFile: l,
                globValue: s
            })
        })
    }), t
}

function ee(e) {
    o(W(e))
}
const T = k("setPageFiles.ts", {});

function kt(e) {
    const {
        pageFiles: t,
        pageConfigs: n,
        pageConfigGlobal: r
    } = Pt(e);
    T.pageFilesAll = t, T.pageConfigs = n, T.pageConfigGlobal = r
}
async function Rt(e, t) {
    e ? (o(!T.pageFilesGetter), o(t === void 0)) : (o(T.pageFilesGetter), o(typeof t == "boolean"), (!T.pageFilesAll || !t) && await T.pageFilesGetter());
    const {
        pageFilesAll: n,
        pageConfigs: r,
        pageConfigGlobal: i
    } = T;
    o(n && r && i);
    const s = xt(n, r);
    return {
        pageFilesAll: n,
        allPageIds: s,
        pageConfigs: r,
        pageConfigGlobal: i
    }
}

function xt(e, t) {
    const n = e.filter(({
            isDefaultPageFile: s
        }) => !s).map(({
            pageId: s
        }) => s),
        r = ae(n),
        i = t.map(s => s.pageId);
    return [...r, ...i]
}

function _t(e, t) {
    return jt(e, t, !0)
}

function jt(e, t, n) {
    const r = n ? "CLIENT_ONLY" : "SERVER_ONLY",
        i = e.filter(g => g.isRelevant(t) && g.fileType !== ".page.route").sort(It(n, t)),
        s = g => {
            const m = i.filter(v => v.pageId === t && v.isEnv(g ? "CLIENT_AND_SERVER" : r));
            h(m.length <= 1, `Merge the following files into a single file: ${m.map(v=>v.filePath).join(" ")}`);
            const $ = m[0];
            return o($ === void 0 || !$.isDefaultPageFile), $
        },
        l = s(!1),
        a = s(!0),
        c = g => i.filter(m => m.isRendererPageFile && m.isEnv(g ? "CLIENT_AND_SERVER" : r))[0],
        u = c(!1),
        f = c(!0),
        d = i.filter(g => g.isDefaultPageFile && !g.isRendererPageFile && (g.isEnv(r) || g.isEnv("CLIENT_AND_SERVER")));
    return [l, a, ...d, u, f].filter(et)
}

function It(e, t) {
    const n = e ? "CLIENT_ONLY" : "SERVER_ONLY",
        r = -1,
        i = 1,
        s = 0;
    return (l, a) => {
        if (!l.isDefaultPageFile && a.isDefaultPageFile) return r;
        if (!a.isDefaultPageFile && l.isDefaultPageFile) return i; {
            const c = l.isRendererPageFile,
                u = a.isRendererPageFile;
            if (!c && u) return r;
            if (!u && c) return i;
            o(c === u)
        } {
            const c = te(t, l.filePath),
                u = te(t, a.filePath);
            if (c < u) return r;
            if (u < c) return i;
            o(c === u)
        } {
            if (l.isEnv(n) && a.isEnv("CLIENT_AND_SERVER")) return r;
            if (a.isEnv(n) && l.isEnv("CLIENT_AND_SERVER")) return i
        }
        return s
    }
}

function te(e, t) {
    _(e), _(t);
    let n = 0;
    for (; n < e.length && n < t.length && e[n] === t[n]; n++);
    const r = e.slice(n),
        i = t.slice(n),
        s = r.split("/").length,
        l = i.split("/").length;
    return s + l
}
const Y = {},
    Ot = {},
    Ct = {},
    Ft = {},
    Lt = [],
    Se = {},
    Wt = !0,
    At = [{
        pageId: "/pages/catch-all",
        isErrorPage: void 0,
        routeFilesystem: {
            routeString: "/catch-all",
            definedBy: "/pages/catch-all/"
        },
        loadConfigValuesAll: () => be(() =>
            import ("./pages_catch-all.K13KjGu-.js").then(e => e.jO), __vite__mapDeps([0, 1, 2])),
        configValuesSerialized: {
            isClientSideRenderable: {
                definedAt: {
                    isComputed: !0
                },
                valueSerialized: "true"
            }
        },
        configValuesImported: []
    }],
    Vt = {
        configValuesImported: []
    },
    zt = Object.assign({}),
    Nt = { ...zt
    };
Y[".page"] = Nt;
const Dt = Object.assign({}),
    Ht = { ...Dt
    };
Y[".page.client"] = Ht;
const Ut = Object.assign({}),
    Bt = { ...Ut
    };
Se[".page.server"] = Bt;
const Gt = Object.freeze(Object.defineProperty({
    __proto__: null,
    isGeneratedFile: Wt,
    neverLoaded: Se,
    pageConfigGlobalSerialized: Vt,
    pageConfigsSerialized: At,
    pageFilesEager: Ot,
    pageFilesExportNamesEager: Ft,
    pageFilesExportNamesLazy: Ct,
    pageFilesLazy: Y,
    pageFilesList: Lt
}, Symbol.toStringTag, {
    value: "Module"
}));
kt(Gt);

function Jt() {
    o(B())
}

function Yt() {
    Jt()
}

function ne(e) {
    const t = e / 1e3;
    if (t < 120) {
        const n = re(t);
        return `${n} second${ie(n)}`
    } {
        const n = t / 60,
            r = re(n);
        return `${r} minute${ie(r)}`
    }
}

function re(e) {
    let t = e.toFixed(1);
    return t.endsWith(".0") && (t = t.slice(0, -2)), t
}

function ie(e) {
    return e === "1" ? "" : "s"
}
const Mt = k("utils/executeHook.ts", {
    userHookErrors: new WeakMap
});

function Xt(e, t) {
    const {
        hookName: n,
        hookFilePath: r,
        hookTimeout: {
            error: i,
            warning: s
        }
    } = t;
    let l, a;
    const c = new Promise((y, g) => {
            l = m => {
                u(), y(m)
            }, a = m => {
                u(), g(m)
            }
        }),
        u = () => {
            f && clearTimeout(f), d && clearTimeout(d)
        },
        f = se(s) && setTimeout(() => {
            P(!1, `The ${n}() hook defined by ${r} is slow: it's taking more than ${ne(s)} (https://vike.dev/hooksTimeout)`, {
                onlyOnce: !1
            })
        }, s),
        d = se(i) && setTimeout(() => {
            const y = Fe(`The ${n}() hook defined by ${r} timed out: it didn't finish after ${ne(i)} (https://vike.dev/hooksTimeout)`);
            a(y)
        }, i);
    return (async () => {
        try {
            const y = await e();
            l(y)
        } catch (y) {
            S(y) && Mt.userHookErrors.set(y, {
                hookName: n,
                hookFilePath: r
            }), a(y)
        }
    })(), c
}

function se(e) {
    return !!e && e !== 1 / 0
}

function ve(e) {
    const t = window.location.href,
        {
            searchOriginal: n,
            hashOriginal: r,
            pathname: i
        } = He(t, "/");
    let s;
    return e != null && e.withoutHash ? s = `${i}${n||""}` : s = `${i}${n||""}${r||""}`, o(s.startsWith("/")), s
}
Yt();

function qt() {
    const e = "vike_pageContext",
        t = document.getElementById(e);
    h(t, `Couldn't find #${e} (which Vike automatically injects in the HTML): make sure it exists (i.e. don't remove it and make sure your HTML isn't malformed)`);
    const n = t.textContent;
    o(n);
    const r = J(n);
    return o(p(r, "_pageId", "string")), r
}

function Kt(e, t) {
    const n = e.filter(i => i.pageId === t);
    return o(n.length <= 1), n[0] ? ? null
}
async function Qt(e, t) {
    if ("isAllLoaded" in e && !t) return e;
    const n = await e.loadConfigValuesAll(); {
        const {
            configValuesImported: r
        } = n, i = N(r);
        Object.assign(e.configValues, i)
    } {
        const {
            configValuesSerialized: r
        } = n, i = we(r);
        Object.assign(e.configValues, i)
    }
    return x(e, {
        isAllLoaded: !0
    }), e
}
const Zt = "__whileFetchingAssets";
async function en(e, t, n) {
    const r = _t(t, e),
        i = Kt(n, e);
    let s;
    const l = !1;
    try {
        s = (await Promise.all([i && Qt(i, l), ...r.map(m => {
            var $;
            return ($ = m.loadFile) == null ? void 0 : $.call(m)
        })]))[0]
    } catch (g) {
        throw tn(g) && Object.assign(g, {
            [Zt]: !0
        }), g
    }
    const {
        config: a,
        configEntries: c,
        exports: u,
        exportsAll: f,
        pageExports: d
    } = at(r, s);
    return {
        config: a,
        configEntries: c,
        exports: u,
        exportsAll: f,
        pageExports: d,
        _pageFilesLoaded: r
    }
}

function tn(e) {
    return e instanceof Error ? ["Failed to fetch dynamically imported module", "error loading dynamically imported module", "Importing a module script failed", "error resolving module specifier", "failed to resolve module"].some(n => e.message.toLowerCase().includes(n.toLowerCase())) : !1
}
const oe = ve({
    withoutHash: !0
});
async function nn() {
    const e = qt();
    return x(e, {
        isHydration: !0,
        isBackwardNavigation: null,
        _hasPageContextFromServer: !0,
        _hasPageContextFromClient: !1
    }), x(e, await sn(e._pageId)), rn(), e
}

function rn() {
    const e = ve({
        withoutHash: !0
    });
    h(oe === e, `The URL was manipulated before the hydration finished ('${oe}' to '${e}'). Ensure the hydration has finished before manipulating the URL. Consider using the onHydrationEnd() hook.`)
}
async function sn(e) {
    const t = {},
        {
            pageFilesAll: n,
            pageConfigs: r
        } = await Rt(!0);
    return x(t, {
        _pageFilesAll: n,
        _pageConfigs: r
    }), x(t, await en(e, t._pageFilesAll, t._pageConfigs)), n.filter(i => i.fileType !== ".page.server").forEach(i => {
        var s;
        P(!((s = i.fileExports) != null && s.onBeforeRender), `export { onBeforeRender } of ${i.filePath} is loaded in the browser but never executed (because you are using Server-side Routing). In order to reduce the size of you browser-side JavaScript, define onBeforeRender() in a .page.server.js file instead, see https://vike.dev/onBeforeRender-isomorphic#server-routing`, {
            onlyOnce: !0
        })
    }), t
}
const on = k("getHook.ts", {
    isPrerendering: !1
});

function D(e, t) {
    if (!(t in e.exports)) return null;
    const {
        hooksTimeout: n
    } = e.config, r = cn(n, t), i = e.exports[t], s = e.exportsAll[t][0];
    if (o(s.exportValue === i), i === null) return null;
    const l = s.filePath;
    return o(l), o(!l.endsWith(" ")), ln(i, {
        hookName: t,
        hookFilePath: l
    }), {
        hookFn: i,
        hookName: t,
        hookFilePath: l,
        hookTimeout: r
    }
}

function an(e, t) {
    D(e, t)
}

function ln(e, {
    hookName: t,
    hookFilePath: n
}) {
    o(t && n), o(!t.endsWith(")")), h(W(e), `Hook ${t}() defined by ${n} should be a function`)
}

function cn(e, t) {
    const n = un(e);
    if (n === !1) return {
        error: !1,
        warning: !1
    };
    const r = n[t],
        i = fn(t);
    return (r == null ? void 0 : r.error) !== void 0 && (i.error = r.error), (r == null ? void 0 : r.warning) !== void 0 && (i.warning = r.warning), i
}

function un(e) {
    if (e === void 0) return {};
    if (e === !1) return !1;
    h(S(e), `Setting ${E.cyan("hooksTimeout")} should be ${E.cyan("false")} or an object`);
    const t = {};
    return Object.entries(e).forEach(([n, r]) => {
        if (r === !1) {
            t[n] = {
                error: !1,
                warning: !1
            };
            return
        }
        h(S(r), `Setting ${E.cyan(`hooksTimeout.${n}`)} should be ${E.cyan("false")} or an object`);
        const [i, s] = ["error", "warning"].map(l => {
            const a = r[l];
            if (a === void 0 || a === !1) return a;
            const c = `Setting ${E.cyan(`hooksTimeout.${n}.${l}`)} should be`;
            return h(typeof a == "number", `${c} ${E.cyan("false")} or a number`), h(a > 0, `${c} a positive number`), a
        });
        t[n] = {
            error: i,
            warning: s
        }
    }), t
}

function fn(e) {
    return e === "onBeforeRoute" ? {
        error: 5 * 1e3,
        warning: 1 * 1e3
    } : on.isPrerendering ? {
        error: 2 * 60 * 1e3,
        warning: 30 * 1e3
    } : (o(!e.toLowerCase().includes("prerender")), {
        error: 30 * 1e3,
        warning: 4 * 1e3
    })
}

function dn(e) {
    const t = Object.entries(e);
    for (const n in e) delete e[n];
    t.sort(([n], [r]) => Ze(n, r)).forEach(([n, r]) => {
        e[n] = r
    })
}

function gn(e) {
    hn(e), pn(e)
}

function hn(e) {
    ft(e._pageId, e._pageConfigs) && o(p(e, "is404", "boolean"))
}

function pn(e) {
    if (e.is404 === void 0 || e.is404 === null) return;
    const t = e.pageProps || {};
    if (!S(t)) {
        P(!1, "pageContext.pageProps should be an object", {
            showStackTrace: !0,
            onlyOnce: !0
        });
        return
    }
    t.is404 = t.is404 || e.is404, e.pageProps = t
}
const mn = "not-serializable",
    O = k("getPageContextProxyForUser.ts", {});

function yn(e) {
    return o([!0, !1].includes(e._hasPageContextFromServer)), o([!0, !1].includes(e._hasPageContextFromClient)), new Proxy(e, {
        get(t, n) {
            const r = e[n],
                i = JSON.stringify(n);
            return h(r !== mn, `pageContext[${i}] couldn't be serialized and, therefore, is missing on the client-side. Check the server logs for more information.`), En(e, n), r
        }
    })
}

function En(e, t) {
    if (O.prev === t || O.prev === "__v_raw" || (vn(t), t in e) || Sn(t)) return;
    const n = JSON.stringify(t);
    e._hasPageContextFromServer && !e._hasPageContextFromClient && h(!1, `pageContext[${n}] isn't available on the client-side because ${n} is missing in passToClient, see https://vike.dev/passToClient`)
}
const wn = ["then", "toJSON"];

function Sn(e) {
    return !!(wn.includes(e) || typeof e == "symbol" || typeof e != "string" || e.startsWith("__v_"))
}

function vn(e) {
    O.prev = e, window.setTimeout(() => {
        O.prev = void 0
    }, 0)
}

function bn(e, t) {
    if (t) {
        const i = e;
        o([!0, !1].includes(i.isHydration)), o([!0, !1, null].includes(i.isBackwardNavigation))
    } else {
        const i = e;
        o(i.isHydration === !0), o(i.isBackwardNavigation === null)
    }
    o("config" in e), o("configEntries" in e), o("exports" in e), o("exportsAll" in e), o("pageExports" in e), o(S(e.pageExports));
    const n = e.exports.Page;
    x(e, {
        Page: n
    }), $n(e), dn(e);
    const r = yn(e);
    return gn(e), r
}

function $n(e) {
    Object.entries(e).forEach(([t, n]) => {
        delete e[t], e[t] = n
    })
}
async function Tn(e, t) {
    const n = bn(e, t);
    let r = null,
        i;
    r = D(e, "render"), i = "render"; {
        const a = D(e, "onRenderClient");
        a && (r = a, i = "onRenderClient")
    }
    if (!r) {
        const a = Pn(e);
        if (o(a), e._pageConfigs.length > 0) h(!1, `No onRenderClient() hook defined for URL '${a}', but it's needed, see https://vike.dev/onRenderClient`);
        else {
            const c = e._pageFilesLoaded.filter(f => f.fileType === ".page.client");
            let u;
            c.length === 0 ? u = "No file `*.page.client.*` found for URL " + a : u = "One of the following files should export a render() hook: " + c.map(f => f.filePath).join(" "), h(!1, u)
        }
    }
    o(r);
    const s = r.hookFn;
    o(i);
    const l = await Xt(() => s(n), r);
    h(l === void 0, `The ${i}() hook defined by ${r.hookFilePath} isn't allowed to return a value`)
}

function Pn(e) {
    let t;
    try {
        t = e.urlPathname ? ? e.urlOriginal
    } catch {}
    return t = t ? ? window.location.href, t
}
Le();
const kn = !0;
xe(kn);
Rn();
async function Rn() {
    var t, n;
    const e = await nn();
    await Tn(e, !1), an(e, "onHydrationEnd"), await ((n = (t = e.exports).onHydrationEnd) == null ? void 0 : n.call(t, e))
}

function __vite__mapDeps(indexes) {
    if (!__vite__mapDeps.viteFileDeps) {
        __vite__mapDeps.viteFileDeps = ["assets/entries/pages_catch-all.K13KjGu-.js", "assets/chunks/preload-helper-Jimfoxkq.js", "assets/static/catch-all.Yj8n6pm8.css"]
    }
    return indexes.map((i) => __vite__mapDeps.viteFileDeps[i])
}